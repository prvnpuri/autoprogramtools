<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ExciseTaxInvoice Controller
 *
 * @property \App\Model\Table\ExciseTaxInvoiceTable $ExciseTaxInvoice
 *
 * @method \App\Model\Entity\ExciseTaxInvoice[] paginate($object = null, array $settings = [])
 */
class ExciseTaxInvoiceController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Invoices', 'BuyerPurchaseOrders', 'OrderAccs', 'OwnerCompanies', 'Consignees', 'Uoms']
        ];
        $exciseTaxInvoice = $this->paginate($this->ExciseTaxInvoice);

        $this->set(compact('exciseTaxInvoice'));
        $this->set('_serialize', ['exciseTaxInvoice']);
    }

    /**
     * View method
     *
     * @param string|null $id Excise Tax Invoice id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $exciseTaxInvoice = $this->ExciseTaxInvoice->get($id, [
            'contain' => ['Orders', 'Invoices', 'BuyerPurchaseOrders', 'OrderAccs', 'OwnerCompanies', 'Consignees', 'Uoms']
        ]);

        $this->set('exciseTaxInvoice', $exciseTaxInvoice);
        $this->set('_serialize', ['exciseTaxInvoice']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $exciseTaxInvoice = $this->ExciseTaxInvoice->newEntity();
        if ($this->request->is('post')) {
            $exciseTaxInvoice = $this->ExciseTaxInvoice->patchEntity($exciseTaxInvoice, $this->request->data);
            if ($this->ExciseTaxInvoice->save($exciseTaxInvoice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Excise Tax Invoice'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Excise Tax Invoice'));
            }
        }
        $orders = $this->ExciseTaxInvoice->Orders->find('list', ['limit' => 200]);
        $invoices = $this->ExciseTaxInvoice->Invoices->find('list', ['limit' => 200]);
        $buyerPurchaseOrders = $this->ExciseTaxInvoice->BuyerPurchaseOrders->find('list', ['limit' => 200]);
        $orderAccs = $this->ExciseTaxInvoice->OrderAccs->find('list', ['limit' => 200]);
        $ownerCompanies = $this->ExciseTaxInvoice->OwnerCompanies->find('list', ['limit' => 200]);
        $consignees = $this->ExciseTaxInvoice->Consignees->find('list', ['limit' => 200]);
        $uoms = $this->ExciseTaxInvoice->Uoms->find('list', ['limit' => 200]);
        $this->set(compact('exciseTaxInvoice', 'orders', 'invoices', 'buyerPurchaseOrders', 'orderAccs', 'ownerCompanies', 'consignees', 'uoms'));
        $this->set('_serialize', ['exciseTaxInvoice']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Excise Tax Invoice id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $exciseTaxInvoice = $this->ExciseTaxInvoice->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $exciseTaxInvoice = $this->ExciseTaxInvoice->patchEntity($exciseTaxInvoice, $this->request->data);
            if ($this->ExciseTaxInvoice->save($exciseTaxInvoice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Excise Tax Invoice'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Excise Tax Invoice'));
            }
        }
        $orders = $this->ExciseTaxInvoice->Orders->find('list', ['limit' => 200]);
        $invoices = $this->ExciseTaxInvoice->Invoices->find('list', ['limit' => 200]);
        $buyerPurchaseOrders = $this->ExciseTaxInvoice->BuyerPurchaseOrders->find('list', ['limit' => 200]);
        $orderAccs = $this->ExciseTaxInvoice->OrderAccs->find('list', ['limit' => 200]);
        $ownerCompanies = $this->ExciseTaxInvoice->OwnerCompanies->find('list', ['limit' => 200]);
        $consignees = $this->ExciseTaxInvoice->Consignees->find('list', ['limit' => 200]);
        $uoms = $this->ExciseTaxInvoice->Uoms->find('list', ['limit' => 200]);
        $this->set(compact('exciseTaxInvoice', 'orders', 'invoices', 'buyerPurchaseOrders', 'orderAccs', 'ownerCompanies', 'consignees', 'uoms'));
        $this->set('_serialize', ['exciseTaxInvoice']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Excise Tax Invoice id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $exciseTaxInvoice = $this->ExciseTaxInvoice->get($id);
        if ($this->ExciseTaxInvoice->delete($exciseTaxInvoice)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Excise Tax Invoice'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Excise Tax Invoice'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
