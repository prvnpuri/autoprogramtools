<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * RunningNumbers Controller
 *
 * @property \App\Model\Table\RunningNumbersTable $RunningNumbers
 *
 * @method \App\Model\Entity\RunningNumber[] paginate($object = null, array $settings = [])
 */
class RunningNumbersController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $runningNumbers = $this->paginate($this->RunningNumbers);

        $this->set(compact('runningNumbers'));
        $this->set('_serialize', ['runningNumbers']);
    }

    /**
     * View method
     *
     * @param string|null $id Running Number id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $runningNumber = $this->RunningNumbers->get($id, [
            'contain' => []
        ]);

        $this->set('runningNumber', $runningNumber);
        $this->set('_serialize', ['runningNumber']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $runningNumber = $this->RunningNumbers->newEntity();
        if ($this->request->is('post')) {
            $runningNumber = $this->RunningNumbers->patchEntity($runningNumber, $this->request->data);
            if ($this->RunningNumbers->save($runningNumber)) {
                $this->Flash->success(__('The {0} has been saved.', 'Running Number'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Running Number'));
            }
        }
        $this->set(compact('runningNumber'));
        $this->set('_serialize', ['runningNumber']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Running Number id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $runningNumber = $this->RunningNumbers->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $runningNumber = $this->RunningNumbers->patchEntity($runningNumber, $this->request->data);
            if ($this->RunningNumbers->save($runningNumber)) {
                $this->Flash->success(__('The {0} has been saved.', 'Running Number'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Running Number'));
            }
        }
        $this->set(compact('runningNumber'));
        $this->set('_serialize', ['runningNumber']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Running Number id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $runningNumber = $this->RunningNumbers->get($id);
        if ($this->RunningNumbers->delete($runningNumber)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Running Number'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Running Number'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
