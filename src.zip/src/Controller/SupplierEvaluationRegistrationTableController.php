<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * SupplierEvaluationRegistrationTable Controller
 *
 * @property \App\Model\Table\SupplierEvaluationRegistrationTableTable $SupplierEvaluationRegistrationTable
 *
 * @method \App\Model\Entity\SupplierEvaluationRegistrationTable[] paginate($object = null, array $settings = [])
 */
class SupplierEvaluationRegistrationTableController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['CompanyMasters', 'OwnerCompanies']
        ];
        $supplierEvaluationRegistrationTable = $this->paginate($this->SupplierEvaluationRegistrationTable);

        $this->set(compact('supplierEvaluationRegistrationTable'));
        $this->set('_serialize', ['supplierEvaluationRegistrationTable']);
    }

    /**
     * View method
     *
     * @param string|null $id Supplier Evaluation Registration Table id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $supplierEvaluationRegistrationTable = $this->SupplierEvaluationRegistrationTable->get($id, [
            'contain' => ['CompanyMasters', 'OwnerCompanies']
        ]);

        $this->set('supplierEvaluationRegistrationTable', $supplierEvaluationRegistrationTable);
        $this->set('_serialize', ['supplierEvaluationRegistrationTable']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $supplierEvaluationRegistrationTable = $this->SupplierEvaluationRegistrationTable->newEntity();
        if ($this->request->is('post')) {
            $supplierEvaluationRegistrationTable = $this->SupplierEvaluationRegistrationTable->patchEntity($supplierEvaluationRegistrationTable, $this->request->data);
            if ($this->SupplierEvaluationRegistrationTable->save($supplierEvaluationRegistrationTable)) {
                $this->Flash->success(__('The {0} has been saved.', 'Supplier Evaluation Registration Table'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Evaluation Registration Table'));
            }
        }
        $companyMasters = $this->SupplierEvaluationRegistrationTable->CompanyMasters->find('list', ['limit' => 200]);
        $ownerCompanies = $this->SupplierEvaluationRegistrationTable->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('supplierEvaluationRegistrationTable', 'companyMasters', 'ownerCompanies'));
        $this->set('_serialize', ['supplierEvaluationRegistrationTable']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Supplier Evaluation Registration Table id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $supplierEvaluationRegistrationTable = $this->SupplierEvaluationRegistrationTable->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $supplierEvaluationRegistrationTable = $this->SupplierEvaluationRegistrationTable->patchEntity($supplierEvaluationRegistrationTable, $this->request->data);
            if ($this->SupplierEvaluationRegistrationTable->save($supplierEvaluationRegistrationTable)) {
                $this->Flash->success(__('The {0} has been saved.', 'Supplier Evaluation Registration Table'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Evaluation Registration Table'));
            }
        }
        $companyMasters = $this->SupplierEvaluationRegistrationTable->CompanyMasters->find('list', ['limit' => 200]);
        $ownerCompanies = $this->SupplierEvaluationRegistrationTable->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('supplierEvaluationRegistrationTable', 'companyMasters', 'ownerCompanies'));
        $this->set('_serialize', ['supplierEvaluationRegistrationTable']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Supplier Evaluation Registration Table id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $supplierEvaluationRegistrationTable = $this->SupplierEvaluationRegistrationTable->get($id);
        if ($this->SupplierEvaluationRegistrationTable->delete($supplierEvaluationRegistrationTable)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Supplier Evaluation Registration Table'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Supplier Evaluation Registration Table'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
