<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanyShippingCondition Controller
 *
 * @property \App\Model\Table\CompanyShippingConditionTable $CompanyShippingCondition
 *
 * @method \App\Model\Entity\CompanyShippingCondition[] paginate($object = null, array $settings = [])
 */
class CompanyShippingConditionController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */

     public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="CompanyShippingCondition.shipping_conditions like '%$query%'";
    	}
    	$this->paginate = [
                'contain' => ['CompanyMaster'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["company_master.Company_name","company_shipping_condition.shipping_conditions"]
    	];
    	$companyShippingCondition= $this->paginate($this->CompanyShippingCondition);
    	
    	
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('companyShippingCondition'));
        $this->set( '_serialize', ['companyShippingCondition','paging']);
        
    }
     /*
    public function index()
    {
        $this->paginate = [
            'contain' => ['CompanyMaster']
        ];
        $companyShippingCondition = $this->paginate($this->CompanyShippingCondition);

        $this->set(compact('companyShippingCondition'));
        $this->set('_serialize', ['companyShippingCondition']);
    }*/

    /**
     * View method
     *
     * @param string|null $id Company Shipping Condition id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companyShippingCondition = $this->CompanyShippingCondition->get($id, [
            'contain' => ['CompanyMaster']
        ]);

        $this->set('companyShippingCondition', $companyShippingCondition);
        $this->set('_serialize', ['companyShippingCondition']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companyShippingCondition = $this->CompanyShippingCondition->newEntity();
        if ($this->request->is('post')) {
            $companyShippingCondition = $this->CompanyShippingCondition->patchEntity($companyShippingCondition, $this->request->data);
            if ($this->CompanyShippingCondition->save($companyShippingCondition)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Shipping Condition'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Shipping Condition'));
            }
        }
        $companies = $this->CompanyShippingCondition->CompanyMaster->find('list', ['limit' => 200]);
        $this->set(compact('companyShippingCondition','companyMaster'));
        $this->set('_serialize', ['companyShippingCondition']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Shipping Condition id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companyShippingCondition = $this->CompanyShippingCondition->get($id, [
            'contain' => ['CompanyMaster']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companyShippingCondition = $this->CompanyShippingCondition->patchEntity($companyShippingCondition, $this->request->data);
            if ($this->CompanyShippingCondition->save($companyShippingCondition)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Shipping Condition'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Shipping Condition'));
            }
        }
        $companies = $this->CompanyShippingCondition->CompanyMaster ->find('list', ['limit' => 200]);
        $this->set(compact('companyShippingCondition','CompanyMaster'));
        $this->set('_serialize', ['companyShippingCondition']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Shipping Condition id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyShippingCondition = $this->CompanyShippingCondition->get($id);
        if ($this->CompanyShippingCondition->delete($companyShippingCondition)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Shipping Condition'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Shipping Condition'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
