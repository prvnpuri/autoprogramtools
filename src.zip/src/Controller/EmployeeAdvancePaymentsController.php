<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * EmployeeAdvancePayments Controller
 *
 * @property \App\Model\Table\EmployeeAdvancePaymentsTable $EmployeeAdvancePayments
 *
 * @method \App\Model\Entity\EmployeeAdvancePayment[] paginate($object = null, array $settings = [])
 */
class EmployeeAdvancePaymentsController extends AppController
{
    
    
    public function initialize(){
        parent::initialize();
        $this->loadModel('EmployeeAdvancePayments');
    }
    

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['EmployeeDetails']
        ];
        $employeeAdvancePayment = $this->paginate($this->EmployeeAdvancePayments);

        $this->set(compact('employeeAdvancePayment'));
        $this->set('_serialize', ['employeeAdvancePayment']);
    }

    /**
     * View method
     *
     * @param string|null $id Employee Advance Payment id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $employeeAdvancePayment = $this->EmployeeAdvancePayments->get($id, [
            'contain' => ['EmployeeDetails', 'EmployeeMonthlySalaries']
        ]);

        $this->set('employeeAdvancePayment', $employeeAdvancePayment);
        $this->set('_serialize', ['employeeAdvancePayment']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $employeeAdvancePayment = $this->EmployeeAdvancePayments->newEntity();
        if ($this->request->is('post')) {
            $employeeAdvancePayment = $this->EmployeeAdvancePayments->patchEntity($employeeAdvancePayment, $this->request->data);
            if ($this->EmployeeAdvancePayments->save($employeeAdvancePayment)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Advance Payment'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Advance Payment'));
            }
        }
        $employeeDetails = $this->EmployeeAdvancePayments->EmployeeDetails->find('list', ['limit' => 200]);
        $this->set(compact('employeeAdvancePayment', 'employeeDetails'));
        $this->set('_serialize', ['employeeAdvancePayment']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Employee Advance Payment id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $employeeAdvancePayment = $this->EmployeeAdvancePayments->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $employeeAdvancePayment = $this->EmployeeAdvancePayments->patchEntity($employeeAdvancePayment, $this->request->data);
            if ($this->EmployeeAdvancePayments->save($employeeAdvancePayment)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Advance Payment'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Advance Payment'));
            }
        }
        $employeeDetails = $this->EmployeeAdvancePayments->EmployeeDetails->find('list', ['limit' => 200]);
        $this->set(compact('employeeAdvancePayment', 'employeeDetails'));
        $this->set('_serialize', ['employeeAdvancePayment']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Employee Advance Payment id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $employeeAdvancePayment = $this->EmployeeAdvancePayments->get($id);
        if ($this->EmployeeAdvancePayments->delete($employeeAdvancePayment)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Employee Advance Payment'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Employee Advance Payment'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
