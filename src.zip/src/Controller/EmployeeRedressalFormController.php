<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * EmployeeRedressalForm Controller
 *
 * @property \App\Model\Table\EmployeeRedressalFormTable $EmployeeRedressalForm
 *
 * @method \App\Model\Entity\EmployeeRedressalForm[] paginate($object = null, array $settings = [])
 */
class EmployeeRedressalFormController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Emps']
        ];
        $employeeRedressalForm = $this->paginate($this->EmployeeRedressalForm);

        $this->set(compact('employeeRedressalForm'));
        $this->set('_serialize', ['employeeRedressalForm']);
    }

    /**
     * View method
     *
     * @param string|null $id Employee Redressal Form id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $employeeRedressalForm = $this->EmployeeRedressalForm->get($id, [
            'contain' => ['Emps']
        ]);

        $this->set('employeeRedressalForm', $employeeRedressalForm);
        $this->set('_serialize', ['employeeRedressalForm']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $employeeRedressalForm = $this->EmployeeRedressalForm->newEntity();
        if ($this->request->is('post')) {
            $employeeRedressalForm = $this->EmployeeRedressalForm->patchEntity($employeeRedressalForm, $this->request->data);
            if ($this->EmployeeRedressalForm->save($employeeRedressalForm)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Redressal Form'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Redressal Form'));
            }
        }
        $emps = $this->EmployeeRedressalForm->Emps->find('list', ['limit' => 200]);
        $this->set(compact('employeeRedressalForm', 'emps'));
        $this->set('_serialize', ['employeeRedressalForm']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Employee Redressal Form id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $employeeRedressalForm = $this->EmployeeRedressalForm->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $employeeRedressalForm = $this->EmployeeRedressalForm->patchEntity($employeeRedressalForm, $this->request->data);
            if ($this->EmployeeRedressalForm->save($employeeRedressalForm)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Redressal Form'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Redressal Form'));
            }
        }
        $emps = $this->EmployeeRedressalForm->Emps->find('list', ['limit' => 200]);
        $this->set(compact('employeeRedressalForm', 'emps'));
        $this->set('_serialize', ['employeeRedressalForm']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Employee Redressal Form id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $employeeRedressalForm = $this->EmployeeRedressalForm->get($id);
        if ($this->EmployeeRedressalForm->delete($employeeRedressalForm)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Employee Redressal Form'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Employee Redressal Form'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
