<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TaxInvoice Controller
 *
 * @property \App\Model\Table\TaxInvoiceTable $TaxInvoice
 *
 * @method \App\Model\Entity\TaxInvoice[] paginate($object = null, array $settings = [])
 */
class TaxInvoiceController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => []
        ];
        $taxInvoice = $this->paginate($this->TaxInvoice);

        $this->set(compact('taxInvoice'));
        $this->set('_serialize', ['taxInvoice']);
    }

    /**
     * View method
     *
     * @param string|null $id Tax Invoice id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $taxInvoice = $this->TaxInvoice->get($id, [
            'contain' => ['Order', 'Invoice', 'BuyerPurchaseOrder', 'OwnerCompanies', 'Supplier', 'Manufact', 'Consignee', 'Uom']
        ]);

        $this->set('taxInvoice', $taxInvoice);
        $this->set('_serialize', ['taxInvoice']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $taxInvoice = $this->TaxInvoice->newEntity();
        if ($this->request->is('post')) {
            $taxInvoice = $this->TaxInvoice->patchEntity($taxInvoice, $this->request->data);
            if ($this->TaxInvoice->save($taxInvoice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Tax Invoice'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Tax Invoice'));
            }
        }
        $order = $this->TaxInvoice->Order->find('list', ['limit' => 200]);
        $invoice = $this->TaxInvoice->Invoice->find('list', ['limit' => 200]);
        $buyerPurchaseOrder = $this->TaxInvoice->BuyerPurchaseOrder->find('list', ['limit' => 200]);
        $ownerCompanies = $this->TaxInvoice->OwnerCompanies->find('list', ['limit' => 200]);
        $supplier = $this->TaxInvoice->Supplier->find('list', ['limit' => 200]);
        $manufact = $this->TaxInvoice->Manufact->find('list', ['limit' => 200]);
        $consignee = $this->TaxInvoice->Consignee->find('list', ['limit' => 200]);
        $uom = $this->TaxInvoice->Uom->find('list', ['limit' => 200]);
        $this->set(compact('taxInvoice', 'order', 'invoice', 'buyerPurchaseOrder', 'ownerCompanies', 'supplier', 'manufact', 'consignee', 'uom'));
        $this->set('_serialize', ['taxInvoice']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Tax Invoice id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $taxInvoice = $this->TaxInvoice->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $taxInvoice = $this->TaxInvoice->patchEntity($taxInvoice, $this->request->data);
            if ($this->TaxInvoice->save($taxInvoice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Tax Invoice'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Tax Invoice'));
            }
        }
        $order = $this->TaxInvoice->Order->find('list', ['limit' => 200]);
        $invoice = $this->TaxInvoice->Invoice->find('list', ['limit' => 200]);
        $buyerPurchaseOrder = $this->TaxInvoice->BuyerPurchaseOrder->find('list', ['limit' => 200]);
        $ownerCompanies = $this->TaxInvoice->OwnerCompanies->find('list', ['limit' => 200]);
        $supplier = $this->TaxInvoice->Supplier->find('list', ['limit' => 200]);
        $manufact = $this->TaxInvoice->Manufact->find('list', ['limit' => 200]);
        $consignee = $this->TaxInvoice->Consignee->find('list', ['limit' => 200]);
        $uom = $this->TaxInvoice->Uom->find('list', ['limit' => 200]);
        $this->set(compact('taxInvoice', 'order', 'invoice', 'buyerPurchaseOrder', 'ownerCompanies', 'supplier', 'manufact', 'consignee', 'uom'));
        $this->set('_serialize', ['taxInvoice']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Tax Invoice id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $taxInvoice = $this->TaxInvoice->get($id);
        if ($this->TaxInvoice->delete($taxInvoice)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Tax Invoice'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Tax Invoice'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
