<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * UploadDocumentList Controller
 *
 * @property \App\Model\Table\UploadDocumentListTable $UploadDocumentList
 *
 * @method \App\Model\Entity\UploadDocumentList[] paginate($object = null, array $settings = [])
 */
class UploadDocumentListController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $uploadDocumentList = $this->paginate($this->UploadDocumentList);

        $this->set(compact('uploadDocumentList'));
        $this->set('_serialize', ['uploadDocumentList']);
    }

    /**
     * View method
     *
     * @param string|null $id Upload Document List id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $uploadDocumentList = $this->UploadDocumentList->get($id, [
            'contain' => []
        ]);

        $this->set('uploadDocumentList', $uploadDocumentList);
        $this->set('_serialize', ['uploadDocumentList']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $uploadDocumentList = $this->UploadDocumentList->newEntity();
        if ($this->request->is('post')) {
            $uploadDocumentList = $this->UploadDocumentList->patchEntity($uploadDocumentList, $this->request->data);
            if ($this->UploadDocumentList->save($uploadDocumentList)) {
                $this->Flash->success(__('The {0} has been saved.', 'Upload Document List'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Upload Document List'));
            }
        }
        $this->set(compact('uploadDocumentList'));
        $this->set('_serialize', ['uploadDocumentList']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Upload Document List id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $uploadDocumentList = $this->UploadDocumentList->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $uploadDocumentList = $this->UploadDocumentList->patchEntity($uploadDocumentList, $this->request->data);
            if ($this->UploadDocumentList->save($uploadDocumentList)) {
                $this->Flash->success(__('The {0} has been saved.', 'Upload Document List'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Upload Document List'));
            }
        }
        $this->set(compact('uploadDocumentList'));
        $this->set('_serialize', ['uploadDocumentList']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Upload Document List id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $uploadDocumentList = $this->UploadDocumentList->get($id);
        if ($this->UploadDocumentList->delete($uploadDocumentList)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Upload Document List'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Upload Document List'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
}
