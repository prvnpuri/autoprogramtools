<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * BatchsheetTran Controller
 *
 * @property \App\Model\Table\BatchsheetTranTable $BatchsheetTran
 *
 * @method \App\Model\Entity\BatchsheetTran[] paginate($object = null, array $settings = [])
 */
class BatchsheetTranController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['BatchsheetMaster', 'RoomTempUoms', 'TotalYeildUoms', 'WeightCrudUoms']
        ];
        $batchsheetTran = $this->paginate($this->BatchsheetTran);

        $this->set(compact('batchsheetTran'));
        $this->set('_serialize', ['batchsheetTran']);
    }

    /**
     * View method
     *
     * @param string|null $id Batchsheet Tran id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $batchsheetTran = $this->BatchsheetTran->get($id, [
            'contain' => ['BatchsheetMaster', 'RoomTempUoms', 'TotalYeildUoms', 'WeightCrudUoms', 'BatchsheetBom', 'BatchsheetStepsTran', 'MaterialRequest', 'ProductionBatches']
        ]);

        $this->set('batchsheetTran', $batchsheetTran);
        $this->set('_serialize', ['batchsheetTran']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $batchsheetTran = $this->BatchsheetTran->newEntity();
        if ($this->request->is('post')) {
            $batchsheetTran = $this->BatchsheetTran->patchEntity($batchsheetTran, $this->request->data);
            if ($this->BatchsheetTran->save($batchsheetTran)) {
                $this->Flash->success(__('The {0} has been saved.', 'Batchsheet Tran'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Batchsheet Tran'));
            }
        }
        $batchsheetMaster = $this->BatchsheetTran->BatchsheetMaster->find('list', ['limit' => 200]);
        $roomTempUoms = $this->BatchsheetTran->RoomTempUoms->find('list', ['limit' => 200]);
        $totalYeildUoms = $this->BatchsheetTran->TotalYeildUoms->find('list', ['limit' => 200]);
        $weightCrudUoms = $this->BatchsheetTran->WeightCrudUoms->find('list', ['limit' => 200]);
        $this->set(compact('batchsheetTran', 'batchsheetMaster', 'roomTempUoms', 'totalYeildUoms', 'weightCrudUoms'));
        $this->set('_serialize', ['batchsheetTran']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Batchsheet Tran id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $batchsheetTran = $this->BatchsheetTran->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $batchsheetTran = $this->BatchsheetTran->patchEntity($batchsheetTran, $this->request->data);
            if ($this->BatchsheetTran->save($batchsheetTran)) {
                $this->Flash->success(__('The {0} has been saved.', 'Batchsheet Tran'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Batchsheet Tran'));
            }
        }
        $batchsheetMaster = $this->BatchsheetTran->BatchsheetMaster->find('list', ['limit' => 200]);
        $roomTempUoms = $this->BatchsheetTran->RoomTempUoms->find('list', ['limit' => 200]);
        $totalYeildUoms = $this->BatchsheetTran->TotalYeildUoms->find('list', ['limit' => 200]);
        $weightCrudUoms = $this->BatchsheetTran->WeightCrudUoms->find('list', ['limit' => 200]);
        $this->set(compact('batchsheetTran', 'batchsheetMaster', 'roomTempUoms', 'totalYeildUoms', 'weightCrudUoms'));
        $this->set('_serialize', ['batchsheetTran']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Batchsheet Tran id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $batchsheetTran = $this->BatchsheetTran->get($id);
        if ($this->BatchsheetTran->delete($batchsheetTran)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Batchsheet Tran'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Batchsheet Tran'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
