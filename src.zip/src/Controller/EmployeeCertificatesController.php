<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * EmployeeCertificates Controller
 *
 * @property \App\Model\Table\EmployeeCertificatesTable $EmployeeCertificates
 *
 * @method \App\Model\Entity\EmployeeCertificate[] paginate($object = null, array $settings = [])
 */
class EmployeeCertificatesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Emps']
        ];
        $employeeCertificates = $this->paginate($this->EmployeeCertificates);

        $this->set(compact('employeeCertificates'));
        $this->set('_serialize', ['employeeCertificates']);
    }

    /**
     * View method
     *
     * @param string|null $id Employee Certificate id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $employeeCertificate = $this->EmployeeCertificates->get($id, [
            'contain' => ['Emps']
        ]);

        $this->set('employeeCertificate', $employeeCertificate);
        $this->set('_serialize', ['employeeCertificate']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $employeeCertificate = $this->EmployeeCertificates->newEntity();
        if ($this->request->is('post')) {
            $employeeCertificate = $this->EmployeeCertificates->patchEntity($employeeCertificate, $this->request->data);
            if ($this->EmployeeCertificates->save($employeeCertificate)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Certificate'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Certificate'));
            }
        }
        $emps = $this->EmployeeCertificates->Emps->find('list', ['limit' => 200]);
        $this->set(compact('employeeCertificate', 'emps'));
        $this->set('_serialize', ['employeeCertificate']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Employee Certificate id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $employeeCertificate = $this->EmployeeCertificates->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $employeeCertificate = $this->EmployeeCertificates->patchEntity($employeeCertificate, $this->request->data);
            if ($this->EmployeeCertificates->save($employeeCertificate)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Certificate'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Certificate'));
            }
        }
        $emps = $this->EmployeeCertificates->Emps->find('list', ['limit' => 200]);
        $this->set(compact('employeeCertificate', 'emps'));
        $this->set('_serialize', ['employeeCertificate']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Employee Certificate id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $employeeCertificate = $this->EmployeeCertificates->get($id);
        if ($this->EmployeeCertificates->delete($employeeCertificate)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Employee Certificate'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Employee Certificate'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
