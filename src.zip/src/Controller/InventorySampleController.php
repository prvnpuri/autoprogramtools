<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * InventorySample Controller
 *
 * @property \App\Model\Table\InventorySampleTable $InventorySample
 *
 * @method \App\Model\Entity\InventorySample[] paginate($object = null, array $settings = [])
 */
class InventorySampleController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products', 'OwnerCompanies', 'WarehouseMasters']
        ];
        $inventorySample = $this->paginate($this->InventorySample);

        $this->set(compact('inventorySample'));
        $this->set('_serialize', ['inventorySample']);
    }

    /**
     * View method
     *
     * @param string|null $id Inventory Sample id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $inventorySample = $this->InventorySample->get($id, [
            'contain' => ['Products', 'OwnerCompanies', 'WarehouseMasters']
        ]);

        $this->set('inventorySample', $inventorySample);
        $this->set('_serialize', ['inventorySample']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $inventorySample = $this->InventorySample->newEntity();
        if ($this->request->is('post')) {
            $inventorySample = $this->InventorySample->patchEntity($inventorySample, $this->request->data);
            if ($this->InventorySample->save($inventorySample)) {
                $this->Flash->success(__('The {0} has been saved.', 'Inventory Sample'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Inventory Sample'));
            }
        }
        $products = $this->InventorySample->Products->find('list', ['limit' => 200]);
        $ownerCompanies = $this->InventorySample->OwnerCompanies->find('list', ['limit' => 200]);
        $warehouseMasters = $this->InventorySample->WarehouseMasters->find('list', ['limit' => 200]);
        $this->set(compact('inventorySample', 'products', 'ownerCompanies', 'warehouseMasters'));
        $this->set('_serialize', ['inventorySample']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Inventory Sample id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $inventorySample = $this->InventorySample->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $inventorySample = $this->InventorySample->patchEntity($inventorySample, $this->request->data);
            if ($this->InventorySample->save($inventorySample)) {
                $this->Flash->success(__('The {0} has been saved.', 'Inventory Sample'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Inventory Sample'));
            }
        }
        $products = $this->InventorySample->Products->find('list', ['limit' => 200]);
        $ownerCompanies = $this->InventorySample->OwnerCompanies->find('list', ['limit' => 200]);
        $warehouseMasters = $this->InventorySample->WarehouseMasters->find('list', ['limit' => 200]);
        $this->set(compact('inventorySample', 'products', 'ownerCompanies', 'warehouseMasters'));
        $this->set('_serialize', ['inventorySample']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Inventory Sample id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $inventorySample = $this->InventorySample->get($id);
        if ($this->InventorySample->delete($inventorySample)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Inventory Sample'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Inventory Sample'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
