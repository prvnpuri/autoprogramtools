<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PostshipmentRemittance Controller
 *
 * @property \App\Model\Table\PostshipmentRemittanceTable $PostshipmentRemittance
 *
 * @method \App\Model\Entity\PostshipmentRemittance[] paginate($object = null, array $settings = [])
 */
class PostshipmentRemittanceController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Oas', 'Currencies']
        ];
        $postshipmentRemittance = $this->paginate($this->PostshipmentRemittance);

        $this->set(compact('postshipmentRemittance'));
        $this->set('_serialize', ['postshipmentRemittance']);
    }

    /**
     * View method
     *
     * @param string|null $id Postshipment Remittance id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $postshipmentRemittance = $this->PostshipmentRemittance->get($id, [
            'contain' => ['Oas', 'Currencies']
        ]);

        $this->set('postshipmentRemittance', $postshipmentRemittance);
        $this->set('_serialize', ['postshipmentRemittance']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $postshipmentRemittance = $this->PostshipmentRemittance->newEntity();
        if ($this->request->is('post')) {
            $postshipmentRemittance = $this->PostshipmentRemittance->patchEntity($postshipmentRemittance, $this->request->data);
            if ($this->PostshipmentRemittance->save($postshipmentRemittance)) {
                $this->Flash->success(__('The {0} has been saved.', 'Postshipment Remittance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Postshipment Remittance'));
            }
        }
        $oas = $this->PostshipmentRemittance->Oas->find('list', ['limit' => 200]);
        $currencies = $this->PostshipmentRemittance->Currencies->find('list', ['limit' => 200]);
        $this->set(compact('postshipmentRemittance', 'oas', 'currencies'));
        $this->set('_serialize', ['postshipmentRemittance']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Postshipment Remittance id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $postshipmentRemittance = $this->PostshipmentRemittance->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $postshipmentRemittance = $this->PostshipmentRemittance->patchEntity($postshipmentRemittance, $this->request->data);
            if ($this->PostshipmentRemittance->save($postshipmentRemittance)) {
                $this->Flash->success(__('The {0} has been saved.', 'Postshipment Remittance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Postshipment Remittance'));
            }
        }
        $oas = $this->PostshipmentRemittance->Oas->find('list', ['limit' => 200]);
        $currencies = $this->PostshipmentRemittance->Currencies->find('list', ['limit' => 200]);
        $this->set(compact('postshipmentRemittance', 'oas', 'currencies'));
        $this->set('_serialize', ['postshipmentRemittance']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Postshipment Remittance id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $postshipmentRemittance = $this->PostshipmentRemittance->get($id);
        if ($this->PostshipmentRemittance->delete($postshipmentRemittance)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Postshipment Remittance'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Postshipment Remittance'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
