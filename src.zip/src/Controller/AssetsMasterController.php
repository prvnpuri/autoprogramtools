<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * AssetsMaster Controller
 *
 * @property \App\Model\Table\AssetsMasterTable $AssetsMaster
 *
 * @method \App\Model\Entity\AssetsMaster[] paginate($object = null, array $settings = [])
 */
class AssetsMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="AssetsMaster.asset_name like '%$query%'";
    	}
    	$this->paginate = [
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","asset_name","asset_type","asset_purpose","capacity","specification"]
    	];
    	$assetsMaster= $this->paginate($this->AssetsMaster);
    	$this->loadModel('Uom');
    	$uomsObj = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_symbol']);
    	$uoms = $uomsObj;
    	
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('assetsMaster', 'uoms'));
    	$this->set( '_serialize', ['uoms','assetsMaster','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Assets Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $assetsMaster = $this->AssetsMaster->get($id, [
            'contain' => ['OwnerCompanyAssets']
        ]);
        $this->loadModel('Uom');
        $uomObj = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_symbol']);
        $uoms = $uomObj->toArray();
        $this->set(compact('assetsMaster','uoms'));
        $this->set('_serialize', ['assetsMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $assetsMaster = $this->AssetsMaster->newEntity();
        if ($this->request->is('post')) {
            $assetsMaster = $this->AssetsMaster->patchEntity($assetsMaster, $this->request->data);
            $assetsMaster['created_by'] = $this->Auth->User('id');
            if ($this->AssetsMaster->save($assetsMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Assets Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Assets Master'));
            }
        }
        $this->loadModel('Uom');
        $uomObj= $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_symbol']);
        $uoms = $uomObj->toArray();
        $this->set(compact('assetsMaster','uoms'));
        $this->set('_serialize', ['assetsMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Assets Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $assetsMaster = $this->AssetsMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $assetsMaster = $this->AssetsMaster->patchEntity($assetsMaster, $this->request->data);
            $assetsMaster['modified_by'] = $this->Auth->User('id');
            if ($this->AssetsMaster->save($assetsMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Assets Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Assets Master'));
            }
        }
        $this->loadModel('Uom');
        $uomObj= $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_symbol']);
        $uoms = $uomObj->toArray();
        $this->set(compact('assetsMaster','uoms'));
        $this->set('_serialize', ['assetsMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Assets Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $assetsMaster = $this->AssetsMaster->get($id);
        if ($this->AssetsMaster->delete($assetsMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Assets Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Assets Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
