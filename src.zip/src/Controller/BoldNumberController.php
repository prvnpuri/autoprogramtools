<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * BoldNumber Controller
 *
 * @property \App\Model\Table\BoldNumberTable $BoldNumber
 *
 * @method \App\Model\Entity\BoldNumber[] paginate($object = null, array $settings = [])
 */
class BoldNumberController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $boldNumber = $this->paginate($this->BoldNumber);

        $this->set(compact('boldNumber'));
        $this->set('_serialize', ['boldNumber']);
    }

    /**
     * View method
     *
     * @param string|null $id Bold Number id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $boldNumber = $this->BoldNumber->get($id, [
            'contain' => []
        ]);

        $this->set('boldNumber', $boldNumber);
        $this->set('_serialize', ['boldNumber']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $boldNumber = $this->BoldNumber->newEntity();
        if ($this->request->is('post')) {
            $boldNumber = $this->BoldNumber->patchEntity($boldNumber, $this->request->data);
            if ($this->BoldNumber->save($boldNumber)) {
                $this->Flash->success(__('The {0} has been saved.', 'Bold Number'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bold Number'));
            }
        }
        $this->set(compact('boldNumber'));
        $this->set('_serialize', ['boldNumber']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Bold Number id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $boldNumber = $this->BoldNumber->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $boldNumber = $this->BoldNumber->patchEntity($boldNumber, $this->request->data);
            if ($this->BoldNumber->save($boldNumber)) {
                $this->Flash->success(__('The {0} has been saved.', 'Bold Number'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bold Number'));
            }
        }
        $this->set(compact('boldNumber'));
        $this->set('_serialize', ['boldNumber']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Bold Number id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $boldNumber = $this->BoldNumber->get($id);
        if ($this->BoldNumber->delete($boldNumber)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Bold Number'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Bold Number'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
