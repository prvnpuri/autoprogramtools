<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PostShipmentInsurancePolicy Controller
 *
 * @property \App\Model\Table\PostShipmentInsurancePolicyTable $PostShipmentInsurancePolicy
 *
 * @method \App\Model\Entity\PostShipmentInsurancePolicy[] paginate($object = null, array $settings = [])
 */
class PostShipmentInsurancePolicyController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Oas']
        ];
        $postShipmentInsurancePolicy = $this->paginate($this->PostShipmentInsurancePolicy);

        $this->set(compact('postShipmentInsurancePolicy'));
        $this->set('_serialize', ['postShipmentInsurancePolicy']);
    }

    /**
     * View method
     *
     * @param string|null $id Post Shipment Insurance Policy id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $postShipmentInsurancePolicy = $this->PostShipmentInsurancePolicy->get($id, [
            'contain' => ['Oas']
        ]);

        $this->set('postShipmentInsurancePolicy', $postShipmentInsurancePolicy);
        $this->set('_serialize', ['postShipmentInsurancePolicy']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $postShipmentInsurancePolicy = $this->PostShipmentInsurancePolicy->newEntity();
        if ($this->request->is('post')) {
            $postShipmentInsurancePolicy = $this->PostShipmentInsurancePolicy->patchEntity($postShipmentInsurancePolicy, $this->request->data);
            if ($this->PostShipmentInsurancePolicy->save($postShipmentInsurancePolicy)) {
                $this->Flash->success(__('The {0} has been saved.', 'Post Shipment Insurance Policy'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Post Shipment Insurance Policy'));
            }
        }
        $oas = $this->PostShipmentInsurancePolicy->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postShipmentInsurancePolicy', 'oas'));
        $this->set('_serialize', ['postShipmentInsurancePolicy']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Post Shipment Insurance Policy id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $postShipmentInsurancePolicy = $this->PostShipmentInsurancePolicy->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $postShipmentInsurancePolicy = $this->PostShipmentInsurancePolicy->patchEntity($postShipmentInsurancePolicy, $this->request->data);
            if ($this->PostShipmentInsurancePolicy->save($postShipmentInsurancePolicy)) {
                $this->Flash->success(__('The {0} has been saved.', 'Post Shipment Insurance Policy'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Post Shipment Insurance Policy'));
            }
        }
        $oas = $this->PostShipmentInsurancePolicy->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postShipmentInsurancePolicy', 'oas'));
        $this->set('_serialize', ['postShipmentInsurancePolicy']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Post Shipment Insurance Policy id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $postShipmentInsurancePolicy = $this->PostShipmentInsurancePolicy->get($id);
        if ($this->PostShipmentInsurancePolicy->delete($postShipmentInsurancePolicy)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Post Shipment Insurance Policy'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Post Shipment Insurance Policy'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
