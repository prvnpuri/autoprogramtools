<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PreShipmentSdf Controller
 *
 * @property \App\Model\Table\PreShipmentSdfTable $PreShipmentSdf
 *
 * @method \App\Model\Entity\PreShipmentSdf[] paginate($object = null, array $settings = [])
 */
class PreShipmentSdfController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'Oas']
        ];
        $preShipmentSdf = $this->paginate($this->PreShipmentSdf);

        $this->set(compact('preShipmentSdf'));
        $this->set('_serialize', ['preShipmentSdf']);
    }

    /**
     * View method
     *
     * @param string|null $id Pre Shipment Sdf id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $preShipmentSdf = $this->PreShipmentSdf->get($id, [
            'contain' => ['Invoices', 'Oas']
        ]);

        $this->set('preShipmentSdf', $preShipmentSdf);
        $this->set('_serialize', ['preShipmentSdf']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $preShipmentSdf = $this->PreShipmentSdf->newEntity();
        if ($this->request->is('post')) {
            $preShipmentSdf = $this->PreShipmentSdf->patchEntity($preShipmentSdf, $this->request->data);
            if ($this->PreShipmentSdf->save($preShipmentSdf)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Sdf'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Sdf'));
            }
        }
        $invoices = $this->PreShipmentSdf->Invoices->find('list', ['limit' => 200]);
        $oas = $this->PreShipmentSdf->Oas->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentSdf', 'invoices', 'oas'));
        $this->set('_serialize', ['preShipmentSdf']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Pre Shipment Sdf id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $preShipmentSdf = $this->PreShipmentSdf->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $preShipmentSdf = $this->PreShipmentSdf->patchEntity($preShipmentSdf, $this->request->data);
            if ($this->PreShipmentSdf->save($preShipmentSdf)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Sdf'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Sdf'));
            }
        }
        $invoices = $this->PreShipmentSdf->Invoices->find('list', ['limit' => 200]);
        $oas = $this->PreShipmentSdf->Oas->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentSdf', 'invoices', 'oas'));
        $this->set('_serialize', ['preShipmentSdf']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Pre Shipment Sdf id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $preShipmentSdf = $this->PreShipmentSdf->get($id);
        if ($this->PreShipmentSdf->delete($preShipmentSdf)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Pre Shipment Sdf'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Pre Shipment Sdf'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
