<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * WarehouseMaster Controller
 *
 * @property \App\Model\Table\WarehouseMasterTable $WarehouseMaster
 *
 * @method \App\Model\Entity\WarehouseMaster[] paginate($object = null, array $settings = [])
 */
class WarehouseMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="WarehouseMaster.name like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['OwnerCompanies','City','State','Countries'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","name","OwnerCompanies.Company_name","address","City.city_name","State.state_name","Countries.country_name"]
    	];
    	
    	
    	$warehouseMaster = $this->paginate($this->WarehouseMaster);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('warehouseMaster', 'ownerCompanies'));
    	$this->set( '_serialize', ['warehouseMaster','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Warehouse Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $warehouseMaster = $this->WarehouseMaster->get($id, [
            'contain' => ['OwnerCompanies', 'InventorySample', 'Inward',  'TransactionProduct', 'WarehouseUnit','City','State','Countries']
        ]);
		
        $this->set('warehouseMaster', $warehouseMaster);
        $this->set('_serialize', ['warehouseMaster']);
        $this->set(compact('warehouseMaster', 'ownerCompanies','city','state','countries'));
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $warehouseMaster = $this->WarehouseMaster->newEntity();
        if ($this->request->is('post')) {
            $warehouseMaster = $this->WarehouseMaster->patchEntity($warehouseMaster, $this->request->data);
            if ($this->WarehouseMaster->save($warehouseMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Warehouse Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Warehouse Master'));
            }
        }
        $ownerCompanies = $this->WarehouseMaster->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'],['limit' => 200]);
        $this->loadModel('City');
        $this->loadModel('State');
        $this->loadModel('Countries');
        $city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name']);
        $state = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name']);
        $countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        $this->set('_serialize', ['warehouseMaster']);
        $this->set(compact('warehouseMaster', 'ownerCompanies','city','state','countries'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Warehouse Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $warehouseMaster = $this->WarehouseMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $warehouseMaster = $this->WarehouseMaster->patchEntity($warehouseMaster, $this->request->data);
            if ($this->WarehouseMaster->save($warehouseMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Warehouse Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Warehouse Master'));
            }
        }
        $ownerCompanies = $this->WarehouseMaster->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'],['limit' => 200]);
        $this->set(compact('warehouseMaster', 'ownerCompanies'));
        $this->loadModel('City');
        $this->loadModel('State');
        $this->loadModel('Countries');
        $city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name']);
        $state = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name']);
        $countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        $this->set('_serialize', ['warehouseMaster']);
        $this->set(compact('warehouseMaster', 'ownerCompanies','city','state','countries'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Warehouse Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $warehouseMaster = $this->WarehouseMaster->get($id);
        if ($this->WarehouseMaster->delete($warehouseMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Warehouse Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Warehouse Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
