<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TestMethods Controller
 *
 * @property \App\Model\Table\TestMethodsTable $TestMethods
 *
 * @method \App\Model\Entity\TestMethod[] paginate($object = null, array $settings = [])
 */
class TestMethodsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['TestingMasters']
        ];
        $testMethods = $this->paginate($this->TestMethods);

        $this->set(compact('testMethods'));
        $this->set('_serialize', ['testMethods']);
    }

    /**
     * View method
     *
     * @param string|null $id Test Method id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $testMethod = $this->TestMethods->get($id, [
            'contain' => ['TestingMasters']
        ]);

        $this->loadModel('TestnameMaster');
        $this->set(compact('testMethod'));
        $this->set('_serialize', ['testMethod']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($id=null)
    {
    	$testMethod = $this->TestMethods->newEntity();
        if ($this->request->is('post')) {
            $testMethod = $this->TestMethods->patchEntity($testMethod, $this->request->data);
            if ($this->TestMethods->save($testMethod)) {
                $this->Flash->success(__('The {0} has been saved.', 'Test Method'));
                return $this->redirect(['controller'=>'TestingMasters','action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Method'));
            }
        }
        $this->loadModel('TestingMasters');
 		$this->loadModel('TestnameMaster');
        $query = $this->TestingMasters->find('all',array(
 	    	'fields'=>array('TestingMasters.id','TestingMasters.test_name'),
	    	'conditions'=>array('TestingMasters.id'=>$id)
	    ));
        $TestingMaster = $query->first();
        $this->set(compact('testMethod', 'TestingMaster'));
        $this->set('_serialize', ['testMethod']);
    }    

    /**
     * Edit method
     *
     * @param string|null $id Test Method id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $testMethod = $this->TestMethods->get($id, [
            'contain' => ['TestingMasters']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $testMethod = $this->TestMethods->patchEntity($testMethod, $this->request->data);
            if ($this->TestMethods->save($testMethod)) {
                $this->Flash->success(__('The {0} has been saved.', 'Test Method'));
                return $this->redirect(['controller'=>'TestingMasters','action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Method'));
            }
        }
        
        $this->loadModel('TestnameMaster');
     	$this->set(compact('testMethod'));
        $this->set('_serialize', ['testMethod']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Test Method id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
    	$this->request->allowMethod(['post', 'delete']);
        $testMethod = $this->TestMethods->get($id);
        if ($this->TestMethods->delete($testMethod)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Test Method'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Test Method'));
        }
        return $this->redirect(['controller'=>'TestingMasters','action' => 'index']);
    }
}
