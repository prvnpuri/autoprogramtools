<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Inward Controller
 *
 * @property \App\Model\Table\InwardTable $Inward
 *
 * @method \App\Model\Entity\Inward[] paginate($object = null, array $settings = [])
 */
class InwardController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$inward =  $this->Inward->find('all',
    			[
    					//'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','ProductsMaster.product_name','id','status','company_ids'],
    					//'conditions'=>['inquiry_type'=>'Chemical Product'],
    					'contain'=>['WarehouseMaster','PurchaseOrder', 'Uom','CompanyMaster'],
    					//'order'=>['SupplierInquiry.id' => 'DESC']
    			]
    			);
    	
       /*  $this->paginate = [
            'contain' => ['WarehouseMaster','PurchaseOrder', 'Uom', 'CompanyMaster']
        ];
        $inward = $this->paginate($this->Inward);
 */
        $this->set(compact('inward'));
        $this->set('_serialize', ['inward']);
    }

    /**
     * View method
     *
     * @param string|null $id Inward id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $inward = $this->Inward->get($id, [
            'contain' => ['WarehouseMaster', 'ProductionBatches', 'Pos', 'Uoms', 'TransporterCompanies', 'PostshipmentTransporter', 'PurchaseOrder', 'SampleProduct', 'TransactionProduct', 'Transporters', 'WarehouseProductDetails']
        ]);

        $this->set('inward', $inward);
        $this->set('_serialize', ['inward']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($purchseOrderId=null)
    {
    	$this->loadModel('PurchaseOrder');
    	$this->loadModel('Inward');
    	 
    	$purchaseOrder = $this->PurchaseOrder->get($purchseOrderId, [
    			'fields'=>['po_number','id','owner_companies_id','po_date','consignee_id','OwnerCompanies.Company_name','Uom.unit_symbol','dispatch_through','destination',
    					'IncoTerms.inco_term','CompanyMaster.Company_name','quantity_ordered','delivery','delivery_to','required_by_us',
    					'rate','total_order_price','your_ref_no','packing_terms','payment_terms','port_of_discharge','country_final_destination','country_of_origin_of_goods',
    					'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no',],
    					//'Inward.id','Inward.supplier_invoice_no','Inward.supplier_invoice_dt','Inward.quantity_supplied','Inward.uom_id',
    					//'Inward.price','Inward.currency','Inward.transporter_company_id','Inward.lr_number','Inward.lr_date'],
    			'contain' => ['OwnerCompanies','ProductsMaster','CompanyMaster','IncoTerms','Uom','Currency']
    	]);
    	 
    	$inward = $this->Inward->newEntity();
        if ($this->request->is('post')) {
        	
        	$next_ref =
        	$this->ReferenceNumber->get_next_ref_number($purchaseOrder['owner_companies_id'],'inward');
        	$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
        	if(!isset($next_ref['full_next_ref_no'])){
        		$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Inquiry'));
        	}else{
        		$inward = $this->Inward->newEntities($this->request->data['inward']);
        		
        		if ($inwardIds=$this->Inward->saveTransactions($inward)) {
        			
					//	print_r($inwardIds);die;
					$inwardQty=0;
        			foreach ($this->request->data['inward'] as $keys=>&$val){
        				if(isset($inwardIds[$keys])){
        					$val['inward_id']=$inwardIds[$keys];
        					$val['company_id']=$val['transporter_company_id'];
        					$inwardQty=$inwardQty+$val['quantity_supplied'];
        				}
        			}
        			
	        			$this->loadModel('Transporters');
	        			$transporters = $this->Transporters->newEntities($this->request->data['inward']);
	        			 
	        			$this->Transporters->saveTransactions($transporters);
	        			
	        		
	        			
        			//Update inward status
        			try{
        			$this->loadModel('PurchaseOrder');
        			$purchaseOrder = $this->PurchaseOrder->get($purchseOrderId, [
        					'fields'=>['quantity_ordered','id','inward_status']
        			]);
        			$status="1";
        			if($inwardQty==$purchaseOrder['quantity_ordered']){
        				$status="2";
        			}
        			$data = array('id' => $purchseOrderId , 'inward_status' => $status);
        			$inwardstatus = $this->PurchaseOrder->patchEntity($purchaseOrder, $data);
        			$this->PurchaseOrder->save($inwardstatus);
        			}catch(Exception $e){
        				echo $e;die;
        			}
        			
        			$this->Flash->success(__('The {0} has been saved.', 'Inward'));
        			return $this->redirect(['controller'=>'purchase-order','action' => 'pending-po-inward']);
        		} else {
        			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Inward'));
        		}
        		
        	}
        	
        }
        $this->loadModel('WarehouseMaster');        
        $warehouseMaster = $this->WarehouseMaster->find('list', ['keyField' => 'id','valueField' => 'name'], ['limit' => 200]);
        
        $inwardData =  $this->Inward->find('all',
    			[
    					'fields'=>[
			    					'Inward.id','Inward.supplier_invoice_no','Inward.supplier_invoice_dt','Inward.quantity_supplied','Inward.uom_id',
			    					'Inward.price','Inward.currency','Inward.transporter_company_id','Inward.lr_number','Inward.lr_date','warehouse_master_id',
    								'Transporters.to_location','Transporters.from_location','CompanyMaster.id','CompanyMaster.Company_name'
    						],
        				'conditions'=>['po_id'=>$purchseOrderId],
        				'contain' => ['CompanyMaster','Uom','Transporters']
    					//'order'=>['SupplierInquiry.id' => 'DESC']
    			]
    			)->toArray();
        
        
    /*     $warehouseMaster = $this->Inward->WarehouseMaster->find('list', ['limit' => 200]);
        $productionBatches = $this->Inward->ProductionBatches->find('list', ['limit' => 200]);
        $pos = $this->Inward->PurchaseOrder->find('list', ['limit' => 200]);
        $uoms = $this->Inward->Uom->find('list', ['limit' => 200]);
        $transporterCompanies = $this->Inward->CompanyMaster->find('list', ['limit' => 200]);
        
     
     */
        $this->loadModel('Uom');
        $uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
        $this->set(compact('inward', 'warehouseMaster','purchaseOrder', 'uom','inwardData'));
        $this->set('_serialize', ['inward']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Inward id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    
  
    public function edit($id = null)
    {
        $inward = $this->Inward->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $inward = $this->Inward->patchEntity($inward, $this->request->data);
            if ($this->Inward->save($inward)) {
                $this->Flash->success(__('The {0} has been saved.', 'Inward'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Inward'));
            }
        }
        $warehouseMaster = $this->Inward->WarehouseMaster->find('list', ['limit' => 200]);
        $productionBatches = $this->Inward->ProductionBatches->find('list', ['limit' => 200]);
        $pos = $this->Inward->Pos->find('list', ['limit' => 200]);
        $uoms = $this->Inward->Uoms->find('list', ['limit' => 200]);
        $transporterCompanies = $this->Inward->TransporterCompanies->find('list', ['limit' => 200]);
        $this->set(compact('inward', 'warehouseMaster', 'productionBatches', 'pos', 'uoms', 'transporterCompanies'));
        $this->set('_serialize', ['inward']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Inward id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $inward = $this->Inward->get($id);
        if ($this->Inward->delete($inward)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Inward'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Inward'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
