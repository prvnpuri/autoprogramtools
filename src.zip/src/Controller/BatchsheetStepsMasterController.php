<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * BatchsheetStepsMaster Controller
 *
 * @property \App\Model\Table\BatchsheetStepsMasterTable $BatchsheetStepsMaster
 *
 * @method \App\Model\Entity\BatchsheetStepsMaster[] paginate($object = null, array $settings = [])
 */
class BatchsheetStepsMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => []
        ];
        $batchsheetStepsMaster = $this->paginate($this->BatchsheetStepsMaster);

        $this->set(compact('batchsheetStepsMaster'));
        $this->set('_serialize', ['batchsheetStepsMaster']);
    }

    /**
     * View method
     *
     * @param string|null $id Batchsheet Steps Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $batchsheetStepsMaster = $this->BatchsheetStepsMaster->get($id, [
            'contain' => []
        ]);

        $this->set('batchsheetStepsMaster', $batchsheetStepsMaster);
        $this->set('_serialize', ['batchsheetStepsMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
    	$this->loadModel('BatchsheetStepsMaster');
    	$this->loadModel('Uom');
    	$batchsheetStepsMaster = $this->BatchsheetStepsMaster->newEntity();
        if ($this->request->is('post')) {
            $batchsheetStepsMaster = $this->BatchsheetStepsMaster->patchEntity($batchsheetStepsMaster, $this->request->data);
            if ($this->BatchsheetStepsMaster->save($batchsheetStepsMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Batchsheet Steps Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Batchsheet Steps Master'));
            }
        }
        $batchsheetMaster = $this->BatchsheetStepsMaster->BatchsheetMaster->find('list', ['limit' => 200]);
        $uom= $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol']);
        $this->set(compact('batchsheetStepsMaster', 'batchsheetMaster', 'uom'));
        $this->set('_serialize', ['batchsheetStepsMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Batchsheet Steps Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $batchsheetStepsMaster = $this->BatchsheetStepsMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $batchsheetStepsMaster = $this->BatchsheetStepsMaster->patchEntity($batchsheetStepsMaster, $this->request->data);
            if ($this->BatchsheetStepsMaster->save($batchsheetStepsMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Batchsheet Steps Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Batchsheet Steps Master'));
            }
        }
        $batchsheetMaster = $this->BatchsheetStepsMaster->BatchsheetMaster->find('list', ['limit' => 200]);
        $this->set(compact('batchsheetStepsMaster', 'batchsheetMaster', 'weightUoms', 'distillationUoms', 'productWeightUoms', 'totalTimeUoms', 'startTempUoms', 'endTempUoms'));
        $this->set('_serialize', ['batchsheetStepsMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Batchsheet Steps Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $batchsheetStepsMaster = $this->BatchsheetStepsMaster->get($id);
        if ($this->BatchsheetStepsMaster->delete($batchsheetStepsMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Batchsheet Steps Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Batchsheet Steps Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
