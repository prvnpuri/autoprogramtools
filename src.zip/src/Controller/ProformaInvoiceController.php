<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProformaInvoice Controller
 *
 * @property \App\Model\Table\ProformaInvoiceTable $ProformaInvoice
 *
 * @method \App\Model\Entity\ProformaInvoice[] paginate($object = null, array $settings = [])
 */
class ProformaInvoiceController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Oas', 'States', 'Banks']
        ];
        $proformaInvoice = $this->paginate($this->ProformaInvoice);

        $this->set(compact('proformaInvoice'));
        $this->set('_serialize', ['proformaInvoice']);
    }

    /**
     * View method
     *
     * @param string|null $id Proforma Invoice id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $proformaInvoice = $this->ProformaInvoice->get($id, [
            'contain' => ['Orders', 'Oas', 'States', 'Banks']
        ]);

        $this->set('proformaInvoice', $proformaInvoice);
        $this->set('_serialize', ['proformaInvoice']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $proformaInvoice = $this->ProformaInvoice->newEntity();
        if ($this->request->is('post')) {
            $proformaInvoice = $this->ProformaInvoice->patchEntity($proformaInvoice, $this->request->data);
            if ($this->ProformaInvoice->save($proformaInvoice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Proforma Invoice'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Proforma Invoice'));
            }
        }
        $orders = $this->ProformaInvoice->Orders->find('list', ['limit' => 200]);
        $oas = $this->ProformaInvoice->Oas->find('list', ['limit' => 200]);
        $states = $this->ProformaInvoice->States->find('list', ['limit' => 200]);
        $banks = $this->ProformaInvoice->Banks->find('list', ['limit' => 200]);
        $this->set(compact('proformaInvoice', 'orders', 'oas', 'states', 'banks'));
        $this->set('_serialize', ['proformaInvoice']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Proforma Invoice id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $proformaInvoice = $this->ProformaInvoice->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $proformaInvoice = $this->ProformaInvoice->patchEntity($proformaInvoice, $this->request->data);
            if ($this->ProformaInvoice->save($proformaInvoice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Proforma Invoice'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Proforma Invoice'));
            }
        }
        $orders = $this->ProformaInvoice->Orders->find('list', ['limit' => 200]);
        $oas = $this->ProformaInvoice->Oas->find('list', ['limit' => 200]);
        $states = $this->ProformaInvoice->States->find('list', ['limit' => 200]);
        $banks = $this->ProformaInvoice->Banks->find('list', ['limit' => 200]);
        $this->set(compact('proformaInvoice', 'orders', 'oas', 'states', 'banks'));
        $this->set('_serialize', ['proformaInvoice']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Proforma Invoice id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $proformaInvoice = $this->ProformaInvoice->get($id);
        if ($this->ProformaInvoice->delete($proformaInvoice)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Proforma Invoice'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Proforma Invoice'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
