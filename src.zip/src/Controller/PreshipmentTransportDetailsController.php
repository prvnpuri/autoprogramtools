<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PreshipmentTransportDetails Controller
 *
 * @property \App\Model\Table\PreshipmentTransportDetailsTable $PreshipmentTransportDetails
 *
 * @method \App\Model\Entity\PreshipmentTransportDetail[] paginate($object = null, array $settings = [])
 */
class PreshipmentTransportDetailsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Transports']
        ];
        $preshipmentTransportDetails = $this->paginate($this->PreshipmentTransportDetails);

        $this->set(compact('preshipmentTransportDetails'));
        $this->set('_serialize', ['preshipmentTransportDetails']);
    }

    /**
     * View method
     *
     * @param string|null $id Preshipment Transport Detail id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $preshipmentTransportDetail = $this->PreshipmentTransportDetails->get($id, [
            'contain' => ['Transports']
        ]);

        $this->set('preshipmentTransportDetail', $preshipmentTransportDetail);
        $this->set('_serialize', ['preshipmentTransportDetail']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $preshipmentTransportDetail = $this->PreshipmentTransportDetails->newEntity();
        if ($this->request->is('post')) {
            $preshipmentTransportDetail = $this->PreshipmentTransportDetails->patchEntity($preshipmentTransportDetail, $this->request->data);
            if ($this->PreshipmentTransportDetails->save($preshipmentTransportDetail)) {
                $this->Flash->success(__('The {0} has been saved.', 'Preshipment Transport Detail'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Preshipment Transport Detail'));
            }
        }
        $transports = $this->PreshipmentTransportDetails->Transports->find('list', ['limit' => 200]);
        $this->set(compact('preshipmentTransportDetail', 'transports'));
        $this->set('_serialize', ['preshipmentTransportDetail']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Preshipment Transport Detail id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $preshipmentTransportDetail = $this->PreshipmentTransportDetails->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $preshipmentTransportDetail = $this->PreshipmentTransportDetails->patchEntity($preshipmentTransportDetail, $this->request->data);
            if ($this->PreshipmentTransportDetails->save($preshipmentTransportDetail)) {
                $this->Flash->success(__('The {0} has been saved.', 'Preshipment Transport Detail'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Preshipment Transport Detail'));
            }
        }
        $transports = $this->PreshipmentTransportDetails->Transports->find('list', ['limit' => 200]);
        $this->set(compact('preshipmentTransportDetail', 'transports'));
        $this->set('_serialize', ['preshipmentTransportDetail']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Preshipment Transport Detail id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $preshipmentTransportDetail = $this->PreshipmentTransportDetails->get($id);
        if ($this->PreshipmentTransportDetails->delete($preshipmentTransportDetail)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Preshipment Transport Detail'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Preshipment Transport Detail'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
