<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductionBatches Controller
 *
 * @property \App\Model\Table\ProductionBatchesTable $ProductionBatches
 *
 * @method \App\Model\Entity\ProductionBatch[] paginate($object = null, array $settings = [])
 */
class ProductionBatchesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ProductionRequests', 'BatchsheetTran']
        ];
        $productionBatches = $this->paginate($this->ProductionBatches);

        $this->set(compact('productionBatches'));
        $this->set('_serialize', ['productionBatches']);
    }

    /**
     * View method
     *
     * @param string|null $id Production Batch id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productionBatch = $this->ProductionBatches->get($id, [
            'contain' => ['ProductionRequests', 'BatchsheetTran']
        ]);

        $this->set('productionBatch', $productionBatch);
        $this->set('_serialize', ['productionBatch']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productionBatch = $this->ProductionBatches->newEntity();
        if ($this->request->is('post')) {
            $productionBatch = $this->ProductionBatches->patchEntity($productionBatch, $this->request->data);
            if ($this->ProductionBatches->save($productionBatch)) {
                $this->Flash->success(__('The {0} has been saved.', 'Production Batch'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Production Batch'));
            }
        }
        $productionRequests = $this->ProductionBatches->ProductionRequests->find('list', ['limit' => 200]);
        $batchsheetTran = $this->ProductionBatches->BatchsheetTran->find('list', ['limit' => 200]);
        $this->set(compact('productionBatch', 'productionRequests', 'batchsheetTran'));
        $this->set('_serialize', ['productionBatch']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Production Batch id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productionBatch = $this->ProductionBatches->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productionBatch = $this->ProductionBatches->patchEntity($productionBatch, $this->request->data);
            if ($this->ProductionBatches->save($productionBatch)) {
                $this->Flash->success(__('The {0} has been saved.', 'Production Batch'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Production Batch'));
            }
        }
        $productionRequests = $this->ProductionBatches->ProductionRequests->find('list', ['limit' => 200]);
        $batchsheetTran = $this->ProductionBatches->BatchsheetTran->find('list', ['limit' => 200]);
        $this->set(compact('productionBatch', 'productionRequests', 'batchsheetTran'));
        $this->set('_serialize', ['productionBatch']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Production Batch id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productionBatch = $this->ProductionBatches->get($id);
        if ($this->ProductionBatches->delete($productionBatch)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Production Batch'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Production Batch'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
