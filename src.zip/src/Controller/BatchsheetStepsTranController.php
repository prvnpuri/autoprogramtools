<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * BatchsheetStepsTran Controller
 *
 * @property \App\Model\Table\BatchsheetStepsTranTable $BatchsheetStepsTran
 *
 * @method \App\Model\Entity\BatchsheetStepsTran[] paginate($object = null, array $settings = [])
 */
class BatchsheetStepsTranController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['BatchsheetStepsMaster', 'BatchsheetTran', 'WeightUoms', 'DistillationUoms', 'ProductWeightUoms', 'StartTimeUoms', 'FinishTimeUoms', 'TotalTimeUoms', 'StartTempUoms', 'EndTempUoms']
        ];
        $batchsheetStepsTran = $this->paginate($this->BatchsheetStepsTran);

        $this->set(compact('batchsheetStepsTran'));
        $this->set('_serialize', ['batchsheetStepsTran']);
    }

    /**
     * View method
     *
     * @param string|null $id Batchsheet Steps Tran id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $batchsheetStepsTran = $this->BatchsheetStepsTran->get($id, [
            'contain' => ['BatchsheetStepsMaster', 'BatchsheetTran', 'WeightUoms', 'DistillationUoms', 'ProductWeightUoms', 'StartTimeUoms', 'FinishTimeUoms', 'TotalTimeUoms', 'StartTempUoms', 'EndTempUoms']
        ]);

        $this->set('batchsheetStepsTran', $batchsheetStepsTran);
        $this->set('_serialize', ['batchsheetStepsTran']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $batchsheetStepsTran = $this->BatchsheetStepsTran->newEntity();
        if ($this->request->is('post')) {
            $batchsheetStepsTran = $this->BatchsheetStepsTran->patchEntity($batchsheetStepsTran, $this->request->data);
            if ($this->BatchsheetStepsTran->save($batchsheetStepsTran)) {
                $this->Flash->success(__('The {0} has been saved.', 'Batchsheet Steps Tran'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Batchsheet Steps Tran'));
            }
        }
        $batchsheetStepsMaster = $this->BatchsheetStepsTran->BatchsheetStepsMaster->find('list', ['limit' => 200]);
        $batchsheetTran = $this->BatchsheetStepsTran->BatchsheetTran->find('list', ['limit' => 200]);
        $weightUoms = $this->BatchsheetStepsTran->WeightUoms->find('list', ['limit' => 200]);
        $distillationUoms = $this->BatchsheetStepsTran->DistillationUoms->find('list', ['limit' => 200]);
        $productWeightUoms = $this->BatchsheetStepsTran->ProductWeightUoms->find('list', ['limit' => 200]);
        $startTimeUoms = $this->BatchsheetStepsTran->StartTimeUoms->find('list', ['limit' => 200]);
        $finishTimeUoms = $this->BatchsheetStepsTran->FinishTimeUoms->find('list', ['limit' => 200]);
        $totalTimeUoms = $this->BatchsheetStepsTran->TotalTimeUoms->find('list', ['limit' => 200]);
        $startTempUoms = $this->BatchsheetStepsTran->StartTempUoms->find('list', ['limit' => 200]);
        $endTempUoms = $this->BatchsheetStepsTran->EndTempUoms->find('list', ['limit' => 200]);
        $this->set(compact('batchsheetStepsTran', 'batchsheetStepsMaster', 'batchsheetTran', 'weightUoms', 'distillationUoms', 'productWeightUoms', 'startTimeUoms', 'finishTimeUoms', 'totalTimeUoms', 'startTempUoms', 'endTempUoms'));
        $this->set('_serialize', ['batchsheetStepsTran']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Batchsheet Steps Tran id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $batchsheetStepsTran = $this->BatchsheetStepsTran->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $batchsheetStepsTran = $this->BatchsheetStepsTran->patchEntity($batchsheetStepsTran, $this->request->data);
            if ($this->BatchsheetStepsTran->save($batchsheetStepsTran)) {
                $this->Flash->success(__('The {0} has been saved.', 'Batchsheet Steps Tran'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Batchsheet Steps Tran'));
            }
        }
        $batchsheetStepsMaster = $this->BatchsheetStepsTran->BatchsheetStepsMaster->find('list', ['limit' => 200]);
        $batchsheetTran = $this->BatchsheetStepsTran->BatchsheetTran->find('list', ['limit' => 200]);
        $weightUoms = $this->BatchsheetStepsTran->WeightUoms->find('list', ['limit' => 200]);
        $distillationUoms = $this->BatchsheetStepsTran->DistillationUoms->find('list', ['limit' => 200]);
        $productWeightUoms = $this->BatchsheetStepsTran->ProductWeightUoms->find('list', ['limit' => 200]);
        $startTimeUoms = $this->BatchsheetStepsTran->StartTimeUoms->find('list', ['limit' => 200]);
        $finishTimeUoms = $this->BatchsheetStepsTran->FinishTimeUoms->find('list', ['limit' => 200]);
        $totalTimeUoms = $this->BatchsheetStepsTran->TotalTimeUoms->find('list', ['limit' => 200]);
        $startTempUoms = $this->BatchsheetStepsTran->StartTempUoms->find('list', ['limit' => 200]);
        $endTempUoms = $this->BatchsheetStepsTran->EndTempUoms->find('list', ['limit' => 200]);
        $this->set(compact('batchsheetStepsTran', 'batchsheetStepsMaster', 'batchsheetTran', 'weightUoms', 'distillationUoms', 'productWeightUoms', 'startTimeUoms', 'finishTimeUoms', 'totalTimeUoms', 'startTempUoms', 'endTempUoms'));
        $this->set('_serialize', ['batchsheetStepsTran']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Batchsheet Steps Tran id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $batchsheetStepsTran = $this->BatchsheetStepsTran->get($id);
        if ($this->BatchsheetStepsTran->delete($batchsheetStepsTran)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Batchsheet Steps Tran'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Batchsheet Steps Tran'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
