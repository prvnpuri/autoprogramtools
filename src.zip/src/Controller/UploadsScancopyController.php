<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;

/**
 * UploadsScancopy Controller
 *
 * @property \App\Model\Table\UploadsScancopyTable $UploadsScancopy
 *
 * @method \App\Model\Entity\UploadsScancopy[] paginate($object = null, array $settings = [])
 */
class UploadsScancopyController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
  /*   public function index()
    {
        $this->paginate = [
            'contain' => ['UploadDocumentList', 'PurchaseOrder', 'Invoices']
        ];
        $uploadsScancopy = $this->paginate($this->UploadsScancopy);

        $this->set(compact('uploadsScancopy'));
        $this->set('_serialize', ['uploadsScancopy']);
    } */

    /**
     * View method
     *
     * @param string|null $id Uploads Scancopy id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $uploadsScancopy = $this->UploadsScancopy->get($id, [
            'contain' => ['UploadDocumentList']
        ]);
     //   debug($uploadsScancopy);
        
       $moduleName=$uploadsScancopy['upload_document_list']['module_name'];
       // $documentName=$uploadsScancopy['document_name'];
        $isLocal=$uploadsScancopy['upload_document_list']['is_local'];
        if($moduleName=="PurchaseOrder")
        {
        	$this->loadModel('Invoices');
        	$purchaseOrder = $this->Invoices->get($uploadsScancopy['invoice_id'], [
        			'contain' => []
        	]);
        	$invoice_number=$purchaseOrder['invoice_no'];
        }
        $this->set('uploadsScancopy', $uploadsScancopy);
        $this->set('invoice_number', $invoice_number);
        
        $this->set('_serialize', ['uploadsScancopy']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($id,$document_id)
    {
    	
    	$this->loadModel('UploadDocumentList');
    	$uploadsdoc = $this->UploadDocumentList->get($document_id, [
    	
    	]);
    	//$document_id=$uploadsdoc['id'];
    	$moduleName=$uploadsdoc['module_name'];
    	$documentName=$uploadsdoc['document_name'];
    	$isLocal=$uploadsdoc['is_local'];
    	//debug($uploadsdoc);
    	/* if($moduleName=="PurchaseOrder")
    	{
    		$this->loadModel('PurchaseOrder');
    		$purchaseOrder = $this->PurchaseOrder->get($id, [
    				'contain' => []
    		]);
    		 
    		$PO_number=$purchaseOrder['po_number'];
    	} */
    	$this->loadModel('Invoices');
    	$Invoices = $this->Invoices->get($id, [
    			'contain' => []
    	]);
    	$invoice_number=$Invoices['invoice_no'];
    	 
        $uploadsScancopy = $this->UploadsScancopy->newEntity();
        if ($this->request->is('post')) {
        	
            $uploadsScancopy = $this->UploadsScancopy->patchEntity($uploadsScancopy, $this->request->data);
            $uploadsScancopy['created_by'] = $this->Auth->User('id');
            $uploadsScancopy['file_name'] = $this->request->data['file_name']['name'];
            
          //	echo '<pre>',print_r($uploadsScancopy);

            if ($this->UploadsScancopy->save($uploadsScancopy)) {
            	
                    unset($this->request->data['upload_document_id']);
		            foreach ($this->request->data['file_name'] as $key => $d ) {
		            
		            	if(isset($d["name"]) &&  $d["error"]==0)
		            	{
		            		$filename=$d["name"];
		            		$url = Router::url('/',true).'upload/scancopy/purchasedoc/'.$filename;
		            		$uploadpath = 'upload/scancopy/purchasedoc/';
		            		$uploadfile = $uploadpath.$filename;
		            		move_uploaded_file($d['tmp_name'], $uploadfile);
		            
		            	}/* else{
		            		unset($d["upload_document_id"]);
		            	}  */
		            }
            // 	echo $moduleName;die;
		            if($moduleName=="PurchaseOrder")
		            {	
		            	$controllerName="invoices";
		            	$action="po-document";
		            }
            	
                $this->Flash->success(__('The {0} has been saved.', 'Uploads Scancopy'));
                return $this->redirect(['controller'=>$controllerName,'action' => $action,$isLocal,$id]);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Uploads Scancopy'));
            }
        }
        

      		//id is nothing but po_id or invoice_id
		$this->set(compact('uploadsScancopy','moduleName','documentName','id','document_id','isLocal','invoice_number'));
        $this->set('_serialize', ['uploadsScancopy']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Uploads Scancopy id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $uploadsScancopy = $this->UploadsScancopy->get($id, [
            'contain' => ['UploadDocumentList']
        		]);
        
        $moduleName=$uploadsScancopy['upload_document_list']['module_name'];
        $documentName=$uploadsScancopy['upload_document_list']['document_name'];
        $isLocal=$uploadsScancopy['upload_document_list']['is_local'];
        if($moduleName=="PurchaseOrder")
        {
        	$this->loadModel('Invoices');
        	$invoices = $this->Invoices->get($uploadsScancopy['invoice_id'], [
        			'contain' => []
        	]);
        	
        	$invoice_number=$invoices['invoice_no'];
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
        	
            $uploadsScancopy = $this->UploadsScancopy->patchEntity($uploadsScancopy, $this->request->data);
            $uploadsScancopy['file_name'] = $this->request->data['file_name']['name'];
            
            if ($this->UploadsScancopy->save($uploadsScancopy)) {
            	
            	
            	unset($this->request->data['upload_document_id']);
            	echo '<pre>',print_r($this->request->data);
            	foreach ($this->request->data as $key => $d ) {
            		//echo '@@@'.$d["error"].'#########'.$d["name"];
            		if(isset($d["name"]) &&  $d["error"]==0)
            		{
            			$filename=$d["name"];
            			$url = Router::url('/',true).'upload/scancopy/purchasedoc/'.$filename;
            			$uploadpath = 'upload/scancopy/purchasedoc/';
            			$uploadfile = $uploadpath.$filename;
            			move_uploaded_file($d['tmp_name'], $uploadfile);
            			//die;
            		} else{
            			//echo 'sf';die;
            		//unset($d["upload_document_id"]);
            		}  
            	}
            	//die;
            	// 	echo $moduleName;die;
            	if($moduleName=="PurchaseOrder")
            	{
            		$controllerName="invoices";
            		$action="po-document";
            	}
            	 
            	$this->Flash->success(__('The {0} has been saved.', 'Uploads Scancopy'));
            	return $this->redirect(['controller'=>$controllerName,'action' => $action,$isLocal,$id]);
            	
                
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Uploads Scancopy'));
            }
        }
       // $uploadDocuments = $this->UploadsScancopy->UploadDocuments->find('list', ['limit' => 200]);
        //$pos = $this->UploadsScancopy->Pos->find('list', ['limit' => 200]);
        //$invoices = $this->UploadsScancopy->Invoices->find('list', ['limit' => 200]);
        $this->set(compact('uploadsScancopy','invoice_number'));
        $this->set('_serialize', ['uploadsScancopy']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Uploads Scancopy id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
 			$uploadsScancopy = $this->UploadsScancopy->get($id, [
            'contain' => ['UploadDocumentList']
        		]);
        
        $moduleName=$uploadsScancopy['upload_document_list']['module_name'];
        $documentName=$uploadsScancopy['upload_document_list']['document_name'];
        $isLocal=$uploadsScancopy['upload_document_list']['is_local'];        
        
        if ($this->UploadsScancopy->delete($uploadsScancopy)) {
        	
            $this->Flash->success(__('The {0} has been deleted.', 'Uploads Scancopy'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Uploads Scancopy'));
        }
        if($moduleName=="PurchaseOrder")
        {
        	$controllerName="invoices";
        	$action="po-document";
        }
        return $this->redirect(['controller'=>$controllerName,'action' => $action,$isLocal,$id]);
    }
}
