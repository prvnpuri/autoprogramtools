<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Cache\Cache;
use Cake\Core\Configure;
use Cake\Mailer\Email;
use Cake\ORM\toArray;
use PhpParser\Node\Stmt\Foreach_;

/**
 * PurchaseOrder Controller
 *
 *
 * @method \App\Model\Entity\PurchaseOrder[] paginate($object = null, array $settings = [])
 */
class PurchaseOrderController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
	public function index()
	{
		//$purchaseOrder = $this->paginate($this->PurchaseOrder);
		$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
	
		$condn=array('PurchaseOrder.owner_companies_id'=>$ownercomp);
		$purchaseOrder = $this->PurchaseOrder->find('all',[
				/* 'fields'=>['po_date','OwnerCompanies.Company_name','po_number','quantity_ordered','rate','total_order_price','IncoTerms.inco_term','Uom.unit_symbol','CompanyMaster.Company_name','ProductsMaster.product_name','send_to_doc','send_to_invoice','id','Uom.unit_symbol',
				 'Currency.sign','status','inward_status','send_to_inward'
				], */
				'conditions'=>[['purchase_type'=>'Chemical Product'],$condn],
				'contain'=>['PurchaseOrderProducts',"PurchaseOrderProducts.ProductsMaster","PurchaseOrderProducts.Uom","PurchaseOrderProducts.Currency",'CompanyMaster','CompanyMaster','IncoTerms','OwnerCompanies','PurchaseOrderProducts.PackingMaster','PurchaseOrderProducts.PackingMaster.PackingType'],
				'order'=>['PurchaseOrder.id' => 'DESC'],
				 
		]);
	
		$this->set(compact('purchaseOrder'));
		$this->set('_serialize', ['purchaseOrder']);
		 
	}
    
    //Pending Po for Inward
    
    public function pendingPoOrder()
    {
    	//$purchaseOrder = $this->paginate($this->PurchaseOrder);
    
    	$purchaseOrder = $this->PurchaseOrder->find('all',[
    			'fields'=>['po_date','OwnerCompanies.Company_name','invoice_qty','balance_qty','OwnerCompanies.id','is_local','po_number','Currency.sign','quantity_ordered','rate','total_order_price','IncoTerms.inco_term','Uom.unit_symbol','CompanyMaster.Company_name','CompanyMaster.id','ProductsMaster.product_name','send_to_doc','id'],
    			'conditions'=>['packingMaster_id IS NULL','Send_to_invoice'=>'YES'],
    			'contain'=>['CompanyMaster','ProductsMaster','Uom','Currency','CompanyMaster','IncoTerms','OwnerCompanies'],
    			'order'=>['PurchaseOrder.id' => 'DESC']]);
//     	/debug($purchaseOrder);
    	 
    	
    	$this->loadModel('InvoiceTypes');
    	$invoiceTypes= $this->InvoiceTypes->find("list",[
    			"keyField"=>"id",
    			"valueField"=>"type",
    			"conditions"=>"type like 'Purchase%'",
    	]);
    	
    	 
    	
    	//echo $cnt;die;
    		//	debug($uploadsdoc);
    	/* foreach ($purchaseOrder as $keys=>$vals){
    		
    	
	    	
	    	
	    	
	    	
	    	debug($uploadsdoc);
    	} */
    	$this->set(compact('purchaseOrder','invoiceTypes'));
    	$this->set('_serialize', ['purchaseOrder']);
    }
    //Pending Po for Inward
    
    public function docIndex()
    {
    	//$purchaseOrder = $this->paginate($this->PurchaseOrder);
    
    	$purchaseOrder = $this->PurchaseOrder->find('all',[
    			'fields'=>['po_date','OwnerCompanies.Company_name','po_number','quantity_ordered','rate','total_order_price','IncoTerms.inco_term','Uom.unit_symbol','CompanyMaster.Company_name','ProductsMaster.product_name','send_to_doc','id'],
    			'conditions'=>['packingMaster_id IS NULL','inward_status'=>'YES'],
    			'contain'=>['CompanyMaster','ProductsMaster','Uom','CompanyMaster','IncoTerms','OwnerCompanies'],
    			'order'=>['PurchaseOrder.id' => 'DESC']]);
    
    	$this->set(compact('purchaseOrder'));
    	
    	$this->set('_serialize', ['purchaseOrder']);
    }

    public function printPo($POId)
    {
    	$this->view($POId);
    	$this->viewBuilder()->setLayout("blank");
    	
    }
    public function printPoConsumable($POId)
    {
    	$this->viewConsumable($POId);
    	$this->viewBuilder()->setLayout("blank");
    	 
    }
    
    public function printPoPacking($POId)
    {
    	$this->viewPacking($POId);
    	$this->viewBuilder()->setLayout("blank");
    	 
    }
    public function indexPacking()
    {
    	//$purchaseOrder = $this->paginate($this->PurchaseOrder);
    
    	$purchaseOrder = $this->PurchaseOrder->find('all',[
    			'fields'=>['status','po_date','OwnerCompanies.Company_name','po_number','quantity_ordered','rate','total_order_price','IncoTerms.inco_term','Uom.unit_symbol','CompanyMaster.Company_name','PackingMaster.specification','PackingMaster.color','send_to_doc','id',
    					'PackingType.packing_type','Currency.sign'
    			],
    			'conditions'=>['product_id IS NULL'],
    			'contain'=>['CompanyMaster','PackingMaster','PackingMaster.PackingSubType', 'PackingMaster.PackingType','Uom','CompanyMaster','IncoTerms','OwnerCompanies','Currency'],
    			'order'=>['PurchaseOrder.id' => 'DESC']]);
    
    	$this->set(compact('purchaseOrder'));
    	$this->set('_serialize', ['purchaseOrder']);
    }
    
    public function indexConsumable()
    {
    	//$purchaseOrder = $this->paginate($this->PurchaseOrder);
    	$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
    	 
    	$condn=array('PurchaseOrder.owner_companies_id'=>$ownercomp);
    	$purchaseOrder = $this->PurchaseOrder->find('all',[
    			/* 'fields'=>['po_date','OwnerCompanies.Company_name','po_number','quantity_ordered','rate','total_order_price','IncoTerms.inco_term','Uom.unit_symbol','CompanyMaster.Company_name','ProductsMaster.product_name','send_to_doc','send_to_invoice','id','Uom.unit_symbol',
    					'Currency.sign','status','inward_status','send_to_inward'
    			], */
    			'conditions'=>[['purchase_type'=>'Consumable'],$condn],
    			'contain'=>['PurchaseOrderProducts',"PurchaseOrderProducts.ConsumablesMaster","PurchaseOrderProducts.Uom","PurchaseOrderProducts.Currency",'CompanyMaster','CompanyMaster','IncoTerms','OwnerCompanies','PurchaseOrderProducts.PackingMaster','PurchaseOrderProducts.PackingMaster.PackingType'],
    			'order'=>['PurchaseOrder.id' => 'DESC'],
    			
    	]);
    
    			$this->set(compact('purchaseOrder'));
    			$this->set('_serialize', ['purchaseOrder']);
    			
    }
    /**
     * View method
     *
     * @param string|null $id Purchase Order id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
    	$purchaseOrder = $this->PurchaseOrder->get($id, [
    			/* 'fields'=>['PurchaseOrder.po_number','PurchaseOrder.po_date','OwnerCompanies.Company_name','Uom.unit_symbol',
    			 'city.city_name','IncoTerms.inco_term','CompanyMaster.Company_name','rate','total_order_price',
    					'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no'], */
    
    			'contain' => ['CountryOfOriginOfGood','CountryOfFinalDestination','PortOfDischarge','SupplierOffer','OwnerCompanies','CompanyMaster','CompanyMaster.CompanyContactPersons','CompanyMaster.CompanySublocation','PackingTerm','PaymentTerm',
    					'CompanyMaster.CompanySublocation.City','CompanyMaster.CompanySublocation.Countries','CompanyMaster.CompanySublocation.State'	,'OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerCompanyOffices.State','CompanyMaster','IncoTerms','PurchaseOrderProducts',"PurchaseOrderProducts.ProductsMaster","PurchaseOrderProducts.Uom","PurchaseOrderProducts.Currency",'PurchaseOrderProducts.PackingMaster','PurchaseOrderProducts.PackingMaster.PackingType']
    	]);
    
    	$this->loadModel('CompanyMaster');
    	$consingee = $this->CompanyMaster->find('all',
    			[		'contain' => ['CompanySublocation.City','CompanySublocation.Countries','CompanySublocation.State'],
    					'conditions'=>['id'=>$purchaseOrder->consignee_id]
    
    			])->toArray();
    			$this->set('consingee', $consingee);
    
    			$this->set('purchaseOrder', $purchaseOrder);
    			$this->set('_serialize', ['purchaseOrder']);
    
    
    }

    
    /**
     * View method
     *
     * @param string|null $id Purchase Order id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function viewPacking($id = null)
    {
    	$purchaseOrder = $this->PurchaseOrder->get($id, [
    			/* 'fields'=>['PurchaseOrder.po_number','PurchaseOrder.po_date','OwnerCompanies.Company_name','Uom.unit_symbol',
    			 'city.city_name','IncoTerms.inco_term','CompanyMaster.Company_name','rate','total_order_price',
    					'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no'], */
    
    			'contain' => ['CountryOfOriginOfGood','CountryOfFinalDestination','PortOfDischarge','SupplierOffer','OwnerCompanies','CompanyMaster','CompanyMaster.CompanyContactPersons','CompanyMaster.CompanySublocation','PackingTerm','PaymentTerm',
    					'CompanyMaster.CompanySublocation.City','CompanyMaster.CompanySublocation.Countries','CompanyMaster.CompanySublocation.State'	,'OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerCompanyOffices.State','ProductsMaster','CompanyMaster','Uom','Currency','IncoTerms']
    	]);
    
    	$this->loadModel('CompanyMaster');
    	$consingee = $this->CompanyMaster->find('all',
    			[		'contain' => ['CompanySublocation.City','CompanySublocation.Countries','CompanySublocation.State'],
    					'conditions'=>['id'=>$purchaseOrder->consignee_id]
    					 
    			])->toArray();
    			$this->set('consingee', $consingee);
    
    			$this->set('purchaseOrder', $purchaseOrder);
    			$this->set('_serialize', ['purchaseOrder']);
    
    			 
    }
    
    public function viewConsumable($id = null)
    {
    	$purchaseOrder = $this->PurchaseOrder->get($id, [
    			/* 'fields'=>['PurchaseOrder.po_number','PurchaseOrder.po_date','OwnerCompanies.Company_name','Uom.unit_symbol',
    			 'city.city_name','IncoTerms.inco_term','CompanyMaster.Company_name','rate','total_order_price',
    					'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no'], */
    
    			'contain' => ['CountryOfOriginOfGood','CountryOfFinalDestination','PortOfDischarge','SupplierOffer','OwnerCompanies','CompanyMaster','CompanyMaster.CompanyContactPersons','CompanyMaster.CompanySublocation','PackingTerm','PaymentTerm',
    					'CompanyMaster.CompanySublocation.City','CompanyMaster.CompanySublocation.Countries','CompanyMaster.CompanySublocation.State'	,'OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerCompanyOffices.State','CompanyMaster','IncoTerms','PurchaseOrderProducts',"PurchaseOrderProducts.ConsumablesMaster","PurchaseOrderProducts.Uom","PurchaseOrderProducts.Currency",'PurchaseOrderProducts.PackingMaster','PurchaseOrderProducts.PackingMaster.PackingType']
    	]);
    
    	$this->loadModel('CompanyMaster');
    	$consingee = $this->CompanyMaster->find('all',
    			[		'contain' => ['CompanySublocation.City','CompanySublocation.Countries','CompanySublocation.State'],
    					'conditions'=>['id'=>$purchaseOrder->consignee_id]
    					 
    			])->toArray();
    			$this->set('consingee', $consingee);
    
    			$this->set('purchaseOrder', $purchaseOrder);
    			$this->set('_serialize', ['purchaseOrder']);
    
    			 
    }
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $purchaseOrder = $this->PurchaseOrder->newEntity();
        if ($this->request->is('post')) {
            $purchaseOrder = $this->PurchaseOrder->patchEntity($purchaseOrder, $this->request->data);
            if ($this->PurchaseOrder->save($purchaseOrder)) {
                $this->Flash->success(__('The {0} has been saved.', 'Purchase Order'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Order'));
            }
        }
        $this->set(compact('purchaseOrder'));
        $this->set('_serialize', ['purchaseOrder']);
    }

	public function sendtodocumentation($id){
		
		//echo $id;die;
		$purchaseOrder = $this->PurchaseOrder->get($id, [
				'contain' => []
		]);
		//echo '<pre>',print_r($purchaseOrder);die;
		
		$data = array('id' => $id , 'send_to_doc' => "YES");
		//print_r($data);die;
		if($this->PurchaseOrder->patchEntity($purchaseOrder,$data)){
			//echo '<pre>',print_r($data);
		//	print_r($purchaseOrder);die;
			$this->PurchaseOrder->save($purchaseOrder);
			
			$this->Flash->success(__('Order has been sent to Documents.', 'Purchase Order'));
			return $this->redirect(['action' => 'index']);
			
			
		}else{
				
			$this->Flash->success(__('Order has not 	been sent to Documents.', 'Purchase Order'));
				
		}
	}
	public function sendtoinvoice($id){
	
		//echo $id;die;
		$purchaseOrder = $this->PurchaseOrder->get($id, [
				'contain' => []
		]);
		//echo '<pre>',print_r($purchaseOrder);die;
	
		$data = array('id' => $id , 'send_to_invoice' => "YES");
		//print_r($data);die;
		if($this->PurchaseOrder->patchEntity($purchaseOrder,$data)){
			//echo '<pre>',print_r($data);die;
			//	print_r($purchaseOrder);die;
			$this->PurchaseOrder->save($purchaseOrder);
				
			$this->Flash->success(__('Order has been sent to Invoice.', 'Purchase Order'));
			return $this->redirect(['action' => 'index']);
				
				
		}else{
	
			$this->Flash->success(__('Order has not 	been sent to Invoice.', 'Purchase Order'));
	
		}
	}
	public function sendtoinward($id,$type){
	
        if($type=="Consumable"){
        	$action="index-consumable";
        }else{
        	$action="index";
        }

		$purchaseOrder = $this->PurchaseOrder->get($id, [
				'contain' => []
		]);
		
		$data = array('id' => $id , 'send_to_inward' => "Y");
		
		if($this->PurchaseOrder->patchEntity($purchaseOrder,$data)){
			$this->PurchaseOrder->save($purchaseOrder);
			$this->Flash->success(__('Purchase Order has been sent to Inward.'));
			return $this->redirect(['action' => $action]);
	
	
		}else{
	
			$this->Flash->success(__('Purchase Order has not been sent to Inward.'));
	
		}
	}
	public function sendEmail($id=null,$sendMail=null){
		//$this->generatePdf($id);
	
		if($sendMail==null){
			return $this->redirect(array("action"=>"sendEmail",$id,0));
		}
		$template='purchaseordermail';
		$purchaseOrder = $this->PurchaseOrder->get($id, [
				/*'fields'=>['po_number','po_file','id','po_date','supplier_id','consignee_id','OwnerCompanies.Company_name','OwnerCompanies.company_email','Uom.unit_symbol','dispatch_through','destination',
				 'IncoTerms.inco_term','CompanyMaster.Company_name','quantity_ordered','delivery','delivery_to','required_by_us',
						'rate','total_order_price','your_ref_no','packing_terms','payment_terms','port_of_discharge','country_final_destination','country_of_origin_of_goods',
						'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no','SupplierOffer.supplier_inquiry_id'],
		*/
				'contain' => ['CountryOfOriginOfGood','CountryOfFinalDestination','PortOfDischarge','SupplierOffer','OwnerCompanies','CompanyMaster','CompanyMaster.CompanyContactPersons','CompanyMaster.CompanySublocation','PackingTerm','PaymentTerm',
						'CompanyMaster.CompanySublocation.City','CompanyMaster.CompanySublocation.Countries','CompanyMaster.CompanySublocation.State'	,'OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerCompanyOffices.State','CompanyMaster','IncoTerms','PurchaseOrderProducts',"PurchaseOrderProducts.ProductsMaster","PurchaseOrderProducts.Uom","PurchaseOrderProducts.Currency",'PurchaseOrderProducts.PackingMaster','PurchaseOrderProducts.PackingMaster.PackingType']
		])->toArray();
		// test email view
		//echo '<pre>',print_r($purchaseOrder);
		$this->loadModel('SupplierInquiry');
		 $supplierInquiry=$this->SupplierInquiry->find(
		 		'all',
		 		[
		 				'fields' => ['SupplierInquiry.company_contact_persons","cc_email'],
		 				'conditions'=>['id'=>$purchaseOrder['supplier_offer']['supplier_inquiry_id']]
		 				 
		 		]
		 		
		 		
		); 
		
		//echo $purchaseOrder['supplier_id'];die;
		$OwnerCompany=$purchaseOrder['owner_company'];
		//echo '<pre>',print_r($PurchaseOrder);die;
		//Get owner company contact person
		$buyercontact=isset($OwnerCompany['owner_contact_persons'])?$OwnerCompany['owner_contact_persons'][0]['user']['userfullname']:'';
		
			$purchaseOrder['buyercontact']=$buyercontact;
		
    		$this->loadModel('CompanyMaster');
    		$this->loadModel('CompanyContactPersons');
    		$companyOne =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $purchaseOrder['supplier_id']])->contain(['CompanyContactPersons','CompanySublocation','CompanySublocation.City','CompanySublocation.State','CompanySublocation.Countries']);
    		$CompanyMaster = $companyOne->first();
    		
    		
    		$companycontactIdval=isset($purchaseOrder->supplier_offer->supplier_inquiry->company_contact_persons)?$purchaseOrder->supplier_offer->supplier_inquiry->company_contact_persons:"";
    		$companycontactIds=explode(",",$companycontactIdval);
    		//echo '<pre>',print_r($companycontactIds);
    		
    		$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $purchaseOrder['supplier_id']])->
    		contain([
    				'CompanyContactPersons' => function ($q)use ($companycontactIds){
    				return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
    				},
    		
    		
    				])->toArray();
    		//echo '<pre>',print_r($companyMaster);
    		
    		$suppliercontact = "";
    		$supplieremail = array();
    		$vpercount=0;
    		foreach ($CompanyMaster["company_contact_persons"] as $contact["CompanyContactPerson"]){
    			$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
    					ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
    					ucfirst($contact["CompanyContactPerson"]["last_name"]);
    					if(trim($personname," ")!=""){
    						$suppliercontact.=$vpercount>0?",":"";
    						$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
    						$vpercount++;
    					}
    
    					$contactemail=$contact["CompanyContactPerson"]["email_id"];
    
    					if(trim($contactemail," ")!=""){
    						array_push($supplieremail, $contactemail);
    					}else{
    						//$this->Flash->error(__("Please check email_id for contact_name is not valid email."));
    						
    						$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
	                		//return $this->redirect(['action' => 'index']);
    					}
    		}
    
    		//debug($suppliercontact);exit;
    		$purchaseOrder['CompanyMaster']=$CompanyMaster;
    		$purchaseOrder['suppliercontact']=$suppliercontact;
    	//	echo '<pre>',print_r($supplieremail);
		//check suppliermails =0
		if(count($contactemail)==0){
			$this->Session->setFlash("Please Select atleast one email id.");
			return $this->redirect(array("action"=>"edit",$id));
		}
		$cc=array();
		
		/* if(isset( $supplierInquiry->cc_email)){
			if(trim($supplierInquiry->cc_email," ")!=""&&Validation::email(trim($supplierInquiry->cc_email," "))){
				$cc[]=$supplierInquiry->cc_email;
			}else{
				$this->Session->setFlash("Please check CC email id form Supplier Inquiry ".$supplierInquiry["SupplierInquiry"]["id"].".");
				return $this->redirect(array("action"=>"edit",$id));
			}
		} */
	
		/******Test View : To check email layout********************
		 foreach ($purchaseOrder as $k => $var){
		 $this->set($k,$var);
		 };
		 $this->layout='Emails/html/purchaseordermailtemplate';
		 $this->render('../Emails/html/purchaseordermail');
		 return true;
		 /*******Test View : End*************************************/
	
		//echo '<pre>',print_r($cc);
		$buyermail=$purchaseOrder['owner_company']['company_email'];
	
		//echo '<pre>',print_r($buyercontact);
	//	echo '<pre>',print_r($suppliercontact);
		if(!isset($buyermail)){
			$this->Session->setFlash('Buyer company not have valid email id.');
		} 
		$to = array();
		if(Configure::read("productionMode")){
				
			/*******Production Mode*******************/
			$to=$supplieremail;
			$cc=$purchaseOrder['supplier_offer']['supplier_inquiry']['cc_email'];
		}else{
			/*******Dev Mode*******************/
			$to=array('smile.patil@pitonsystems.com');
			$cc=array("smile.sp28@gmail.com");
			/**************************/
		}
		//$attachedFile='';
		
		$attachedFile=WWW_ROOT.DS.'upload'. DS.'purchase-order'.DS.$purchaseOrder['id'].'_'.$purchaseOrder['owner_companies_id'].'.pdf';
		/* $url = Router::url('/',true).'upload/purchase-order/'.$filename;
		$uploadpath = 'upload/visiting-cards/';
		$uploadfile = $uploadpath.$filename;
		
		$attachedFile=WWW_ROOT.$this->PurchaseOrder->getFileName($id,$purchaseOrder['po_file']); */
		$attachedFileLabel="PurchaseOrder_".$id."_from_".$purchaseOrder['owner_company']['Company_name']."_po_file.".pathinfo($attachedFile,PATHINFO_EXTENSION);
		$subject=	'Purchase Order from '.$OwnerCompany['Company_name'];
		//echo '@@'.$sendMail;die;
		/// for send email and preview
		if( isset($sendMail)&& $sendMail==1){
			/// send email
			
			
			$email = new Email('default');
			
			if(file_exists($attachedFile)){
				$email->attachments( array($attachedFileLabel=> $attachedFile));
			}
			$email			
			->template('purchaseordermail','purchaseordermail')
			->from($buyermail)
			->to($to)
			->cc($cc)
			//->bcc($bcc)
			->subject($subject)
			->emailFormat('html')
			->viewVars($purchaseOrder);
			//->send('sendmail');
				
				
			if ($email->send()) {
			
				//-------------- Make isoffered field in inquiry table true --------------------
			
				/* $inquiry = $this->Inquiry->get($off['inquiry_id']);
				$data = array('id' => $off['inquiry_id'], 'isoffered' => true);
				$inquiry = $this->Inquiry->patchEntity($inquiry, $data);
				$this->Inquiry->save($inquiry); */
			
				//--------------------------------------------------------------------------------------------------
				//------------- Make status field of offer table submitted ---------------
			
			
				$po = $this->PurchaseOrder->get($purchaseOrder['id']);
				$data = array('id' => $purchaseOrder['id'], 'status' => 1);
				$offer = $this->PurchaseOrder->patchEntity($po, $data);
				$this->PurchaseOrder->save($offer);
			
				$this->Flash->success(__('The {0} has been sent successfully.', "PurchaseOrder"));
				return $this->redirect(['action' => 'index']);
			} else {
				$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "PurchaseOrder"));
			}
			
			
			

				
		}else{
				
			//email preview
// 				/debug($OwnerCompany);
			foreach ($purchaseOrder as  $key=> $data ){
				$this->set($key,$data);
			}
			if(file_exists($attachedFile)){
				$this->set("attachments",array(
						$attachedFileLabel=> array(
								"controller"=>"upload",
								"action"=>"purchase_order",
								$purchaseOrder['id'].'_'.$purchaseOrder['owner_companies_id'].'.pdf')
				)
						);
			}
			$this->set("mails",array(
					"from"=>$buyermail,
					"to" =>$to,
					"cc" => $cc,
					"subject"=>$subject
			));
				
			$this->set("title_for_layout","Purchase order.");
			$this->set("mailSendAction",array(
					"send"=>array("action"=>"sendEmail",$id,1),
					"cancel"=>array("action"=>"index")
			));
			
				
			$this->viewBuilder()->setLayout("/Email/html/emailpreview");
			$this->render('/Email/html/purchaseordermail');
			
			
		}
	}
	
	
	public function sendEmailPacking($id=null,$sendMail=null){
		if($sendMail==null){
			return $this->redirect(array("action"=>"sendEmailPacking",$id,0));
		}
		$template='purchaseordermail';
		$purchaseOrder = $this->PurchaseOrder->get($id, [
				/*'fields'=>['po_number','po_file','id','po_date','supplier_id','consignee_id','OwnerCompanies.Company_name','OwnerCompanies.company_email','Uom.unit_symbol','dispatch_through','destination',
				 'IncoTerms.inco_term','CompanyMaster.Company_name','quantity_ordered','delivery','delivery_to','required_by_us',
						'rate','total_order_price','your_ref_no','packing_terms','payment_terms','port_of_discharge','country_final_destination','country_of_origin_of_goods',
						'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no','SupplierOffer.supplier_inquiry_id'],
		*/
				'contain' => ['OwnerCompanies','SupplierOffer','SupplierOffer.SupplierInquiry','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerContactPersons.Users','OwnerCompanies.OwnerCompanyOffices','OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerCompanyOffices.State','OwnerCompanies.OwnerCompanyOffices.Countries','ProductsMaster',
						'CompanyMaster','IncoTerms','Uom','Currency','SupplierOffer','PackingMaster','PackingMaster.PackingType','PackingMaster.PackingSubtype']
		])->toArray();
		// test email view
		//echo '<pre>',print_r($purchaseOrder);
		$this->loadModel('SupplierInquiry');
		$supplierInquiry=$this->SupplierInquiry->find(
				'all',
				[
						'fields' => ['SupplierInquiry.company_contact_persons","cc_email'],
						'conditions'=>['id'=>$purchaseOrder['supplier_offer']['supplier_inquiry_id']]
	
				]
				 
				 
				);
	
		//echo $purchaseOrder['supplier_id'];die;
		$OwnerCompany=$purchaseOrder['owner_company'];
		$buyercontact=$OwnerCompany['owner_contact_persons'][0]['user']['userfullname'];
	
		$purchaseOrder['buyercontact']=$buyercontact;
	
		$this->loadModel('CompanyMaster');
		$this->loadModel('CompanyContactPersons');
		$companyOne =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $purchaseOrder['supplier_id']])->contain(['CompanyContactPersons','CompanySublocation','CompanySublocation.City','CompanySublocation.State','CompanySublocation.Countries']);
		$CompanyMaster = $companyOne->first();
	
	
		$companycontactIdval=isset($purchaseOrder->supplier_offer->supplier_inquiry->company_contact_persons)?$purchaseOrder->supplier_offer->supplier_inquiry->company_contact_persons:"";
		$companycontactIds=explode(",",$companycontactIdval);
	
		$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $purchaseOrder['supplier_id']])->
		contain([
				'CompanyContactPersons' => function ($q)use ($companycontactIds){
				return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
				},
	
	
				])->toArray();
				//echo '<pre>',print_r($companyMaster);
	
				$suppliercontact = "";
				$supplieremail = array();
				$vpercount=0;
				foreach ($CompanyMaster["company_contact_persons"] as $contact["CompanyContactPerson"]){
					$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
							ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
							ucfirst($contact["CompanyContactPerson"]["last_name"]);
							if(trim($personname," ")!=""){
								$suppliercontact.=$vpercount>0?",":"";
								$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
								$vpercount++;
							}
	
							$contactemail=$contact["CompanyContactPerson"]["email_id"];
	
							if(trim($contactemail," ")!=""){
								array_push($supplieremail, $contactemail);
							}else{
								//$this->Flash->error(__("Please check email_id for contact_name is not valid email."));
	
								$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
								//return $this->redirect(['action' => 'index']);
							}
				}
	
				//debug($suppliercontact);exit;
				$purchaseOrder['CompanyMaster']=$CompanyMaster;
				$purchaseOrder['suppliercontact']=$suppliercontact;
				//	echo '<pre>',print_r($supplieremail);
				//check suppliermails =0
				if(count($contactemail)==0){
					$this->Session->setFlash("Please Select atleast one email id.");
					return $this->redirect(array("action"=>"edit",$id));
				}
				$cc=array();
	
				/******Test View : To check email layout********************
				 foreach ($purchaseOrder as $k => $var){
				 $this->set($k,$var);
				 };
				 $this->layout='Emails/html/purchaseordermailtemplate';
				 $this->render('../Emails/html/purchaseordermail');
				 return true;
				 /*******Test View : End*************************************/
	
				//echo '<pre>',print_r($cc);
				$buyermail=$purchaseOrder['owner_company']['company_email'];
	
				//echo '<pre>',print_r($buyercontact);
				//	echo '<pre>',print_r($suppliercontact);
				if(!isset($buyermail)){
					$this->Session->setFlash('Buyer company not have valid email id.');
				}
				$to = array();
				if(Configure::read("productionMode")){
	
					/*******Production Mode*******************/
					$to=$supplieremail;
					$cc=$purchaseOrder['supplier_offer']['supplier_inquiry']['cc_email'];
				}else{
					/*******Dev Mode*******************/
					$to=array('dkvastrakar18@gmail.com');
					$cc=array("dkvastrakar18@gmail.com");
					/**************************/
				}
				//$attachedFile='';
	
				$attachedFile=WWW_ROOT.DS.'upload'. DS.'purchase-order'.DS.'packing_product'.DS.$purchaseOrder['id'].'_'.$purchaseOrder['owner_companies_id'].'.pdf';
                $attachedFileLabel="PurchaseOrder_".$id."_from_".$purchaseOrder['owner_company']['Company_name']."_po_file.".pathinfo($attachedFile,PATHINFO_EXTENSION);
				$subject=	'Purchase Order from '.$OwnerCompany['Company_name'];
			
				/// for send email and preview
				if( isset($sendMail)&& $sendMail==1){
					/// send email
						
						
					$email = new Email('default');
						
					if(file_exists($attachedFile)){
						$email->attachments( array($attachedFileLabel=> $attachedFile));
					}
					$email
					->template('purchaseordermail_packing','purchaseordermail_packing')
					->from($buyermail)
					->to($to)
					->cc($cc)
					//->bcc($bcc)
					->subject($subject)
					->emailFormat('html')
					->viewVars($purchaseOrder);
					//->send('sendmail');
	
	
					if ($email->send()) {
							
						//-------------- Make isoffered field in inquiry table true --------------------
							
						/* $inquiry = $this->Inquiry->get($off['inquiry_id']);
						 $data = array('id' => $off['inquiry_id'], 'isoffered' => true);
						 $inquiry = $this->Inquiry->patchEntity($inquiry, $data);
						 $this->Inquiry->save($inquiry); */
							
						//--------------------------------------------------------------------------------------------------
						//------------- Make status field of offer table submitted ---------------
							
							
						$po = $this->PurchaseOrder->get($purchaseOrder['id']);
						$data = array('id' => $purchaseOrder['id'], 'status' => 1);
						$offer = $this->PurchaseOrder->patchEntity($po, $data);
						$this->PurchaseOrder->save($offer);
							
						$this->Flash->success(__('The {0} has been sent successfully.', "PurchaseOrder"));
						return $this->redirect(['action' => 'index_packing']);
					} else {
						$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "PurchaseOrder"));
					}
						
						
						
	
	
				}else{
	
					//email preview
					//debug($OwnerCompany);
					foreach ($purchaseOrder as  $key=> $data ){
						$this->set($key,$data);
					}
					if(file_exists($attachedFile)){
						$this->set("attachments",array(
								$attachedFileLabel=> array(
										"controller"=>"upload",
										"action"=>"purchase_order","packing_product",
										$purchaseOrder['id'].'_'.$purchaseOrder['owner_companies_id'].'.pdf')
						)
								);
					}
					$this->set("mails",array(
							"from"=>$buyermail,
							"to" =>$to,
							"cc" => $cc,
							"subject"=>$subject
					));
	
					$this->set("title_for_layout","Purchase order.");
					$this->set("mailSendAction",array(
							"send"=>array("action"=>"sendEmailPacking",$id,1),
							"cancel"=>array("action"=>"index_packing")
					));
						
	
					$this->viewBuilder()->setLayout("/Email/html/emailpreview");
					$this->render('/Email/html/purchaseordermail_packing');
						
						
				}
	}
	
	
	
	public function sendEmailConsumable($id=null,$sendMail=null){
		//$this->generatePdf($id);
	
		if($sendMail==null){
			return $this->redirect(array("action"=>"sendEmailConsumable",$id,0));
		}
		$template='purchaseordermail_consumable';
		$purchaseOrder = $this->PurchaseOrder->get($id, [
				/*'fields'=>['po_number','po_file','id','po_date','supplier_id','consignee_id','OwnerCompanies.Company_name','OwnerCompanies.company_email','Uom.unit_symbol','dispatch_through','destination',
				 'IncoTerms.inco_term','CompanyMaster.Company_name','quantity_ordered','delivery','delivery_to','required_by_us',
						'rate','total_order_price','your_ref_no','packing_terms','payment_terms','port_of_discharge','country_final_destination','country_of_origin_of_goods',
						'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no','SupplierOffer.supplier_inquiry_id'],
		*/
				'contain' => ['CountryOfOriginOfGood','CountryOfFinalDestination','PortOfDischarge','SupplierOffer','OwnerCompanies','CompanyMaster','CompanyMaster.CompanyContactPersons','CompanyMaster.CompanySublocation','PackingTerm','PaymentTerm',
    					'CompanyMaster.CompanySublocation.City','CompanyMaster.CompanySublocation.Countries','CompanyMaster.CompanySublocation.State'	,'OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerCompanyOffices.State','CompanyMaster','IncoTerms','PurchaseOrderProducts',"PurchaseOrderProducts.ConsumablesMaster","PurchaseOrderProducts.Uom","PurchaseOrderProducts.Currency",'PurchaseOrderProducts.PackingMaster','PurchaseOrderProducts.PackingMaster.PackingType']
		])->toArray();
		// test email view
		//debug($purchaseOrder);exit;
		$this->loadModel('SupplierInquiry');
		$supplierInquiry=$this->SupplierInquiry->find(
				'all',
				[
						'fields' => ['SupplierInquiry.company_contact_persons","cc_email'],
						'conditions'=>['id'=>$purchaseOrder['supplier_offer']['supplier_inquiry_id']]
	
				]
				 
				 
				);
	
		//echo $purchaseOrder['supplier_id'];die;
		$OwnerCompany=$purchaseOrder['owner_company'];
		//echo '<pre>',print_r($PurchaseOrder);die;
		//Get owner company contact person
		$buyercontact=isset($OwnerCompany['owner_contact_persons'])?$OwnerCompany['owner_contact_persons'][0]['user']['userfullname']:'';
	
		$purchaseOrder['buyercontact']=$buyercontact;
	
		$this->loadModel('CompanyMaster');
		$this->loadModel('CompanyContactPersons');
		$companyOne =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $purchaseOrder['supplier_id']])->contain(['CompanyContactPersons','CompanySublocation','CompanySublocation.City','CompanySublocation.State','CompanySublocation.Countries']);
		$CompanyMaster = $companyOne->first();
	
	
		$companycontactIdval=isset($purchaseOrder->supplier_offer->supplier_inquiry->company_contact_persons)?$purchaseOrder->supplier_offer->supplier_inquiry->company_contact_persons:"";
		$companycontactIds=explode(",",$companycontactIdval);
		//echo '<pre>',print_r($companycontactIds);
	
		$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $purchaseOrder['supplier_id']])->
		contain([
				'CompanyContactPersons' => function ($q)use ($companycontactIds){
				return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
				},
	
	
				])->toArray();
				//echo '<pre>',print_r($companyMaster);
	
				$suppliercontact = "";
				$supplieremail = array();
				$vpercount=0;
				foreach ($CompanyMaster["company_contact_persons"] as $contact["CompanyContactPerson"]){
					$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
							ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
							ucfirst($contact["CompanyContactPerson"]["last_name"]);
							if(trim($personname," ")!=""){
								$suppliercontact.=$vpercount>0?",":"";
								$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
								$vpercount++;
							}
	
							$contactemail=$contact["CompanyContactPerson"]["email_id"];
	
							if(trim($contactemail," ")!=""){
								array_push($supplieremail, $contactemail);
							}else{
								//$this->Flash->error(__("Please check email_id for contact_name is not valid email."));
	
								$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
								//return $this->redirect(['action' => 'index']);
							}
				}
	
				//debug($suppliercontact);exit;
				$purchaseOrder['CompanyMaster']=$CompanyMaster;
				$purchaseOrder['suppliercontact']=$suppliercontact;
				//	echo '<pre>',print_r($supplieremail);
				//check suppliermails =0
				if(count($contactemail)==0){
					$this->Session->setFlash("Please Select atleast one email id.");
					return $this->redirect(array("action"=>"edit",$id));
				}
				$cc=array();
	
				/* if(isset( $supplierInquiry->cc_email)){
				 if(trim($supplierInquiry->cc_email," ")!=""&&Validation::email(trim($supplierInquiry->cc_email," "))){
					$cc[]=$supplierInquiry->cc_email;
					}else{
					$this->Session->setFlash("Please check CC email id form Supplier Inquiry ".$supplierInquiry["SupplierInquiry"]["id"].".");
					return $this->redirect(array("action"=>"edit",$id));
					}
					} */
	
				/******Test View : To check email layout********************
				 foreach ($purchaseOrder as $k => $var){
				 $this->set($k,$var);
				 };
				 $this->layout='Emails/html/purchaseordermailtemplate';
				 $this->render('../Emails/html/purchaseordermail');
				 return true;
				 /*******Test View : End*************************************/
	
				//echo '<pre>',print_r($cc);
				$buyermail=$purchaseOrder['owner_company']['company_email'];
	
				//echo '<pre>',print_r($buyercontact);
				//	echo '<pre>',print_r($suppliercontact);
				if(!isset($buyermail)){
					$this->Session->setFlash('Buyer company not have valid email id.');
				}
				$to = array();
				if(Configure::read("productionMode")){
	
					/*******Production Mode*******************/
					$to=$supplieremail;
					$cc=$purchaseOrder['supplier_offer']['supplier_inquiry']['cc_email'];
				}else{
					/*******Dev Mode*******************/
					$to=array('dkvastrakar18@gmail.com');
					$cc=array("dkvastrakar18@gmail.com");
					/**************************/
				}
				//$attachedFile='';
	
				$attachedFile=WWW_ROOT.DS.'upload'. DS.'purchase-order'.DS.$purchaseOrder['id'].'_'.$purchaseOrder['owner_companies_id'].'.pdf';
				/* $url = Router::url('/',true).'upload/purchase-order/'.$filename;
				 $uploadpath = 'upload/visiting-cards/';
				 $uploadfile = $uploadpath.$filename;
	
				 $attachedFile=WWW_ROOT.$this->PurchaseOrder->getFileName($id,$purchaseOrder['po_file']); */
				$attachedFileLabel="PurchaseOrder_".$id."_from_".$purchaseOrder['owner_company']['Company_name']."_po_file.".pathinfo($attachedFile,PATHINFO_EXTENSION);
				$subject=	'Purchase Order from '.$OwnerCompany['Company_name'];
				//echo '@@'.$sendMail;die;
				/// for send email and preview
				if( isset($sendMail)&& $sendMail==1){
					/// send email
						
						
					$email = new Email('default');
						
					if(file_exists($attachedFile)){
						$email->attachments( array($attachedFileLabel=> $attachedFile));
					}
					$email
					->template('purchaseordermail_consumable','purchaseordermail_consumable')
					->from($buyermail)
					->to($to)
					->cc($cc)
					//->bcc($bcc)
					->subject($subject)
					->emailFormat('html')
					->viewVars($purchaseOrder);
					//->send('sendmail');
	
	
					if ($email->send()) {
							
						//-------------- Make isoffered field in inquiry table true --------------------
							
						/* $inquiry = $this->Inquiry->get($off['inquiry_id']);
						 $data = array('id' => $off['inquiry_id'], 'isoffered' => true);
						 $inquiry = $this->Inquiry->patchEntity($inquiry, $data);
						 $this->Inquiry->save($inquiry); */
							
						//--------------------------------------------------------------------------------------------------
						//------------- Make status field of offer table submitted ---------------
							
							
						$po = $this->PurchaseOrder->get($purchaseOrder['id']);
						$data = array('id' => $purchaseOrder['id'], 'status' => 1);
						$offer = $this->PurchaseOrder->patchEntity($po, $data);
						$this->PurchaseOrder->save($offer);
							
						$this->Flash->success(__('The {0} has been sent successfully.', "PurchaseOrder"));
						return $this->redirect(['action' => 'index-consumable']);
					} else {
						$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "PurchaseOrder"));
					}
						
						
						
	
	
				}else{
	
					//email preview
					// 				/debug($OwnerCompany);
					foreach ($purchaseOrder as  $key=> $data ){
						$this->set($key,$data);
					}
					if(file_exists($attachedFile)){
						$this->set("attachments",array(
								$attachedFileLabel=> array(
										"controller"=>"upload",
										"action"=>"purchase_order",
										$purchaseOrder['id'].'_'.$purchaseOrder['owner_companies_id'].'.pdf')
						)
								);
					}
					$this->set("mails",array(
							"from"=>$buyermail,
							"to" =>$to,
							"cc" => $cc,
							"subject"=>$subject
					));
	
					$this->set("title_for_layout","Purchase order.");
					$this->set("mailSendAction",array(
							"send"=>array("action"=>"sendEmailConsumable",$id,1),
							"cancel"=>array("action"=>"index-consumable")
					));
						
	
					$this->viewBuilder()->setLayout("/Email/html/emailpreview");
					$this->render('/Email/html/purchaseordermail_consumable');
						
						
				}
	}
    /**
     * Edit method
     *
     * @param string|null $id Purchase Order id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
	public function edit($id = null)
	{
		$purchaseOrder = $this->PurchaseOrder->get($id, [
				/* 	'fields'=>['po_number','id','po_date','inco_terms_id','consignee_id','OwnerCompanies.Company_name','Uom.unit_symbol','dispatch_through','destination',
				 'IncoTerms.inco_term','CompanyMaster.Company_name','quantity_ordered','delivery','delivery_to','required_by_us',
						'rate','total_order_price','your_ref_no','packing_terms','payment_terms','port_of_discharge','country_final_destination','country_of_origin_of_goods',
						'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no'],
		*/
				'contain' => ['OwnerCompanies','CompanyMaster','IncoTerms','PurchaseOrderProducts',"PurchaseOrderProducts.ProductsMaster","PurchaseOrderProducts.Uom","PurchaseOrderProducts.Currency",'PurchaseOrderProducts.PackingMaster','PurchaseOrderProducts.PackingMaster.PackingType']
		]);
		if ($this->request->is(['patch', 'post', 'put'])) {
	
			 
			 
			$purchaseOrder = $this->PurchaseOrder->patchEntity($purchaseOrder, $this->request->data);
	
			//debug($this->request->data);die;
	
			if ($this->PurchaseOrder->save($purchaseOrder)) {
				//$this->generatePdf($id);
				$this->Flash->success(__('The {0} has been saved.', 'Purchase Order'));
				return $this->redirect(['action' => 'index']);
			} else {
				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Order'));
			}
		}
	
		$this->loadModel('Currency');
		$this->loadModel('Uom');
		$this->loadModel('PortOfDischarge');
		$this->loadModel('Countries');
		$this->loadModel('PackingTerm');
		$this->loadModel('PaymentTerm');
		//  $this->loadModel('IncoTerms');
		$this->loadModel('CompanyMaster');
		$consingee = $this->CompanyMaster->find('all',
				[
						'fields' => ['Company_name'],
						'conditions'=>['id'=>$purchaseOrder->consignee_id]
	
				])->toArray();
	
				$options='';
				if($purchaseOrder->is_local==1){
	
					$CurrencyKey=$purchaseOrder->owner_companies_id.'_'.'currency';
					$currencyId = Cache::read($CurrencyKey, $config = 'default');
					$options=array('id'=>$currencyId);
				}
				$packingterm= $this->PackingTerm->find('list', ['keyField' => 'id','valueField' => 'packing_term','order'=>'packing_term']);
				$paymentterm= $this->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
	
	
				//   $incoterms = $this->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
				$countries= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
	
				$currencies = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','conditions'=>$options,'limit' => 200]);
				$countryoforigineofgoods= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
				$portofdischarge= $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge']);
				$incoterms = $this->PurchaseOrder->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
				//$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
	
				$this->set(compact('incoterms','consingee','paymentterm','packingterm','purchaseOrder','currencies','uom','portofdischarge','countryoforigineofgoods','countries'));
				$this->set('_serialize', ['purchaseOrder']);
	}
    public function editPacking($id = null)
    {
    	
    	$purchaseOrder = $this->PurchaseOrder->get($id, [
    	/* 	'fields'=>['po_number','id','po_date','consignee_id','OwnerCompanies.Company_name','Uom.unit_symbol','dispatch_through','destination',
    					'IncoTerms.inco_term','CompanyMaster.Company_name','quantity_ordered','delivery','delivery_to','required_by_us','shipping_conditions',
    					'rate','total_order_price','your_ref_no','packing_terms','payment_terms','port_of_discharge','country_final_destination','country_of_origin_of_goods',
    					'Currency.sign','PackingMaster.description','PackingMaster.color','PackingMaster.specification','PackingType.packing_type','PackingSubtype.sub_type'],
    			  */'contain' => ['OwnerCompanies','CompanyMaster','CompanyMaster.CompanyContactPersons','IncoTerms','Uom','Currency','PackingMaster','PackingMaster.PackingType','PackingMaster.PackingSubtype']
    	]);
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		//debug($this->request->data);exit;
    		$purchaseOrder = $this->PurchaseOrder->patchEntity($purchaseOrder, $this->request->data);
    		//debug($purchaseOrder);exit;
    		if ($this->PurchaseOrder->save($purchaseOrder)) {
    			$this->generate_packing_Pdf($id);
    			$this->Flash->success(__('The {0} has been saved.', 'Purchase Order'));
    			return $this->redirect(['action' => 'index_packing']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Order'));
    		}
    	}
    	
    	$this->loadModel('Currency');
    	$this->loadModel('Uom');
    	$this->loadModel('PortOfDischarge');
    	$this->loadModel('Countries');
    	$this->loadModel('PackingTerm');
    	$this->loadModel('PaymentTerm');
    	//  $this->loadModel('IncoTerms');
    	$this->loadModel('CompanyMaster');
    	$consingee = $this->CompanyMaster->find('all',
    			[
    					'fields' => ['Company_name'],
    					'conditions'=>['id'=>$purchaseOrder->consignee_id]
    					 
    			])->toArray();
    	
    			$options='';
    			if($purchaseOrder->is_local==1){
    	
    				$CurrencyKey=$purchaseOrder->owner_companies_id.'_'.'currency';
    				$currencyId = Cache::read($CurrencyKey, $config = 'default');
    				$options=array('id'=>$currencyId);
    			}
    			$packingterm= $this->PackingTerm->find('list', ['keyField' => 'id','valueField' => 'packing_term','order'=>'packing_term']);
    			$paymentterm= $this->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
    	
    	
    			//   $incoterms = $this->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    			$countries= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
    	
    			$currencies = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','conditions'=>$options,'limit' => 200]);
    			$countryoforigineofgoods= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
    			$portofdischarge= $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge']);
    	
    			//$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    			$incoterms = $this->PurchaseOrder->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    			$this->set(compact('incoterms','consingee','paymentterm','packingterm','purchaseOrder','currencies','uom','portofdischarge','countryoforigineofgoods','countries'));
    			$this->set('_serialize', ['purchaseOrder']);
    }

    
    public function editConsumable($id = null)
    {
    	$purchaseOrder = $this->PurchaseOrder->get($id, [
    		/* 	'fields'=>['po_number','id','po_date','inco_terms_id','consignee_id','OwnerCompanies.Company_name','Uom.unit_symbol','dispatch_through','destination',
    					'IncoTerms.inco_term','CompanyMaster.Company_name','quantity_ordered','delivery','delivery_to','required_by_us',
    					'rate','total_order_price','your_ref_no','packing_terms','payment_terms','port_of_discharge','country_final_destination','country_of_origin_of_goods',
    					'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no'],
    			 */
    			'contain' => ['OwnerCompanies','CompanyMaster','IncoTerms','PurchaseOrderProducts',"PurchaseOrderProducts.ConsumablesMaster","PurchaseOrderProducts.Uom","PurchaseOrderProducts.Currency",'PurchaseOrderProducts.PackingMaster','PurchaseOrderProducts.PackingMaster.PackingType']
    	]);
    	if ($this->request->is(['patch', 'post', 'put'])) {
    
    		 
    		 
    		$purchaseOrder = $this->PurchaseOrder->patchEntity($purchaseOrder, $this->request->data);
    
    		//debug($this->request->data);die;
    
    		if ($this->PurchaseOrder->save($purchaseOrder)) {
    			//$this->generatePdf($id);
    			$this->Flash->success(__('The {0} has been saved.', 'Purchase Order'));
    			return $this->redirect(['action' => 'index-consumable']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Order'));
    		}
    	}
    
    	$this->loadModel('Currency');
    	$this->loadModel('Uom');
    	$this->loadModel('PortOfDischarge');
    	$this->loadModel('Countries');
    	$this->loadModel('PackingTerm');
    	$this->loadModel('PaymentTerm');
    	//  $this->loadModel('IncoTerms');
    	$this->loadModel('CompanyMaster');
    	$consingee = $this->CompanyMaster->find('all',
    			[
    					'fields' => ['Company_name'],
    					'conditions'=>['id'=>$purchaseOrder->consignee_id]
    					 
    			])->toArray();
    
    			$options='';
    			if($purchaseOrder->is_local==1){
    
    				$CurrencyKey=$purchaseOrder->owner_companies_id.'_'.'currency';
    				$currencyId = Cache::read($CurrencyKey, $config = 'default');
    				$options=array('id'=>$currencyId);
    			}
    			$packingterm= $this->PackingTerm->find('list', ['keyField' => 'id','valueField' => 'packing_term','order'=>'packing_term']);
    			$paymentterm= $this->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
    
    
    			//   $incoterms = $this->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    			$countries= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
    
    			$currencies = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','conditions'=>$options,'limit' => 200]);
    			$countryoforigineofgoods= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
    			$portofdischarge= $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge']);
    			$incoterms = $this->PurchaseOrder->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    			//$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    
    			$this->set(compact('incoterms','consingee','paymentterm','packingterm','purchaseOrder','currencies','uom','portofdischarge','countryoforigineofgoods','countries'));
    			$this->set('_serialize', ['purchaseOrder']);
    }
    /**
     * Delete method
     *
     * @param string|null $id Purchase Order id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
    	
        $this->request->allowMethod(['post', 'delete']);
        $purchaseOrder = $this->PurchaseOrder->get($id);
        
        $po = $this->PurchaseOrder->get($id, [
        		'contain' => []
        ]);
        $data = array('id' => $po['supplier_offer_id'] , 'status' => "0");
        //print_r($data);die;
        $this->loadModel('SupplierOffer');
        $supplieroffer= $this->SupplierOffer->get($po['supplier_offer_id'], [
        		'contain' => []
        ]);
        if($this->SupplierOffer->patchEntity($supplieroffer,$data)){
        	$this->SupplierOffer->save($supplieroffer);
        
        }
        if ($this->PurchaseOrder->delete($purchaseOrder)) {
        	
        	
        	
        	//echo '<pre>',print_r($purchaseOrder);die;
        	
        	
            $this->Flash->success(__('The {0} has been deleted.', 'Purchase Order'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Purchase Order'));
        }
        return $this->redirect(['action' => 'index']);
    }
    public function generatePdf($id = null)
    {
    	$purchaseOrder = $this->PurchaseOrder->get($id, [
    			/* 'fields'=>['PurchaseOrder.po_number','PurchaseOrder.po_date','OwnerCompanies.Company_name','Uom.unit_symbol',
    			 'city.city_name','IncoTerms.inco_term','CompanyMaster.Company_name','rate','total_order_price',
    					'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no'], */
    	
            'contain' => ['OwnerCompanies','SupplierOffer','SupplierOffer.SupplierInquiry','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerContactPersons.Users','OwnerCompanies.OwnerCompanyOffices','OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerCompanyOffices.State','OwnerCompanies.OwnerCompanyOffices.Countries','ProductsMaster',
            				'CompanyMaster','IncoTerms','Uom','Currency','PackingTerm','PaymentTerm',]
    			]);
    	
		    	$this->loadModel('CompanyMaster');
		    	$consingee = $this->CompanyMaster->find('all',
    			[		'contain' => ['CompanySublocation.City','CompanySublocation.Countries','CompanySublocation.State'],
    					'conditions'=>['id'=>$purchaseOrder->consignee_id]
    					 
    			])->toArray();
    			//$this->set('consingee', $consingee);
    			
    			 
    			$supplier = $this->CompanyMaster->find('all',
    					[		'contain' => ['CompanySublocation.City','CompanySublocation.Countries','CompanySublocation.State'],
    							'conditions'=>['id'=>$purchaseOrder->supplier_id]
    			
    					])->toArray();
    					
    					//echo '<pre>',print_R($purchaseOrder["ProductDataTest"]);
    						
    			$this->set('purchaseOrder', $purchaseOrder);
    			$this->set('supplier', $supplier);
    			$this->set('consingee', $consingee);
    			$this->loadModel('ProductDataTests');
    			
    			$productDataTest=$this->ProductDataTests->find("all",[
    				
    					"conditions"=>array("id IN"=>explode(",",$purchaseOrder["supplier_offer"]["supplier_inquiry"]['product_specifications']))
    			])->toArray();
    			$purchaseOrder["ProductDataTest"]=$productDataTest;
    			//echo '<pre>',print_R($purchaseOrder["ProductDataTest"]);
    			    
    			//Owner Company
    			/* $city=trim($purchaseOrder['owner_company']['owner_company_offices'][0]['CityName']['city_name']," ")!=""?$purchaseOrder['owner_company']['owner_company_offices'][0]['CityName']['city_name'].", ":"";
    			$state=trim($purchaseOrder['owner_company']['owner_company_offices'][0]['StateName']['state_name']," ")!=""?$purchaseOrder['owner_company']['owner_company_offices'][0]['StateName']['state_name'].", ":"";
    			$country=trim($purchaseOrder['owner_company']['owner_company_offices'][0]['Country']['country_name']," ")!=""?$purchaseOrder['owner_company']['owner_company_offices'][0]['Country']['country_name'].", ":"";
    			
    			
    			$owncompanyName= $purchaseOrder['owner_company']["Company_name"] .".<br/> ".$purchaseOrder['owner_company']['owner_company_offices'][0]["address"]."<BR>";
    			$owncompanyAddress=h($city).h($state).h($country);
    			if(isset($purchaseOrder['owner_company']["pin_code"])){
    				 $owncompanyAddress.="-".$purchaseOrder['owner_company']["pin_code"];
    			} */
    			 
    			//Supplier Comapany
    			/*  $supplierName=$supplier[0]['Company_name']."<br/>";
    			 $supplierAddress=$supplier[0]["company_sublocation"][0]['Address']."<br/>";
    			 $supplierAddress.=$supplier[0]['company_sublocation'][0]["City"]['city_name'].", ".$supplier[0]['company_sublocation'][0]["State"]["state_name"].", ".$supplier[0]['company_sublocation'][0]["Country"]["country_name"]."-".$supplier[0]['company_sublocation'][0]["postal_code"]."<br/>";
    			 */
    			//Consingee Company    			
/*     			 $consingeeAddress=$consingee[0]["Company_name"]."<br/>";
    			 $consingeeAddress.=isset($consingee[0]["company_sublocation"][0])?$consingee[0]["company_sublocation"][0]['Address']:''."<br/>";
    			 $consingeeAddress.=isset($consingee[0]['company_sublocation'][0])?$consingee[0]['company_sublocation'][0]["City"]['city_name']:'';
    			 $consingeeAddress.=isset($consingee[0]['company_sublocation'][0])?','.$consingee[0]['company_sublocation'][0]["State"]["state_name"]:'';
    			 $consingeeAddress.=isset($consingee[0]['company_sublocation'][0])?','.$consingee[0]['company_sublocation'][0]["Country"]["country_name"]:'';
    			 $consingeeAddress.=isset($consingee[0]['company_sublocation'][0])?'-'.$consingee[0]['company_sublocation'][0]["postal_code"]:'';
    			 
    			 
				$purchaseOrder['purchaseName']=$owncompanyName;
				$purchaseOrder['purchaseBy']=$owncompanyAddress;				
				$purchaseOrder['consingeeBy']= $consingeeAddress; */
				//$purchaseOrder['supplierBy']= $supplierAddress;
				
	//echo '<pre>',print_R($purchaseOrder);die;
    			 
    	$CakePdf = new \CakePdf\Pdf\CakePdf();
    	$CakePdf->template('purchase_order_pdf', 'default');
    	$CakePdf->viewVars($this->viewVars);
    	
    	$pdf = $CakePdf->output();
    	
    	//echo $pdf;die;
    	
    	$pdf = $CakePdf->write(WWW_ROOT.DS.'upload'. DS.'purchase-order'.DS.$purchaseOrder->id.'_'.$purchaseOrder->owner_companies_id.'.pdf');
    	
    	
    }
    
    public function generate_packing_Pdf($id = null)
    {
    	$purchaseOrder = $this->PurchaseOrder->get($id, [
    			/* 'fields'=>['PurchaseOrder.po_number','PurchaseOrder.po_date','OwnerCompanies.Company_name','Uom.unit_symbol',
    			 'city.city_name','IncoTerms.inco_term','CompanyMaster.Company_name','rate','total_order_price',
    					'Currency.sign','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no'], */
    			 
    			'contain' => ['OwnerCompanies','SupplierOffer','SupplierOffer.SupplierInquiry','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerContactPersons.Users','OwnerCompanies.OwnerCompanyOffices','OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerCompanyOffices.State','OwnerCompanies.OwnerCompanyOffices.Countries','ProductsMaster',
    					'CompanyMaster','IncoTerms','Uom','Currency','PackingTerm','PaymentTerm','PackingMaster','PackingMaster.PackingSubType', 'PackingMaster.PackingType']
    	]);
    	 
    	$this->loadModel('CompanyMaster');
    	$consingee = $this->CompanyMaster->find('all',
    			[		'contain' => ['CompanySublocation.City','CompanySublocation.Countries','CompanySublocation.State'],
    					'conditions'=>['id'=>$purchaseOrder->consignee_id]
    
    			])->toArray();

    			$supplier = $this->CompanyMaster->find('all',
    					[		'contain' => ['CompanySublocation.City','CompanySublocation.Countries','CompanySublocation.State'],
    							'conditions'=>['id'=>$purchaseOrder->supplier_id]
    							 
    					])->toArray();
    						
    					//echo '<pre>',print_R($purchaseOrder["ProductDataTest"]);
    
    					$this->set('purchaseOrder', $purchaseOrder);
    					$this->set('supplier', $supplier);
    					$this->set('consingee', $consingee);
    					$this->loadModel('ProductDataTests');
    					 
    					$productDataTest=$this->ProductDataTests->find("all",[
    
    							"conditions"=>array("id IN"=>explode(",",$purchaseOrder["supplier_offer"]["supplier_inquiry"]['product_specifications']))
    					])->toArray();
    					$purchaseOrder["ProductDataTest"]=$productDataTest;

   
    					$CakePdf = new \CakePdf\Pdf\CakePdf();
    					$CakePdf->template('purchase_order_pdf_packing', 'default');
    					$CakePdf->viewVars($this->viewVars);
    					 
    					$pdf = $CakePdf->output();
    					 
    					//echo $pdf;die;
    					 
    					$pdf = $CakePdf->write(WWW_ROOT.DS.'upload'. DS.'purchase-order'.DS.'packing_product'.DS.$purchaseOrder->id.'_'.$purchaseOrder->owner_companies_id.'.pdf');
    					 
    					 
    }
    
    
 
    
}
