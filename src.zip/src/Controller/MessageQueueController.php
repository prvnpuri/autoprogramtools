<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * MessageQueue Controller
 *
 * @property \App\Model\Table\MessageQueueTable $MessageQueue
 *
 * @method \App\Model\Entity\MessageQueue[] paginate($object = null, array $settings = [])
 */
class MessageQueueController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Messages', 'Records']
        ];
        $messageQueue = $this->paginate($this->MessageQueue);

        $this->set(compact('messageQueue'));
        $this->set('_serialize', ['messageQueue']);
    }

    /**
     * View method
     *
     * @param string|null $id Message Queue id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $messageQueue = $this->MessageQueue->get($id, [
            'contain' => ['Messages', 'Records']
        ]);

        $this->set('messageQueue', $messageQueue);
        $this->set('_serialize', ['messageQueue']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $messageQueue = $this->MessageQueue->newEntity();
        if ($this->request->is('post')) {
            $messageQueue = $this->MessageQueue->patchEntity($messageQueue, $this->request->data);
            if ($this->MessageQueue->save($messageQueue)) {
                $this->Flash->success(__('The {0} has been saved.', 'Message Queue'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Message Queue'));
            }
        }
        $messages = $this->MessageQueue->Messages->find('list', ['limit' => 200]);
        $records = $this->MessageQueue->Records->find('list', ['limit' => 200]);
        $this->set(compact('messageQueue', 'messages', 'records'));
        $this->set('_serialize', ['messageQueue']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Message Queue id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $messageQueue = $this->MessageQueue->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $messageQueue = $this->MessageQueue->patchEntity($messageQueue, $this->request->data);
            if ($this->MessageQueue->save($messageQueue)) {
                $this->Flash->success(__('The {0} has been saved.', 'Message Queue'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Message Queue'));
            }
        }
        $messages = $this->MessageQueue->Messages->find('list', ['limit' => 200]);
        $records = $this->MessageQueue->Records->find('list', ['limit' => 200]);
        $this->set(compact('messageQueue', 'messages', 'records'));
        $this->set('_serialize', ['messageQueue']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Message Queue id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $messageQueue = $this->MessageQueue->get($id);
        if ($this->MessageQueue->delete($messageQueue)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Message Queue'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Message Queue'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
