<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * AccountBalances Controller
 *
 * @property \App\Model\Table\AccountBalancesTable $AccountBalances
 *
 * @method \App\Model\Entity\AccountBalance[] paginate($object = null, array $settings = [])
 */
class AccountBalancesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $accountBalances = $this->paginate($this->AccountBalances);

        $this->set(compact('accountBalances'));
        $this->set('_serialize', ['accountBalances']);
    }

    /**
     * View method
     *
     * @param string|null $id Account Balance id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $accountBalance = $this->AccountBalances->get($id, [
            'contain' => []
        ]);

        $this->set('accountBalance', $accountBalance);
        $this->set('_serialize', ['accountBalance']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $accountBalance = $this->AccountBalances->newEntity();
        if ($this->request->is('post')) {
            $accountBalance = $this->AccountBalances->patchEntity($accountBalance, $this->request->data);
            if ($this->AccountBalances->save($accountBalance)) {
                $this->Flash->success(__('The {0} has been saved.', 'Account Balance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Account Balance'));
            }
        }
        $this->set(compact('accountBalance'));
        $this->set('_serialize', ['accountBalance']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Account Balance id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $accountBalance = $this->AccountBalances->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $accountBalance = $this->AccountBalances->patchEntity($accountBalance, $this->request->data);
            if ($this->AccountBalances->save($accountBalance)) {
                $this->Flash->success(__('The {0} has been saved.', 'Account Balance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Account Balance'));
            }
        }
        $this->set(compact('accountBalance'));
        $this->set('_serialize', ['accountBalance']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Account Balance id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $accountBalance = $this->AccountBalances->get($id);
        if ($this->AccountBalances->delete($accountBalance)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Account Balance'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Account Balance'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
