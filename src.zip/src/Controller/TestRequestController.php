<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Mailer\Email;
use Cake\Core\Configure;
use DebugKit\Mailer\SentMailResult;
use Cake\Network\Exception\NotFoundException;
use App\Model\Table\ConsumableInventoryTable;



/**
 * TestRequest Controller
 *
 * @property \App\Model\Table\TestRequestTable $TestRequest
 * @property ConsumableInventoryTable $ConsumableInventory
 * @method \App\Model\Entity\TestRequest[] paginate($object = null, array $settings = [])
 */
class TestRequestController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
    	
    	$condn=array('TestRequest.owner_companies_id'=>$ownercomp,'TestRequest.product_type'=>'Product');
    	
        $this->paginate = [
            'conditions'=>$condn,
            'contain' => ['OwnerCompanies', 'ProductsMaster','TestRequestDet','TestRequestDet.TestReports','ProductsMaster.ProductDataTests','TestRequestDet.CompanyMaster','TestRequestDet.ProductDataTests'],
        ];       
        
        $testRequest = $this->paginate($this->TestRequest);

        $this->set(compact('testRequest'));
        $this->set('_serialize', ['testRequest']);
    }

    /**
     * View method
     *
     * @param string|null $id Test Request id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $testRequest = $this->TestRequest->get($id, [
            'contain' => ['OwnerCompanies', 'ProductsMaster','TestRequestDet','TestRequestDet.TestReports','ProductsMaster.ProductDataTests','TestRequestDet.CompanyMaster','TestRequestDet.ProductDataTests'],
      
        ]);

        $this->set('testRequest', $testRequest);
        $this->set('_serialize', ['testRequest']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $testRequest = $this->TestRequest->newEntity();
        if ($this->request->is('post')) {
        	
        	foreach ($this->request->data['test_request_det'] as $key=> $det){
        		$det['test_id'] = trim($det['test_id']);
        		if($det['test_id'] !== ''){
        			$details[] = $det;
        		}
        	}
        	unset($this->request->data['test_request_det']);
        	$this->request->data['test_request_det'] = $details;
        	$this->loadModel('ReferenceNumberCounter');
        	$this->loadComponent('ReferenceNumber');
        	
        	$next_ref =
        	$this->ReferenceNumber->get_next_ref_number($this->request->session()->read('Auth.User.owner_company_id'),'sup_inq');
        	$this->request->data['reference_no'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
        	if(!isset($next_ref['full_next_ref_no'])){
        		$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Test Request'));
        	}else{
        	
         $testRequest= $this->TestRequest->patchEntity($testRequest, $this->request->data);
         $testRequest['created_by'] = $this->Auth->User('id');
        // debug($this->request->data);exit;
            if ($this->TestRequest->save($testRequest)) {
                $this->Flash->success(__('The {0} has been saved.', 'Test Request'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Request'));
            }
        }
        }
        
        $ownerCompanies = $this->TestRequest->OwnerCompanies->find('list', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions'=>array('id'=>$this->request->session()->read('Auth.User.owner_company_id')),
        		'order' => ['OwnerCompanies.Company_name' => 'ASC']
        ]);
        $this->loadModel('CompanyMaster');
        $labname = $this->CompanyMaster->find('list', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions' => ['CompanyMaster.company_types_master_id' => '14'],
        		'order' => ['CompanyMaster.Company_name' => 'ASC']
        ]);
        $this->loadModel('Users');
        $users = $this->Users->find('list', [
        		'keyField' => 'id',
        		'valueField' => 'username',
        		'order' => ['Users.username' => 'ASC']
        ]);
        
        $productsMasters = $this->TestRequest->ProductsMaster->find('list', ['limit' => 200]);
        $this->set(compact('testRequest', 'ownerCompanies', 'productsMasters','labname', 'users'));
        $this->set('_serialize', ['testRequest']);

    }

    
    /**
     * sendtestrequestmail method
     */
    public function sendtestrequestmail($testRequestDetid = null,$isView=true){

    	//echo $testRequestDet;exit;
    	$this->loadModel('TestRequestDet');
    	$testRequestDet = $this->TestRequestDet->get($testRequestDetid, [
    			'contain' => ['TestReports','TestRequest','TestRequest.ProductsMaster','CompanyMaster','TestRequest.OwnerCompanies','CompanyMaster.CompanyContactPersons']
    	]);

    	$this->loadModel('ProductDataTests');
    	$productDataTest = $this->ProductDataTests->find('all', [
    			'conditions'=>['ProductDataTests.id' => $testRequestDet->test_id],
    			'order' => ['ProductDataTests.id' => 'ASC']
    	]);
    	$productDataTest = $productDataTest->first();

    	$this->loadModel('CompanyMaster');
    	$suppliers = $this->CompanyMaster->find('all', [
    			'conditions'=>['CompanyMaster.id' => $testRequestDet->test_request->manufacturer_by],
    			'order' => ['CompanyMaster.id' => 'ASC']
    	]);
    	$suppliers = $suppliers->first();
    
    	$this->set(compact('testReport','productDataTest','testRequestDet','lab','testRequest', 'ownerCompanies', 'productsMasters','users','suppliers'));
    	
    	$OwnerCompanyEmail = $testRequestDet->test_request->owner_company->company_email;
        $Subject = 'Test Request from '.$testRequestDet->test_request->owner_company->Company_name;
    	
    	foreach($testRequestDet->company_master->company_contact_persons as $key => $lab){
    		$labEmail[] = trim($lab->email_id);
    		
    	}

    	$to = array();
    	$cc = array();
    	if(Configure::read("productionMode")){
    		/*******Production Mode*******************/
    		$to=$labEmail;
    		//$cc=array("sagar@jpharmachem.com","ketan@jpharmachem.com");
    		$cc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    	}else{
    		/*******Dev Mode*******************/
    		$to=array('dkvastrakar18@gmail.com');
    		$cc=array("dkvastrakar18@gmail.com");
    		/**************************/
    	}
    	
        
    	if($isView===true){
    		/*******Email Preview Mode*******************/
    		
    		/*******For local*******************/
    		 $this->set("mails",array(
    				"from"=>"dkvastrakar18@gmail.com",
    				"to" =>"dkvastrakar18@gmail.com",
    				"cc" => "dkvastrakar18@gmail.com",
    				"bcc"=> "dkvastrakar18@gmail.com",
    				"subject"=>"TestRequest"
    		)); 
    		/**************************/
    		
    		/*******For Production*******************/
   		  /*   $this->set("mails",array(
    				"from"=>$OwnerCompanyEmail,
    				"subject"=>$Subject,
   		    		"to" =>$to,
   		    		"cc" => $cc
    		));  */
    		/**************************/
    		
    		
    		
    			
    		$this->set("title_for_layout","TestReport");
    		$this->set(	"mailSendAction",array(
    				"send"=>array("action"=>"sendtestrequestmail",$testRequestDet->id,"false"),
    				"cancel"=>array("action"=>"index")
    		));
    		
    		//$this->layout = 'emailpreview';
    		$this->viewBuilder()->setLayout("/Email/html/emailpreview");
    		$this->render('/Email/html/testingreport');
    		/**************************/
    	}else{

		   		$email = new Email('default');
		    	$email
		    	//->setTransport($name)
		    	->template('testingreport','testingreport')
		    	->from($OwnerCompanyEmail)
		    	->to($to)
		    	->subject($Subject)
		    	->emailFormat('html')
		    	->viewVars($this->viewVars );
		    	//->send('sendmail');
		    	 
		    	
		    	if ($email->send()) {
		    		$this->request->data['id'] = $testRequestDetid;
		    		$this->request->data['email_status'] = 'Y';
		    		$testRequestDetsave = $this->TestRequestDet->patchEntity($testRequestDet, $this->request->data);
		    		$this->TestRequestDet->save($testRequestDetsave);
		    		$labname = $testRequestDet->company_master->Company_name;
		    		$this->Flash->success(__('The {0} has been sent successfully.', "Test Request for lab $labname"));
		    		return $this->redirect(['action' => 'index']);
		    	} else {
		    		$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "Test Request for lab $labname"));
		    	}
    	
    	
    	}
    }
    
    
    
    
    
    public function printrequest($testRequestDetid = null){
    
    	$this->loadModel('TestRequestDet');
    	$testRequestDet = $this->TestRequestDet->get($testRequestDetid, [
    			'contain' => ['TestReports','TestRequest','TestRequest.ProductsMaster','CompanyMaster','TestRequest.OwnerCompanies']
    	]);
    	
    	$this->loadModel('ProductDataTests');
    	$productDataTest = $this->ProductDataTests->find('all', [
    			'conditions'=>['ProductDataTests.id' => $testRequestDet->test_id],
    			'order' => ['ProductDataTests.id' => 'ASC']
    	]);
    	$productDataTest = $productDataTest->first();
    	
    	$this->loadModel('CompanyMaster');
    	$suppliers = $this->CompanyMaster->find('all', [
    			'conditions'=>['CompanyMaster.id' => $testRequestDet->test_request->manufacturer_by],
    			'order' => ['CompanyMaster.id' => 'ASC']
    	]);
    	$suppliers = $suppliers->first();
    	 
    	 
    	
    	
    	$this->set(compact('testReport','productDataTest','testRequestDet','lab','testRequest', 'ownerCompanies', 'productsMasters','users','suppliers'));
    	$this->viewBuilder()->setLayout(false);
    	
    }
    
    
    
    /**
     * Edit method
     *
     * @param string|null $id Test Request id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $testRequest = $this->TestRequest->get($id, [
            'contain' => ['TestRequestDet','ProductsMaster','OwnerCompanies','ProductsMaster.ProductDataTests','TestRequestDet.CompanyMaster','TestRequestDet.ProductDataTests']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
        	//debug($this->request->data);exit;
        	
            $testRequest = $this->TestRequest->patchEntity($testRequest, $this->request->data);
            $testRequest['modified_by'] = $this->Auth->User('id');
            //debug($this->request->data);exit;
            if ($this->TestRequest->save($testRequest)) {
                $this->Flash->success(__('The {0} has been saved.', 'Test Request'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Request'));
            }
        }
        
        $ownerCompanies = $this->TestRequest->OwnerCompanies->find('list', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions'=>array('id'=>$this->request->session()->read('Auth.User.owner_company_id')),
        		'order' => ['OwnerCompanies.Company_name' => 'ASC']
        ]);
        $this->loadModel('Users');
        $users = $this->Users->find('list', [
        		'keyField' => 'id',
        		'valueField' => 'username',
        		'order' => ['Users.username' => 'ASC']
        ]);
        
        $this->loadModel('CompanyMaster');
        $suppliers = $this->CompanyMaster->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions'=>['CompanyMaster.id' => $testRequest->manufacturer_by],
        		'order' => ['CompanyMaster.id' => 'ASC']
        ]);
        $suppliers = $suppliers->first();
        
        
        $labname = $this->CompanyMaster->find('list', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions' => ['CompanyMaster.company_types_master_id' => Configure::read('lab.Lab')],
        		'order' => ['CompanyMaster.Company_name' => 'ASC']
        ]);
        
        
        $this->set(compact('labname','testRequest', 'ownerCompanies', 'productsMasters','users','suppliers'));
        $this->set('_serialize', ['testRequest']);
        
        
        
    }

    /**
     * Delete method
     *
     * @param string|null $id Test Request id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $testRequest = $this->TestRequest->get($id);
        if ($this->TestRequest->delete($testRequest)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Test Request'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Test Request'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    
    
    
    
    public function indexConsumable()
    {
    	$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
    	
    	$condn=array('TestRequest.owner_companies_id'=>$ownercomp,'TestRequest.product_type'=>'Consumable');
    	
    	$this->paginate = [
    			'conditions'=>$condn,
    			'contain' => ['OwnerCompanies', 'ConsumablesMaster'],
    	];
    	
    	$testRequest = $this->paginate($this->TestRequest);
    	
    	$this->set(compact('testRequest'));
    	$this->set('_serialize', ['testRequest']);
    }
    
    public function approvepregrn($id){
    	
    	$prGrn = $this->TestRequest->get($id, [
    			'contain' => []
    	]);
    	
    	
    	$data = array('id' => $id , 'is_approve' => "Y");
    	if($this->TestRequest->patchEntity($prGrn,$data)){
    		$this->TestRequest->save($prGrn);
    		return $this->redirect(['action' => 'indexConsumable']);
    	}
    }
    
    public function rejectpregrn($id){
    	
    	$prRequest = $this->TestRequest->get($id, [
    			'contain' => []
    	]);
    	
    	$data = array('id' => $id , 'is_approve' => "N");
    	if($this->TestRequest->patchEntity($prRequest,$data)){
    		$this->TestRequest->save($prRequest);
    		return $this->redirect(['action' => 'indexConsumable']);
    	}
    }
    
    public function pendingGrn()
    {
    	$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
    	
    	$condn=array('TestRequest.owner_companies_id'=>$ownercomp,'TestRequest.product_type'=>'Consumable','TestRequest.is_approve'=>'Y');
    	
    	$this->paginate = [
    			'conditions'=>$condn,
    			'contain' => ['OwnerCompanies', 'ConsumablesMaster','ConsumableInventory'],
    	];
    	
    	$testRequest = $this->paginate($this->TestRequest);
    	
    	$this->set(compact('testRequest'));
    	$this->set('_serialize', ['testRequest']);
    }
    public function pendingproductGrn()
    {
    	$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
    	
    	$condn=array('TestRequest.owner_companies_id'=>$ownercomp,'TestRequest.product_type'=>'Product','TestRequest.is_approve'=>'Y');
    	
    	$this->paginate = [
    			'conditions'=>$condn,
    			'contain' => ['OwnerCompanies', 'ConsumablesMaster'],
    	];
    	
    	$testRequest = $this->paginate($this->TestRequest);
    	
    	$this->set(compact('testRequest'));
    	$this->set('_serialize', ['testRequest']);
    }
    
    
    
    
    
    
    
    
    
    public function editstockupdate($id = null)
    {
    	$this->loadModel('WarehouseInventory');
    
    	
    	$materialRequest= $this->TestRequest->get($id, [
    			'contain' => ['TestRequestDet','ConsumablesMaster']
    	]);
    	
    	
    	
    	
    	
    	
    	
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		
    			
    			
    			$MaterialRequest=$this->request->getData();
    			
    		
    			
    				$this->updateConsumableStock($MaterialRequest);
    			
    			
    			$data = array('id' => $id , 'status' => "1");
    			if($this->TestRequest->patchEntity($materialRequest,$data)){
    				$this->TestRequest->save($materialRequest);
    				
    			}
    			
    			
    			$this->Flash->success(__('The {0} has been saved.', 'Material Request'));
    			return $this->redirect(['action' => 'pendingGrn']);
    			
    		
    	}
    	$this->loadModel('Uom');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	
    	
    	
    		$this->loadModel('ConsumableStoreMaster');
    		$consumablestores= $this->ConsumableStoreMaster->find('list', ['keyField' => 'id','valueField' => 'store_location','order'=>'store_location'], ['limit' => 200]);
    		
    	$this->set(compact('materialRequest','uom','unsufficientStock','consumablestores'));
    	$this->set('_serialize', ['materialRequest']);
    }
    
    
    
    public  function updateConsumableStock($MaterialRequest){
    	
    	
    	$this->loadModel('ConsumableTran');
    	$this->loadModel('ConsumableInventory');
    	$this->loadModel('ConsumableInventoryDetails');
    	//debug($MaterialRequest);die();
    
    	
    	$preconsumableInventorystock = $this->ConsumableInventory
    	->find()
    	->select(['id','product_id','test_request_id'])
    	->where(['product_id'=>$MaterialRequest['product_id'],'test_request_id'=> $MaterialRequest['id']])
    	
    	->toArray();
    	
    //echo "<pre>";
    
  //  print_r($preconsumableInventorystock);exit;
    	
    	
    	if(!empty( $preconsumableInventorystock[0])){
    		
    		
    		$BalanceQty=$preconsumableInventorystock[0]['balance_qty']+$MaterialRequest['issue_qty'];
    		$data=array('test_request_id'=> $MaterialRequest['id'],'product_id'=>$MaterialRequest['product_id'],'balance_qty'=>$BalanceQty,'owner_company_id'=>$this->Auth->User('owner_company_id'));
    		
    	///	echo "<pre>";
    	//	print_r($data);exit;
    		
    		$ConsumableInventorystockEntity=$this->ConsumableInventory->patchEntity($data);
    		if($result=$this->ConsumableInventory->save($ConsumableInventorystockEntity)){
    			
    		
    			$datadetails=array('consumable_inventory_id'=>$result->id,'consumable_store_id'=>$MaterialRequest['consumable_store_id'],'expiry_date'=>$MaterialRequest['expiry_date'],'balance_qty'=>$BalanceQty);
    			$ConsumableInventorystockdetailEntity=$this->ConsumableInventoryDetails->patchEntity($datadetails);
    			$this->ConsumableInventoryDetails->save($ConsumableInventorystockdetailEntity);
    			
    			$this->Flash->success(__('Saved'));
    		}
    		
    		
    			
    		
    	}
    	else{
    		
    		$BalanceQty=$MaterialRequest['issue_qty'];
    		$data=array('test_request_id'=> $MaterialRequest['id'],'product_id'=>$MaterialRequest['product_id'],'balance_qty'=>$BalanceQty,'owner_company_id'=>$this->Auth->User('owner_company_id'));
    		
    		$ConsumableInventorystockEntity=$this->ConsumableInventory->newEntity($data);
    		if($result=$this->ConsumableInventory->save($ConsumableInventorystockEntity)){
    			
    			$datadetails=array('consumable_inventory_id'=>$result->id,'consumable_store_id'=>$MaterialRequest['consumable_store_id'],'expiry_date'=>$MaterialRequest['expiry_date'],'balance_qty'=>$BalanceQty);
    			$ConsumableInventorystockdetailEntity=$this->ConsumableInventoryDetails->newEntity($datadetails);
    			$this->ConsumableInventoryDetails->save($ConsumableInventorystockdetailEntity);
    			$this->Flash->success(__('Saved'));
    		}
    		
    			
    		
    	}
    	
    
    				
    				
    
    }
    
    
    
    public function viewConsumableGrn($id = null)
    {
    	
    	$this->loadModel('ConsumableInventory');
    	$this->loadModel('ConsumableInventoryDetails');
    	
    	
    	$testRequest = $this->ConsumableInventory->get($id, [
    			'contain' => ['ConsumableInventoryDetails','ConsumablesMaster','ConsumableInventoryDetails.ConsumableStoreMaster']
    	]);
    	
    	
    	$this->loadModel('ConsumableStoreMaster');
    	$consumablestores= $this->ConsumableStoreMaster->find('list', ['keyField' => 'id','valueField' => 'store_location','order'=>'store_location'], ['limit' => 200]);
    	
    	$this->set(compact('testRequest','consumablestores'));
    	$this->set('_serialize', ['testRequest']);
    	
    	
    	
    }
    
    
    public function editConsumableGrn($id = null)
    {
    	
    	$this->loadModel('ConsumableInventory');
    	$this->loadModel('ConsumableInventoryDetails');
    	
    	
    	$testRequest = $this->ConsumableInventory->get($id, [
    			'contain' => ['ConsumableInventoryDetails','ConsumablesMaster']
    	]);
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		
    		$testRequest = $this->ConsumableInventory->patchEntity($testRequest, $this->request->data);
    		$testRequest['modified_by'] = $this->Auth->User('id');
    		//debug($this->request->data);exit;
    		if ($this->ConsumableInventory->save($testRequest)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Test Request'));
    			return $this->redirect(['action' => 'index']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Request'));
    		}
    	}
    	
    	
    	
    	
    	$this->loadModel('CompanyMaster');
    	$labname = $this->CompanyMaster->find('list', [
    			'keyField' => 'id',
    			'valueField' => 'Company_name',
    			'conditions' => ['CompanyMaster.company_types_master_id' => Configure::read('lab.Lab')],
    			'order' => ['CompanyMaster.Company_name' => 'ASC']
    	]);
    	
    	$this->loadModel('ConsumableStoreMaster');
    	$consumablestores= $this->ConsumableStoreMaster->find('list', ['keyField' => 'id','valueField' => 'store_location','order'=>'store_location'], ['limit' => 200]);
    	
    	$this->set(compact('labname','testRequest','consumablestores'));
    	$this->set('_serialize', ['testRequest']);
    	
    	
    	
    }
    
    
}
