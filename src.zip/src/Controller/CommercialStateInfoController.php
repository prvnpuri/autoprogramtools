<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CommercialStateInfo Controller
 *
 * @property \App\Model\Table\CommercialStateInfoTable $CommercialStateInfo
 *
 * @method \App\Model\Entity\CommercialStateInfo[] paginate($object = null, array $settings = [])
 */
class CommercialStateInfoController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['States']
        ];
        $commercialStateInfo = $this->paginate($this->CommercialStateInfo);

        $this->set(compact('commercialStateInfo'));
        $this->set('_serialize', ['commercialStateInfo']);
    }

    /**
     * View method
     *
     * @param string|null $id Commercial State Info id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $commercialStateInfo = $this->CommercialStateInfo->get($id, [
            'contain' => ['States']
        ]);

        $this->set('commercialStateInfo', $commercialStateInfo);
        $this->set('_serialize', ['commercialStateInfo']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $commercialStateInfo = $this->CommercialStateInfo->newEntity();
        if ($this->request->is('post')) {
            $commercialStateInfo = $this->CommercialStateInfo->patchEntity($commercialStateInfo, $this->request->data);
            if ($this->CommercialStateInfo->save($commercialStateInfo)) {
                $this->Flash->success(__('The {0} has been saved.', 'Commercial State Info'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Commercial State Info'));
            }
        }
        $states = $this->CommercialStateInfo->States->find('list', ['limit' => 200]);
        $this->set(compact('commercialStateInfo', 'states'));
        $this->set('_serialize', ['commercialStateInfo']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Commercial State Info id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $commercialStateInfo = $this->CommercialStateInfo->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $commercialStateInfo = $this->CommercialStateInfo->patchEntity($commercialStateInfo, $this->request->data);
            if ($this->CommercialStateInfo->save($commercialStateInfo)) {
                $this->Flash->success(__('The {0} has been saved.', 'Commercial State Info'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Commercial State Info'));
            }
        }
        $states = $this->CommercialStateInfo->States->find('list', ['limit' => 200]);
        $this->set(compact('commercialStateInfo', 'states'));
        $this->set('_serialize', ['commercialStateInfo']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Commercial State Info id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $commercialStateInfo = $this->CommercialStateInfo->get($id);
        if ($this->CommercialStateInfo->delete($commercialStateInfo)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Commercial State Info'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Commercial State Info'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
