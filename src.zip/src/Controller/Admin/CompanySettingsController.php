<?php
namespace App\Controller\Admin;


use App\Controller\AppController;

/**
 * CompanySettings Controller
 *
 * @property \App\Model\Table\CompanySettingsTable $CompanySettings
 *
 * @method \App\Model\Entity\CompanySetting[] paginate($object = null, array $settings = [])
 */
class CompanySettingsController extends AppController
{

	/**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function shashikant(){
		
		echo "This is the shashikant functionality";
		die();
	}


    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanies']
        ];
        $companySettings = $this->paginate($this->CompanySettings);
		$ownerCompaniesData = $companySettings->toArray();
		$this->set(compact('companySettings'));
        $this->set('_serialize', ['companySettings']);
    }

    /**
     * View method
     *
     * @param string|null $id Company Setting id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companySetting = $this->CompanySettings->get($id, [
            'contain' => ['OwnerCompanies']
        ]);
		
	
        $this->set('companySetting', $companySetting);
        $this->set('_serialize', ['companySetting']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companySetting = $this->CompanySettings->newEntity();
        if ($this->request->is('post')) {
            $companySetting = $this->CompanySettings->patchEntity($companySetting, $this->request->data);
            if ($this->CompanySettings->save($companySetting)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Setting'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Setting'));
            }
        }
        
		$ownerCompanies1 = $this->CompanySettings->OwnerCompanies->find('list', ['limit' => 200]); //'keyField' => 'id', 'valueField' => 'Company_name', 
		$ownerCompaniesData = $ownerCompanies1->toArray();
		$this->loadModel('Owner_companies');			
		foreach($ownerCompaniesData as $key=>$id){
			$ownerCompanies2 = $this->Owner_companies->get($id);						
			$ownerCompanies[$key] = $ownerCompanies2['Company_name'];
		}
		
		//$this->set('companyMaster', $companyMaster);			
		$this->set(compact('companySetting', 'ownerCompanies'));
        $this->set('_serialize', ['companySetting']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Setting id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    
	public function edit($id = null)
    {
        $companySetting = $this->CompanySettings->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companySetting = $this->CompanySettings->patchEntity($companySetting, $this->request->data);
            if ($this->CompanySettings->save($companySetting)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Setting'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Setting'));
            }
        }
        $ownerCompanies1 = $this->CompanySettings->OwnerCompanies->find('list', ['limit' => 200]);
        $ownerCompaniesData = $ownerCompanies1->toArray();
		$this->loadModel('Owner_companies');			
		foreach($ownerCompaniesData as $key=>$id){
			$ownerCompanies2 = $this->Owner_companies->get($id);						
			$ownerCompanies[$key] = $ownerCompanies2['Company_name'];
		}
		$this->set(compact('companySetting', 'ownerCompanies'));
        $this->set('_serialize', ['companySetting']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Setting id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companySetting = $this->CompanySettings->get($id);
        if ($this->CompanySettings->delete($companySetting)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Setting'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Setting'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
