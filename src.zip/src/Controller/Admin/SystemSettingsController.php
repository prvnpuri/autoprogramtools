<?php

namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * SystemSettings Controller
 *
 * @property \App\Model\Table\SystemSettingsTable $SystemSettings
 *
 * @method \App\Model\Entity\SystemSetting[] paginate($object = null, array $settings = [])
 */
class SystemSettingsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $systemSettings = $this->paginate($this->SystemSettings);
		
        $this->set(compact('systemSettings'));
        $this->set('_serialize', ['systemSettings']);
    }

    /**
     * View method
     *
     * @param string|null $id System Setting id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $systemSetting = $this->SystemSettings->get($id, [
            'contain' => []
        ]);
		
        $this->set('systemSetting', $systemSetting);
        $this->set('_serialize', ['systemSetting']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $systemSetting = $this->SystemSettings->newEntity();
        if ($this->request->is('post')) {
            $systemSetting = $this->SystemSettings->patchEntity($systemSetting, $this->request->data);
            if ($this->SystemSettings->save($systemSetting)) {
                $this->Flash->success(__('The {0} has been saved.', 'System Setting'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'System Setting'));
            }
        }
        $this->set(compact('systemSetting'));
        $this->set('_serialize', ['systemSetting']);
    }

    /**
     * Edit method
     *
     * @param string|null $id System Setting id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $systemSetting = $this->SystemSettings->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $systemSetting = $this->SystemSettings->patchEntity($systemSetting, $this->request->data);
            if ($this->SystemSettings->save($systemSetting)) {
                $this->Flash->success(__('The {0} has been saved.', 'System Setting'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'System Setting'));
            }
        }
        $this->set(compact('systemSetting'));
        $this->set('_serialize', ['systemSetting']);
    }

    /**
     * Delete method
     *
     * @param string|null $id System Setting id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $systemSetting = $this->SystemSettings->get($id);
        if ($this->SystemSettings->delete($systemSetting)) {
            $this->Flash->success(__('The {0} has been deleted.', 'System Setting'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'System Setting'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
