<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * MarketingCampaignCompany Controller
 *
 * @property \App\Model\Table\MarketingCampaignCompanyTable $MarketingCampaignCompany
 *
 * @method \App\Model\Entity\MarketingCampaignCompany[] paginate($object = null, array $settings = [])
 */
class MarketingCampaignCompanyController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['CompanyMasters', 'MarketingCampaigns']
        ];
        $marketingCampaignCompany = $this->paginate($this->MarketingCampaignCompany);

        $this->set(compact('marketingCampaignCompany'));
        $this->set('_serialize', ['marketingCampaignCompany']);
    }

    /**
     * View method
     *
     * @param string|null $id Marketing Campaign Company id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $marketingCampaignCompany = $this->MarketingCampaignCompany->get($id, [
            'contain' => ['CompanyMasters', 'MarketingCampaigns']
        ]);

        $this->set('marketingCampaignCompany', $marketingCampaignCompany);
        $this->set('_serialize', ['marketingCampaignCompany']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $marketingCampaignCompany = $this->MarketingCampaignCompany->newEntity();
        if ($this->request->is('post')) {
            $marketingCampaignCompany = $this->MarketingCampaignCompany->patchEntity($marketingCampaignCompany, $this->request->data);
            if ($this->MarketingCampaignCompany->save($marketingCampaignCompany)) {
                $this->Flash->success(__('The {0} has been saved.', 'Marketing Campaign Company'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Marketing Campaign Company'));
            }
        }
        $companyMasters = $this->MarketingCampaignCompany->CompanyMasters->find('list', ['limit' => 200]);
        $marketingCampaigns = $this->MarketingCampaignCompany->MarketingCampaigns->find('list', ['limit' => 200]);
        $this->set(compact('marketingCampaignCompany', 'companyMasters', 'marketingCampaigns'));
        $this->set('_serialize', ['marketingCampaignCompany']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Marketing Campaign Company id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $marketingCampaignCompany = $this->MarketingCampaignCompany->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $marketingCampaignCompany = $this->MarketingCampaignCompany->patchEntity($marketingCampaignCompany, $this->request->data);
            if ($this->MarketingCampaignCompany->save($marketingCampaignCompany)) {
                $this->Flash->success(__('The {0} has been saved.', 'Marketing Campaign Company'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Marketing Campaign Company'));
            }
        }
        $companyMasters = $this->MarketingCampaignCompany->CompanyMasters->find('list', ['limit' => 200]);
        $marketingCampaigns = $this->MarketingCampaignCompany->MarketingCampaigns->find('list', ['limit' => 200]);
        $this->set(compact('marketingCampaignCompany', 'companyMasters', 'marketingCampaigns'));
        $this->set('_serialize', ['marketingCampaignCompany']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Marketing Campaign Company id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $marketingCampaignCompany = $this->MarketingCampaignCompany->get($id);
        if ($this->MarketingCampaignCompany->delete($marketingCampaignCompany)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Marketing Campaign Company'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Marketing Campaign Company'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
