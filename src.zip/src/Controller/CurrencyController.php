<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Currency Controller
 *
 * @property \App\Model\Table\CurrencyTable $Currency
 *
 * @method \App\Model\Entity\Currency[] paginate($object = null, array $settings = [])
 */
class CurrencyController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="Currency.name like '%$query%'";
    	}
    	$this->paginate = [
    			
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","name","mini_currency","iso_code","iso_code_num","sign","blank"]
    	];
    	
    	$currency = $this->paginate($this->Currency);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('currency'));
    	$this->set( '_serialize', ['currency','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Currency id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $currency = $this->Currency->get($id, [
            'contain' => ['BuyerPurchaseOrder', 'CompanyBankMaster', 'Inquiry', 'Invoices', 'Lrcopy', 'Offer', 'Order', 'OwnerBankMaster', 'PaymentsReceived', 'PostshipmentRemittance', 'PostshipmentTransporter', 'PreShipmentBase', 'PreShipmentInsurance', 'SupplierInquiry', 'SupplierOffer', 'Transporters']
        ]);

        $this->set('currency', $currency);
        $this->set('_serialize', ['currency']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $currency = $this->Currency->newEntity();
        if ($this->request->is('post')) {
            $currency = $this->Currency->patchEntity($currency, $this->request->data);
            if ($this->Currency->save($currency)) {
                $this->Flash->success(__('The {0} has been saved.', 'Currency'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Currency'));
            }
        }
        $this->set(compact('currency'));
        $this->set('_serialize', ['currency']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Currency id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $currency = $this->Currency->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $currency = $this->Currency->patchEntity($currency, $this->request->data);
            if ($this->Currency->save($currency)) {
                $this->Flash->success(__('The {0} has been saved.', 'Currency'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Currency'));
            }
        }
        $this->set(compact('currency'));
        $this->set('_serialize', ['currency']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Currency id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $currency = $this->Currency->get($id);
        if ($this->Currency->delete($currency)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Currency'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Currency'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
