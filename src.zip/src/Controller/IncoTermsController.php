<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * IncoTerms Controller
 *
 * @property \App\Model\Table\IncoTermsTable $IncoTerms
 *
 * @method \App\Model\Entity\IncoTerm[] paginate($object = null, array $settings = [])
 */
class IncoTermsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="IncoTerms.inco_term like '%$query%'";
    	}
    	$this->paginate = [
    			
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","inco_term","term_description"]
    	];
    	
    	$incoTerms = $this->paginate($this->IncoTerms);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('incoTerms'));
    	$this->set( '_serialize', ['incoTerms','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Inco Term id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $incoTerm = $this->IncoTerms->get($id, [
            'contain' => []
        ]);

        $this->set('incoTerm', $incoTerm);
        $this->set('_serialize', ['incoTerm']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $incoTerm = $this->IncoTerms->newEntity();
        if ($this->request->is('post')) {
            $incoTerm = $this->IncoTerms->patchEntity($incoTerm, $this->request->data);
            if ($this->IncoTerms->save($incoTerm)) {
                $this->Flash->success(__('The {0} has been saved.', 'Inco Term'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Inco Term'));
            }
        }
        $this->set(compact('incoTerm'));
        $this->set('_serialize', ['incoTerm']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Inco Term id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $incoTerm = $this->IncoTerms->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $incoTerm = $this->IncoTerms->patchEntity($incoTerm, $this->request->data);
            if ($this->IncoTerms->save($incoTerm)) {
                $this->Flash->success(__('The {0} has been saved.', 'Inco Term'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Inco Term'));
            }
        }
        $this->set(compact('incoTerm'));
        $this->set('_serialize', ['incoTerm']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Inco Term id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $incoTerm = $this->IncoTerms->get($id);
        if ($this->IncoTerms->delete($incoTerm)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Inco Term'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Inco Term'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
