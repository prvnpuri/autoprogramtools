<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductIndustryApplications Controller
 *
 * @property \App\Model\Table\ProductIndustryApplicationsTable $ProductIndustryApplications
 *
 * @method \App\Model\Entity\ProductIndustryApplication[] paginate($object = null, array $settings = [])
 */
class ProductIndustryApplicationsMarketingController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ProductsMasterMarketing', 'IndustryTypeMaster', 'ProductApplications']
        ];
        $productIndustryApplications = $this->paginate($this->ProductIndustryApplicationsMarketing);

        $this->set(compact('productIndustryApplications'));
        $this->set('_serialize', ['productIndustryApplications']);
    }

    /**
     * View method
     *
     * @param string|null $id Product Industry Application id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productIndustryApplication = $this->ProductIndustryApplicationsMarketing->get($id, [
            'contain' => ['ProductsMasterMarketing', 'IndustryTypeMaster', 'ProductApplications']
        ]);

        $this->set('productIndustryApplication', $productIndustryApplication);
        $this->set('_serialize', ['productIndustryApplication']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productIndustryApplication = $this->ProductIndustryApplicationsMarketing->newEntity();
        if ($this->request->is('post')) {
            $productIndustryApplication = $this->ProductIndustryApplicationsMarketing->patchEntity($productIndustryApplication, $this->request->data);
            if ($this->ProductIndustryApplicationsMarketing->save($productIndustryApplication)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Industry Application'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Industry Application'));
            }
        }
        $productsMaster = $this->ProductIndustryApplicationsMarketing->ProductsMasterMarketing->find('list', ['limit' => 200]);
        $industryTypeMaster = $this->ProductIndustryApplicationsMarketing->IndustryTypeMaster->find('list', ['limit' => 200]);
        $productApplications = $this->ProductIndustryApplicationsMarketing->ProductApplications->find('list', ['limit' => 200]);
        $this->set(compact('productIndustryApplication', 'productsMaster', 'industryTypeMaster', 'productApplications'));
        $this->set('_serialize', ['productIndustryApplication']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product Industry Application id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productIndustryApplication = $this->ProductIndustryApplicationsMarketing->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productIndustryApplication = $this->ProductIndustryApplicationsMarketing->patchEntity($productIndustryApplication, $this->request->data);
            if ($this->ProductIndustryApplicationsMarketing->save($productIndustryApplication)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Industry Application'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Industry Application'));
            }
        }
        $productsMaster = $this->ProductIndustryApplicationsMarketing->ProductsMasterMarketing->find('list', ['limit' => 200]);
        $industryTypeMaster = $this->ProductIndustryApplicationsMarketing->IndustryTypeMaster->find('list', ['limit' => 200]);
        $productApplications = $this->ProductIndustryApplicationsMarketing->ProductApplications->find('list', ['limit' => 200]);
        $this->set(compact('productIndustryApplication', 'productsMaster', 'industryTypeMaster', 'productApplications'));
        $this->set('_serialize', ['productIndustryApplication']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product Industry Application id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productIndustryApplication = $this->ProductIndustryApplicationsMarketing->get($id);
        if ($this->ProductIndustryApplicationsMarketing->delete($productIndustryApplication)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product Industry Application'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product Industry Application'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
