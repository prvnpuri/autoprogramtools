<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PurchaseInvoice Controller
 *
 * @property \App\Model\Table\PurchaseInvoiceTable $PurchaseInvoice
 *
 * @method \App\Model\Entity\PurchaseInvoice[] paginate($object = null, array $settings = [])
 */
class PurchaseInvoiceController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $purchaseInvoice = $this->paginate($this->PurchaseInvoice);

        $this->set(compact('purchaseInvoice'));
        $this->set('_serialize', ['purchaseInvoice']);
    }

    /**
     * View method
     *
     * @param string|null $id Purchase Invoice id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $purchaseInvoice = $this->PurchaseInvoice->get($id, [
            'contain' => []
        ]);

        $this->set('purchaseInvoice', $purchaseInvoice);
        $this->set('_serialize', ['purchaseInvoice']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $purchaseInvoice = $this->PurchaseInvoice->newEntity();
        if ($this->request->is('post')) {
            $purchaseInvoice = $this->PurchaseInvoice->patchEntity($purchaseInvoice, $this->request->data);
            if ($this->PurchaseInvoice->save($purchaseInvoice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Purchase Invoice'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Invoice'));
            }
        }
        $this->set(compact('purchaseInvoice'));
        $this->set('_serialize', ['purchaseInvoice']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Purchase Invoice id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $purchaseInvoice = $this->PurchaseInvoice->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $purchaseInvoice = $this->PurchaseInvoice->patchEntity($purchaseInvoice, $this->request->data);
            if ($this->PurchaseInvoice->save($purchaseInvoice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Purchase Invoice'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Invoice'));
            }
        }
        $this->set(compact('purchaseInvoice'));
        $this->set('_serialize', ['purchaseInvoice']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Purchase Invoice id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $purchaseInvoice = $this->PurchaseInvoice->get($id);
        if ($this->PurchaseInvoice->delete($purchaseInvoice)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Purchase Invoice'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Purchase Invoice'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
