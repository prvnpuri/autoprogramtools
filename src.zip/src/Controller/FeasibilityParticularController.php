<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * FeasibilityParticular Controller
 *
 * @property \App\Model\Table\FeasibilityParticularTable $FeasibilityParticular
 *
 * @method \App\Model\Entity\FeasibilityParticular[] paginate($object = null, array $settings = [])
 */
class FeasibilityParticularController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ParticularMasters', 'FeasibilityMasters']
        ];
        $feasibilityParticular = $this->paginate($this->FeasibilityParticular);

        $this->set(compact('feasibilityParticular'));
        $this->set('_serialize', ['feasibilityParticular']);
    }

    /**
     * View method
     *
     * @param string|null $id Feasibility Particular id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $feasibilityParticular = $this->FeasibilityParticular->get($id, [
            'contain' => ['ParticularMasters', 'FeasibilityMasters']
        ]);

        $this->set('feasibilityParticular', $feasibilityParticular);
        $this->set('_serialize', ['feasibilityParticular']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $feasibilityParticular = $this->FeasibilityParticular->newEntity();
        if ($this->request->is('post')) {
            $feasibilityParticular = $this->FeasibilityParticular->patchEntity($feasibilityParticular, $this->request->data);
            if ($this->FeasibilityParticular->save($feasibilityParticular)) {
                $this->Flash->success(__('The {0} has been saved.', 'Feasibility Particular'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Feasibility Particular'));
            }
        }
        $particularMasters = $this->FeasibilityParticular->ParticularMasters->find('list', ['limit' => 200]);
        $feasibilityMasters = $this->FeasibilityParticular->FeasibilityMasters->find('list', ['limit' => 200]);
        $this->set(compact('feasibilityParticular', 'particularMasters', 'feasibilityMasters'));
        $this->set('_serialize', ['feasibilityParticular']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Feasibility Particular id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $feasibilityParticular = $this->FeasibilityParticular->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $feasibilityParticular = $this->FeasibilityParticular->patchEntity($feasibilityParticular, $this->request->data);
            if ($this->FeasibilityParticular->save($feasibilityParticular)) {
                $this->Flash->success(__('The {0} has been saved.', 'Feasibility Particular'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Feasibility Particular'));
            }
        }
        $particularMasters = $this->FeasibilityParticular->ParticularMasters->find('list', ['limit' => 200]);
        $feasibilityMasters = $this->FeasibilityParticular->FeasibilityMasters->find('list', ['limit' => 200]);
        $this->set(compact('feasibilityParticular', 'particularMasters', 'feasibilityMasters'));
        $this->set('_serialize', ['feasibilityParticular']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Feasibility Particular id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $feasibilityParticular = $this->FeasibilityParticular->get($id);
        if ($this->FeasibilityParticular->delete($feasibilityParticular)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Feasibility Particular'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Feasibility Particular'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
