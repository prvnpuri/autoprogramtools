<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * FeasibilityMaster Controller
 *
 * @property \App\Model\Table\FeasibilityMasterTable $FeasibilityMaster
 *
 * @method \App\Model\Entity\FeasibilityMaster[] paginate($object = null, array $settings = [])
 */
class FeasibilityMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Inquiry']
        ];
        $feasibilityMaster = $this->paginate($this->FeasibilityMaster);

        $this->set(compact('feasibilityMaster'));
        $this->set('_serialize', ['feasibilityMaster']);
    }

    /**
     * View method
     *
     * @param string|null $id Feasibility Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $feasibilityMaster = $this->FeasibilityMaster->get($id, [
            'contain' => ['Inquiry',  'FeasibilityParticular']
        ]);

        $this->set('feasibilityMaster', $feasibilityMaster);
        $this->set('_serialize', ['feasibilityMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($inqury_id=null)
    {
        $this->loadModel('Inquiry');
    	$inquiry = $this->Inquiry->get($inqury_id, [
    			'contain' => ['CompanyMaster', 'ProductsMaster','ProductsMaster.ProductDataTests','OwnerCompanies', 'Uom', 'Currency', 'FeasibilityMaster', 'Offer','PackingTerm','PaymentTerm','PortOfDischarge','Countries']
    	]);
    	
    	$this->set(compact('inquiry'));
    	
    	$this->loadModel('ParticularMaster');
    	
    	$feasibilityPerticular= $this->ParticularMaster->find('list', ['keyField' => 'id','valueField' => 'particulars']);
    	$this->set('FeasibilityPart',$feasibilityPerticular);
    	
    	
    	$feasibilityMaster = $this->FeasibilityMaster->newEntity();
        if ($this->request->is('post')) {
           
            $feasibilityMaster= $this->FeasibilityMaster->patchEntity($feasibilityMaster, $this->request->data,
            		[
            				'associated' => ['FeasibilityParticular']
            		]
            		);
           
             if ($this->FeasibilityMaster->save($feasibilityMaster)) {
             	
             	
             	
             	if(isset($this->request->data["offer_feasible"])){
             		$inquiry_id = $this->request->data["inquiry_id"];
             		$offer_feasible = $this->request->data["offer_feasible"];
             		if($offer_feasible == 0) // If feasibility not offered , Inquiry status should change to No offered.
             		{
             			
             			$inquiry1 = $this->Inquiry->get($inquiry_id);
             			
             			$data = array('id' => $inquiry_id, 'isoffered' => 0);
             			$inquiry1 = $this->Inquiry->patchEntity($inquiry1, $data);
             			
             			
             			$this->Inquiry->save($inquiry1);
             			
             			
             			
             		}
             	}
             	
              $this->Flash->success(__('The {0} has been saved.', 'Feasibility Master'));
                return $this->redirect(['controller'=>'Inquiry','action' => 'feasibilityindex']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Feasibility Master'));
            }
        }
       
        $this->set(compact('feasibilityMaster'));
        $this->set('_serialize', ['feasibilityMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Feasibility Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
    	
    	$this->loadModel('Inquiry');
        $feasibilityMaster = $this->FeasibilityMaster->get($id, [
        		'contain' => ['Inquiry','CompanyMaster','Inquiry.CompanyMaster','Inquiry.ProductsMaster','Inquiry.Uom','Inquiry.PackingTerm','FeasibilityParticular']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
        	
        	$feasibilityMaster= $this->FeasibilityMaster->patchEntity($feasibilityMaster, $this->request->getData(),
        			[
        					'associated' => ['FeasibilityParticular']
        			]
        			);
        	
        	
        	
        	
        	
            if ($this->FeasibilityMaster->save($feasibilityMaster)) {
            	
            	
            	if(isset($this->request->data["offer_feasible"])){
            		$inquiry_id = $this->request->data["inquiry_id"];
            		$offer_feasible = $this->request->data["offer_feasible"];
            		if($offer_feasible == 0) // If feasibility not offered , Inquiry status should change to No offered.
            		{
            			
            			$inquiry1 = $this->Inquiry->get($inquiry_id);
            			
            			$data = array('id' => $inquiry_id, 'isoffered' => 0);
            			$inquiry1 = $this->Inquiry->patchEntity($inquiry1, $data);
            			
            			
            			$this->Inquiry->save($inquiry1);
            			
            			
            			
            		}
            		else if($offer_feasible == 1){
            			$inquiry1 = $this->Inquiry->get($inquiry_id);
            			
            			$data = array('id' => $inquiry_id, 'isoffered' => NULL);
            			$inquiry1 = $this->Inquiry->patchEntity($inquiry1, $data);
            			
            			
            			$this->Inquiry->save($inquiry1);
            			
            		}
            	}
            	
            	
            	
            	
                $this->Flash->success(__('The {0} has been saved.', 'Feasibility Master'));
                return $this->redirect(['controller'=>'Inquiry','action' => 'feasibilityindex']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Feasibility Master'));
            }
        }
        $this->loadModel('ParticularMaster');
        
        $feasibilityPerticular= $this->ParticularMaster->find('list', ['keyField' => 'id','valueField' => 'particulars']);
        $this->set('FeasibilityPart',$feasibilityPerticular);
        $this->set(compact('feasibilityMaster'));
        $this->set('_serialize', ['feasibilityMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Feasibility Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $feasibilityMaster = $this->FeasibilityMaster->get($id);
        if ($this->FeasibilityMaster->delete($feasibilityMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Feasibility Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Feasibility Master'));
        }
        return $this->redirect(['Inquiry','action' => 'feasibility_index']);
    }
}
