<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Photo Controller
 *
 * @property \App\Model\Table\PhotoTable $Photo
 *
 * @method \App\Model\Entity\Photo[] paginate($object = null, array $settings = [])
 */
class PhotoController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanies']
        ];
        $photo = $this->paginate($this->Photo);

        $this->set(compact('photo'));
        $this->set('_serialize', ['photo']);
    }

    /**
     * View method
     *
     * @param string|null $id Photo id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $photo = $this->Photo->get($id, [
            'contain' => ['OwnerCompanies', 'Lrcopy']
        ]);

        $this->set('photo', $photo);
        $this->set('_serialize', ['photo']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $photo = $this->Photo->newEntity();
        if ($this->request->is('post')) {
            $photo = $this->Photo->patchEntity($photo, $this->request->data);
            if ($this->Photo->save($photo)) {
                $this->Flash->success(__('The {0} has been saved.', 'Photo'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Photo'));
            }
        }
        $ownerCompanies = $this->Photo->OwnerCompanies->find('list', ['limit' => 200]);
        $lrcopy = $this->Photo->Lrcopy->find('list', ['limit' => 200]);
        $this->set(compact('photo', 'ownerCompanies', 'lrcopy'));
        $this->set('_serialize', ['photo']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Photo id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $photo = $this->Photo->get($id, [
            'contain' => ['Lrcopy']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $photo = $this->Photo->patchEntity($photo, $this->request->data);
            if ($this->Photo->save($photo)) {
                $this->Flash->success(__('The {0} has been saved.', 'Photo'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Photo'));
            }
        }
        $ownerCompanies = $this->Photo->OwnerCompanies->find('list', ['limit' => 200]);
        $lrcopy = $this->Photo->Lrcopy->find('list', ['limit' => 200]);
        $this->set(compact('photo', 'ownerCompanies', 'lrcopy'));
        $this->set('_serialize', ['photo']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Photo id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $photo = $this->Photo->get($id);
        if ($this->Photo->delete($photo)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Photo'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Photo'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
