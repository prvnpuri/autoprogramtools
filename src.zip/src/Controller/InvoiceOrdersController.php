<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * InvoiceOrders Controller
 *
 * @property \App\Model\Table\InvoiceOrdersTable $InvoiceOrders
 *
 * @method \App\Model\Entity\InvoiceOrder[] paginate($object = null, array $settings = [])
 */
class InvoiceOrdersController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoice', 'Order']
        ];
        $invoiceOrders = $this->paginate($this->InvoiceOrders);

        $this->set(compact('invoiceOrders'));
        $this->set('_serialize', ['invoiceOrders']);
    }

    /**
     * View method
     *
     * @param string|null $id Invoice Order id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $invoiceOrder = $this->InvoiceOrders->get($id, [
            'contain' => ['Invoice', 'Order']
        ]);

        $this->set('invoiceOrder', $invoiceOrder);
        $this->set('_serialize', ['invoiceOrder']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $invoiceOrder = $this->InvoiceOrders->newEntity();
        if ($this->request->is('post')) {
            $invoiceOrder = $this->InvoiceOrders->patchEntity($invoiceOrder, $this->request->data);
            if ($this->InvoiceOrders->save($invoiceOrder)) {
                $this->Flash->success(__('The {0} has been saved.', 'Invoice Order'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice Order'));
            }
        }
        $invoice = $this->InvoiceOrders->Invoice->find('list', ['limit' => 200]);
        $order = $this->InvoiceOrders->Order->find('list', ['limit' => 200]);
        $this->set(compact('invoiceOrder', 'invoice', 'order'));
        $this->set('_serialize', ['invoiceOrder']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Invoice Order id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $invoiceOrder = $this->InvoiceOrders->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $invoiceOrder = $this->InvoiceOrders->patchEntity($invoiceOrder, $this->request->data);
            if ($this->InvoiceOrders->save($invoiceOrder)) {
                $this->Flash->success(__('The {0} has been saved.', 'Invoice Order'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice Order'));
            }
        }
        $invoice = $this->InvoiceOrders->Invoice->find('list', ['limit' => 200]);
        $order = $this->InvoiceOrders->Order->find('list', ['limit' => 200]);
        $this->set(compact('invoiceOrder', 'invoice', 'order'));
        $this->set('_serialize', ['invoiceOrder']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Invoice Order id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $invoiceOrder = $this->InvoiceOrders->get($id);
        if ($this->InvoiceOrders->delete($invoiceOrder)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Invoice Order'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Invoice Order'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
