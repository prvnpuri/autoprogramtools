<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Cache\Cache;
use Cake\Routing\Router;

/**
 * PettyCashDailyExpenses Controller
 *
 * @property \App\Model\Table\PettyCashDailyExpensesTable $PettyCashDailyExpenses
 *
 * @method \App\Model\Entity\PettyCashDailyExpense[] paginate($object = null, array $settings = [])
 */
class PettyCashDailyExpensesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
	
	public function index($ownercomp = null,$sublocation=null) {
				
		if((empty($ownercomp)) && (empty($sublocation)))
			$showPettyListing = 0;
		else
			$showPettyListing = 1;

		$this->set("showPettyListing", $showPettyListing);

		//Requested Search Data
		if(!empty($this->request->query)){
			$this->request->query['selectmonth'] = $this->request->query['_year'].'-'.$this->request->query['_month'];
		}
		
		$id=$this->Auth->user('id');		
		$this->request->data["Search"]=$this->request->query;
		$selectmonth=$this->request->data["Search"]["selectmonth"]=isset($this->request->data["Search"]["selectmonth"])?$this->request->data["Search"]["selectmonth"]:date("Y-m");
		$this->request->data["Search"]["_year"]=substr($selectmonth,0,4);
		$this->request->data["Search"]["_month"]=substr($selectmonth,5,2);
		
		//Loaded Required Models
		$this->loadModel('CompanyMaster');
		$this->loadModel('OwnerCompanies');
		$this->loadModel('CompanySublocation');
		$this->loadModel('PettyCashDailyExpenses');
								
								
		// echo "<br />sublocation".$sublocation;							
									
		//Company Sub Location							
		$CompanySubLocation=$this->CompanySublocation->find("all",array(
					"joins"=>array(
						array(
							"table"=>"owner_companies",
							"alias"=>"OwnerCompany",
							"conditions"=>"OwnerCompany.id=CompanySublocation.company_id",
							"type"=>"left"		
						)		
					),
					"conditions"=>array("CompanySublocation.id"=>$sublocation),					
				)
			);			
		$CompanySubLocation = $CompanySubLocation->first();
				
		//echo "ownercomp".$ownercomp;
					
		//Owner Companies		
		$OwnerCompanies=$this->OwnerCompanies->find("all",array(
					"conditions"=>array("OwnerCompanies.id"=>$ownercomp)
				)
			);
		
		$OwnerCompanies = $OwnerCompanies->first();
		$CompanySubLocation['OwnerCompanies'] = $OwnerCompanies;
		
		/*
		echo "CompanySubLocation<pre>";
		print_r($CompanySubLocation);
		
		die();
		*/

		// Petty Cash Expenses
		// 'PettyCashDailyExpenses.created_by'=>$id,
		$pettyCashExpenses=$this->PettyCashDailyExpenses->find("all",array(
					"conditions"=>array(
							'PettyCashDailyExpenses.owner_company_id'=>$ownercomp,							
							"PettyCashDailyExpenses.sublocation"=>$sublocation,
							"PettyCashDailyExpenses.transaction_date like '$selectmonth-%'"
							),
					"order"=>"PettyCashDailyExpenses.id desc",
				)
			);
				
		/*
		echo "CompanySubLocation<pre>";
		print_r($CompanySubLocation);
		
		die();
		*/
		
		$this->set("monthlyData",$this->getBalance($ownercomp, $sublocation, $selectmonth));
		$this->set("pettyCashExpenses",$pettyCashExpenses);
		$this->set("companySublocation",$CompanySubLocation);
		$this->set("sublocations",$sublocation);
		$this->set('ownercomp', $ownercomp);				
		$this->set('sublocation', $sublocation);				
		
	}

	//Finish Monthly Entry	
	public function finishMontlyEntry($pettyCashMonthlyId=null, $ownercomp = null,$sublocation=null){
			
		$this->loadModel('PettyCashMonthlyBalance');
		$update_conditions = array("petty_cash_monthly_balance.id"=>$pettyCashMonthlyId);
		$updatedata["entry_status"] = 0;

		if($this->PettyCashMonthlyBalance->updateAll([$updatedata], [$update_conditions])){
			$this->Flash->success(__('Petty Cash Montly expenses has been finished and Locked entry.'));
		}
		else{
			$this->Flash->error(__('Unalble to set finish Petty Cash Montly expenses.'));			
		}

		return $this->redirect(array("action"=>"index",$ownercomp,$sublocation));
	}

	//Get Balance Functionality	
	public function getBalance($ownercomp,$sublocation,$month){

		$id=$this->Auth->User('id');
		$balance_conditions=array(
			"owner_company"=>$ownercomp,
			"sublocation"=>$sublocation,
			"created_by"=>$id,
			"account_name"=>"petty_cash"
		);		
		
		$this->loadModel('AccountBalances');
		
		$AccountBalance=$this->AccountBalances->find("all",array("conditions"=>$balance_conditions));		
		$AccountBalance = $AccountBalance->first();	
		
		if(!isset($AccountBalance["id"])){
			
			$AccountBalance["AccountBalance"]=array(
				"owner_company"=>$ownercomp,
				"sublocation"=>$sublocation,
				"account_name"=>"petty_cash",
				"created_by"=>$id,
				"balance"=>"0"
			);
		}
		
		$MonthlyBalance_exists_conditions=array("month"=>$month,"sublocation"=>$sublocation,"owner_company_id"=>$ownercomp,"created_by"=>$id);
		$this->loadModel('PettyCashMonthlyBalance');
				
		$PettyCashMonthlyBalance=$this->PettyCashMonthlyBalance->find("all",array("conditions"=>$MonthlyBalance_exists_conditions));		
		$PettyCashMonthlyBalance = $PettyCashMonthlyBalance->first();	
		
		if(!isset($PettyCashMonthlyBalance['id'])){
						
			$prevbal=$this->PettyCashMonthlyBalance->find("all",array(
				"conditions"=>array(
						"PettyCashMonthlyBalance.month <= '$month' " ,"sublocation"=>$sublocation,"owner_company_id"=>$ownercomp,"created_by"=>$id
					),
				"order"=>"PettyCashMonthlyBalance.month desc",
			));
			$prevbal = $prevbal->first();				
			
			$PettyCashMonthlyBalance=array(
				"month"=>$month,
				"total_amount"=>"0.00",
				"net_balance_amount"=>isset($prevbal["net_balance_amount"])?$prevbal["net_balance_amount"]:"0.00",
				"sublocation"=>$sublocation,
				"owner_company_id"=>$ownercomp,
				"created_by"=>$id,
				"entry_status"=>1     // entry status for month = 1 ,0
				// 1 for Allow entry for that month
				// 0 for closed entry for that month and can't enter in future
			);
		}
				
		return array("AccountBalance"=>$AccountBalance["AccountBalance"],"PettyCashMonthlyBalance"=> $PettyCashMonthlyBalance);
	}
	
	/**
     * View method
     *
     * @param string|null $id Petty Cash Daily Expense id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $pettyCashDailyExpense = $this->PettyCashDailyExpenses->get($id, [
            'contain' => ['OwnerCompanies']
        ]);

        $this->set('pettyCashDailyExpense', $pettyCashDailyExpense);
        $this->set('_serialize', ['pettyCashDailyExpense']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
	 
	public function add($ownercomp = null,$sublocation=null) {
		
		$PettyCashDailyExpenses = $this->PettyCashDailyExpenses->newEntity();
		
		if($this->request->is('post')){

			$ownercomp = $this->request->data['owner_company_id'];
			$sublocation = $this->request->data['sublocation'];
		
			$data["PettyCashDailyExpenses"]=$this->request->data;
			$data["PettyCashDailyExpenses"]["owner_company_id"]=$this->request->data['owner_company_id'];
			$data["PettyCashDailyExpenses"]["sublocation"]=$this->request->data['sublocation'];
			$data["PettyCashDailyExpenses"]["created_by"]=$id=$this->Auth->User('id');
			$data["PettyCashDailyExpenses"]["date_of_creation"]=date ( 'Y-m-d H:i:s' );
			$data["PettyCashDailyExpenses"]["in_amount"]=trim($data["PettyCashDailyExpenses"]["in_amount"]," ")==""?0:$data["PettyCashDailyExpenses"]["in_amount"];
			$data["PettyCashDailyExpenses"]["out_amount"]=trim($data["PettyCashDailyExpenses"]["out_amount"]," ")==""?0:$data["PettyCashDailyExpenses"]["out_amount"];
						
			$PettyCashDailyExpenses = $this->PettyCashDailyExpenses->patchEntity($PettyCashDailyExpenses, $data);
			
			if(!empty($this->request->data['transaction_date'])){				
				$PettyCashDailyExpenses['transaction_date'] = date('Y-m-d', strtotime($this->request->data['transaction_date']));								
			}
			else{
				
				$PettyCashDailyExpenses['transaction_date'] = date('Y-m-d');
			}
			
			if($this->PettyCashDailyExpenses->save($PettyCashDailyExpenses)) {
			
				$in_amount=$data["PettyCashDailyExpenses"]["in_amount"];
				$out_amount=$data["PettyCashDailyExpenses"]["out_amount"];
				$month=$data["PettyCashDailyExpenses"]["selected_month"];
				$this->updateBalance($ownercomp, $sublocation, $in_amount, $out_amount, $month);				
				$this->Flash->success(__('Petty Cash Daily Expenses has been saved.'));												
				return $this->redirect(['action' => 'index', $ownercomp, $sublocation, "?"=>$this->request->query]);				
			}
			else{				
				$this->Flash->error(__('Petty Cash Daily Expenses unable to save.'));
				return $this->redirect(['action' => 'index', $ownercomp, $sublocation, "?"=>$this->request->query]);
			}
		}
	}	 
		
	//Update Balance Functionality	
	public function updateBalance($ownercomp,$sublocation,$in_amount,$out_amount,$month){
		
		$id=$this->Auth->User('id');		
		$entry_amount=$in_amount-$out_amount;
		$balance_conditions=array(
					"owner_company"=>$ownercomp,
					"sublocation"=>$sublocation,
					"created_by"=>$id,
					"account_name"=>"petty_cash"
				);
				
		/********* Account Balance **********/				
		$this->loadModel('AccountBalances');
		$AccountBalances=$this->AccountBalances->find("all",array("conditions"=>$balance_conditions));		
		$AccountBalances = $AccountBalances->first();
		
		if(!isset($AccountBalances["AccountBalances"]["id"])){
			
			//create account balance
			$AccountBalanceInfo["AccountBalances"]=array(
					"owner_company"=>$ownercomp,
					"sublocation"=>$sublocation,
					"created_by"=>$id,
					"account_name"=>"petty_cash",
					"balance"=>"0"
					);
					
			$AccountBalances = $this->AccountBalances->newEntity();			
			$AccountBalances = $this->AccountBalances->patchEntity($AccountBalances, $AccountBalanceInfo);
			
			$accountSavedData = $this->AccountBalances->save($AccountBalances);
			
			if($accountSavedData) {				
				//$AccountBalances["AccountBalances"]["id"]=$accountSavedData->id;
				$AccountBalances["id"]=$accountSavedData->id;
			}
		}
		/********* Account Balance **********/		
				
		
		/********* Monthly Balance **********/		
		//conditions for  monthly balance
		$MonthlyBalance_exists_conditions=array("month"=>$month,"sublocation"=>$sublocation,"owner_company_id"=>$ownercomp,"created_by"=>$id);
		
		$this->loadModel('PettyCashMonthlyBalance');
		$PettyCashMonthlyBalance=$this->PettyCashMonthlyBalance->find("all", array("conditions"=>$MonthlyBalance_exists_conditions));
		
		$PettyCashMonthlyBalance = $PettyCashMonthlyBalance->first();
				
		if(!isset($PettyCashMonthlyBalance["PettyCashMonthlyBalance"])){
			
			$this->loadModel('PettyCashMonthlyBalance');	
			
			// create Petty Cash Monthly Balance for new month
			$prevbal=$this->PettyCashMonthlyBalance->find("all",array(
					"conditions"=>array(
						"PettyCashMonthlyBalance.month <= '$month' " ,"sublocation"=>$sublocation,"owner_company_id"=>$ownercomp,"created_by"=>$id
					),
					"order"=>"PettyCashMonthlyBalance.month desc",
					));
			
			$prevbal = $prevbal->first();
			
			$PettyCashMonthlyBalanceInfo["PettyCashMonthlyBalance"]=array(
					"month"=>$month,
					"total_amount"=>"0.00",
					"net_balance_amount"=>isset($prevbal["net_balance_amount"])?$prevbal["net_balance_amount"]:"0.00",
					"sublocation"=>$sublocation,
					"owner_company_id"=>$ownercomp,
					"created_by"=>$id,
					"entry_status"=>1     // entry status for month = 1 ,0
					// 1 for Allow entry for that month
					// 0 for closed entry for that month and can't enter in future
			);
						
			$PettyCashMonthlyBalance = $this->PettyCashMonthlyBalance->newEntity();			
			$PettyCashMonthlyBalance = $this->PettyCashMonthlyBalance->patchEntity($PettyCashMonthlyBalance, $PettyCashMonthlyBalanceInfo);						
			$savedData = $this->PettyCashMonthlyBalance->save($PettyCashMonthlyBalance);
			
			if($savedData) {				
				$PettyCashMonthlyBalance["id"]=$savedData->id;		
			}						
		}
		
		/********* Monthly Balance **********/		
				
		// update total balance of month
		$this->PettyCashMonthlyBalance->id=$PettyCashMonthlyBalance["id"];
		$PettyCashMonthlyBalance["total_amount"]=$PettyCashMonthlyBalance["total_amount"]+$entry_amount;

		$pettyMonth = $PettyCashMonthlyBalance;

		$this->PettyCashMonthlyBalance->save($PettyCashMonthlyBalance);
		
		$AccountBalancesData["AccountBalances"]["balance"]=$AccountBalances["AccountBalance"]["balance"]+$entry_amount;
		$AccountBalancesData["AccountBalances"]["id"]=$AccountBalances["id"];
		
		$AccountBalances = $this->AccountBalances->patchEntity($AccountBalances, $AccountBalancesData);
		$this->AccountBalances->save($AccountBalances);
				
		// update net_balance from month
		$netbalancedata=array("net_balance_amount"=>"petty_cash_monthly_balance.net_balance_amount+".$entry_amount);
				
		$net_update_conditions=array(
				"DATE( CONCAT( petty_cash_monthly_balance.month, '-01' ) ) >= DATE( CONCAT( '$month','-01') )",
				"petty_cash_monthly_balance.sublocation"=>$sublocation,
				"petty_cash_monthly_balance.owner_company_id"=>$ownercomp,
				"petty_cash_monthly_balance.created_by"=>$id,
				);
				
		$updateQuery=$this->PettyCashMonthlyBalance->query();
		
		$updateQuery->update()
		->set(['net_balance_amount =  ( net_balance_amount + '.$entry_amount. ' ) ' ] )
		->where($net_update_conditions)->execute();		
	}
	
	 	
    /**
     * Edit method
     *
     * @param string|null $id Petty Cash Daily Expense id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($ownercomp = null,$sublocation=null)
    {		
		if($this->request->is('post')){
			
			$ownercomp = $this->request->data['owner_company_id'];
			$sublocation = $this->request->data['sublocation'];
			
			//$PettyCashDailyExpenses=$this->request->data;
			$pettyCashDailyExpenses = $this->PettyCashDailyExpenses->get($this->request->data['id'], [
				'contain' => []
			]);
			
			$data["PettyCashDailyExpenses"]=$this->request->data;			
			$data["PettyCashDailyExpenses"]['owner_company_id']=$ownercomp;
			$data["PettyCashDailyExpenses"]['sublocation']=$sublocation;
			$data["PettyCashDailyExpenses"]["id"]=$this->request->data['id'];
			$data["PettyCashDailyExpenses"]["modified_by"]=$id=$this->Auth->user('id');
			$data["PettyCashDailyExpenses"]["date_of_modification"]=date ( 'Y-m-d H:i:s' );
			$data[	"PettyCashDailyExpenses"]["in_amount"]=trim($data["PettyCashDailyExpenses"]["in_amount"]," ")==""?0:$data["PettyCashDailyExpenses"]["in_amount"];
			$data["PettyCashDailyExpenses"]["out_amount"]=trim($data["PettyCashDailyExpenses"]["out_amount"]," ")==""?0:$data["PettyCashDailyExpenses"]["out_amount"];
			
			$PettyCashDailyExpenses = $this->PettyCashDailyExpenses->patchEntity($pettyCashDailyExpenses, $data);
			
			if(!empty($this->request->data['transaction_date'])){				
				$PettyCashDailyExpenses['transaction_date'] = date('Y-m-d', strtotime($this->request->data['transaction_date']));								
			}
			else{
				$PettyCashDailyExpenses['transaction_date'] = date('Y-m-d');
			}
			
			if($this->PettyCashDailyExpenses->save($PettyCashDailyExpenses)){
				
				$in_amount=$data["PettyCashDailyExpenses"]["in_amount"]-$data["PettyCashDailyExpenses"]["pre_in_amount"];
				$out_amount=$data["PettyCashDailyExpenses"]["out_amount"]-$data["PettyCashDailyExpenses"]["pre_out_amount"];
				$month=$data["PettyCashDailyExpenses"]["selected_month"];
				$this->updateBalance($ownercomp, $sublocation, $in_amount, $out_amount, $month);				
				$this->Flash->success(__('Petty Cash Daily Expenses has been saved.'));
				return $this->redirect(['action' => 'index', $ownercomp, $sublocation, "?"=>$this->request->query]);				
			}
			else{				
				$this->Flash->error(__('Petty Cash Daily Expenses unable to save.'));
				return $this->redirect(['action' => 'index', $ownercomp, $sublocation, "?"=>$this->request->query]);
			}
		}
    }

    /**
     * Delete method
     *
     * @param string|null $id Petty Cash Daily Expense id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null){

		$pettyCashDailyExpense = $this->PettyCashDailyExpenses->get($id);
		
		if ($this->PettyCashDailyExpenses->delete($pettyCashDailyExpense)) {
			
			$ownercomp=$pettyCashDailyExpense["owner_company_id"];
			$sublocation=$pettyCashDailyExpense["sublocation"];
			$created_by=$pettyCashDailyExpense["created_by"];
			
			$transaction_date=$pettyCashDailyExpense["transaction_date"];
			$trans_month = date('Y-m', strtotime($transaction_date));			
			
			$in_amount=$pettyCashDailyExpense["in_amount"];			
			$out_amount=$pettyCashDailyExpense["out_amount"];
						
			$this->updateBalance($ownercomp, $sublocation, -$in_amount, -$out_amount, $trans_month);
			$this->Flash->success(__('The {0} has been deleted successfully.', 'PettyCash'));
			return $this->redirect(array("action"=>"index",$ownercomp,$sublocation,"?"=>$this->request->query));
		}
    }

	// Print Report Functionality
	public function printReport($ownercomp = null,$sublocation=null){
		
		$this->set('ownercomp', $ownercomp);
		$this->set('sublocation', $sublocation);
		
		$this->index($ownercomp,$sublocation);
		$this->viewBuilder()->setLayout('');
	}
}
