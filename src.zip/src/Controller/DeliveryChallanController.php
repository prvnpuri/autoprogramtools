<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * DeliveryChallan Controller
 *
 * @property \App\Model\Table\DeliveryChallanTable $DeliveryChallan
 *
 * @method \App\Model\Entity\DeliveryChallan[] paginate($object = null, array $settings = [])
 */
class DeliveryChallanController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices','Invoices.OwnerCompanies','Invoices.ConsigneeMaster','DeliveryChallanProduct.Order']
        ];
        
//         $invoice = $this->Invoices->find('all',[
//         		'fields'=>['OwnerCompanies.Company_name','CompanyMaster.Company_name','is_local','id','invoice_no','invoice_date','invoice_types_id','grand_total_amount','send_to_payment','send_to_postshipment'],
//         		'conditions'=>['invoice_types_id IN'=>$ids],
//         		'contain'=>['OwnerCompanies','CompanyMaster'],
//         ]);
        
        $deliveryChallan = $this->paginate($this->DeliveryChallan);

        $this->set(compact('deliveryChallan'));
        $this->set('_serialize', ['deliveryChallan']);
    }
    
    public function challanIndex($invoice_id){
    	$this->paginate = [
    			'contain' => ['Invoices','Invoices.OwnerCompanies','Invoices.ConsigneeMaster','DeliveryChallanProduct.Order']
    	];
    	$deliveryChallan = $this->paginate($this->DeliveryChallan);
    	
    	$this->set(compact('deliveryChallan','invoice_id'));
    	$this->set('_serialize', ['deliveryChallan']);
    	
    	
    	
    	
    	
    	
    	
    	
//     	$this->DeliveryChallan->virtualFields=array (
//     		'challan_qty'=> 'SUM(DeliveryChallanProduct.qty)'
//     	);
    
//     	$this->Paginator->settings=array(
//     			"fields"=>array(
//     					'DeliveryChallan.*','Invoice.invoice_no'),
//     			"conditions"=>array('invoice_id'=>$invoice_id),
//     			"recursive"=>-1,
//     			"order"=>'id desc',
//     			"joins"=>array(
//     					array(
//     							'table' => 'invoices',
//     							'alias' => 'Invoice',
//     							'conditions'=> array('DeliveryChallan.invoice_id = Invoice.id'),
//     							'type' => 'left'
//     					),
//     					array(
//     							'table' => 'delivery_challan_product',
//     							'alias' => 'DeliveryChallanProduct',
//     							'conditions'=> array('DeliveryChallan.id = DeliveryChallanProduct.delivery_challan_id'),
//     							'type' => 'left'
//     					),
//     			)
//     	);
    
//     	$this->set('DeliveryChallan', $this->Paginator->paginate('DeliveryChallan'));
//     	$this->set('invoice_id',$invoice_id);
    }

    /**
     * View method
     *
     * @param string|null $id Delivery Challan id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $deliveryChallan = $this->DeliveryChallan->get($id, [
            'contain' => ['Invoices', 'DeliveryChallanEwayBillPhoto', 'DeliveryChallanProduct']
        ]);

        $this->set('deliveryChallan', $deliveryChallan);
        $this->set('_serialize', ['deliveryChallan']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $deliveryChallan = $this->DeliveryChallan->newEntity();
        if ($this->request->is('post')) {
            $deliveryChallan = $this->DeliveryChallan->patchEntity($deliveryChallan, $this->request->data);
            $deliveryChallan['created_by'] = $this->Auth->User('id');
            if ($this->DeliveryChallan->save($deliveryChallan)) {
                $this->Flash->success(__('The {0} has been saved.', 'Delivery Challan'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Delivery Challan'));
            }
        }
        $invoices = $this->DeliveryChallan->Invoices->find('list', ['limit' => 200]);
        $this->set(compact('deliveryChallan', 'invoices'));
        $this->set('_serialize', ['deliveryChallan']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Delivery Challan id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $deliveryChallan = $this->DeliveryChallan->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $deliveryChallan = $this->DeliveryChallan->patchEntity($deliveryChallan, $this->request->data);
            $deliveryChallan['modified_by'] = $this->Auth->User('id');
            if ($this->DeliveryChallan->save($deliveryChallan)) {
                $this->Flash->success(__('The {0} has been saved.', 'Delivery Challan'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Delivery Challan'));
            }
        }
        $invoices = $this->DeliveryChallan->Invoices->find('list', ['limit' => 200]);
        $this->set(compact('deliveryChallan', 'invoices'));
        $this->set('_serialize', ['deliveryChallan']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Delivery Challan id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $deliveryChallan = $this->DeliveryChallan->get($id);
        if ($this->DeliveryChallan->delete($deliveryChallan)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Delivery Challan'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Delivery Challan'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
