<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductsNonCommercial Controller
 *
 * @property \App\Model\Table\ProductsNonCommercialTable $ProductsNonCommercial
 *
 * @method \App\Model\Entity\ProductsNonCommercial[] paginate($object = null, array $settings = [])
 */
class ProductsNonCommercialController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="ProductsNonCommercial.product_name like '%$query%'";
    	}
    	$this->paginate = [
    			
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","product_name","cas_no"]
    	];
    	
    	$productsNonCommercial = $this->paginate($this->ProductsNonCommercial);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('productsNonCommercial'));
    	$this->set( '_serialize', ['productsNonCommercial','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Products Non Commercial id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productsNonCommercial = $this->ProductsNonCommercial->get($id, [
            'contain' => []
        ]);

        $this->set('productsNonCommercial', $productsNonCommercial);
        $this->set('_serialize', ['productsNonCommercial']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productsNonCommercial = $this->ProductsNonCommercial->newEntity();
        if ($this->request->is('post')) {
            $productsNonCommercial = $this->ProductsNonCommercial->patchEntity($productsNonCommercial, $this->request->data);
            if ($this->ProductsNonCommercial->save($productsNonCommercial)) {
                $this->Flash->success(__('The {0} has been saved.', 'Products Non Commercial'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Products Non Commercial'));
            }
        }
        $this->set(compact('productsNonCommercial'));
        $this->set('_serialize', ['productsNonCommercial']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Products Non Commercial id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productsNonCommercial = $this->ProductsNonCommercial->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productsNonCommercial = $this->ProductsNonCommercial->patchEntity($productsNonCommercial, $this->request->data);
            if ($this->ProductsNonCommercial->save($productsNonCommercial)) {
                $this->Flash->success(__('The {0} has been saved.', 'Products Non Commercial'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Products Non Commercial'));
            }
        }
        $this->set(compact('productsNonCommercial'));
        $this->set('_serialize', ['productsNonCommercial']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Products Non Commercial id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productsNonCommercial = $this->ProductsNonCommercial->get($id);
        if ($this->ProductsNonCommercial->delete($productsNonCommercial)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Products Non Commercial'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Products Non Commercial'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
