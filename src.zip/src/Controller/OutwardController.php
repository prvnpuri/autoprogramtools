<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Outward Controller
 *
 * @property \App\Model\Table\OutwardTable $Outward
 *
 * @method \App\Model\Entity\Outward[] paginate($object = null, array $settings = [])
 */
class OutwardController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['WarehouseMaster', 'MaterialRequest', 'Oas', 'Orders', 'Products', 'Uoms', 'IncoTerms', 'Transporters']
        ];
        $outward = $this->paginate($this->Outward);

        $this->set(compact('outward'));
        $this->set('_serialize', ['outward']);
    }

    /**
     * View method
     *
     * @param string|null $id Outward id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $outward = $this->Outward->get($id, [
            'contain' => ['WarehouseMaster', 'MaterialRequest', 'Oas', 'Orders', 'Products', 'Uoms', 'IncoTerms', 'Transporters', 'SampleProduct', 'TransactionProduct']
        ]);

        $this->set('outward', $outward);
        $this->set('_serialize', ['outward']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $outward = $this->Outward->newEntity();
        if ($this->request->is('post')) {
            $outward = $this->Outward->patchEntity($outward, $this->request->data);
            if ($this->Outward->save($outward)) {
                $this->Flash->success(__('The {0} has been saved.', 'Outward'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Outward'));
            }
        }
        $warehouseMaster = $this->Outward->WarehouseMaster->find('list', ['limit' => 200]);
        $materialRequest = $this->Outward->MaterialRequest->find('list', ['limit' => 200]);
        $oas = $this->Outward->Oas->find('list', ['limit' => 200]);
        $orders = $this->Outward->Orders->find('list', ['limit' => 200]);
        $products = $this->Outward->Products->find('list', ['limit' => 200]);
        $uoms = $this->Outward->Uoms->find('list', ['limit' => 200]);
        $incoTerms = $this->Outward->IncoTerms->find('list', ['limit' => 200]);
        $transporters = $this->Outward->Transporters->find('list', ['limit' => 200]);
        $this->set(compact('outward', 'warehouseMaster', 'materialRequest', 'oas', 'orders', 'products', 'uoms', 'incoTerms', 'transporters'));
        $this->set('_serialize', ['outward']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Outward id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $outward = $this->Outward->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $outward = $this->Outward->patchEntity($outward, $this->request->data);
            if ($this->Outward->save($outward)) {
                $this->Flash->success(__('The {0} has been saved.', 'Outward'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Outward'));
            }
        }
        $warehouseMaster = $this->Outward->WarehouseMaster->find('list', ['limit' => 200]);
        $materialRequest = $this->Outward->MaterialRequest->find('list', ['limit' => 200]);
        $oas = $this->Outward->Oas->find('list', ['limit' => 200]);
        $orders = $this->Outward->Orders->find('list', ['limit' => 200]);
        $products = $this->Outward->Products->find('list', ['limit' => 200]);
        $uoms = $this->Outward->Uoms->find('list', ['limit' => 200]);
        $incoTerms = $this->Outward->IncoTerms->find('list', ['limit' => 200]);
        $transporters = $this->Outward->Transporters->find('list', ['limit' => 200]);
        $this->set(compact('outward', 'warehouseMaster', 'materialRequest', 'oas', 'orders', 'products', 'uoms', 'incoTerms', 'transporters'));
        $this->set('_serialize', ['outward']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Outward id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $outward = $this->Outward->get($id);
        if ($this->Outward->delete($outward)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Outward'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Outward'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
