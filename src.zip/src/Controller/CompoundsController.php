<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Compounds Controller
 *
 * @property \App\Model\Table\CompoundsTable $Compounds
 *
 * @method \App\Model\Entity\Compound[] paginate($object = null, array $settings = [])
 */
class CompoundsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products', 'ConstituentProducts']
        ];
        $compounds = $this->paginate($this->Compounds);

        $this->set(compact('compounds'));
        $this->set('_serialize', ['compounds']);
    }

    /**
     * View method
     *
     * @param string|null $id Compound id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $compound = $this->Compounds->get($id, [
            'contain' => ['Products', 'ConstituentProducts']
        ]);

        $this->set('compound', $compound);
        $this->set('_serialize', ['compound']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $compound = $this->Compounds->newEntity();
        if ($this->request->is('post')) {
            $compound = $this->Compounds->patchEntity($compound, $this->request->data);
            if ($this->Compounds->save($compound)) {
                $this->Flash->success(__('The {0} has been saved.', 'Compound'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Compound'));
            }
        }
        $products = $this->Compounds->Products->find('list', ['limit' => 200]);
        $constituentProducts = $this->Compounds->ConstituentProducts->find('list', ['limit' => 200]);
        $this->set(compact('compound', 'products', 'constituentProducts'));
        $this->set('_serialize', ['compound']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Compound id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $compound = $this->Compounds->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $compound = $this->Compounds->patchEntity($compound, $this->request->data);
            if ($this->Compounds->save($compound)) {
                $this->Flash->success(__('The {0} has been saved.', 'Compound'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Compound'));
            }
        }
        $products = $this->Compounds->Products->find('list', ['limit' => 200]);
        $constituentProducts = $this->Compounds->ConstituentProducts->find('list', ['limit' => 200]);
        $this->set(compact('compound', 'products', 'constituentProducts'));
        $this->set('_serialize', ['compound']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Compound id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $compound = $this->Compounds->get($id);
        if ($this->Compounds->delete($compound)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Compound'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Compound'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
