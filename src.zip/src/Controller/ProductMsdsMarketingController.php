<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductMsds Controller
 *
 * @property \App\Model\Table\ProductMsdsTable $ProductMsds
 *
 * @method \App\Model\Entity\ProductMsd[] paginate($object = null, array $settings = [])
 */
class ProductMsdsMarketingController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ProductsMasterMarketing', 'ProductMsdsForm']
        ];
        $productMsds = $this->paginate($this->ProductMsds);

        $this->set(compact('productMsds'));
        $this->set('_serialize', ['productMsds']);
    }

    /**
     * View method
     *
     * @param string|null $id Product Msd id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
//     public function view($id = null)
//     {
//         $productMsd = $this->ProductMsds->get($id, [
//             'contain' => ['ProductsMaster', 'ProductMsdsForm']
//         ]);

//         $this->set('productMsd', $productMsd);
//         $this->set('_serialize', ['productMsd']);
//     }

    
    
    
    public function view($id = null,$caseno=null,$isdownload=1){
    	
    	
    	$this->loadModel('ProductsMasterMarketing');
    	$this->loadModel('ProductMsdsForm');
    	$this->loadModel('OwnerCompanies');
    	
    	$this->set('products_id', $id);
    	
    	$productresult= $this->ProductsMasterMarketing->get($id);
    	
    	$this->set('productresult',$productresult);
    	
    	$productmsdresult = $this->ProductMsdsMarketing->find('all', array(
    			'conditions' => array('ProductMsdsMarketing.products_master_id' => $id)
    	))->toArray();
    	$results=array();
    	foreach( $productmsdresult as &$msdresult)
    	{
//     		echo "<pre>";
//     		print_r($msdresult);exit;
    		
    		
    		
    		if($msdresult['product_msds_form_id']=="10")
    		{
//     			$productcompany	=$this->OwnerCompanies->find('first',array('conditions'=>array('OwnerCompanies.id'=>$msdresult['data']),
//     					'fields' => array('OwnerCompanies.Company_name','OwnerCompanies.Address')));
//     			$data1= isset( $productcompany['Company_name'] ) ? $productcompany['Company_name'] :"";
//     			$data2= isset($productcompany['Address'] )?$productcompany['Address']:"";
    			
    			
//     			$msdresult['data']="$data1 \r\n\n $data2" ;
    			
    		
    			$query=$this->OwnerCompanies->find('all',array('conditions'=>array('OwnerCompanies.id'=>$msdresult['data']),
    			'fields' => array('OwnerCompanies.Company_name','OwnerCompanies.Address')));
    		
    			$productcompany= $query->first();
    			
    			$data1= isset( $productcompany['Company_name'] ) ? $productcompany['Company_name'] :"";
    			$data2= isset($productcompany['Address'] )?$productcompany['Address']:"";
    			
    			$msdresult['data']="$data1 \r\n\n $data2" ;
    			
    		
    		
    		}
    		
    	}
    	if (isset($results['products_master_id'])) {
    		$results=$results['products_master_id'];
    	}
    	
    
    	
    	$productresult= $this->ProductsMasterMarketing->get($id);
    	
    	
    	$productmsdresult= $this->ProductMsdsMarketing->find('all', array(
    			'conditions' => array('ProductMsdsMarketing.products_master_id' => $id)
    	))->toArray();
    	
    	
    	
    	$this->set( "product_msd_count", count($productmsdresult));
    	$this->set( "has_msds_pdf", $productresult["has_msds_pdf"]);
    	
    	$productmsdformresult = $this->ProductMsdsForm->find('all', array('order'=>array('ProductMsdsForm.display_order')));
    	
    	//Now populate the data in the form from the productmsd table
    	$combined_array = array();
    	$i = 0;
    	$operationtype = "";
    	
    	foreach ($productmsdformresult as $pmfr){
    		$combined_array[$i] = $pmfr;
    		if(isset($pmfr['auto_value'])) {
    			$aval = explode(":", $pmfr['auto_value']);
    			//var_dump($aval);
    			//using variable as a variable.
    			$combined_array[$i]["data"] = ${ $aval[0] }[$aval[1]][$aval[2]][$aval[3]];
    		}
    		
    		
    		if (!empty($productmsdresult)){
    			$operationtype = "edit";
    			foreach ($productmsdresult as $pmr){
    				if ($pmfr['id'] == $pmr['product_msds_form_id']){
    					$combined_array[$i]["data"] = $pmr['data'];
    					$combined_array[$i]["data_col2"] = $pmr['data_col2'];
    					$combined_array[$i]["data_col3"] = $pmr['data_col3'];
    					$combined_array[$i]["productmsd_id"] = $pmr['id'];
    				}
    			}
    		} else {
    			$operationtype = "add";
    		}
    		$i++;
    	}
    	//$this->set('productmsdresult', $productmsdresult);
    	$this->set('productMsdsForms', $combined_array);
    	$ownerCompanies= $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
    	$this->set("ownerCompanies",$ownerCompanies);
//     
    }
    
    
    
    
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($id = null, $prnt = null)
    {
    	
    	$this->loadModel('ProductsMasterMarketing');
    	$this->loadModel('ProductMsdsForm');
    	$this->loadModel('OwnerCompanies');
    	$userid=$this->Auth->User('id');
    	$forprint = "false";
    	    	if ($prnt != null && $prnt == "print") {
    	    		//$this->layout = "print";
    	    		$this->viewBuilder()->layout();
    	    		$forprint = "true";
    	    	}
    	
    	
    	
    	if ($this->request->is('post')) {
    	
	    	//$productMsd = $this->ProductMsds->patchEntity($productMsd, $this->request->data);
	    	$product_msds_data=$this->request->getData();
	    	$product_id=$product_msds_data["productid"];
	    	unset($product_msds_data["productid"]);
	    	unset($product_msds_data["operationtype"]);
	    	foreach ($product_msds_data as &$product_msds){
	    		$product_msds["products_master_id"]=$product_id;
	    	}
	    	
	//     	print_r($productMsd);exit;
	    		
	    	
	    	
	    	foreach ($product_msds_data as  &$dd){
	    		
		    	if (isset($dd['data']) && is_array($dd['data'])){
		    		$dd['data'] = implode(":", $dd['data']);
		    		}
		    	if (isset($dd['data_col2']) && is_array($dd['data_col2'])){
		    		$dd['data_col2'] = implode(":", $dd['data_col2']);
		    	}
		    	$dd["products_master_id"]=$id;
	    	}
	    	$productMsdEntities= $this->ProductMsdsMarketing->newEntities($product_msds_data);
	    	//debug($productMsdEntities);exit();
	    	
	    		
	    	if ($this->ProductMsdsMarketing->saveMany($productMsdEntities)) {
	    	
	    		
	    		
			    	if ($this->request->data['operationtype'] == "add"){
			    				
				    	$productsmast = $this->ProductsMasterMarketing->get($id);
				    				
				    	$data = array('id' => $id , 'msds_created_by' => $userid);
				    	$productsmast= $this->ProductsMasterMarketing->patchEntity($productsmast, $data);
				    	$this->ProductsMasterMarketing->save($productsmast);
				    	$this->Flash->success(__('The product msds has been saved.'));
				    } else {
				    	$productsmast = $this->ProductsMasterMarketing->get($id);
				    					
				    	$data = array('id' => $id , 'msds_modified_by' => $userid);
				    	$productsmast= $this->ProductsMasterMarketing->patchEntity($productsmast, $data);
				    	$this->ProductsMasterMarketing->save($productsmast);
				    	$this->Flash->success(__('The product msd has been updated.'));
				    }
				    $product= $this->ProductsMasterMarketing->get($id);
				    if(isset($product["has_msds_pdf"]) && $product["has_msds_pdf"]==1) {
				    	return $this->redirect( array('controller'=>'ProductMsdsMarketing', 'action' => 'product_msds_marketing',$id,'update',2));
			    	} else {
			    		$this->Flash->success(__('The {0} has been updated but unable to generate MSDS pdf..', 'Product MSDS'));
			    	}
				    return $this->redirect(array('controller'=>'ProductsMasterMarketing', 'action' => 'index'));
		    			
		      } else {
	    			$this->log("Error : " . mysql_errno());
	    			if ($this->request->data['operationtype'] == "add"){
	    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product MSDS'));
		   	 		}else {
		    			$this->Flash->error(__('The {0} could not be updated. Please, try again.', 'Product MSDS'));
		    		}
	    	 }
    	}

    $this->set('product_id', $id);
    $productresult = $this->ProductsMasterMarketing->get($id);
   $productmsdresult=$this->ProductMsdsMarketing->find("all",array(
    			"fields"=>array("id","products_master_id","product_msds_form_id","data","data_col2","data_col3"),
    			"conditions"=>array("products_master_id"=>$id)
    	))->toArray();
    	
 
    	
    	$this->set( "product_msd_count", count($productmsdresult));
    	$this->set( "has_msds_pdf", $productresult["has_msds_pdf"]);
    	
    	$productmsdformresult = $this->ProductMsdsForm->find('all', array('order'=>array('ProductMsdsForm.display_order')));
    	
    	//Now populate the data in the form from the productmsd table
    	$combined_array = array();
    	$i = 0;
    	$operationtype = "";
    	
    	foreach ($productmsdformresult as $pmfr){
    	
    	
    		$combined_array[$i] = $pmfr;
    		if(isset($pmfr['auto_value'])) {
    			$aval = explode(":", $pmfr['auto_value']);
    	
    			$combined_array[$i]["data"] = ${ $aval[0] }[$aval[1]][$aval[2]][$aval[3]];
    		}
    	
    	
    		if (!empty($productmsdresult)){
    			$operationtype = "edit";
    			foreach ($productmsdresult as $pmr){
    				if ($pmfr['id'] == $pmr['product_msds_form_id']){
    					$combined_array[$i]["data"] = $pmr['data'];
    					$combined_array[$i]["data_col2"] = $pmr['data_col2'];
    					$combined_array[$i]["data_col3"] = $pmr['data_col3'];
    					$combined_array[$i]["productmsd_id"] = $pmr['id'];
    				}
    			}
    		} else {
    			$operationtype = "add";
    		}
    		$i++;
    	}
    	$this->set('productMsdsForms', $combined_array);
    	$this->set('operationtype', $operationtype);
    	$this->set('forprint', $forprint);
    	$ownerCompanies= $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
    	$this->set("ownerCompanies",$ownerCompanies);
    	    	
    	    	$this->set(compact('productMsd'));
    	    	$this->set('_serialize', ['productMsd']);
    	
    }

   
    
    
    public function downloadPdf($id = null,$caseno=null,$isdownload=1){

    	
    	$this->loadModel('ProductsMasterMarketing');
    	$this->loadModel('ProductMsdsForm');
    	$this->loadModel('OwnerCompanies');
    	
    	
    	
    	$this->set('products_id', $id);
    	$productresult= $this->ProductsMasterMarketing->get($id);
    	$this->set('productresult',$productresult);
    	
    	$productmsdresult= $this->ProductMsdsMarketing->find('all', array(
    			'conditions' => array('ProductMsdsMarketing.products_master_id' => $id),
    	))->contain("ProductMsdsForm");
    	$results=array();
    
    	
    
    	$this->set('results',$productmsdresult);
    	if (isset($results['products_master_id'])) {
    		$results=$results['products_master_id'];
    	}
    	
    	//***create pdfs for all**********
    	$ownercompanies=$this->OwnerCompanies->find("all");
    	
    	
    	foreach($ownercompanies as $ownercompany){
    		$this->set("ownercomapny",$ownercompany);
    		
    	  $productmsdformresult = $this->ProductMsdsForm->find('all', array('order'=>array('ProductMsdsForm.display_order')));
    	  $this->set('productmsdformresult', $productmsdformresult);
    	  $CakePdf = new \CakePdf\Pdf\CakePdf();
    	  $CakePdf->template('product_msds_marketing', 'default');
    	  $CakePdf->viewVars($this->viewVars);
    	  
    	  $pdf = $CakePdf->output();
    	  
    	 
    	  
    	  
    	  
    	  $pdf = $CakePdf->write(WWW_ROOT.DS.'upload'. DS.'product-marketing-msds'.DS.$productresult->cas_no.'_'.$ownercompany->id.'.pdf');
    	  
    	}
    	  
    	  $message="";
    	  $pro = $this->ProductsMasterMarketing->get($id);
    	  
    	  $data = array('id' => $id , 'has_msds_pdf' => 1);
    	  $pro= $this->ProductsMasterMarketing->patchEntity($pro, $data);
    	 
    	  if($this->ProductsMasterMarketing->save($pro)){
    		$message="MSDS Pdf has been generated.";
	    	}else{
	    		$message="MSDS Pdf has failed to generated.";
	    	}
    	
    	$isdownload=intval($isdownload);
    	
    	if( $isdownload==1){
    		$this->Flash->success($message);
    		return $this->redirect(array('controller'=>'ProductsMasterMarketing','action' => 'index'));
    	}else if($isdownload==2){
    		return $this->redirect(array('controller'=>'ProductsMasterMarketing','action' => 'index'));
    	} 
    	
    	
    	//$this->viewBuilder()->setLayout("../Pdf/default");
    	//$this->render('/Pdf/product_msds_marketing');
    	
    	
    }
    
    
    
    public function print_pdf($id = null,$filename=null){
    	
    	if(!isset($filename)){
    		exit ("Error_On_Prameter:File Not Found.");
    	}
    	$para=APP."pdf".DS.$filename;
    	$file=new File($para);
    	
    	if(!$file->exists()||!$file->readable()){
    		exit ("Error_Does_Not_Exist:File Not Found.");
    	}
    	// 		exit($id."/".$filename);
    	header("Content-type: application/pdf");
    	
    	$str=$file->read();
    	echo $str;
    	$file->close();
    	
    	exit();
    	//  $this->render('/Pdf/show_pdf');
    }
    
    
    
   
    /**
     * Delete method
     *
     * @param string|null $id Product Msd id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productMsd = $this->ProductMsdsMarketing->get($id);
        if ($this->ProductMsds->delete($productMsd)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product Msd'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product Msd'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
