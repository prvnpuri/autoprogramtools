<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;
/**
 * TaskCompleted Controller
 *
 * @property \App\Model\Table\TaskCompletedTable $TaskCompleted
 *
 * @method \App\Model\Entity\TaskCompleted[] paginate($object = null, array $settings = [])
 */
class TaskCompletedController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $oldmonth=isset($this->request->query['Select_Month'])?$this->request->query['Select_Month']:'13';
		$currentyear=isset($this->request->query['Select_Year'])?$this->request->query['Select_Year']:'2018';
		
		//$currentyear = date('Y');
		$this->set('currentYear',$currentyear);
		if(isset($oldmonth) && $oldmonth != 13 ){
			$currentMonth = $oldmonth + 1;		
			$this->set('currentMonth',$currentMonth);
			
			$oldTasks = $this->TaskCompleted->find('all',array(
					'conditions'=> array('month(completed_date)'=> $currentMonth , 'year(completed_date)'=> $currentyear )));			
					$oldTaskscount = count($oldTasks->toArray());
			//debug($oldTaskscount);exit;
			$taskCompleteds = $this->TaskCompleted->find('all',array(
					'fields'=>array('task_id', 'day'=>'DAY(`completed_date`)'),
					//'conditions'=> array("completed_date like '$currentyear-$currentMonth-%'")
					'conditions'=> array('month(completed_date)'=> $currentMonth , 'year(completed_date)'=> $currentyear )));
						
					/* )
			); */
			$renderArray=array();
			$rearrangeCnt=0;
			foreach ($taskCompleteds as $taskComKey => $taskComVal)
			{
				$renderArray[$taskComVal['task_id']][$rearrangeCnt]['task_id']=$taskComVal['task_id'];
				$renderArray[$taskComVal['task_id']][$rearrangeCnt]['day']=$taskComVal['day'];
				$rearrangeCnt++;
			}
			
			$this->set('taskCompleteds',$renderArray);
			$tasks = $this->TaskCompleted->Tasks->find('all',array(
					'fields'=>array('id','task',"task_type"),
					"order"=>"task_type asc,task asc"
			))->toArray();
			$this->set('tasks',$tasks);
			
			$maxTaskTypeIds=$this->TaskCompleted->Tasks->find('all',array(
					'fields'=>array('task_type','maxTypeid'=>'MAX(`id`)'),
					'group' => array('task_type'),
					'order'=> array('id'=>'Asc')))->toArray();
			
			$renderArray=array();
			foreach ($maxTaskTypeIds as $taskTypKey => $taskTypVal)
			{
				$renderArray[$taskTypVal['task_type']]=$taskTypVal['task_type'];
				$renderArray[$taskTypVal['maxTypeid']]=$taskTypVal['maxTypeid'];
			}
			// 		print_r($renderArray);exit();
			$this->set('maxRowCnt',$renderArray);
		//	debug($oldTaskscount);exit;
			if ($oldTaskscount > 0){
			//	$this->TaskCompleted->deleteAll(array('month(TaskCompleted.completed_date)' => $oldmonth), false);
			}
				
		}else{		
		
		//to display current month & it's prev months records date('m') - $mnt;
		$currentMonth = date('m');	
        $this->set('currentMonth',$currentMonth);
        //debug($currentMonth);
		$taskCompleteds = $this->TaskCompleted->find('all',[
                'fields'=>['task_id','day'=>'DAY(`completed_date`)'],
                'conditions'=> array("completed_date like '$currentyear-$currentMonth-%'")
               
        ])->toArray();
    //  debug($taskCompleteds);exit;
		$renderArray=array();
		$rearrangeCnt=0;
		foreach ($taskCompleteds as $taskComKey => $taskComVal)
		{ 
			$renderArray[$taskComVal['task_id']][$rearrangeCnt]['task_id']=$taskComVal['task_id'];
			$renderArray[$taskComVal['task_id']][$rearrangeCnt]['day']=$taskComVal['day'];
			$rearrangeCnt++;			
		}		
       // debug($renderArray);exit;
		$this->set('taskCompleteds',$renderArray);
       
		$tasks = $this->TaskCompleted->Tasks->find('all',array(
				'fields'=>array('id','task',"task_type"),
				"order"=>"task_type asc,task asc"
				))->toArray();
		$this->set('tasks',$tasks);
		//debug($tasks);exit;
		$this->loadModel('Tasks');
		$maxTaskTypeIds=$this->Tasks->find('all',array(
									'fields'=>array('task_type','maxTypeid'=>'MAX(`id`)'),
									'group' => array('task_type'),				
									'order'=> array('id'=>'Asc')))->toArray();		
        //debug($maxTaskTypeIds);exit();                            
		$renderArray=array();		
		foreach ($maxTaskTypeIds as $taskTypKey => $taskTypVal)
		{
			$renderArray[$taskTypVal['task_type']]=$taskTypVal['task_type'];
			$renderArray[$taskTypVal['maxTypeid']]=$taskTypVal['maxTypeid'];
        }	
       
// 		print_r($renderArray);exit();
		$this->set('maxRowCnt',$renderArray);
		} // end of else


       
    }

    /**
     * View method
     *
     * @param string|null $id Task Completed id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $taskCompleted = $this->TaskCompleted->get($id, [
            'contain' => ['Tasks']
        ]);

        $this->set('taskCompleted', $taskCompleted);
        $this->set('_serialize', ['taskCompleted']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($taskType = null, $tdate = null)
    {
        $taskCompleted = $this->TaskCompleted->newEntity();
       
        if ($this->request->is('post') && !isset($this->request->params['pass']['1'])) {
            //debug($this->request->data['nostore']['created_by']);exit;
            foreach ($this->request->data['TaskCompleted'] as $filekey => $fileval)
			{
               // debug($fileval);exit;
				if($fileval['select']==1)
				{
                    $this->request->data['TaskCompleted'][$filekey]['completed_date']=$this->request->data['nostore']['date1'];
                    $this->request->data['TaskCompleted'][$filekey]['created_by']=$this->request->data['nostore']['created_by'];
                   // debug($this->request->data['nostore']['created_by']);exit;
					$this->request->data['TaskCompleted'][$filekey]['date_of_creation']=date('Y-m-d H:i:s');
				}
				else 
				{	//if task is not completed i.e. checkbox is unchecked then delete the record 					
					if (isset($this->request->data['TaskCompleted'][$filekey]['id'])) {						
						$this->TaskCompleted->delete($this->request->data['TaskCompleted'][$filekey]['id']);
					}
					unset($this->request->data['TaskCompleted'][$filekey]);				
                }
               
            }
            
            $taskCompleted = $this->TaskCompleted->newEntities($this->request->data['TaskCompleted']);
            debug($taskCompleted);exit;
            if ($this->TaskCompleted->saveMany($taskCompleted)) {
                //echo ('hii'); exit;
                $this->Flash->success(__('The {0} has been saved.', 'Task Completed'));
                return $this->redirect(['action' => 'index']);
            } else {
                echo('bye');exit;
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Task Completed'));
            }
        }else 
		{
			//code if tdate = null then pass current date in coundition else tdate to retrive records	
			if(isset($this->request->params['pass']['1']))
				$cmpDate = $this->request->params['pass']['1'];
			else
				$cmpDate=date("Y-m-d");
			
			$this->set('cmpDate',$cmpDate);		
            
			$taskType = $this->request->params['pass']['0'];
            $this->set('taskType',$taskType);
            
			//for Daily & weekend
			if ($taskType == "Daily")
			{
				$seltimestamp = strtotime($cmpDate);
                $selday = date('D', $seltimestamp);	
                
				//if saturday then show Daily as well as Weekend
				if ($selday == 'Sat'){
					$cond = array('task_type !=' => 'Monthly') ;					
				}				
				else 
				{
                    $cond = array('task_type' => 'Daily') ;
                   
                    //debug ($cond);exit();
				}
                $this->set('selday',$selday);
               // 
			}	
			else 
			//for Monthly	
			{
				$cond = array('task_type' => 'Monthly') ;
			}
				$tasknames = $this->TaskCompleted->Tasks->find('all',['fields'=>['id','task','task_type'],
                        'conditions'=>$cond ])->toArray();		
              //  debug($tasknames);exit;	
				$renderArray=array();
				foreach ($tasknames as $tasknmKey => $tasknmVal)
				{
					$tid=$tasknmVal['id'];
					$rerranged_pr[$tid]['id'] = $tasknmVal['id'];
					$rerranged_pr[$tid]['task'] = $tasknmVal['task'];
					$rerranged_pr[$tid]['task_type'] = $tasknmVal['task_type'];
					
				}
				$this->set('tasknames',$rerranged_pr);
				//debug($rerranged_pr);exit;				
				$this->set('taskType',$taskType);
				
				//code for monthly /daily condition
				if ($taskType == "Daily")
				{
                    $dtcond=array('completed_date'=>$cmpDate);
                   
				}
				else 
				{
					$dtcond= array('month(completed_date)'=> date('m'));
				}							
				$taskcompleted = $this->TaskCompleted->find('all',array('fields'=>array('id','task_id'),
						'order'=>'id ASC',
						'conditions'=>$dtcond))->toArray();
                				
				foreach ($taskcompleted as $taskComId => $taskComKey) 
				{
					$newId = $taskComKey['TaskCompleted']['task_id'];
					$task[$newId]['task_id'] = $taskComKey['TaskCompleted']['task_id'];
					$task[$newId]['id'] = $taskComKey['TaskCompleted']['id'];
				}
				if (isset($task)) $this->set('task',$task);				
		}	
	}

    /**
     * Edit method
     *
     * @param string|null $id Task Completed id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $taskCompleted = $this->TaskCompleted->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $taskCompleted = $this->TaskCompleted->patchEntity($taskCompleted, $this->request->data);
            if ($this->TaskCompleted->save($taskCompleted)) {
                $this->Flash->success(__('The {0} has been saved.', 'Task Completed'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Task Completed'));
            }
        }
        $tasks = $this->TaskCompleted->Tasks->find('list', ['limit' => 200]);
        $this->set(compact('taskCompleted', 'tasks'));
        $this->set('_serialize', ['taskCompleted']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Task Completed id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $taskCompleted = $this->TaskCompleted->get($id);
        if ($this->TaskCompleted->delete($taskCompleted)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Task Completed'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Task Completed'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
