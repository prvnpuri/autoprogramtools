<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ShippingDocumentsPhysical Controller
 *
 * @property \App\Model\Table\ShippingDocumentsPhysicalTable $ShippingDocumentsPhysical
 *
 * @method \App\Model\Entity\ShippingDocumentsPhysical[] paginate($object = null, array $settings = [])
 */
class ShippingDocumentsPhysicalController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Invoices', 'ShippingDocsMaster']
        ];
        $shippingDocumentsPhysical = $this->paginate($this->ShippingDocumentsPhysical);

        $this->set(compact('shippingDocumentsPhysical'));
        $this->set('_serialize', ['shippingDocumentsPhysical']);
    }

    /**
     * View method
     *
     * @param string|null $id Shipping Documents Physical id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $shippingDocumentsPhysical = $this->ShippingDocumentsPhysical->get($id, [
            'contain' => ['Orders', 'Invoices', 'ShippingDocsMaster']
        ]);

        $this->set('shippingDocumentsPhysical', $shippingDocumentsPhysical);
        $this->set('_serialize', ['shippingDocumentsPhysical']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $shippingDocumentsPhysical = $this->ShippingDocumentsPhysical->newEntity();
        if ($this->request->is('post')) {
            $shippingDocumentsPhysical = $this->ShippingDocumentsPhysical->patchEntity($shippingDocumentsPhysical, $this->request->data);
            if ($this->ShippingDocumentsPhysical->save($shippingDocumentsPhysical)) {
                $this->Flash->success(__('The {0} has been saved.', 'Shipping Documents Physical'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Shipping Documents Physical'));
            }
        }
        $orders = $this->ShippingDocumentsPhysical->Orders->find('list', ['limit' => 200]);
        $invoices = $this->ShippingDocumentsPhysical->Invoices->find('list', ['limit' => 200]);
        $shippingDocsMaster = $this->ShippingDocumentsPhysical->ShippingDocsMaster->find('list', ['limit' => 200]);
        $this->set(compact('shippingDocumentsPhysical', 'orders', 'invoices', 'shippingDocsMaster'));
        $this->set('_serialize', ['shippingDocumentsPhysical']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Shipping Documents Physical id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $shippingDocumentsPhysical = $this->ShippingDocumentsPhysical->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $shippingDocumentsPhysical = $this->ShippingDocumentsPhysical->patchEntity($shippingDocumentsPhysical, $this->request->data);
            if ($this->ShippingDocumentsPhysical->save($shippingDocumentsPhysical)) {
                $this->Flash->success(__('The {0} has been saved.', 'Shipping Documents Physical'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Shipping Documents Physical'));
            }
        }
        $orders = $this->ShippingDocumentsPhysical->Orders->find('list', ['limit' => 200]);
        $invoices = $this->ShippingDocumentsPhysical->Invoices->find('list', ['limit' => 200]);
        $shippingDocsMaster = $this->ShippingDocumentsPhysical->ShippingDocsMaster->find('list', ['limit' => 200]);
        $this->set(compact('shippingDocumentsPhysical', 'orders', 'invoices', 'shippingDocsMaster'));
        $this->set('_serialize', ['shippingDocumentsPhysical']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Shipping Documents Physical id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $shippingDocumentsPhysical = $this->ShippingDocumentsPhysical->get($id);
        if ($this->ShippingDocumentsPhysical->delete($shippingDocumentsPhysical)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Shipping Documents Physical'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Shipping Documents Physical'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
