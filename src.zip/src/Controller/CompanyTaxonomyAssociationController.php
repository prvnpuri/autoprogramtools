<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanyTaxonomyAssociation Controller
 *
 * @property \App\Model\Table\CompanyTaxonomyAssociationTable $CompanyTaxonomyAssociation
 *
 * @method \App\Model\Entity\CompanyTaxonomyAssociation[] paginate($object = null, array $settings = [])
 */
class CompanyTaxonomyAssociationController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['CompanyTaxonomies']
        ];
        $companyTaxonomyAssociation = $this->paginate($this->CompanyTaxonomyAssociation);

        $this->set(compact('companyTaxonomyAssociation'));
        $this->set('_serialize', ['companyTaxonomyAssociation']);
    }

    /**
     * View method
     *
     * @param string|null $id Company Taxonomy Association id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companyTaxonomyAssociation = $this->CompanyTaxonomyAssociation->get($id, [
            'contain' => ['CompanyTaxonomies']
        ]);

        $this->set('companyTaxonomyAssociation', $companyTaxonomyAssociation);
        $this->set('_serialize', ['companyTaxonomyAssociation']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companyTaxonomyAssociation = $this->CompanyTaxonomyAssociation->newEntity();
        if ($this->request->is('post')) {
            $companyTaxonomyAssociation = $this->CompanyTaxonomyAssociation->patchEntity($companyTaxonomyAssociation, $this->request->data);
            if ($this->CompanyTaxonomyAssociation->save($companyTaxonomyAssociation)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Taxonomy Association'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Taxonomy Association'));
            }
        }
        $companyTaxonomies = $this->CompanyTaxonomyAssociation->CompanyTaxonomies->find('list', ['limit' => 200]);
        $this->set(compact('companyTaxonomyAssociation', 'companyTaxonomies'));
        $this->set('_serialize', ['companyTaxonomyAssociation']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Taxonomy Association id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companyTaxonomyAssociation = $this->CompanyTaxonomyAssociation->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companyTaxonomyAssociation = $this->CompanyTaxonomyAssociation->patchEntity($companyTaxonomyAssociation, $this->request->data);
            if ($this->CompanyTaxonomyAssociation->save($companyTaxonomyAssociation)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Taxonomy Association'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Taxonomy Association'));
            }
        }
        $companyTaxonomies = $this->CompanyTaxonomyAssociation->CompanyTaxonomies->find('list', ['limit' => 200]);
        $this->set(compact('companyTaxonomyAssociation', 'companyTaxonomies'));
        $this->set('_serialize', ['companyTaxonomyAssociation']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Taxonomy Association id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyTaxonomyAssociation = $this->CompanyTaxonomyAssociation->get($id);
        if ($this->CompanyTaxonomyAssociation->delete($companyTaxonomyAssociation)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Taxonomy Association'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Taxonomy Association'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
