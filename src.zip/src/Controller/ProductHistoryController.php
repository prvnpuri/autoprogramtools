<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductHistory Controller
 *
 * @property \App\Model\Table\ProductHistoryTable $ProductHistory
 *
 * @method \App\Model\Entity\ProductHistory[] paginate($object = null, array $settings = [])
 */
class ProductHistoryController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products']
        ];
        $productHistory = $this->paginate($this->ProductHistory);

        $this->set(compact('productHistory'));
        $this->set('_serialize', ['productHistory']);
    }

    /**
     * View method
     *
     * @param string|null $id Product History id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productHistory = $this->ProductHistory->get($id, [
            'contain' => ['Products']
        ]);

        $this->set('productHistory', $productHistory);
        $this->set('_serialize', ['productHistory']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productHistory = $this->ProductHistory->newEntity();
        if ($this->request->is('post')) {
            $productHistory = $this->ProductHistory->patchEntity($productHistory, $this->request->data);
            if ($this->ProductHistory->save($productHistory)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product History'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product History'));
            }
        }
        $products = $this->ProductHistory->Products->find('list', ['limit' => 200]);
        $this->set(compact('productHistory', 'products'));
        $this->set('_serialize', ['productHistory']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product History id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productHistory = $this->ProductHistory->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productHistory = $this->ProductHistory->patchEntity($productHistory, $this->request->data);
            if ($this->ProductHistory->save($productHistory)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product History'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product History'));
            }
        }
        $products = $this->ProductHistory->Products->find('list', ['limit' => 200]);
        $this->set(compact('productHistory', 'products'));
        $this->set('_serialize', ['productHistory']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product History id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productHistory = $this->ProductHistory->get($id);
        if ($this->ProductHistory->delete($productHistory)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product History'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product History'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
