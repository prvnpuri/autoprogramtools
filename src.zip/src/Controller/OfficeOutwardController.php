<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OfficeOutward Controller
 *
 * @property \App\Model\Table\OfficeOutwardTable $OfficeOutward
 *
 * @method \App\Model\Entity\OfficeOutward[] paginate($object = null, array $settings = [])
 */
class OfficeOutwardController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanies','Users','CompanyMaster']
        ];
        $officeOutward = $this->paginate($this->OfficeOutward);
        $ownerCompanies= $this->OfficeOutward->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
        $companyMaster= $this->OfficeOutward->CompanyMaster->find('list', ['keyField' => 'id','valueField' => 'Company_name'], ['limit' => 200]);
        $users = $this->OfficeOutward->Users->find('list', ['keyField'=>'id', 'valueField'=>'userfullname','order'=>'userfullname'],['limit'=>200]);
        $this->loadModel('Countries');
        $countries = $this->Countries->find('list', ['keyField'=>'country_name', 'valueField'=>'country_name','order'=>'country_name'],['limit'=>200]);
        $this->loadModel('State');
        $state = $this->State->find('list', ['keyField'=>'state_name', 'valueField'=>'state_name','order'=>'state_name'],['limit'=>200]);
        $this->loadModel('City');
        $city = $this->City->find('list', ['keyField'=>'city_name', 'valueField'=>'city_name','order'=>'city_name'],['limit'=>200]);
        $this->set(compact('officeOutward','ownerCompanies','users','countries','state','city','companyMaster'));
        $this->set('_serialize', ['officeOutward']);
    }

    /**
     * View method
     *
     * @param string|null $id Office Outward id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $officeOutward = $this->OfficeOutward->get($id, [
            'contain' => ['OwnerCompanies']
        ]);

        $this->set('officeOutward', $officeOutward);
        $this->set('_serialize', ['officeOutward']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $officeOutward = $this->OfficeOutward->newEntity();
        if ($this->request->is('post')) {
            $this->request->data['outward_date']=date_create($this->request->data['outward_date']);
           
         $this->loadModel('ReferenceNumberCounter');
         $this->loadComponent('ReferenceNumber');
         $next_ref =
         $this->ReferenceNumber->get_next_ref_number($this->request->data['owner_company_id'],'office_outward');
         
         $this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
         
        // debug($next_ref);exit();
         if(!isset($next_ref['full_next_ref_no'])){
           //  debug($this->request->data);exit();
          
             $this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Office Outward'));
             //return $this->redirect(['action' => 'index']);
         }else{

            $this->request->data['sent_to_company']= $this->request->data['sent_to_company_new'];
            $officeOutward = $this->OfficeOutward->patchEntity($officeOutward, $this->request->data);
           /// debug($this->request->data);
            //debug($officeOutward);exit;
            if ($this->OfficeOutward->save($officeOutward)) {
                $this->Flash->success(__('The {0} has been saved.', 'Office Outward'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Office Outward'));
            }
        }
    }
        $ownerCompanies = $this->OfficeOutward->OwnerCompanies->find('list', ['limit' => 200]);
        $users = $this->OfficeOutward->Users->find('list',['limit'=>200]);
        $this->set(compact('officeOutward', 'ownerCompanies','users'));
        $this->set('_serialize', ['officeOutward']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Office Outward id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    { 
        $officeOutward = $this->OfficeOutward->get($this->request->data['id'], [
            'contain' => ['OwnerCompanies','Users']
        ]);
       
        if ($this->request->is(['patch', 'post', 'put']) && !isset($this->request->params['pass']['1'])) {
           debug($this->request->data);exit;
            $this->request->data['outward_date']=date_create($this->request->data['outward_date']);
            $this->request->data['sent_to_company']= $this->request->data['sent_to_company_new'];
            $officeOutward = $this->OfficeOutward->patchEntity($officeOutward, $this->request->data);
          debug($officeOutward);exit;
            if ($this->OfficeOutward->save($officeOutward)) {
                $this->Flash->success(__('The {0} has been saved.', 'Office Outward'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Office Outward'));
            }
        }
        $ownerCompanies = $this->OfficeOutward->OwnerCompanies->find('list', ['limit' => 200]);
        $users = $this->OfficeOutward->Users->find('list',['limit'=>200]);
        $this->set(compact('officeOutward', 'ownerCompanies','users'));
        $this->set('_serialize', ['officeOutward']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Office Outward id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $officeOutward = $this->OfficeOutward->get($id);
        if ($this->OfficeOutward->delete($officeOutward)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Office Outward'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Office Outward'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
