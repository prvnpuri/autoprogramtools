<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PreShipmentShipperInstruction Controller
 *
 * @property \App\Model\Table\PreShipmentShipperInstructionTable $PreShipmentShipperInstruction
 *
 * @method \App\Model\Entity\PreShipmentShipperInstruction[] paginate($object = null, array $settings = [])
 */
class PreShipmentShipperInstructionController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'Oas']
        ];
        $preShipmentShipperInstruction = $this->paginate($this->PreShipmentShipperInstruction);

        $this->set(compact('preShipmentShipperInstruction'));
        $this->set('_serialize', ['preShipmentShipperInstruction']);
    }

    /**
     * View method
     *
     * @param string|null $id Pre Shipment Shipper Instruction id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $preShipmentShipperInstruction = $this->PreShipmentShipperInstruction->get($id, [
            'contain' => ['Invoices', 'Oas']
        ]);

        $this->set('preShipmentShipperInstruction', $preShipmentShipperInstruction);
        $this->set('_serialize', ['preShipmentShipperInstruction']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $preShipmentShipperInstruction = $this->PreShipmentShipperInstruction->newEntity();
        if ($this->request->is('post')) {
            $preShipmentShipperInstruction = $this->PreShipmentShipperInstruction->patchEntity($preShipmentShipperInstruction, $this->request->data);
            if ($this->PreShipmentShipperInstruction->save($preShipmentShipperInstruction)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Shipper Instruction'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Shipper Instruction'));
            }
        }
        $invoices = $this->PreShipmentShipperInstruction->Invoices->find('list', ['limit' => 200]);
        $oas = $this->PreShipmentShipperInstruction->Oas->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentShipperInstruction', 'invoices', 'oas'));
        $this->set('_serialize', ['preShipmentShipperInstruction']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Pre Shipment Shipper Instruction id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $preShipmentShipperInstruction = $this->PreShipmentShipperInstruction->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $preShipmentShipperInstruction = $this->PreShipmentShipperInstruction->patchEntity($preShipmentShipperInstruction, $this->request->data);
            if ($this->PreShipmentShipperInstruction->save($preShipmentShipperInstruction)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Shipper Instruction'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Shipper Instruction'));
            }
        }
        $invoices = $this->PreShipmentShipperInstruction->Invoices->find('list', ['limit' => 200]);
        $oas = $this->PreShipmentShipperInstruction->Oas->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentShipperInstruction', 'invoices', 'oas'));
        $this->set('_serialize', ['preShipmentShipperInstruction']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Pre Shipment Shipper Instruction id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $preShipmentShipperInstruction = $this->PreShipmentShipperInstruction->get($id);
        if ($this->PreShipmentShipperInstruction->delete($preShipmentShipperInstruction)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Pre Shipment Shipper Instruction'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Pre Shipment Shipper Instruction'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
