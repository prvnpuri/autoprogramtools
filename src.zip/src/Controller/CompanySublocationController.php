<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanySublocation Controller
 *
 * @property \App\Model\Table\CompanySublocationTable $CompanySublocation
 *
 * @method \App\Model\Entity\CompanySublocation[] paginate($object = null, array $settings = [])
 */
class CompanySublocationController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['CompanyMaster']
        ];
        $companySublocation = $this->paginate($this->CompanySublocation);

        $this->set(compact('companySublocation'));
        $this->set('_serialize', ['companySublocation']);
    }

    /**
     * View method
     *
     * @param string|null $id Company Sublocation id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companySublocation = $this->CompanySublocation->get($id, [
            'contain' => ['CompanyMaster']
        ]);

        $this->set('companySublocation', $companySublocation);
        $this->set('_serialize', ['companySublocation']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companySublocation = $this->CompanySublocation->newEntity();
        if ($this->request->is('post')) {
            $companySublocation = $this->CompanySublocation->patchEntity($companySublocation, $this->request->data,
            		[
            		'associated' => ['CompanyMaster']
            		]
            		);
            if ($this->CompanySublocation->save($companySublocation)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Sublocation'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Sublocation'));
            }
        }
        $companyMaster = $this->CompanySublocation->companyMaster->find('list', ['limit' => 200]);
        $this->set(compact('companySublocation', 'companyMaster'));
        $this->set('_serialize', ['companySublocation']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Sublocation id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companySublocation = $this->CompanySublocation->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companySublocation = $this->CompanySublocation->patchEntity($companySublocation, $this->request->data);
            if ($this->CompanySublocation->save($companySublocation)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Sublocation'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Sublocation'));
            }
        }
        $companyMaster = $this->CompanySublocation->companyMaster->find('list', ['limit' => 200]);
        $this->set(compact('companySublocation', 'companyMaster'));
        $this->set('_serialize', ['companySublocation']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Sublocation id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companySublocation = $this->CompanySublocation->get($id);
        if ($this->CompanySublocation->delete($companySublocation)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Sublocation'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Sublocation'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
