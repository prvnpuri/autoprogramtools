<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TestRequestDet Controller
 *
 * @property \App\Model\Table\TestRequestDetTable $TestRequestDet
 *
 * @method \App\Model\Entity\TestRequestDet[] paginate($object = null, array $settings = [])
 */
class TestRequestDetController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['TestRequests', 'Tests', 'Labs']
        ];
        $testRequestDet = $this->paginate($this->TestRequestDet);

        $this->set(compact('testRequestDet'));
        $this->set('_serialize', ['testRequestDet']);
    }

    /**
     * View method
     *
     * @param string|null $id Test Request Det id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $testRequestDet = $this->TestRequestDet->get($id, [
            'contain' => ['TestRequests', 'Tests', 'Labs', 'TestReports']
        ]);

        $this->set('testRequestDet', $testRequestDet);
        $this->set('_serialize', ['testRequestDet']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $testRequestDet = $this->TestRequestDet->newEntity();
        if ($this->request->is('post')) {
            $testRequestDet = $this->TestRequestDet->patchEntity($testRequestDet, $this->request->data);
            if ($this->TestRequestDet->save($testRequestDet)) {
                $this->Flash->success(__('The {0} has been saved.', 'Test Request Det'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Request Det'));
            }
        }
        $testRequests = $this->TestRequestDet->TestRequests->find('list', ['limit' => 200]);
        $tests = $this->TestRequestDet->Tests->find('list', ['limit' => 200]);
        $labs = $this->TestRequestDet->Labs->find('list', ['limit' => 200]);
        $this->set(compact('testRequestDet', 'testRequests', 'tests', 'labs'));
        $this->set('_serialize', ['testRequestDet']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Test Request Det id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $testRequestDet = $this->TestRequestDet->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $testRequestDet = $this->TestRequestDet->patchEntity($testRequestDet, $this->request->data);
            if ($this->TestRequestDet->save($testRequestDet)) {
                $this->Flash->success(__('The {0} has been saved.', 'Test Request Det'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Request Det'));
            }
        }
        $testRequests = $this->TestRequestDet->TestRequests->find('list', ['limit' => 200]);
        $tests = $this->TestRequestDet->Tests->find('list', ['limit' => 200]);
        $labs = $this->TestRequestDet->Labs->find('list', ['limit' => 200]);
        $this->set(compact('testRequestDet', 'testRequests', 'tests', 'labs'));
        $this->set('_serialize', ['testRequestDet']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Test Request Det id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $testRequestDet = $this->TestRequestDet->get($id);
        if ($this->TestRequestDet->delete($testRequestDet)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Test Request Det'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Test Request Det'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
