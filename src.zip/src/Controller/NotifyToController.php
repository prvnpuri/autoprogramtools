<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * NotifyTo Controller
 *
 * @property \App\Model\Table\NotifyToTable $NotifyTo
 *
 * @method \App\Model\Entity\NotifyTo[] paginate($object = null, array $settings = [])
 */
class NotifyToController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Companies']
        ];
        $notifyTo = $this->paginate($this->NotifyTo);

        $this->set(compact('notifyTo'));
        $this->set('_serialize', ['notifyTo']);
    }

    /**
     * View method
     *
     * @param string|null $id Notify To id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $notifyTo = $this->NotifyTo->get($id, [
            'contain' => ['Orders', 'Companies']
        ]);

        $this->set('notifyTo', $notifyTo);
        $this->set('_serialize', ['notifyTo']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $notifyTo = $this->NotifyTo->newEntity();
        if ($this->request->is('post')) {
            $notifyTo = $this->NotifyTo->patchEntity($notifyTo, $this->request->data);
            if ($this->NotifyTo->save($notifyTo)) {
                $this->Flash->success(__('The {0} has been saved.', 'Notify To'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Notify To'));
            }
        }
        $orders = $this->NotifyTo->Orders->find('list', ['limit' => 200]);
        $companies = $this->NotifyTo->Companies->find('list', ['limit' => 200]);
        $this->set(compact('notifyTo', 'orders', 'companies'));
        $this->set('_serialize', ['notifyTo']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Notify To id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $notifyTo = $this->NotifyTo->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $notifyTo = $this->NotifyTo->patchEntity($notifyTo, $this->request->data);
            if ($this->NotifyTo->save($notifyTo)) {
                $this->Flash->success(__('The {0} has been saved.', 'Notify To'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Notify To'));
            }
        }
        $orders = $this->NotifyTo->Orders->find('list', ['limit' => 200]);
        $companies = $this->NotifyTo->Companies->find('list', ['limit' => 200]);
        $this->set(compact('notifyTo', 'orders', 'companies'));
        $this->set('_serialize', ['notifyTo']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Notify To id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $notifyTo = $this->NotifyTo->get($id);
        if ($this->NotifyTo->delete($notifyTo)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Notify To'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Notify To'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
