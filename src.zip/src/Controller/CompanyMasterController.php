<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;
use Cake\Cache\Cache;


/**
 * CompanyMaster Controller
 *
 * @property \App\Model\Table\CompanyMasterTable $CompanyMaster
 *
 * @method \App\Model\Entity\CompanyMaster[] paginate($object = null, array $settings = [])
 */

 class CompanyMasterController extends AppController
{
	/**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
		// $systemInfo1= 'Test Key1';	
		//$systemsettingData = Cache::read($systemInfo1, $config = 'default');
		
		// $companyInfo1 = '2_Test2';
		//$companysettingData = Cache::read($companyInfo1, $config = 'default');
    	$query=$this->request->getQuery("search");
    	
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="CompanyMaster.Company_name like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['CompanyIndustryTypes','CompanyContactPersons','CompanySublocation','CompanyTypesMaster','CompanySublocation.city','CompanySublocation.state','CompanySublocation.countries','CompanyIndustryTypes.IndustryTypeMaster'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","Company_name", "CompanyTypesMaster.type_short_name","company_sublocation.City.city_name"]
    	];
    	
		$this->set(compact('companysettingData'));
		$this->set('_serialize', ['companysettingData']);
		

        
		$companyMaster = $this->paginate($this->CompanyMaster);
        $this->set('companyMaster', $companyMaster);
        $this->set('_serialize', ['companyMaster']);
        $this->loadModel('CompanyTypesMaster');
        $this->loadModel('City');
        $this->loadModel('State');
        $this->loadModel('Countries');
        $this->loadModel('IndustryTypeMaster');
        $this->set("paging",$this->request->getParam("paging"));
		$companyTypes = $this->CompanyTypesMaster->find('list', ['id' => 5,'keyField' => 'id','valueField' => 'type_short_name','order'=>'type_short_name']);
        
		/*
		$companyTypes = $this->CompanyTypesMaster->find('list', ['id' => 5,'keyField' => 'id','valueField' => 'type_short_name','order'=>'type_short_name']);
		$companyTypes = $this->CompanyTypesMaster->find('list', [
		'conditions' => [
			'id IN' => [1, 3, 5],
			'date' => date('Y-m-d')
		]]);
		*
		
		/* echo "companyTypes<pre>";
		print_r($companyTypes);				
		die(); */
		
		/*echo "CompanyTypes<pre>";
		print_r($companyTypes);		
		die();*/		
			
		$city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name']);
		$state = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name']);
        $countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        $industryMaster = $this->IndustryTypeMaster->find('list', ['keyField' => 'id','valueField' => 'industry_type','order'=>'industry_type']);
        $this->set(compact('companyTypes','industryMaster','city','state','countries'));  
        $this->set( '_serialize', ['companyMaster','paging']);
    }
	
	
    /**
     * View method
     *
     * @param string|null $id Company Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
    	
        $companyMaster = $this->CompanyMaster->get($id, [
        		'contain' => ['CompanyIndustryTypes','CompanyContactPersons','CompanySublocation','CompanyTypesMaster',
        				'CompanySublocation.city','CompanySublocation.state','CompanySublocation.countries', 
        				'CompanySublocation.PortOfDischargeAir','CompanySublocation.PortOfDischargeSea']
        ]);
        //debug($companyMaster, true, true);
        $this->set('companyMaster', $companyMaster);
        $this->set('_serialize', ['companyMaster']);
        $this->loadModel('CompanyTypesMaster');
        $this->loadModel('IndustryTypeMaster');
        $this->loadModel('IndustryTypeMaster');
        $companyTypes = $this->CompanyTypesMaster->find('list', ['keyField' => 'id','valueField' => 'type_short_name','order'=>'type_short_name']);
        $industryMaster = $this->IndustryTypeMaster->find('list', ['keyField' => 'id','valueField' => 'industry_type','order'=>'industry_type']);
        $this->set(compact('companyTypes','industryMaster'));
    }

    public function printview($id = null)
    {
    	
    	$companyMaster = $this->CompanyMaster->get($id, [
    			'contain' => ['CompanyIndustryTypes','CompanyContactPersons','CompanySublocation','CompanyTypesMaster','CompanySublocation.city','CompanySublocation.state','CompanySublocation.countries','PortOfDischarge']
    	]);
    	$this->set('companyMaster', $companyMaster);
    	$this->set('_serialize', ['companyMaster']);
    	$this->loadModel('CompanyTypesMaster');
    	$this->loadModel('IndustryTypeMaster');
    	$this->loadModel('PortOfDischarge');
    	$port_of_discharge_air = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['id'=>$companyMaster->port_of_discharge_air]]);
    	$port_of_discharge_sea = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['id'=>$companyMaster->port_of_discharge_sea]]);
    	$companyTypes = $this->CompanyTypesMaster->find('list', ['keyField' => 'id','valueField' => 'type_short_name','order'=>'type_short_name']);
    	$industryMaster = $this->IndustryTypeMaster->find('list', ['keyField' => 'id','valueField' => 'industry_type','order'=>'industry_type']);
    	$this->set(compact('companyTypes','industryMaster','port_of_discharge_air','port_of_discharge_sea'));
    }
	
	
	
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companyMaster = $this->CompanyMaster->newEntity();
        if ($this->request->is('post')) {
        	//debug($this->request->data['company_industry_types']['industry_type_master_id']);
        	foreach ($this->request->data['company_industry_types']['industry_type_master_id'] as $industry => $ind){
        	$inds= $ind;
        	$this->request->data['company_industry_types'][$industry]['industry_type_master_id'] = $ind;
        	
        }
        unset($this->request->data['company_industry_types']['industry_type_master_id'] );
      
        foreach ($this->request->data['company_industry_types'] as $keyN => $Val){
        	
        	if(!isset($this->request->data['company_industry_types'][$keyN]['industry_type_master_id'])){
        		unset($this->request->data['company_industry_types'][$keyN]);
        	}
        }
       // debug($this->request->data); 
			$companyMaster = $this->CompanyMaster->patchEntity($companyMaster, $this->request->data,
            		[
            				'associated' => ['CompanyIndustryTypes','CompanyContactPersons','CompanySublocation']
            		]
            		);
           //debug($this->request->data);exit;
            //visiting card image unset code start
            foreach ($this->request->data["company_contact_persons"] as $key => $d ) {
            if(isset($d["image"]) &&  $d["image"]["error"]==0)
				{
					$filename=$d["image"]["name"];
					$companyMaster["company_contact_persons"][$key]["visiting_card"]=$filename;
				}else{
				    unset($d["visiting_card"]);
			    }
			 } 
			 
			 // visiting card image unset code end
			 //print_r($companyMaster);exit;
			// debug($this->request->data);exit;
            if ($this->CompanyMaster->save($companyMaster)) {
            	
            //visiting card image move code start
            foreach ($this->request->data["company_contact_persons"] as $key => $d ) {
            if(isset($d["image"]) &&  $d["image"]["error"]==0)
				{
					$filename=$d["image"]["name"];
					$url = Router::url('/',true).'upload/visiting-cards/'.$filename;
					$uploadpath = 'upload/visiting-cards/';
					$uploadfile = $uploadpath.$filename;
					move_uploaded_file($d["image"]['tmp_name'], $uploadfile);
					
				}else{
				    unset($d["visiting_card"]);
			    }
			}
			//visiting card image move code end
			
                $this->Flash->success(__('The {0} has been saved.', 'Company Master'));
                return $this->redirect(['action' => 'index']);
            } else {
            //	print_r('else');exit;
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Master'));
            }
        }
        
        $this->set(compact('companyMaster'));
        $this->set('_serialize', ['companyMaster']);
        $this->loadModel('CompanyTypesMaster');
        //$this->loadModel('City');
        //$this->loadModel('State');
        $this->loadModel('Countries');
        $this->loadModel('IndustryTypeMaster');
        //$this->loadModel('PortOfDischarge');
        $companyTypes = $this->CompanyTypesMaster->find('list', ['keyField' => 'id','valueField' => 'type_short_name','order'=>'type_short_name']);
        //$city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name']);
        //$state = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name']);
        $countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        $industryMaster = $this->IndustryTypeMaster->find('list', ['keyField' => 'id','valueField' => 'industry_type','order'=>'industry_type']);
        //$port_of_discharge_sea = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['type like'=>'0']]);
        //$port_of_discharge_air = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['type like'=>'1']]);
        $this->set(compact('companyTypes','industryMaster','city','state','countries','port_of_discharge_sea','port_of_discharge_air'));
        
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
    	
        $companyMaster = $this->CompanyMaster->get($id, [
            'contain' => ['CompanyIndustryTypes','CompanyContactPersons','CompanySublocation']
        ]);
        $this->loadModel('State');
        $this->loadModel('City');
        $this->loadModel('PortOfDischarge');
        foreach ($companyMaster['company_sublocation'] as $k => $compMaster){
        	$states = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name','conditions'=>['State.country_id'=>$compMaster['country']]]);
        	$states = $states->toArray();
        	$companyMaster['company_sublocation'][$k]['states'] = $states;
        	
        	$portAir = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['PortOfDischarge.countries_id'=>$compMaster['country']]]);
        	$portAir= $portAir->toArray();
        	$companyMaster['company_sublocation'][$k]['portAir'] = $portAir;
        	$companyMaster['company_sublocation'][$k]['portSea'] = $portAir;
        	
        	$cities = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name','conditions'=>['City.state_id'=>$compMaster['state']]]);
        	$cities = $cities->toArray();
        	$companyMaster['company_sublocation'][$k]['cities'] = $cities;
        }
        
    	//$companyMaster = $this->paginate($this->CompanyMaster);
        if ($this->request->is(['post', 'put'])) {
        	
        	//Delete Industry type
        	$this->loadModel('CompanyTypesMaster');
        	$industryType=$this->request->data['company_industry_types']['industry_type_master_id'];
        	foreach ($industryType as $industries => $inddetails){
        		//$inds= $ind;
        		$details[]= $inddetails;
        		
        	}
      
       		$industryId=implode(", ", $details);
    	 
      	  $this->CompanyMaster->CompanyIndustryTypes->deleteAll(['industry_type_master_id not IN'=>$industryId,'company_master_id'=>$this->request->data['id']]);
        	
      		$ids = explode(",",$this->request->data['company_industry_types']['id']);
        	
        	foreach ($ids as $keyId=>$IndustryId){
        		$this->request->data['company_industry_types'][$keyId]['id'] = $IndustryId;
        		foreach ($this->request->data['company_industry_types']['industry_type_master_id'] as $industry => $ind){
        			$inds= $ind;
        			$this->request->data['company_industry_types'][$industry]['industry_type_master_id'] = $ind;
        		}
        		
        	}
        	
        	unset($this->request->data['company_industry_types']['industry_type_master_id'] );
        	unset($this->request->data['company_industry_types']['id'] );
        	
        	foreach ($this->request->data['company_industry_types'] as $keyN => $Val){
        		
        		if(!isset($this->request->data['company_industry_types'][$keyN]['industry_type_master_id'])){
        			unset($this->request->data['company_industry_types'][$keyN]);	
        		}
        	}
        //	debug($this->request->data);exit;
            $companyMaster = $this->CompanyMaster->patchEntity($companyMaster, $this->request->getData(),
            		[
            				'associated' => ['CompanyIndustryTypes','CompanyContactPersons','CompanySublocation']
            		]
            		);
            //visiting card image unset code start
            foreach ($this->request->data["company_contact_persons"] as $key => $d ) {
            	if(isset($d["image"]) &&  $d["image"]["error"]==0)
            	{
            		$filename=$d["image"]["name"];
            		
            		$companyMaster["company_contact_persons"][$key]["visiting_card"]=$filename;
            	}else{
            		unset($d["visiting_card"]);
            	}
            }
          //  echo $companyMaster;
          //  exit;
            
            // visiting card image unset code end
            //print_r($companyMaster); exit;
            //multiple contact delete
           // debug($this->request->data);exit;
            if ($this->CompanyMaster->save($companyMaster)) {
            	
            	//visiting card image move code start
            	foreach ($this->request->data["company_contact_persons"] as $key => $d ) {
            		if(isset($d["image"]) &&  $d["image"]["error"]==0)
            		{
            			$filename=$d["image"]["name"];
            			$url = Router::url('/',true).'upload/visiting-cards/'.$filename;
            			$uploadpath = 'upload/visiting-cards/';
            			$uploadfile = $uploadpath.$filename;
            			move_uploaded_file($d["image"]['tmp_name'], $uploadfile);
            			
            		}else{
            			unset($d["visiting_card"]);
            		}
            	}
            	//debug($uploadfile);exit;
            	//visiting card image move code end
            	
            	//Multiple industry type delete start
            	if(isset($this->request->data["data"]["delContactDetail"])){
            		//print_r($expression)
            		$this->CompanyMaster->CompanyContactPersons->deleteAll(['id IN'=>$this->request->data["data"]["delContactDetail"]]);
            	}
            	//Multiple industry type delete end
            //multiple contact delete
            //Multiple address delete
            	if(isset($this->request->data["data"]["deladdDetail"])){
            		//print_r($expression)
            		$this->CompanyMaster->CompanySublocation->deleteAll(['id IN'=>$this->request->data["data"]["deladdDetail"]]);
            	}
            //Multiple address delete
            //print_r($this->request->data["data"]["delindustryDetail"]);exit;
            //Multiple industry type delete
            	if(isset($this->request->data["data"]["delindustryDetail"])){
            		//print_r($expression)
            		$this->CompanyMaster->CompanyIndustryTypes->deleteAll(['id IN'=>$this->request->data["data"]["delindustryDetail"]]);
            	}
            //Multiple industry type delete
                $this->Flash->success(__('The {0} has been saved.', 'Company Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Master'));
            }
        }
      // $companyTypesMaster = $this->CompanyMaster->CompanyTypesMaster->find('list', ['limit' => 200]);
        $this->loadModel('CompanyTypesMaster');
        $this->loadModel('Countries');
        $this->loadModel('IndustryTypeMaster');       
        $companyTypes = $this->CompanyTypesMaster->find('list', ['keyField' => 'id','valueField' => 'type_short_name','order'=>'type_short_name']);
        $countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        $industryMaster = $this->IndustryTypeMaster->find('list', ['keyField' => 'id','valueField' => 'industry_type','order'=>'industry_type']);
        $this->set(compact('companyTypes','industryMaster','city','state','countries','port_of_discharge_sea','port_of_discharge_air'));
        $this->set(compact('companyMaster'));
        $this->set('_serialize', ['companyMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyMaster = $this->CompanyMaster->get($id);
        if ($this->CompanyMaster->delete($companyMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
	
	    /**
     * Test method
     *
     * @param string|null $id Company Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */

	
    function ajaxData() {
				
		$conn = mysqli_connect("localhost","root","","test");
		 
		// Check connection
		if (mysqli_connect_errno()){
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		
		
		$aColumns = array( 'id', 'employee_name', 'employee_salary', 'employee_age');
        
        /* Indexed column (used for fast and accurate table cardinality) */
        $sIndexColumn = "id";
        
        /* DB table to use */
        $sTable = "employee";
        
        /*
         * Paging
        */
        $sLimit = "";
        if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
        {
            $sLimit = "LIMIT ".intval( $_GET['iDisplayStart'] ).", ".
            intval( $_GET['iDisplayLength'] );
        }
         
        /*
         * Ordering
        */
        $sOrder = "";
        if ( isset( $_GET['iSortCol_0'] ) )
        {
            $sOrder = "ORDER BY  ";
            for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
            {
                if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
                {
                    $sOrder .= "`".$aColumns[ intval( $_GET['iSortCol_'.$i] ) ]."` ".
                        ($_GET['sSortDir_'.$i]==='asc' ? 'asc' : 'desc') .", ";
                }
            }
         
				$sOrder = substr_replace( $sOrder, "", -2 );
            if ( $sOrder == "ORDER BY" )
            {
                $sOrder = "";
            }
        }
          
		/*
        * Filtering
        * NOTE this does not match the built-in DataTables filtering which does it
        * word by word on any field. It's possible to do here, but concerned about efficiency
        * on very large tables, and MySQL's regex functionality is very limited
        */
        $sWhere = "";
        if ( isset($_GET['sSearch']) && $_GET['sSearch'] != "" )
        {
            $sWhere = "WHERE (";
            for ( $i=0 ; $i<count($aColumns) ; $i++ )
            {
                $sWhere .= "`".$aColumns[$i]."` LIKE '%".$_GET['sSearch']."%' OR ";
            }
            $sWhere = substr_replace( $sWhere, "", -3 );
            $sWhere .= ')';
        }
			
		/* Individual column filtering */
        for ( $i=0 ; $i<count($aColumns) ; $i++ )
        {
            if ( isset($_GET['bSearchable_'.$i]) && $_GET['bSearchable_'.$i] == "true" && $_GET['sSearch_'.$i] != '' )
            {
                if ( $sWhere == "" )
                {
                    $sWhere = "WHERE ";
                }
                else
                {
                    $sWhere .= " AND ";
                }
                $sWhere .= "`".$aColumns[$i]."` LIKE '%".$_GET['sSearch_'.$i]."%' ";
            }
        }
		
		/*
        * SQL queries
        * Get data to display
        */
        $sQuery = "
		SELECT SQL_CALC_FOUND_ROWS `".str_replace(" , ", " ", implode("`, `", $aColumns))."`
		FROM   $sTable
		$sWhere
		$sOrder
		$sLimit
		";
		
		//$rResult = mysqli_query( $sQuery, $conn ) or fatal_error( 'MySQL Error: ' . mysqli_errno() );
        $rResult=mysqli_query($conn,$sQuery);
		
        /* Data set length after filtering */
        $sQuery = "
		SELECT FOUND_ROWS()
		";
        $rResultFilterTotal = mysqli_query( $conn, $sQuery) or fatal_error( 'MySQL Error: ' . mysqli_errno() );
        $aResultFilterTotal = mysqli_fetch_array($rResultFilterTotal);
        $iFilteredTotal = $aResultFilterTotal[0];
        
		/* Total data set  length */
        $sQuery = "
		SELECT COUNT(`".$sIndexColumn."`)
            FROM   $sTable
            ";
        $rResultTotal = mysqli_query( $conn, $sQuery ) or fatal_error( 'MySQL Error: ' . mysqli_errno() );
        $aResultTotal = mysqli_fetch_array($rResultTotal);
        $iTotal = $aResultTotal[0];
        		
        /*
         * Output
        */
        $output = array(
                "sEcho" => intval($_GET['sEcho']),
                "iTotalRecords" => $iTotal,
                "iTotalDisplayRecords" => $iFilteredTotal,
                "aaData" => array()
        );
				
        while ( $aRow = mysqli_fetch_array( $rResult ) )
        {
            $row = array();
            for ( $i=0 ; $i<count($aColumns) ; $i++ )
            {
                if ( $aColumns[$i] == "version" )
                {
                    /* Special output formatting for 'version' column */
                    $row[] = ($aRow[ $aColumns[$i] ]=="0") ? '-' : $aRow[ $aColumns[$i] ];
                }
                else if ( $aColumns[$i] != ' ' )
                {
                    /* General output */
                    $row[] = $aRow[ $aColumns[$i] ];
                }
            }
            $output['aaData'][] = $row;
        }
		
		//return $output;		
		
		echo json_encode($output);
		
		die();
		
		/* $this->modelClass = "Browser";
        $this->autoRender = false;
        $output = $this->Browser->GetData();
		
        echo json_encode($output); */
    }
	 
	public function test(){
		
    }
	
	public function testpagination($id = null)
    {
		echo "This is the testpagination";
		die();
	}
	
	public function listOfCountries(){
	    $listCountries=$this->CompanyMaster->CompanySublocation->find("list",[
	        "keyField"=>"country_code",
	        "valueField"=>"count"
	    ])->contain(["Countries"]);
	    $listCountries->select([
	        "count"=>"COUNT(CompanySublocation.country)",
	       "country_code"=>"Countries.country_code"
	    ]);
	    $listCountries->group(["CompanySublocation.country"]);
	    $listCountries->execute()->fetchAll();
	    $this->set("list_of_countries",$listCountries);
	    $this->set('_serialize', ['list_of_countries']);
	}
	
}
