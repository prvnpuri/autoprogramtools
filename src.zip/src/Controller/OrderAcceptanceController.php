<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Mailer\Email;
use DebugKit\Mailer\SentMailResult;
use Cake\Cache\Cache;
use Cake\Network\Exception\NotFoundException;

/**
 * OrderAcceptance Controller
 *
 * @property \App\Model\Table\OrderAcceptanceTable $OrderAcceptance
 *
 * @method \App\Model\Entity\OrderAcceptance[] paginate($object = null, array $settings = [])
 */
class OrderAcceptanceController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$ownercompanyid = $this->Auth->User('owner_company_id');
        $this->loadModel('Order');
        $options = $this->Order->find("all",[
        		"contain"=>['OrderAcceptance','CompanyMaster','CustomerMaster','ProductsMaster','Uom','Currency','OwnerCompanies'],
        		"conditions"=>["Order.send_to_oa"=>"SENT","Order.owner_companies_id"=>$ownercompanyid],
        		"order"=>"Order.id"
        ]);
        $this->set('orderAcceptance',$this->paginate($options));
        
        $this->set('_serialize', ['orderAcceptance']);
        
        
        
        
        
        
    }

    /**
     * View method
     *
     * @param string|null $id Order Acceptance id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $orderAcceptance = $this->OrderAcceptance->get($id, [
            'contain' => ['Order','Order.CompanyMaster','Order.ProductsMaster','Order.Uom','Order.Currency','Order.IncoTerms','Order.OrderReviews']
        ]);

        $this->loadModel('CompanyMaster');
        $consignee = $this->CompanyMaster->find('all', ['conditions'=>['CompanyMaster.id' => $orderAcceptance['order']['consignee']],
        		'contain'=>['CompanyContactPersons']
        
        ]);
        $consignee = $consignee->toArray();
        $supplierCompany= $this->CompanyMaster->find('all', ['conditions'=>['CompanyMaster.id' => $orderAcceptance['order']['supplier_company']],
        		'contain'=>['CompanyContactPersons']
        
        ]);
        $supplierCompany = $supplierCompany->toArray();
        $this->set(compact('orderAcceptance', 'consignee', 'supplierCompany'));
        $this->set('_serialize', ['orderAcceptance']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($order_id = null)
    {
    	$this->loadModel('Order');
    	$order = $this->Order->get($order_id, [
    			'contain' => ['OrderReviews','CompanyMaster','CompanyMaster.CompanyContactPersons','ShippingCompany','ShippingCompany.CompanyContactPersons',
    					'ProductsMaster','PackingTerm','PackingType','Uom','IncoTerms', 'Currency','OwnerCompanies',
    					'CountryOfFinalDestination','CountryOfOriginOfGood','PortOfDischarge','Countries','PaymentTerm','DeliveryTerm']
    	]);
    	$this->set(compact('order'));
    	$orderAcceptance= $this->OrderAcceptance->newEntity();
    	
    	if ($this->request->is('post')) {
    		$this->loadModel('ReferenceNumberCounter');
    		$this->loadComponent('ReferenceNumber');
    		
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'OrderAcceptance');
    		$this->request->data['reference_number'] = $next_ref['full_next_ref_no'];
    		
    		
    	
    		$orderAcceptance= $this->OrderAcceptance->patchEntity($orderAcceptance, $this->request->data);
    		
    		if(isset($this->request->data['supplier_contact_persons'])){
    			$ptr=0;
    			foreach ($this->request->data['supplier_contact_persons'] as $contact_id){
    				$orderAcceptance->supplier_contact_persons.=$ptr>0?",":"";
    				$orderAcceptance->supplier_contact_persons.=$contact_id;
    				$ptr++;
    			}
    		}
    		if(isset($this->request->data['consignee_contact_persons'])){
    			$ptr=0;
    			foreach ($this->request->data['consignee_contact_persons'] as $contact_id){
    				$orderAcceptance->consignee_contact_persons.=$ptr>0?",":"";
    				$orderAcceptance->consignee_contact_persons.=$contact_id;
    				$ptr++;
    			}
    		}
    		
    		$orderAcceptance['created_by'] = $this->Auth->User('id');
    		
    		
    		
    		if(!isset($next_ref['full_next_ref_no'])){
    			
    			$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Order Acceptance'));
    			
    		}
    		
    		
    		else{
    		
    		
    		if ($result=$this->OrderAcceptance->save($orderAcceptance)) {
    			
    			$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    			$id=$result->id;
    			$this->orderacceptancePdf($id);
    			$this->Flash->success(__('The {0} has been saved.', 'Order Acceptance'));
    			return $this->redirect(['action' => 'index']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Order Acceptance'));
    		}
    		
    		
    		
    	}
    		
    		
    	}
    	
    
    	$paymentterm= $this->Order->PaymentTerm->find('list', ['keyField' => 'term','valueField' => 'term','order'=>'term']);
    	
    	$packingtype= $this->Order->PackingType->find('list', ['keyField' => 'packing_type','valueField' => 'packing_type','order'=>'packing_type']);
    	
    
    	$this->set(compact('orderAcceptance','paymentterm','packingtype'));
    	$this->set('_serialize', ['orderAcceptance']);
       
    }

    /**
     * Edit method
     *
     * @param string|null $id Order Acceptance id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
       
        $orderAcceptance= $this->OrderAcceptance->get($id, [
        		'contain' => ['Order','Order.OrderReviews','Order.CompanyMaster','Order.ShippingCompany','Order.CompanyMaster.CompanyContactPersons','Order.ShippingCompany.CompanyContactPersons',
        				'Order.ProductsMaster','Order.PackingTerm','Order.PackingType','Order.Uom','Order.IncoTerms', 'Order.Currency','Order.OwnerCompanies',
        				'Order.CountryOfFinalDestination','Order.CountryOfOriginOfGood','Order.PortOfDischarge','Order.Countries','Order.PaymentTerm','Order.DeliveryTerm']
        ]);
        
        
        if ($this->request->is(['patch', 'post', 'put'])) {

        	$orderAcceptance = $this->OrderAcceptance->patchEntity($orderAcceptance, $this->request->data);
        	
            if(isset($this->request->data['supplier_contact_persons'])){
            	$ptr=0;
            	foreach ($this->request->data['supplier_contact_persons'] as $contact_id){
            		$this->request->data['supplier_contact_persons'].=$ptr>0?",":"";
            		$this->request->data['supplier_contact_persons'].=$contact_id;
            		$ptr++;
            	}
            	
            }
            
           
            if(isset($this->request->data['consignee_contact_persons'])){
            	$ptr=0;
            	foreach ($this->request->data['consignee_contact_persons'] as $contact_id){
            		$this->request->data['consignee_contact_persons'].=$ptr>0?",":"";
            		$this->request->data['consignee_contact_persons'].=$contact_id;
            		$ptr++;
            	}
            	
            }
        
            $orderAcceptance['modified_by'] = $this->Auth->User('id');
            
            if ($this->OrderAcceptance->save($orderAcceptance)) {
            	$this->orderacceptancePdf($id);
                $this->Flash->success(__('The {0} has been saved.', 'Order Acceptance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Order Acceptance'));
            }
        }
      
        
       
        $this->set(compact('orderAcceptance'));
        $this->set('_serialize', ['orderAcceptance']);
    }

    
    
    
    
    
    public function printOrderacceptance($id)
    {
    	$orderAcceptance= $this->OrderAcceptance->get($id, [
    			'contain' => ['Order','Order.OwnerCompanies','Order.CompanyMaster','Order.ShippingCompany',
    					'Order.ProductsMaster','Order.Uom','Order.IncoTerms', 'Order.Currency',
    					'Order.CountryOfFinalDestination','Order.CountryOfOriginOfGood','Order.PortOfDischarge','Order.Countries','Order.PaymentTerm','Order.DeliveryTerm']
    	]);
    	
    	$this->set(compact('orderAcceptance'));
    	//$this->viewBuilder()->setLayout("blank");
    	
    }
    
    
    
    private function orderacceptancePdf($id){
    	$OrderAcceptance= $this->OrderAcceptance->get($id, [
    			'contain' => ['Order','Order.OwnerCompanies','Order.CompanyMaster','Order.ShippingCompany',
    					'Order.ProductsMaster','Order.Uom','Order.IncoTerms', 'Order.Currency',
    					'Order.CountryOfFinalDestination','Order.CountryOfOriginOfGood','Order.PortOfDischarge','Order.Countries','Order.PaymentTerm','Order.DeliveryTerm']
    	]);
    	
    	$this->set(compact('OrderAcceptance'));
    	
    	 $owner_comapny_name=$OrderAcceptance->order->owner_company->Company_name;
    	  
	 
    		$CakePdf = new \CakePdf\Pdf\CakePdf();
    		$CakePdf->template('order_acceptance_mail', 'default');
    		$CakePdf->viewVars($this->viewVars);
    		
    		$pdf = $CakePdf->output();
    		
            $pdf = $CakePdf->write(WWW_ROOT.DS.'upload'. DS.'order-acceptance'.DS.$id.'_'.$owner_comapny_name.'pdf');
            
    }
    
    
    
    public function sendEmail($id=null,$sendMail=null){
    	if($sendMail==null){
    		return $this->redirect(array("action"=>"sendEmail",$id,0));
    	}
    
    	$emailvar=array();
    	
    	$orderaccpatance= $this->OrderAcceptance->get($id, [
    			'contain' => ['Order','Order.OwnerCompanies','Order.CompanyMaster','Order.ShippingCompany',
    					'Order.ProductsMaster','Order.Uom','Order.IncoTerms', 'Order.Currency',
    					'Order.CountryOfFinalDestination','Order.CountryOfOriginOfGood','Order.PortOfDischarge','Order.Countries','Order.PaymentTerm','Order.DeliveryTerm']
    	]);
    	
    	
    	$this->loadModel('CompanyContactPersons');
    	$companycontactpersons=$this->CompanyContactPersons->find("all",array(
    			"fields"=>array("id","prefix_name","first_name","middle_name","last_name","email_id"),
    			"conditions"=>array("id IN"=>explode(",",$orderaccpatance->supplier_contact_persons)),
    			
    			"order"=>"id"
    	));
    	
    	
    	
    	
    	
    	$suppliercontactpersons=$this->CompanyContactPersons->find("all",array(
    			"fields"=>array("id","prefix_name","first_name","middle_name","last_name","email_id","phone"),
    			"conditions"=>array("CompanyContactPerson.id"=>explode(",", $orderaccpatance->consignee_contact_persons) ),
    			"recursive" => -1,
    			"order"=>"concat(`first_name`,`middle_name`,`last_name`)"
    	));
    	
    	
    	
    	$inq_contact_persons=$orderaccpatance->order->company_contact_persons;
    	
    	$contacts=$companycontactpersons;
    	//$contacts=array_merge($contacts,$suppliercontactpersons);
    	$emailvar["OrderAcceptance"]=$orderaccpatance;
    	
    	$fromid=$orderaccpatance->order->owner_company->company_email;
    	
    	
    	
    	if(!isset($fromid)){
    		throw new NotFoundException("Your Seller Company maild is empty. please fill up your Seller company email id first after then we can send mail.");
    	}
    	
    	$to=array();
    	$cc=array();
    	$buyeremail = array();
    	
    	$buyercontact = "";
    	$vpercount=0;
    	
    	foreach ($contacts as $key => $contact){
    		$personname=ucfirst($contact["first_name"])." ".
      		ucfirst($contact["middle_name"])." ".
      		ucfirst($contact["last_name"]);
      		if(trim($personname," ")!=""){
      			$buyercontact.=$vpercount>0?",":"";
      			$buyercontact.= (isset($contact["prefix_name"])?$contact["prefix_name"]:"" )." ".$personname;
      			$vpercount++;
      		}
      		
      		$contactemail=$contact["email_id"];
      		if(trim($contactemail," ")!=""){
      			$buyeremail[]= $contactemail;
      		}else{
      			
      			$this->Flash->error(__('Please check email_id {0} for contact_name {1} is not valid email.',$contactemail,$personname));
      			return false;
      		}
    	}
    	
    
    	
    	if(count($buyeremail)==0){
    		
    		$this->Flash->error(__("Please select contact persons for sending mail order acceptance."));
    		
    		
    		return $this->redirect(array("controller"=>"OrderAcceptance","action"=>"edit",$orderaccpatance->id));
    	}
    	
    	if(Configure::read('productionMode')){
    		// uncomment when deployee in production
    		$to=$buyeremail;
    	} else {
    		$to=array("sujatasid@gmail.com");
    		$cc=array("sujata.sid@pitonsystems.com");
    	}

    	$filename=$orderaccpatance->id."_".$orderaccpatance->order->owner_company->Company_name."pdf";
    	$uploadpath = 'upload/order-acceptance/';
    	$uploadfile = $uploadpath.$filename;
    
    	$attachedFile=$uploadfile;
    	
    	
    
    
    	$attachedFilelabel= str_replace(".", "_", $orderaccpatance->order->owner_company->Company_name)."_Order_Acceptance.pdf";
    	if( isset($sendMail)&& $sendMail==1){
    		try{
    			$companyname=$orderaccpatance->order->owner_company->Company_name;
    			$orderno=$orderaccpatance->order->order_no;
    			$orderdate=date_format($orderaccpatance->order->order_date,'Y-m-d');
    			
    			$Email=new Email('default');
    			if(file_exists($attachedFile)){
    				$Email->addAttachments( array($attachedFilelabel=> $attachedFile));
    			}
    			$Email
    			
    			->setSubject("Order Acceptance for your Order no- ".$orderno ."Date-". $orderdate)
    			->setViewVars($emailvar)
    			->template('order_acceptance_mail', 'order_acceptance_mail')
    			->from($fromid)
    			
    			->to($to)
    			->cc($cc)
    			->emailFormat('html')
    			->send();
    			
    			
    			$oa = $this->OrderAcceptance->get($id);
    			$data = array('id' => $id, 'status' => 1);
    			$oa= $this->OrderAcceptance->patchEntity($oa, $data);
    			if($this->OrderAcceptance->save($oa))
    			{
    				//$this->Flash->success(__('Order Acceptance mail has been send to Buyer company. but unable to change email send status from database.'));
    				
    				$this->Flash->success(__('Order Acceptance mail has been send to Buyer company.'));
    				
    			
    			
    			}
    			
    			
    			return $this->redirect(['action' => 'index']);
    			
    		
    		}catch(Exception $e){
    			
    			$this->Flash->error(__('Unable to send Order Acceptance mail to Buyer company.'));
    			
    		
    			return $this->redirect(['action' => 'index']);
    			
    			
    		}
    	}
    	else
    	{
    		//email preview
    		$companyname=$orderaccpatance->order->owner_company->Company_name;
    		foreach ($emailvar as  $key=> $data ){
    			$this->set($key,$data);
    		}
    		if(file_exists($attachedFile)){
    			$this->set("attachments",array(
    					$attachedFilelabel=> array(
    							"controller"=>"upload",
    							"action"=>"order-acceptance",$filename
    					)
    			)
    					);
    		}
    		$this->set("mails",array(
    				"from"=>$fromid,
    				"to" =>$to,
    				"cc" => $cc,
    				"subject"=>"Order Acceptance Mail from ".$companyname
    		));
    		
    		$this->set("title_for_layout","Order Acceptance.");
    		$this->set("mailSendAction",array(
    				"send"=>array("action"=>"sendEmail",$id,1),
    				"cancel"=>array("action"=>"index")
    		));
    		
    		$this->viewBuilder()->setLayout("/Email/html/emailpreview");
    		$html=$this->render('/Email/html/order_acceptance_mail');
    		
    		echo $html;
    		exit();
    	
    	
    	
    	}
    	
    }
    
    
    
    /**
     * Delete method
     *
     * @param string|null $id Order Acceptance id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $orderAcceptance = $this->OrderAcceptance->get($id);
        if ($this->OrderAcceptance->delete($orderAcceptance)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Order Acceptance'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Order Acceptance'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    
    
    
    
    public function sendToDemandQueue($id=null) {
    	
    	$orderacceptance = $this->OrderAcceptance->get($id);
    	$userid= $this->Auth->User('id');
    	$data = array('id' => $id , 'send_to_demandqueue' => "Y");
    	$orderacceptance= $this->OrderAcceptance->patchEntity($orderacceptance, $data);
    	$this->loadModel('DemandQueue');
    	$order_id=$orderacceptance->order_id;
    	$demanddata = array('order_id' => $order_id);
    	if($this->OrderAcceptance->save($orderacceptance)){
    		
    		$demandqueue= $this->DemandQueue->newEntity();
    		$demandqueue= $this->DemandQueue->patchEntity($demandqueue, $demanddata);
    	
    		$this->DemandQueue->save($demandqueue);
    		$this->loadModel('Notifications');
    		
    		$notifications= $this->Notifications->find()->where(['notification_by' => 'OrderAcceptance','transaction_id'=>$id])->first();
    		
    		$data1 = array('transaction_id' => $id , 'status' => "2",'action_taken_by'=>$userid,'action_taken_on'=>date('Y-m-d'));
    		$notifications= $this->Notifications->patchEntity($notifications, $data1);
    		$this->Notifications->save($notifications);
    		
    		$this->Flash->success(__('Order has been sent to Documentation.'));
    	}else {
    		$this->Flash->error(__('The {0} could not be sent for docmentation. Please, try again.', 'Order Acceptance'));
    	}
    	return $this->redirect(['action' => 'index']);
    	
    	
    	
    }
    
    public function sendToDoc($order_id=null){
        
        if(!$this->OrderAcceptance->exists( [ "order_id"=> $order_id ] )){
            throw new NotFoundException(__('Order not found'));
        }
        $oaData=$this->OrderAcceptance->find('all')->where(['order_id'=>$order_id])->first();
        $toUpdate=['send_to_doc'=>'Yes'];
        
        $oaData=$this->OrderAcceptance->patchEntity($oaData,$toUpdate);
        if(  $this->OrderAcceptance->save($oaData)){
            $this->Flash->success(__('Order has been sent to Invoice'));
        }else{
            $this->Flash->success(__('Order has been sent to pending order for creating Invoice'));
        }
        
        return $this->redirect(['action'=>'index']);
        
    }
    
    
    public function pendingOrder()
    {
    	 
    	$this->loadModel('OrderAcceptance');
    	$options = $this->OrderAcceptance->find("all",[
    			"contain"=>['Order','Order.CompanyMaster','Order.CustomerMaster','Order.ProductsMaster','Order.Uom','Order.Currency'],
    			"conditions"=>["OrderAcceptance.send_to_doc"=>"YES"],
    			"order"=>"Order.id"
    	]);
    	$this->set('orderAcceptance',$this->paginate($options));
    
    	$this->set('_serialize', ['orderAcceptance']);
    
    
    
    
    }
    
    
    
}
