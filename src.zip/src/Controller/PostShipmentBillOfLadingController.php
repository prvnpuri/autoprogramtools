<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PostShipmentBillOfLading Controller
 *
 * @property \App\Model\Table\PostShipmentBillOfLadingTable $PostShipmentBillOfLading
 *
 * @method \App\Model\Entity\PostShipmentBillOfLading[] paginate($object = null, array $settings = [])
 */
class PostShipmentBillOfLadingController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Oas']
        ];
        $postShipmentBillOfLading = $this->paginate($this->PostShipmentBillOfLading);

        $this->set(compact('postShipmentBillOfLading'));
        $this->set('_serialize', ['postShipmentBillOfLading']);
    }

    /**
     * View method
     *
     * @param string|null $id Post Shipment Bill Of Lading id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $postShipmentBillOfLading = $this->PostShipmentBillOfLading->get($id, [
            'contain' => ['Oas']
        ]);

        $this->set('postShipmentBillOfLading', $postShipmentBillOfLading);
        $this->set('_serialize', ['postShipmentBillOfLading']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $postShipmentBillOfLading = $this->PostShipmentBillOfLading->newEntity();
        if ($this->request->is('post')) {
            $postShipmentBillOfLading = $this->PostShipmentBillOfLading->patchEntity($postShipmentBillOfLading, $this->request->data);
            if ($this->PostShipmentBillOfLading->save($postShipmentBillOfLading)) {
                $this->Flash->success(__('The {0} has been saved.', 'Post Shipment Bill Of Lading'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Post Shipment Bill Of Lading'));
            }
        }
        $oas = $this->PostShipmentBillOfLading->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postShipmentBillOfLading', 'oas'));
        $this->set('_serialize', ['postShipmentBillOfLading']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Post Shipment Bill Of Lading id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $postShipmentBillOfLading = $this->PostShipmentBillOfLading->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $postShipmentBillOfLading = $this->PostShipmentBillOfLading->patchEntity($postShipmentBillOfLading, $this->request->data);
            if ($this->PostShipmentBillOfLading->save($postShipmentBillOfLading)) {
                $this->Flash->success(__('The {0} has been saved.', 'Post Shipment Bill Of Lading'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Post Shipment Bill Of Lading'));
            }
        }
        $oas = $this->PostShipmentBillOfLading->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postShipmentBillOfLading', 'oas'));
        $this->set('_serialize', ['postShipmentBillOfLading']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Post Shipment Bill Of Lading id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $postShipmentBillOfLading = $this->PostShipmentBillOfLading->get($id);
        if ($this->PostShipmentBillOfLading->delete($postShipmentBillOfLading)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Post Shipment Bill Of Lading'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Post Shipment Bill Of Lading'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
