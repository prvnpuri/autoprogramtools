<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * AssetMaintenanceRecords Controller
 *
 * @property \App\Model\Table\AssetMaintenanceRecordsTable $AssetMaintenanceRecords
 *
 * @method \App\Model\Entity\AssetMaintenanceRecord[] paginate($object = null, array $settings = [])
 */
class AssetMaintenanceRecordsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['AssetsMaster', 'AssetMaintenanceSchedule']
        ];
        $assetMaintenanceRecords = $this->paginate($this->AssetMaintenanceRecords);

        $this->set(compact('assetMaintenanceRecords'));
        $this->set('_serialize', ['assetMaintenanceRecords']);
    }

    /**
     * View method
     *
     * @param string|null $id Asset Maintenance Record id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $assetMaintenanceRecord = $this->AssetMaintenanceRecords->get($id, [
            'contain' => ['AssetsMaster', 'AssetMaintenanceSchedule']
        ]);

        $this->set('assetMaintenanceRecord', $assetMaintenanceRecord);
        $this->set('_serialize', ['assetMaintenanceRecord']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $assetMaintenanceRecord = $this->AssetMaintenanceRecords->newEntity();
        if ($this->request->is('post')) {
            $assetMaintenanceRecord = $this->AssetMaintenanceRecords->patchEntity($assetMaintenanceRecord, $this->request->data);
            if ($this->AssetMaintenanceRecords->save($assetMaintenanceRecord)) {
                $this->Flash->success(__('The {0} has been saved.', 'Asset Maintenance Record'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Asset Maintenance Record'));
            }
        }
        $assetsMaster = $this->AssetMaintenanceRecords->AssetsMaster->find('list', ['limit' => 200]);
        $assetMaintenanceSchedule = $this->AssetMaintenanceRecords->AssetMaintenanceSchedule->find('list', ['limit' => 200]);
        $this->set(compact('assetMaintenanceRecord', 'assetsMaster', 'assetMaintenanceSchedule'));
        $this->set('_serialize', ['assetMaintenanceRecord']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Asset Maintenance Record id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $assetMaintenanceRecord = $this->AssetMaintenanceRecords->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $assetMaintenanceRecord = $this->AssetMaintenanceRecords->patchEntity($assetMaintenanceRecord, $this->request->data);
            if ($this->AssetMaintenanceRecords->save($assetMaintenanceRecord)) {
                $this->Flash->success(__('The {0} has been saved.', 'Asset Maintenance Record'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Asset Maintenance Record'));
            }
        }
        $assetsMaster = $this->AssetMaintenanceRecords->AssetsMaster->find('list', ['limit' => 200]);
        $assetMaintenanceSchedule = $this->AssetMaintenanceRecords->AssetMaintenanceSchedule->find('list', ['limit' => 200]);
        $this->set(compact('assetMaintenanceRecord', 'assetsMaster', 'assetMaintenanceSchedule'));
        $this->set('_serialize', ['assetMaintenanceRecord']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Asset Maintenance Record id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $assetMaintenanceRecord = $this->AssetMaintenanceRecords->get($id);
        if ($this->AssetMaintenanceRecords->delete($assetMaintenanceRecord)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Asset Maintenance Record'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Asset Maintenance Record'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
