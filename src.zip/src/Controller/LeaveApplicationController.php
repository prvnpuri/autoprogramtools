<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * LeaveApplication Controller
 *
 * @property \App\Model\Table\LeaveApplicationTable $LeaveApplication
 *
 * @method \App\Model\Entity\LeaveApplication[] paginate($object = null, array $settings = [])
 */
class LeaveApplicationController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Employees', 'LeaveTypes']
        ];
        $leaveApplication = $this->paginate($this->LeaveApplication);

        $this->set(compact('leaveApplication'));
        $this->set('_serialize', ['leaveApplication']);
    }

    /**
     * View method
     *
     * @param string|null $id Leave Application id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $leaveApplication = $this->LeaveApplication->get($id, [
            'contain' => ['Employees', 'LeaveTypes']
        ]);

        $this->set('leaveApplication', $leaveApplication);
        $this->set('_serialize', ['leaveApplication']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $leaveApplication = $this->LeaveApplication->newEntity();
        if ($this->request->is('post')) {
            $leaveApplication = $this->LeaveApplication->patchEntity($leaveApplication, $this->request->data);
            if ($this->LeaveApplication->save($leaveApplication)) {
                $this->Flash->success(__('The {0} has been saved.', 'Leave Application'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Leave Application'));
            }
        }
        $employees = $this->LeaveApplication->Employees->find('list', ['limit' => 200]);
        $leaveTypes = $this->LeaveApplication->LeaveTypes->find('list', ['limit' => 200]);
        $this->set(compact('leaveApplication', 'employees', 'leaveTypes'));
        $this->set('_serialize', ['leaveApplication']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Leave Application id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $leaveApplication = $this->LeaveApplication->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $leaveApplication = $this->LeaveApplication->patchEntity($leaveApplication, $this->request->data);
            
            if ($this->LeaveApplication->save($leaveApplication)) {
                $this->Flash->success(__('The {0} has been saved.', 'Leave Application'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Leave Application'));
            }
        }
        $employees = $this->LeaveApplication->Employees->find('list', ['limit' => 200]);
        $leaveTypes = $this->LeaveApplication->LeaveTypes->find('list', ['limit' => 200]);
        $this->set(compact('leaveApplication', 'employees', 'leaveTypes'));
        $this->set('_serialize', ['leaveApplication']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Leave Application id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $leaveApplication = $this->LeaveApplication->get($id);
        if ($this->LeaveApplication->delete($leaveApplication)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Leave Application'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Leave Application'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
