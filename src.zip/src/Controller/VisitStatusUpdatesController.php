<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * VisitStatusUpdates Controller
 *
 * @property \App\Model\Table\VisitStatusUpdatesTable $VisitStatusUpdates
 *
 * @method \App\Model\Entity\VisitStatusUpdate[] paginate($object = null, array $settings = [])
 */
class VisitStatusUpdatesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['SubsequentVisits']
        ];
        $visitStatusUpdates = $this->paginate($this->VisitStatusUpdates);

        $this->set(compact('visitStatusUpdates'));
        $this->set('_serialize', ['visitStatusUpdates']);
    }

    /**
     * View method
     *
     * @param string|null $id Visit Status Update id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $visitStatusUpdate = $this->VisitStatusUpdates->get($id, [
            'contain' => ['SubsequentVisits']
        ]);

        $this->set('visitStatusUpdate', $visitStatusUpdate);
        $this->set('_serialize', ['visitStatusUpdate']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $visitStatusUpdate = $this->VisitStatusUpdates->newEntity();
        if ($this->request->is('post')) {
            $visitStatusUpdate = $this->VisitStatusUpdates->patchEntity($visitStatusUpdate, $this->request->data);
            if ($this->VisitStatusUpdates->save($visitStatusUpdate)) {
                $this->Flash->success(__('The {0} has been saved.', 'Visit Status Update'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Visit Status Update'));
            }
        }
        $subsequentVisits = $this->VisitStatusUpdates->SubsequentVisits->find('list', ['limit' => 200]);
        $this->set(compact('visitStatusUpdate', 'subsequentVisits'));
        $this->set('_serialize', ['visitStatusUpdate']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Visit Status Update id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $visitStatusUpdate = $this->VisitStatusUpdates->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $visitStatusUpdate = $this->VisitStatusUpdates->patchEntity($visitStatusUpdate, $this->request->data);
            if ($this->VisitStatusUpdates->save($visitStatusUpdate)) {
                $this->Flash->success(__('The {0} has been saved.', 'Visit Status Update'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Visit Status Update'));
            }
        }
        $subsequentVisits = $this->VisitStatusUpdates->SubsequentVisits->find('list', ['limit' => 200]);
        $this->set(compact('visitStatusUpdate', 'subsequentVisits'));
        $this->set('_serialize', ['visitStatusUpdate']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Visit Status Update id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $visitStatusUpdate = $this->VisitStatusUpdates->get($id);
        if ($this->VisitStatusUpdates->delete($visitStatusUpdate)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Visit Status Update'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Visit Status Update'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
