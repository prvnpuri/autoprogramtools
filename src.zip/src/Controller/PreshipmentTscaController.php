<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PreshipmentTsca Controller
 *
 * @property \App\Model\Table\PreshipmentTscaTable $PreshipmentTsca
 *
 * @method \App\Model\Entity\PreshipmentTsca[] paginate($object = null, array $settings = [])
 */
class PreshipmentTscaController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Invoices', 'OrderAccs', 'OwnerCompanies']
        ];
        $preshipmentTsca = $this->paginate($this->PreshipmentTsca);

        $this->set(compact('preshipmentTsca'));
        $this->set('_serialize', ['preshipmentTsca']);
    }

    /**
     * View method
     *
     * @param string|null $id Preshipment Tsca id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $preshipmentTsca = $this->PreshipmentTsca->get($id, [
            'contain' => ['Orders', 'Invoices', 'OrderAccs', 'OwnerCompanies']
        ]);

        $this->set('preshipmentTsca', $preshipmentTsca);
        $this->set('_serialize', ['preshipmentTsca']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $preshipmentTsca = $this->PreshipmentTsca->newEntity();
        if ($this->request->is('post')) {
            $preshipmentTsca = $this->PreshipmentTsca->patchEntity($preshipmentTsca, $this->request->data);
            if ($this->PreshipmentTsca->save($preshipmentTsca)) {
                $this->Flash->success(__('The {0} has been saved.', 'Preshipment Tsca'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Preshipment Tsca'));
            }
        }
        $orders = $this->PreshipmentTsca->Orders->find('list', ['limit' => 200]);
        $invoices = $this->PreshipmentTsca->Invoices->find('list', ['limit' => 200]);
        $orderAccs = $this->PreshipmentTsca->OrderAccs->find('list', ['limit' => 200]);
        $ownerCompanies = $this->PreshipmentTsca->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('preshipmentTsca', 'orders', 'invoices', 'orderAccs', 'ownerCompanies'));
        $this->set('_serialize', ['preshipmentTsca']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Preshipment Tsca id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $preshipmentTsca = $this->PreshipmentTsca->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $preshipmentTsca = $this->PreshipmentTsca->patchEntity($preshipmentTsca, $this->request->data);
            if ($this->PreshipmentTsca->save($preshipmentTsca)) {
                $this->Flash->success(__('The {0} has been saved.', 'Preshipment Tsca'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Preshipment Tsca'));
            }
        }
        $orders = $this->PreshipmentTsca->Orders->find('list', ['limit' => 200]);
        $invoices = $this->PreshipmentTsca->Invoices->find('list', ['limit' => 200]);
        $orderAccs = $this->PreshipmentTsca->OrderAccs->find('list', ['limit' => 200]);
        $ownerCompanies = $this->PreshipmentTsca->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('preshipmentTsca', 'orders', 'invoices', 'orderAccs', 'ownerCompanies'));
        $this->set('_serialize', ['preshipmentTsca']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Preshipment Tsca id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $preshipmentTsca = $this->PreshipmentTsca->get($id);
        if ($this->PreshipmentTsca->delete($preshipmentTsca)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Preshipment Tsca'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Preshipment Tsca'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
