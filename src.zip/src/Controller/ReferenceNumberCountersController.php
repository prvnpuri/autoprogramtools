<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ReferenceNumberCounters Controller
 *
 * @property \App\Model\Table\ReferenceNumberCountersTable $ReferenceNumberCounters
 *
 * @method \App\Model\Entity\ReferenceNumberCounter[] paginate($object = null, array $settings = [])
 */
class ReferenceNumberCountersController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanies']
        ];
        $referenceNumberCounters = $this->paginate($this->ReferenceNumberCounters);

        $this->set(compact('referenceNumberCounters'));
        $this->set('_serialize', ['referenceNumberCounters']);
    }

    /**
     * View method
     *
     * @param string|null $id Reference Number Counter id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $referenceNumberCounter = $this->ReferenceNumberCounters->get($id, [
            'contain' => ['OwnerCompanies']
        ]);

        $this->set('referenceNumberCounter', $referenceNumberCounter);
        $this->set('_serialize', ['referenceNumberCounter']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $referenceNumberCounter = $this->ReferenceNumberCounters->newEntity();
        if ($this->request->is('post')) {
            $referenceNumberCounter = $this->ReferenceNumberCounters->patchEntity($referenceNumberCounter, $this->request->data);
            if ($this->ReferenceNumberCounters->save($referenceNumberCounter)) {
                $this->Flash->success(__('The {0} has been saved.', 'Reference Number Counter'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Reference Number Counter'));
            }
        }
        $ownerCompanies = $this->ReferenceNumberCounters->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('referenceNumberCounter', 'ownerCompanies'));
        $this->set('_serialize', ['referenceNumberCounter']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Reference Number Counter id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $referenceNumberCounter = $this->ReferenceNumberCounters->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $referenceNumberCounter = $this->ReferenceNumberCounters->patchEntity($referenceNumberCounter, $this->request->data);
            if ($this->ReferenceNumberCounters->save($referenceNumberCounter)) {
                $this->Flash->success(__('The {0} has been saved.', 'Reference Number Counter'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Reference Number Counter'));
            }
        }
        $ownerCompanies = $this->ReferenceNumberCounters->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('referenceNumberCounter', 'ownerCompanies'));
        $this->set('_serialize', ['referenceNumberCounter']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Reference Number Counter id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $referenceNumberCounter = $this->ReferenceNumberCounters->get($id);
        if ($this->ReferenceNumberCounters->delete($referenceNumberCounter)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Reference Number Counter'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Reference Number Counter'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
