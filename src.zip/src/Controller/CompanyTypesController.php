<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanyTypes Controller
 *
 * @property \App\Model\Table\CompanyTypesTable $CompanyTypes
 *
 * @method \App\Model\Entity\CompanyType[] paginate($object = null, array $settings = [])
 */
class CompanyTypesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['CompanyMasters', 'CompanyTypeMasters']
        ];
        $companyTypes = $this->paginate($this->CompanyTypes);

        $this->set(compact('companyTypes'));
        $this->set('_serialize', ['companyTypes']);
    }

    /**
     * View method
     *
     * @param string|null $id Company Type id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companyType = $this->CompanyTypes->get($id, [
            'contain' => ['CompanyMasters', 'CompanyTypeMasters']
        ]);

        $this->set('companyType', $companyType);
        $this->set('_serialize', ['companyType']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companyType = $this->CompanyTypes->newEntity();
        if ($this->request->is('post')) {
            $companyType = $this->CompanyTypes->patchEntity($companyType, $this->request->data);
            if ($this->CompanyTypes->save($companyType)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Type'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Type'));
            }
        }
        $companyMasters = $this->CompanyTypes->CompanyMasters->find('list', ['limit' => 200]);
        $companyTypeMasters = $this->CompanyTypes->CompanyTypeMasters->find('list', ['limit' => 200]);
        $this->set(compact('companyType', 'companyMasters', 'companyTypeMasters'));
        $this->set('_serialize', ['companyType']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Type id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companyType = $this->CompanyTypes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companyType = $this->CompanyTypes->patchEntity($companyType, $this->request->data);
            if ($this->CompanyTypes->save($companyType)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Type'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Type'));
            }
        }
        $companyMasters = $this->CompanyTypes->CompanyMasters->find('list', ['limit' => 200]);
        $companyTypeMasters = $this->CompanyTypes->CompanyTypeMasters->find('list', ['limit' => 200]);
        $this->set(compact('companyType', 'companyMasters', 'companyTypeMasters'));
        $this->set('_serialize', ['companyType']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Type id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyType = $this->CompanyTypes->get($id);
        if ($this->CompanyTypes->delete($companyType)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Type'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Type'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
