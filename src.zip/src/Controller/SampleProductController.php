<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * SampleProduct Controller
 *
 * @property \App\Model\Table\SampleProductTable $SampleProduct
 *
 * @method \App\Model\Entity\SampleProduct[] paginate($object = null, array $settings = [])
 */
class SampleProductController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['FromTos', 'Inwards', 'Outwards', 'Products', 'Uoms', 'OwnerCompanies']
        ];
        $sampleProduct = $this->paginate($this->SampleProduct);

        $this->set(compact('sampleProduct'));
        $this->set('_serialize', ['sampleProduct']);
    }

    /**
     * View method
     *
     * @param string|null $id Sample Product id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $sampleProduct = $this->SampleProduct->get($id, [
            'contain' => ['FromTos', 'Inwards', 'Outwards', 'Products', 'Uoms', 'OwnerCompanies']
        ]);

        $this->set('sampleProduct', $sampleProduct);
        $this->set('_serialize', ['sampleProduct']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $sampleProduct = $this->SampleProduct->newEntity();
        if ($this->request->is('post')) {
            $sampleProduct = $this->SampleProduct->patchEntity($sampleProduct, $this->request->data);
            if ($this->SampleProduct->save($sampleProduct)) {
                $this->Flash->success(__('The {0} has been saved.', 'Sample Product'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Sample Product'));
            }
        }
        $fromTos = $this->SampleProduct->FromTos->find('list', ['limit' => 200]);
        $inwards = $this->SampleProduct->Inwards->find('list', ['limit' => 200]);
        $outwards = $this->SampleProduct->Outwards->find('list', ['limit' => 200]);
        $products = $this->SampleProduct->Products->find('list', ['limit' => 200]);
        $uoms = $this->SampleProduct->Uoms->find('list', ['limit' => 200]);
        $ownerCompanies = $this->SampleProduct->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('sampleProduct', 'fromTos', 'inwards', 'outwards', 'products', 'uoms', 'ownerCompanies'));
        $this->set('_serialize', ['sampleProduct']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Sample Product id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $sampleProduct = $this->SampleProduct->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $sampleProduct = $this->SampleProduct->patchEntity($sampleProduct, $this->request->data);
            if ($this->SampleProduct->save($sampleProduct)) {
                $this->Flash->success(__('The {0} has been saved.', 'Sample Product'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Sample Product'));
            }
        }
        $fromTos = $this->SampleProduct->FromTos->find('list', ['limit' => 200]);
        $inwards = $this->SampleProduct->Inwards->find('list', ['limit' => 200]);
        $outwards = $this->SampleProduct->Outwards->find('list', ['limit' => 200]);
        $products = $this->SampleProduct->Products->find('list', ['limit' => 200]);
        $uoms = $this->SampleProduct->Uoms->find('list', ['limit' => 200]);
        $ownerCompanies = $this->SampleProduct->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('sampleProduct', 'fromTos', 'inwards', 'outwards', 'products', 'uoms', 'ownerCompanies'));
        $this->set('_serialize', ['sampleProduct']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Sample Product id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $sampleProduct = $this->SampleProduct->get($id);
        if ($this->SampleProduct->delete($sampleProduct)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Sample Product'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Sample Product'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
