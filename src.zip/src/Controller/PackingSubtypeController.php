<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PackingSubtype Controller
 *
 * @property \App\Model\Table\PackingSubtypeTable $PackingSubtype
 *
 * @method \App\Model\Entity\PackingSubtype[] paginate($object = null, array $settings = [])
 */
class PackingSubtypeController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="PackingSubtype.sub_type like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['PackingType'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","sub_type","PackingType.packing_type"]
    	];
    	
    	
    	$packingSubtype = $this->paginate($this->PackingSubtype);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('packingSubtype'));
    	// $this->set('_serialize', ['city']);
    	$this->set( '_serialize', ['packingSubtype','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Packing Subtype id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $packingSubtype = $this->PackingSubtype->get($id, [
            'contain' => ['PackingType']
        ]);

        $this->set('packingSubtype', $packingSubtype);
        $this->set('_serialize', ['packingSubtype']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $packingSubtype = $this->PackingSubtype->newEntity();
        if ($this->request->is('post')) {
            $packingSubtype = $this->PackingSubtype->patchEntity($packingSubtype, $this->request->data);
            $packingSubtype['created_by'] = $this->Auth->User('id');
            if ($this->PackingSubtype->save($packingSubtype)) {
                $this->Flash->success(__('The {0} has been saved.', 'Packing Subtype'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Packing Subtype'));
            }
        }
        $packingtype = $this->PackingSubtype->Packingtype->find('list',['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type'], ['limit' => 200]);
        $this->set(compact('packingSubtype', 'packingtype'));
        $this->set('_serialize', ['packingSubtype']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Packing Subtype id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $packingSubtype = $this->PackingSubtype->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $packingSubtype = $this->PackingSubtype->patchEntity($packingSubtype, $this->request->data);
            $packingSubtype['created_by'] = $this->Auth->User('id');
            if ($this->PackingSubtype->save($packingSubtype)) {
                $this->Flash->success(__('The {0} has been saved.', 'Packing Subtype'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Packing Subtype'));
            }
        }
        $packingtype = $this->PackingSubtype->PackingType->find('list',['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type'], ['limit' => 200]);
        //$packingtype = $this->PackingSubtype->Packingtype->find('list', ['limit' => 200]);
        $this->set(compact('packingSubtype', 'packingtype'));
        $this->set('_serialize', ['packingSubtype']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Packing Subtype id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $packingSubtype = $this->PackingSubtype->get($id);
        if ($this->PackingSubtype->delete($packingSubtype)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Packing Subtype'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Packing Subtype'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
