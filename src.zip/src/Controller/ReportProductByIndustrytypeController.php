<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ReportProductByIndustrytype Controller
 *
 * @property \App\Model\Table\ReportProductByIndustrytypeTable $ReportProductByIndustrytype
 *
 * @method \App\Model\Entity\ReportProductByIndustrytype[] paginate($object = null, array $settings = [])
 */
class ReportProductByIndustrytypeController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['IndustryTypes', 'Products']
        ];
        $reportProductByIndustrytype = $this->paginate($this->ReportProductByIndustrytype);

        $this->set(compact('reportProductByIndustrytype'));
        $this->set('_serialize', ['reportProductByIndustrytype']);
    }

    /**
     * View method
     *
     * @param string|null $id Report Product By Industrytype id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $reportProductByIndustrytype = $this->ReportProductByIndustrytype->get($id, [
            'contain' => ['IndustryTypes', 'Products']
        ]);

        $this->set('reportProductByIndustrytype', $reportProductByIndustrytype);
        $this->set('_serialize', ['reportProductByIndustrytype']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $reportProductByIndustrytype = $this->ReportProductByIndustrytype->newEntity();
        if ($this->request->is('post')) {
            $reportProductByIndustrytype = $this->ReportProductByIndustrytype->patchEntity($reportProductByIndustrytype, $this->request->data);
            if ($this->ReportProductByIndustrytype->save($reportProductByIndustrytype)) {
                $this->Flash->success(__('The {0} has been saved.', 'Report Product By Industrytype'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Report Product By Industrytype'));
            }
        }
        $industryTypes = $this->ReportProductByIndustrytype->IndustryTypes->find('list', ['limit' => 200]);
        $products = $this->ReportProductByIndustrytype->Products->find('list', ['limit' => 200]);
        $this->set(compact('reportProductByIndustrytype', 'industryTypes', 'products'));
        $this->set('_serialize', ['reportProductByIndustrytype']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Report Product By Industrytype id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $reportProductByIndustrytype = $this->ReportProductByIndustrytype->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $reportProductByIndustrytype = $this->ReportProductByIndustrytype->patchEntity($reportProductByIndustrytype, $this->request->data);
            if ($this->ReportProductByIndustrytype->save($reportProductByIndustrytype)) {
                $this->Flash->success(__('The {0} has been saved.', 'Report Product By Industrytype'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Report Product By Industrytype'));
            }
        }
        $industryTypes = $this->ReportProductByIndustrytype->IndustryTypes->find('list', ['limit' => 200]);
        $products = $this->ReportProductByIndustrytype->Products->find('list', ['limit' => 200]);
        $this->set(compact('reportProductByIndustrytype', 'industryTypes', 'products'));
        $this->set('_serialize', ['reportProductByIndustrytype']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Report Product By Industrytype id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $reportProductByIndustrytype = $this->ReportProductByIndustrytype->get($id);
        if ($this->ReportProductByIndustrytype->delete($reportProductByIndustrytype)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Report Product By Industrytype'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Report Product By Industrytype'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
