<?php
namespace App\Controller;

use App\Controller\AppController;
use App\Model\Table\PurchaseOrderTable;
use Cake\Log\Log;
use Cake\Core\Configure;
use Cake\Mailer\Email;

/**
 * GoodsDeliveryNote Controller
 *
 * @property \App\Model\Table\GoodsDeliveryNoteTable $GoodsDeliveryNote
 * @property PurchaseOrderTable $PurchaseOrder
 *
 * @method \App\Model\Entity\GoodsDeliveryNote[] paginate($object = null, array $settings = [])
 */
class GoodsDeliveryNoteController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
	public function index()
    {
    	$this->loadModel('PurchaseOrder');
    	
    	$pendingpurchaseorder = $this->PurchaseOrder->find('all',[
    			'fields'=>['OwnerCompanies.Company_name','CompanyMaster.Company_name','Currency.sign','GoodsDeliveryNote.id','is_local','id','po_number','po_date','product_id','total_order_price','send_to_inward','inward_status','qc_status'],
    			'conditions'=>['send_to_inward'=>'Y','purchase_type'=>'Chemical Product'],
    			'contain'=>['OwnerCompanies','CompanyMaster','Currency','GoodsDeliveryNote','PurchaseOrderProducts'],
    	]);
    	
    	
    	$this->set(compact('pendingpurchaseorder'));
    	$this->set('_serialize', ['pendingpurchaseorder']);
    }

    
    
    public function sendtoqc($id){
    	
    	
    	$GoodsDeliveryNote= $this->GoodsDeliveryNote->get($id, [
    			'contain' => ['GdnProducts']
    	]);
    	
    	$data = array('id' => $id , 'qc_status' => "Y");

   
    	$GoodsDeliveryNote=$this->GoodsDeliveryNote->patchEntity($GoodsDeliveryNote,$data);
    		
    		if($this->GoodsDeliveryNote->save($GoodsDeliveryNote)){
    		
    		
    		foreach ($GoodsDeliveryNote['gdn_products'] as $key=> $GoodsDeliveryNotes){
    			
    			
    			$this->loadModel('TestRequest');
    			
    			$qc= $this->TestRequest->newEntity();
    			$dataqc=array(
    					'reference_no' => $GoodsDeliveryNote->reference_number,
    					'test_requested_by'=>$this->Auth->User('id'),
    					'owner_companies_id'=>$this->Auth->User('owner_company_id'),
    					'products_master_id'=>$GoodsDeliveryNotes['product_id'],
    					'product_type'=>'Consumable',
    					'quantity'=>$GoodsDeliveryNotes['quantity'],
    					'created_by'=>$this->Auth->User('id')
    				
    			);
    			$qc= $this->TestRequest->patchEntity($qc, $dataqc,["associated"=>[
    					"TestRequestDet"
    			]]);
    			//echo "<pre>";
    			
    			//print_r($qc);
    			$this->TestRequest->save($qc);
    		}//exit;
    		
    		
    		$this->Flash->success(__('GDN has been sent to QC.'));
    		$controllerName="GoodsDeliveryNote";
    		$action="indexConsumable";
    		return $this->redirect(['controller'=>$controllerName,'action' => $action]);
    		
    		
    	}else{
    		
    		$this->Flash->success(__('GDN has not been sent to QC.'));
    		
    	}
    }
    
    
    public function pregrnsendtoqc($id){
    	
    	
    	$GoodsDeliveryNote= $this->GoodsDeliveryNote->get($id, [
    			'contain' => ['GdnProducts']
    	]);
    	
    	$data = array('id' => $id , 'qc_status' => "Y");
    	
    	
    	$GoodsDeliveryNote=$this->GoodsDeliveryNote->patchEntity($GoodsDeliveryNote,$data);
    	
    	if($this->GoodsDeliveryNote->save($GoodsDeliveryNote)){
    		
    		
    		foreach ($GoodsDeliveryNote['gdn_products'] as $key=> $GoodsDeliveryNotes){
    			
    			
    			$this->loadModel('TestRequest');
    			
    			$qc= $this->TestRequest->newEntity();
    			$dataqc=array(
    					'reference_no' => $GoodsDeliveryNote->reference_number,
    					'test_requested_by'=>$this->Auth->User('id'),
    					'owner_companies_id'=>$this->Auth->User('owner_company_id'),
    					'products_master_id'=>$GoodsDeliveryNotes['product_id'],
    					'created_by'=>$this->Auth->User('id')
    					
    			);
    			$qc= $this->TestRequest->patchEntity($qc, $dataqc,["associated"=>[
    					"TestRequestDet"
    			]]);
    			//echo "<pre>";
    			
    			//print_r($qc);
    			$this->TestRequest->save($qc);
    		}//exit;
    		
    		
    		$this->Flash->success(__('GDN has been sent to QC.'));
    		$controllerName="GoodsDeliveryNote";
    		$action="index";
    		return $this->redirect(['controller'=>$controllerName,'action' => $action]);
    		
    		
    	}else{
    		
    		$this->Flash->success(__('GDN has not been sent to QC.'));
    		
    	}
    }
    
    
    
    
    
    
    /**
     * View method
     *
     * @param string|null $id Goods Delivery Note id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
    	$goodsDeliveryNote = $this->GoodsDeliveryNote->get($id, [
    			'contain' => ['GdnProducts','GdnProducts.ProductsMaster','PurchaseOrder','PurchaseOrder.PurchaseOrderProducts','PurchaseOrder.PurchaseOrderProducts.Uom','CompanyMaster','FromLocation','ToLocation','GdnProducts.Uom']
    	]);
    	$this->loadModel('PurchaseOrder');
    	$purchaseOrder = $this->PurchaseOrder->get($goodsDeliveryNote->po_id, [
    			
    			'contain' => ['OwnerCompanies','CompanyMaster','IncoTerms']
    	]);

    	$this->loadModel('Uom');
    	$this->loadModel('City');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name'], ['limit' => 200]);
    	$this->set(compact('goodsDeliveryNote', 'purchaseOrder', 'uom','city'));
    	$this->set('_serialize', ['goodsDeliveryNote']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($purchseOrderId=null)
    {
    	$this->loadModel('PurchaseOrder');
    	
    	$purchaseOrder = $this->PurchaseOrder->get($purchseOrderId, [
    			
    			'contain' => ['OwnerCompanies','PurchaseOrderProducts','PurchaseOrderProducts.ProductsMaster','PurchaseOrderProducts.Uom','CompanyMaster','IncoTerms','Uom','Currency']
    	]);
    	
    	
    	$goodsDeliveryNote= $this->GoodsDeliveryNote->newEntity();
    	
    	if ($this->request->is('post')) {
    		
    		
    		
    		$this->request->data['GoodsDeliveryNote']['gdn_status'] ='2';
    		$this->loadModel('ReferenceNumberCounter');
    		$this->loadComponent('ReferenceNumber');
    		
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($purchaseOrder['owner_companies_id'],'gdn');
    		$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    		
    		
    		$goodsDeliveryNote= $this->GoodsDeliveryNote->patchEntity($goodsDeliveryNote, $this->request->getData(),[
    				
    		]);
    		
    		
    		//debug($goodsDeliveryNote);exit;
    		$goodsDeliveryNote['created_by'] = $this->Auth->User('id');
    		if(!isset($next_ref['full_next_ref_no'])){
    			$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'GDN'));
    		}else{
    			
    			if ($inwardIds=$this->GoodsDeliveryNote->save($goodsDeliveryNote)) {
    				
    				
    				$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    				
    				
    				$inwardQty=0;
    				
    				$gdn_remain=[];
    				
    				$product_qty_list= $this->PurchaseOrder->PurchaseOrderProducts->find("list",[
    						"keyField"=>"product_id",
    						"valueField"=>"qty"
    				])->toArray();
    				foreach ($this->request->data['gdn_products'] as $keys=>&$val){
    					
    					$inwardQty=$inwardQty+$val['quantity'];
    					
    					$gdn_remain[]=[
    							"product_id"=>$val['product_id'],
    							"quantity"=>$product_qty_list[$val['product_id']]-$val['quantity'],
    							"uom_id"=>$val["uom_id"]
    					];
    				}
    				
    				
    				
    				//Update inward status
    				try{
    					$this->loadModel('PurchaseOrder');
    					$this->loadModel('PurchaseOrderProducts');
    					
    					
    					$query = $this->PurchaseOrderProducts->find('all');
    					$sum = $query->func()->sum('qty');
    					$results = $query->select(['total' => $sum])
    					->where([
    							'purchase_order_id' => $purchseOrderId,
    					])->toArray();
    					
    					
    					
    					$status="2";
    					if($inwardQty!=$results[0]['total']){
    						$status="1";
    						$this->sendEmailProduct($purchseOrderId);
    					}
    					
    					
    					$reference_number = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    					
    					
    					$goodsDeliveryNote= $this->GoodsDeliveryNote->newEntity();
    					$remainingqty=array(
    							'po_id' => $purchseOrderId,'gdn_status'=>$status,'reference_number'=>$reference_number,'parent_id'=>$inwardIds->id,
    							
    							"gdn_products"=>$gdn_remain,
    							
    					);
    					$goodsDeliveryNote= $this->GoodsDeliveryNote->patchEntity($goodsDeliveryNote, $remainingqty,[
    							"associated"=>[
    									"GdnProducts"
    							]
    					]);
    					
    					$this->GoodsDeliveryNote->save($goodsDeliveryNote);
    					$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    					
    					
    					
    				}catch(Exception $e){
    					echo $e;die;
    				}
    				
    				
    				
    				$this->Flash->success(__('The {0} has been saved.', 'GDN'));
    				return $this->redirect(['controller'=>'GoodsDeliveryNote','action' => 'indexConsumable']);
    			} else {
    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'GDN'));
    			}
    			
    		}
    		
    	}
    	
    	
    	$this->loadModel('Uom');
    	$this->loadModel('City');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name'], ['limit' => 200]);
    	$this->set(compact('goodsDeliveryNote', 'purchaseOrder', 'uom','city'));
    	$this->set('_serialize', ['goodsDeliveryNote']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Goods Delivery Note id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
    	$goodsDeliveryNote = $this->GoodsDeliveryNote->get($id, [
    			'contain' => ['GdnProducts','GdnProducts.ProductsMaster','PurchaseOrder','PurchaseOrder.PurchaseOrderProducts','PurchaseOrder.PurchaseOrderProducts.Uom','CompanyMaster']
    	]);
    	
    	$po_id=$goodsDeliveryNote->po_id;
    	
    	$this->loadModel('PurchaseOrder');
    	$purchaseOrder = $this->PurchaseOrder->get($goodsDeliveryNote->po_id, [
    			
    			'contain' => ['OwnerCompanies','CompanyMaster','IncoTerms']
    	]);
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		$this->request->data['GoodsDeliveryNote']['gdn_status'] ='2';
    		$goodsDeliveryNote= $this->GoodsDeliveryNote->patchEntity($goodsDeliveryNote, $this->request->getData(),[
    				"associated"=>[
    						"GdnProducts"
    				]
    		]);
    		$goodsDeliveryNote['modified_by'] = $this->Auth->User('id');
    		
    		$inwardQty=0;
    		
    		$gdn_remain=[];
    		
    		$product_qty_list= $this->GoodsDeliveryNote->GdnProducts->find("list",[
    				"keyField"=>"product_id",
    				"valueField"=>"quantity",'conditions'=>['goods_delivery_note_id'=>$id]])->toArray();
    		
    		foreach ($this->request->data['gdn_products'] as $keys=>&$val){
    			
    			$inwardQty=$inwardQty+$val['quantity'];
    			
    			$gdn_remain[]=[
    					"product_id"=>$val['product_id'],
    					
    					"quantity"=>$product_qty_list[$val['product_id']]-$val['quantity'],
    					"uom_id"=>$val["uom_id"]
    			];
    		}
    		$query = $this->GoodsDeliveryNote->GdnProducts->find('all');
    		$sum = $query->func()->sum('quantity');
    		$results = $query->select(['total' => $sum])
    		->where([
    				'goods_delivery_note_id' => $id,
    		])->toArray();
    		
    		if ($inwardIds=$this->GoodsDeliveryNote->save($goodsDeliveryNote)) {
    			
    			//Update inward status
    			try{
    				
    				
    				$status="2";
    				if($inwardQty!=$results[0]['total']){
    					$status="1";
    					$this->sendEmailProduct($po_id);
    				}
    				
    				
    				if($goodsDeliveryNote->parent_id!=NULL && $inwardQty!=$results[0]['total']){
    					
    					
    					$goodsDeliveryNote= $this->GoodsDeliveryNote->newEntity();
    					$remainingqty=array(
    							'po_id' => $po_id,'gdn_status'=>$status,'parent_id'=>$inwardIds->id,
    							
    							"gdn_products"=>$gdn_remain,
    							
    					);
    					$goodsDeliveryNote= $this->GoodsDeliveryNote->patchEntity($goodsDeliveryNote, $remainingqty,[
    							"associated"=>[
    									"GdnProducts"
    							]
    					]);
    					
    					$this->GoodsDeliveryNote->save($goodsDeliveryNote);
    				}else{
    					Log::debug("Order completed.");
    				}
    				
    				
    			}catch(Exception $e){
    				echo $e;die;
    			}
    			
    			
    			$this->Flash->success(__('The {0} has been saved.', 'Goods Delivery Note'));
    			return $this->redirect(['action' => 'indexConsumable']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Goods Delivery Note'));
    		}
    	}
    	
    	
    	
    	$previousdata = $this->GoodsDeliveryNote->GdnProducts->find ( 'all', [
    			'contain' => [
    					'ConsumablesMaster','Uom'
    			],
    			'conditions' => [
    					'GdnProducts.goods_delivery_note_id'=>$goodsDeliveryNote->parent_id
    			]
    			
    	])->toArray();
    	
    	$product_recived_qty_list= $this->GoodsDeliveryNote->find("list",[
    			"keyField"=>"GdnProducts.product_id",
    			"valueField"=> 'revived_qty',
    			'conditions'=>['po_id'=>$po_id,'gdn_status'=>2]
    	])->contain(['GdnProducts']);
    	$product_recived_qty_list=$product_recived_qty_list->select([
    			'GdnProducts.product_id',
    			'revived_qty'=>	$product_recived_qty_list->func()->sum('GdnProducts.quantity'),
    	])->join([
    			[
    					'table'=>'gdn_products',
    					'alias'=>'GdnProducts',
    					'conditions'=>'GdnProducts.goods_delivery_note_id=GoodsDeliveryNote.id',
    					'type'=>'left'
    			]
    	])->group(['GdnProducts.product_id'])-> toArray();
    	
    	$this->set('product_recived_qty_list',$product_recived_qty_list);
    	
    	
    	
    	
    	$this->loadModel('Uom');
    	$this->loadModel('City');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name'], ['limit' => 200]);
    	$this->set(compact('goodsDeliveryNote', 'purchaseOrder', 'uom','city','previousdata'));
    	$this->set('_serialize', ['goodsDeliveryNote']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Goods Delivery Note id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $goodsDeliveryNote = $this->GoodsDeliveryNote->get($id);
        if ($this->GoodsDeliveryNote->delete($goodsDeliveryNote)) {
        	$this->loadModel('PurchaseOrder');
        	
        	$purchaseOrder = $this->PurchaseOrder->get($goodsDeliveryNote->po_id, [
        			'fields'=>['id','inward_status','qc_status']
        	]);
        	$data = array('id' => $goodsDeliveryNote->po_id, 'inward_status' => '0','qc_status'=>null);
        	$inwardstatus = $this->PurchaseOrder->patchEntity($purchaseOrder, $data);
        	$this->PurchaseOrder->save($inwardstatus);
        	
            $this->Flash->success(__('The {0} has been deleted.', 'Goods Delivery Note'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Goods Delivery Note'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    
    
    
    
    
    
    public function indexConsumable()
    {
    	$this->loadModel('PurchaseOrder');
    	
    	$pendingpurchaseorder = $this->PurchaseOrder->find('all',[
    			'fields'=>['OwnerCompanies.Company_name','CompanyMaster.Company_name','Currency.sign','GoodsDeliveryNote.id','GoodsDeliveryNote.gdn_status','GoodsDeliveryNote.qc_status','is_local','id','po_number','po_date','product_id','total_order_price','send_to_inward','inward_status','qc_status'],
    			'conditions'=>['send_to_inward'=>'Y','purchase_type'=>'Consumable'],
    			'contain'=>['OwnerCompanies','CompanyMaster','Currency','GoodsDeliveryNote','PurchaseOrderProducts'],
    	]);
    	
    	
    	$this->set(compact('pendingpurchaseorder'));
    	$this->set('_serialize', ['pendingpurchaseorder']);
    }
    
    
    
    
    
    
    /**
     * View method
     *
     * @param string|null $id Goods Delivery Note id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function viewConsumable($id = null)
    {
    	$goodsDeliveryNote = $this->GoodsDeliveryNote->get($id, [
    			'contain' => ['GdnProducts','GdnProducts.ConsumablesMaster','PurchaseOrder','PurchaseOrder.PurchaseOrderProducts','PurchaseOrder.PurchaseOrderProducts.Uom','CompanyMaster','FromLocation','ToLocation','GdnProducts.Uom']
    	]);
    	$this->loadModel('PurchaseOrder');
    	$purchaseOrder = $this->PurchaseOrder->get($goodsDeliveryNote->po_id, [
    			
    			'contain' => ['OwnerCompanies','CompanyMaster','IncoTerms']
    	]);
    	
    	$this->loadModel('Uom');
    	$this->loadModel('City');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name'], ['limit' => 200]);
    	$this->set(compact('goodsDeliveryNote', 'purchaseOrder', 'uom','city'));
    	$this->set('_serialize', ['goodsDeliveryNote']);
    }
    
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function addConsumable($purchseOrderId=null)
    {
    	$this->loadModel('PurchaseOrder');
    	
    	$purchaseOrder = $this->PurchaseOrder->get($purchseOrderId, [
    			
    			'contain' => ['OwnerCompanies','PurchaseOrderProducts','PurchaseOrderProducts.ConsumablesMaster','PurchaseOrderProducts.Uom','CompanyMaster','IncoTerms','Uom','Currency']
    	]);
    	
    	
    	$goodsDeliveryNote= $this->GoodsDeliveryNote->newEntity();
    	
    	if ($this->request->is('post')) {
    		
    		
    		
    		$this->request->data['GoodsDeliveryNote']['gdn_status'] ='2';
    		$this->loadModel('ReferenceNumberCounter');
    		$this->loadComponent('ReferenceNumber');
    		
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($purchaseOrder['owner_companies_id'],'gdn');
    		$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    		
    		
    		$goodsDeliveryNote= $this->GoodsDeliveryNote->patchEntity($goodsDeliveryNote, $this->request->getData(),[
    				
    		]);
    		
    		
    		//debug($goodsDeliveryNote);exit;
    		$goodsDeliveryNote['created_by'] = $this->Auth->User('id');
    		if(!isset($next_ref['full_next_ref_no'])){
    			$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'GDN'));
    		}else{
    			
    			if ($inwardIds=$this->GoodsDeliveryNote->save($goodsDeliveryNote)) {
    				

    				$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    				
    				
    				$inwardQty=0;
    				
    				$gdn_remain=[];
    				
    				$product_qty_list= $this->PurchaseOrder->PurchaseOrderProducts->find("list",[
    						"keyField"=>"product_id",
    						"valueField"=>"qty"
    				])->toArray();
    				foreach ($this->request->data['gdn_products'] as $keys=>&$val){
    					
    					$inwardQty=$inwardQty+$val['quantity'];
    					
    					 $gdn_remain[]=[
    					 		"product_id"=>$val['product_id'],
    					 		"quantity"=>$product_qty_list[$val['product_id']]-$val['quantity'],
    					 		"uom_id"=>$val["uom_id"]
    					 ];
    				}
    				
    				
    				
    				//Update inward status
    				try{
    					$this->loadModel('PurchaseOrder');
    					$this->loadModel('PurchaseOrderProducts');
    					
    					
    					$query = $this->PurchaseOrderProducts->find('all');
    					$sum = $query->func()->sum('qty');
    					$results = $query->select(['total' => $sum])
    					->where([
    							'purchase_order_id' => $purchseOrderId,
    					])->toArray();
    					
    		
    					
    					$status="2";
    					if($inwardQty!=$results[0]['total']){
    						$status="1";
    						$this->sendEmailConsumable($purchseOrderId);
    					}
    					
    					
    					$reference_number = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    					
    					
    						$goodsDeliveryNote= $this->GoodsDeliveryNote->newEntity();
    						$remainingqty=array(
    								'po_id' => $purchseOrderId,'gdn_status'=>$status,'reference_number'=>$reference_number,'parent_id'=>$inwardIds->id,
									
    								"gdn_products"=>$gdn_remain,
									
							);
    						$goodsDeliveryNote= $this->GoodsDeliveryNote->patchEntity($goodsDeliveryNote, $remainingqty,[
    								"associated"=>[
    										"GdnProducts"
    								]
    						]);
    						
    						$this->GoodsDeliveryNote->save($goodsDeliveryNote);
    						$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    						
    				
    					
    				}catch(Exception $e){
    					echo $e;die;
    				}
    				
    				
    				
    				$this->Flash->success(__('The {0} has been saved.', 'GDN'));
    				return $this->redirect(['controller'=>'GoodsDeliveryNote','action' => 'indexConsumable']);
    			} else {
    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'GDN'));
    			}
    			
    		}
    		
    	}
    	
    	
    	$this->loadModel('Uom');
    	$this->loadModel('City');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name'], ['limit' => 200]);
    	$this->set(compact('goodsDeliveryNote', 'purchaseOrder', 'uom','city'));
    	$this->set('_serialize', ['goodsDeliveryNote']);
    }
    
    /**
     * Edit method
     *
     * @param string|null $id Goods Delivery Note id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function editConsumable($id = null)
    {
    	$goodsDeliveryNote = $this->GoodsDeliveryNote->get($id, [
    			'contain' => ['GdnProducts','GdnProducts.ConsumablesMaster','PurchaseOrder','PurchaseOrder.PurchaseOrderProducts','PurchaseOrder.PurchaseOrderProducts.Uom','CompanyMaster']
    	]);
    	
    	$po_id=$goodsDeliveryNote->po_id;
    	
    	$this->loadModel('PurchaseOrder');
    	$purchaseOrder = $this->PurchaseOrder->get($goodsDeliveryNote->po_id, [
    			
    			'contain' => ['OwnerCompanies','CompanyMaster','IncoTerms']
    	]);
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		$this->request->data['GoodsDeliveryNote']['gdn_status'] ='2';
    		$goodsDeliveryNote= $this->GoodsDeliveryNote->patchEntity($goodsDeliveryNote, $this->request->getData(),[
    				"associated"=>[
    						"GdnProducts"
    				]
    		]);
    		$goodsDeliveryNote['modified_by'] = $this->Auth->User('id');
    		
    		$inwardQty=0;
    		
    		$gdn_remain=[];
    		
    		$product_qty_list= $this->GoodsDeliveryNote->GdnProducts->find("list",[
    				"keyField"=>"product_id",
    				"valueField"=>"quantity",'conditions'=>['goods_delivery_note_id'=>$id]])->toArray();
    	
    		foreach ($this->request->data['gdn_products'] as $keys=>&$val){
    			
    			$inwardQty=$inwardQty+$val['quantity'];
    			
    			$gdn_remain[]=[
    					"product_id"=>$val['product_id'],
    					
    					"quantity"=>$product_qty_list[$val['product_id']]-$val['quantity'],
    					"uom_id"=>$val["uom_id"]
    			];
    		}
    		$query = $this->GoodsDeliveryNote->GdnProducts->find('all');
    		$sum = $query->func()->sum('quantity');
    		$results = $query->select(['total' => $sum])
    		->where([
    				'goods_delivery_note_id' => $id,
    		])->toArray();
    		
    		if ($inwardIds=$this->GoodsDeliveryNote->save($goodsDeliveryNote)) {
    		
    			//Update inward status
    			try{
    				
    			
    				$status="2";
    				if($inwardQty!=$results[0]['total']){
    					$this->sendEmailConsumable($po_id);
    					$status="1";
    				}
    				
    				
    				if($goodsDeliveryNote->parent_id!=NULL && $inwardQty!=$results[0]['total']){
    				
    					
    				$goodsDeliveryNote= $this->GoodsDeliveryNote->newEntity();
    				$remainingqty=array(
    						'po_id' => $po_id,'gdn_status'=>$status,'parent_id'=>$inwardIds->id,
    						
    						"gdn_products"=>$gdn_remain,
    						
    				);
    				$goodsDeliveryNote= $this->GoodsDeliveryNote->patchEntity($goodsDeliveryNote, $remainingqty,[
    						"associated"=>[
    								"GdnProducts"
    						]
    				]);
    				
    				$this->GoodsDeliveryNote->save($goodsDeliveryNote);
    				}else{
    					Log::debug("Order completed.");
    				}
    				
    				
    			}catch(Exception $e){
    				echo $e;die;
    			}
    			
    			
    			$this->Flash->success(__('The {0} has been saved.', 'Goods Delivery Note'));
    			return $this->redirect(['action' => 'indexConsumable']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Goods Delivery Note'));
    		}
    	}
    	
    	
    	  
    	$previousdata = $this->GoodsDeliveryNote->GdnProducts->find ( 'all', [ 
    			'contain' => [ 
						'ConsumablesMaster','Uom' 
				],
				'conditions' => [ 
						'GdnProducts.goods_delivery_note_id'=>$goodsDeliveryNote->parent_id
				]
    			
    	])->toArray();
    	
    	$product_recived_qty_list= $this->GoodsDeliveryNote->find("list",[
    			"keyField"=>"GdnProducts.product_id",
    			"valueField"=> 'revived_qty',
    			'conditions'=>['po_id'=>$po_id,'gdn_status'=>2]
    	])->contain(['GdnProducts']);
    	$product_recived_qty_list=$product_recived_qty_list->select([
    			'GdnProducts.product_id',
    			'revived_qty'=>	$product_recived_qty_list->func()->sum('GdnProducts.quantity'),
    	])->join([
    			[
    					'table'=>'gdn_products',
    					'alias'=>'GdnProducts',
    					'conditions'=>'GdnProducts.goods_delivery_note_id=GoodsDeliveryNote.id',
    					'type'=>'left'
    			]
    	])->group(['GdnProducts.product_id'])-> toArray(); 
    	    	
    	$this->set('product_recived_qty_list',$product_recived_qty_list);
    	
    	
    	
    	
    	$this->loadModel('Uom');
    	$this->loadModel('City');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name'], ['limit' => 200]);
    	$this->set(compact('goodsDeliveryNote', 'purchaseOrder', 'uom','city','previousdata'));
    	$this->set('_serialize', ['goodsDeliveryNote']);
    }
    
    /**
     * Delete method
     *
     * @param string|null $id Goods Delivery Note id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function deleteConsumable($id = null)
    {
    	$this->request->allowMethod(['post', 'delete']);
    	$goodsDeliveryNote = $this->GoodsDeliveryNote->get($id);
    	if ($this->GoodsDeliveryNote->delete($goodsDeliveryNote)) {
    		$this->loadModel('PurchaseOrder');
    		
    		$purchaseOrder = $this->PurchaseOrder->get($goodsDeliveryNote->po_id, [
    				'fields'=>['id','inward_status']
    		]);
    		$data = array('id' => $goodsDeliveryNote->po_id, 'inward_status' => '0');
    		$inwardstatus = $this->PurchaseOrder->patchEntity($purchaseOrder, $data);
    		$this->PurchaseOrder->save($inwardstatus);
    		
    		$this->Flash->success(__('The {0} has been deleted.', 'Goods Delivery Note'));
    	} else {
    		$this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Goods Delivery Note'));
    	}
    	return $this->redirect(['action' => 'indexConsumable']);
    }
    
  
    
    
    
    
    
    
    
    public function sendEmailConsumable($id=null,$sendMail=null){
    	
    	
    	$this->loadModel('PurchaseOrder');
    	
    	if($sendMail==null){
    		return $this->redirect(array("action"=>"sendEmailConsumable",$id,0));
    	}
    	
    	$purchaseOrder = $this->PurchaseOrder->get($id, [
    			
    			'contain' => ['GoodsDeliveryNote','GoodsDeliveryNote.GdnProducts','GoodsDeliveryNote.GdnProducts.ConsumablesMaster','SupplierOffer','OwnerCompanies','CompanyMaster','CompanyMaster.CompanyContactPersons','CompanyMaster.CompanySublocation',
    					'CompanyMaster.CompanySublocation.City','CompanyMaster.CompanySublocation.Countries','CompanyMaster.CompanySublocation.State'	,'OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerCompanyOffices.State','PurchaseOrderProducts',"PurchaseOrderProducts.ConsumablesMaster","PurchaseOrderProducts.Uom","PurchaseOrderProducts.Currency"]
    	])->toArray();
    	
    	$this->loadModel('SupplierInquiry');
    	$supplierInquiry=$this->SupplierInquiry->find(
    			'all',
    			[
    					'fields' => ['SupplierInquiry.company_contact_persons","cc_email'],
    					'conditions'=>['id'=>$purchaseOrder['supplier_offer']['supplier_inquiry_id']]
    					
    			]
    			
    			
    			);
    	
    	
    	$OwnerCompany=$purchaseOrder['owner_company'];
    	
    	$gdndetails=$purchaseOrder['goods_delivery_note'];
    	
    	$product_recived_qty_list= $this->GoodsDeliveryNote->find("list",[
    			"keyField"=>"GdnProducts.product_id",
    			"valueField"=> 'revived_qty',
    			'conditions'=>['po_id'=>$id,'gdn_status'=>2]
    	])->contain(['GdnProducts']);
    	$product_recived_qty_list=$product_recived_qty_list->select([
    			'GdnProducts.product_id',
    			'revived_qty'=>	$product_recived_qty_list->func()->sum('GdnProducts.quantity'),
    	])->join([
    			[
    					'table'=>'gdn_products',
    					'alias'=>'GdnProducts',
    					'conditions'=>'GdnProducts.goods_delivery_note_id=GoodsDeliveryNote.id',
    					'type'=>'left'
    			]
    	])->group(['GdnProducts.product_id'])->toArray();
    	
    	
    	$buyercontact=isset($OwnerCompany['owner_contact_persons'])?$OwnerCompany['owner_contact_persons'][0]['user']['userfullname']:'';
    	
    	$purchaseOrder['buyercontact']=$buyercontact;
    	
    	$this->loadModel('CompanyMaster');
    	$this->loadModel('CompanyContactPersons');
    	$companyOne =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $purchaseOrder['supplier_id']])->contain(['CompanyContactPersons','CompanySublocation','CompanySublocation.City','CompanySublocation.State','CompanySublocation.Countries']);
    	$CompanyMaster = $companyOne->first();
    	
    	
    	$companycontactIdval=isset($purchaseOrder->supplier_offer->supplier_inquiry->company_contact_persons)?$purchaseOrder->supplier_offer->supplier_inquiry->company_contact_persons:"";
    	$companycontactIds=explode(",",$companycontactIdval);
    	
    	$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $purchaseOrder['supplier_id']])->
    	contain([
    			'CompanyContactPersons' => function ($q)use ($companycontactIds){
    			return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
    			},
    			
    			
    			])->toArray();
    			
    			$suppliercontact = "";
    			$supplieremail = array();
    			$vpercount=0;
    			foreach ($CompanyMaster["company_contact_persons"] as $contact["CompanyContactPerson"]){
    				$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
      				ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
      				ucfirst($contact["CompanyContactPerson"]["last_name"]);
      				if(trim($personname," ")!=""){
      					$suppliercontact.=$vpercount>0?",":"";
      					$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
      					$vpercount++;
      				}
      				
      				$contactemail=$contact["CompanyContactPerson"]["email_id"];
      				
      				if(trim($contactemail," ")!=""){
      					array_push($supplieremail, $contactemail);
      				}else{
      					
      					$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
      				
      				}
    			}
    			
    			//debug($suppliercontact);exit;
    			$purchaseOrder['CompanyMaster']=$CompanyMaster;
    			$purchaseOrder['suppliercontact']=$suppliercontact;
    			$purchaseOrder['gdn']=$gdndetails;
    			$purchaseOrder['product_recived_qty_list']=$product_recived_qty_list;
//     			if(count($contactemail)==0){
//     				$this->Session->setFlash("Please Select atleast one email id.");
//     				return $this->redirect(array("action"=>"edit",$id));
//     			}
    			$cc=array();
    			
    			
    			
    			$buyermail=$purchaseOrder['owner_company']['company_email'];
    			
    			
    			if(!isset($buyermail)){
    				$this->Session->setFlash('Buyer company not have valid email id.');
    			}
    			$to = array();
    			if(Configure::read("productionMode")){
    				
    				/*******Production Mode*******************/
    				$to=$supplieremail;
    				$cc=$purchaseOrder['supplier_offer']['supplier_inquiry']['cc_email'];
    			}else{
    				/*******Dev Mode*******************/
    				$to=array('sujatasid@gmail.com');
    				$cc=array("sujatasid@gmail.com");
    				/**************************/
    			}
    			
    			$subject=	'Pre GRN from '.$OwnerCompany['Company_name'];
    			//echo '@@'.$sendMail;die;
    			/// for send email and preview
    			if( isset($sendMail)&& $sendMail==1){
    				/// send email
    				
    				
    				$email = new Email('default');
    				
    				
    				$email
    				->template('pregrn_consumable','pregrn_consumable')
    				->from($buyermail)
    				->to($to)
    				->cc($cc)
    				//->bcc($bcc)
    				->subject($subject)
    				->emailFormat('html')
    				->viewVars($purchaseOrder);
    				//->send('sendmail');
    				
    				
    				if ($email->send()) {
    				
    					$this->Flash->success(__('The {0} has been sent successfully.', "Pending GDN"));
    					return $this->redirect(['action' => 'index-consumable']);
    				} else {
    					$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "Pending GDN"));
    				}
    				
    				
    				
    				
    				
    			}else{
    				
    				//email preview
    				// 				/debug($OwnerCompany);
    				foreach ($purchaseOrder as  $key=> $data ){
    					$this->set($key,$data);
    				}
    				
    				$this->set("mails",array(
    						"from"=>$buyermail,
    						"to" =>$to,
    						"cc" => $cc,
    						"subject"=>$subject
    				));
    				
    				$this->set("title_for_layout","Pre GRN.");
    				$this->set("mailSendAction",array(
    						"send"=>array("action"=>"sendEmailConsumable",$id,true),
    						"cancel"=>array("action"=>"index-consumable")
    				));
    				
    				
    				$this->viewBuilder()->setLayout("/Email/html/emailpreview");
    				$this->render('/Email/html/pregrn_consumable');
    				
    				
    			}
  
    			
    }
    
    
    
    
    
    
    
    public function sendEmailProduct($id=null,$sendMail=null){
    	
    	
    	$this->loadModel('PurchaseOrder');
    	
    	if($sendMail==null){
    		return $this->redirect(array("action"=>"sendEmailProduct",$id,0));
    	}
    	$purchaseOrder = $this->PurchaseOrder->get($id, [
    			
    			'contain' => ['GoodsDeliveryNote','GoodsDeliveryNote.GdnProducts','GoodsDeliveryNote.GdnProducts.ProductsMaster','SupplierOffer','OwnerCompanies','CompanyMaster','CompanyMaster.CompanyContactPersons','CompanyMaster.CompanySublocation',
    					'CompanyMaster.CompanySublocation.City','CompanyMaster.CompanySublocation.Countries','CompanyMaster.CompanySublocation.State'	,'OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerCompanyOffices.State','PurchaseOrderProducts',"PurchaseOrderProducts.ConsumablesMaster","PurchaseOrderProducts.Uom","PurchaseOrderProducts.Currency"]
    	])->toArray();
    	
    	$this->loadModel('SupplierInquiry');
    	$supplierInquiry=$this->SupplierInquiry->find(
    			'all',
    			[
    					'fields' => ['SupplierInquiry.company_contact_persons","cc_email'],
    					'conditions'=>['id'=>$purchaseOrder['supplier_offer']['supplier_inquiry_id']]
    					
    			]
    			
    			
    			);
    	
    	
    	$OwnerCompany=$purchaseOrder['owner_company'];
    	
    	$gdndetails=$purchaseOrder['goods_delivery_note'];
    	
    	$product_recived_qty_list= $this->GoodsDeliveryNote->find("list",[
    			"keyField"=>"GdnProducts.product_id",
    			"valueField"=> 'revived_qty',
    			'conditions'=>['po_id'=>$id,'gdn_status'=>2]
    	])->contain(['GdnProducts']);
    	$product_recived_qty_list=$product_recived_qty_list->select([
    			'GdnProducts.product_id',
    			'revived_qty'=>	$product_recived_qty_list->func()->sum('GdnProducts.quantity'),
    	])->join([
    			[
    					'table'=>'gdn_products',
    					'alias'=>'GdnProducts',
    					'conditions'=>'GdnProducts.goods_delivery_note_id=GoodsDeliveryNote.id',
    					'type'=>'left'
    			]
    	])->group(['GdnProducts.product_id'])->toArray();
    	
    	
    	$buyercontact=isset($OwnerCompany['owner_contact_persons'])?$OwnerCompany['owner_contact_persons'][0]['user']['userfullname']:'';
    	
    	$purchaseOrder['buyercontact']=$buyercontact;
    	
    	$this->loadModel('CompanyMaster');
    	$this->loadModel('CompanyContactPersons');
    	$companyOne =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $purchaseOrder['supplier_id']])->contain(['CompanyContactPersons','CompanySublocation','CompanySublocation.City','CompanySublocation.State','CompanySublocation.Countries']);
    	$CompanyMaster = $companyOne->first();
    	
    	
    	$companycontactIdval=isset($purchaseOrder->supplier_offer->supplier_inquiry->company_contact_persons)?$purchaseOrder->supplier_offer->supplier_inquiry->company_contact_persons:"";
    	$companycontactIds=explode(",",$companycontactIdval);
    	
    	$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $purchaseOrder['supplier_id']])->
    	contain([
    			'CompanyContactPersons' => function ($q)use ($companycontactIds){
    			return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
    			},
    			
    			
    			])->toArray();
    			
    			$suppliercontact = "";
    			$supplieremail = array();
    			$vpercount=0;
    			foreach ($CompanyMaster["company_contact_persons"] as $contact["CompanyContactPerson"]){
    				$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
      				ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
      				ucfirst($contact["CompanyContactPerson"]["last_name"]);
      				if(trim($personname," ")!=""){
      					$suppliercontact.=$vpercount>0?",":"";
      					$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
      					$vpercount++;
      				}
      				
      				$contactemail=$contact["CompanyContactPerson"]["email_id"];
      				
      				if(trim($contactemail," ")!=""){
      					array_push($supplieremail, $contactemail);
      				}else{
      					
      					$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
      					
      				}
    			}
    			
    			//debug($suppliercontact);exit;
    			$purchaseOrder['CompanyMaster']=$CompanyMaster;
    			$purchaseOrder['suppliercontact']=$suppliercontact;
    			$purchaseOrder['gdn']=$gdndetails;
    			$purchaseOrder['product_recived_qty_list']=$product_recived_qty_list;
//     			if(count($contactemail)==0){
//     				$this->Session->setFlash("Please Select atleast one email id.");
//     				return $this->redirect(array("action"=>"edit",$id));
//     			}
    			$cc=array();
    			
    			
    			
    			$buyermail=$purchaseOrder['owner_company']['company_email'];
    			
    			
    			if(!isset($buyermail)){
    				$this->Session->setFlash('Buyer company not have valid email id.');
    			}
    			$to = array();
    			if(Configure::read("productionMode")){
    				
    				/*******Production Mode*******************/
    				$to=$supplieremail;
    				$cc=$purchaseOrder['supplier_offer']['supplier_inquiry']['cc_email'];
    			}else{
    				/*******Dev Mode*******************/
    				$to=array('sujatasid@gmail.com');
    				$cc=array("sujatasid@gmail.com");
    				/**************************/
    			}
    			
    			$subject=	'Pre GRN from '.$OwnerCompany['Company_name'];
    			//echo '@@'.$sendMail;die;
    			/// for send email and preview
    			if( isset($sendMail)&& $sendMail==1){
    				/// send email
    				
    				
    				$email = new Email('default');
    				
    				
    				$email
    				->template('pregrn_product','pregrn_product')
    				->from($buyermail)
    				->to($to)
    				->cc($cc)
    				//->bcc($bcc)
    				->subject($subject)
    				->emailFormat('html')
    				->viewVars($purchaseOrder);
    				//->send('sendmail');
    				
    				
    				if ($email->send()) {
    					
    					$this->Flash->success(__('The {0} has been sent successfully.', "Pending GDN"));
    					return $this->redirect(['action' => 'index']);
    				} else {
    					$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "Pending GDN"));
    				}
    				
    				
    				
    				
    				
    			}else{
    				
    				//email preview
    				// 				/debug($OwnerCompany);
    				foreach ($purchaseOrder as  $key=> $data ){
    					$this->set($key,$data);
    				}
    				
    				$this->set("mails",array(
    						"from"=>$buyermail,
    						"to" =>$to,
    						"cc" => $cc,
    						"subject"=>$subject
    				));
    				
    				$this->set("title_for_layout","Pre GRN.");
    				$this->set("mailSendAction",array(
    						"send"=>array("action"=>"sendEmailProduct",$id,true),
    						"cancel"=>array("action"=>"index")
    				));
    				
    				
    				$this->viewBuilder()->setLayout("/Email/html/emailpreview");
    				$this->render('/Email/html/pregrn_product');
    				
    				
    			}
    			
    			
    }
    
    
    
    
    
}
