<?php
//App::uses('AppController', 'Controller');

namespace App\Controller;

use App\Controller\AppController;
use Cake\Cache\Cache;
use Cake\Routing\Router;


/**
 * PettyCashDailyExpenses Controller
 *
 * @property PettyCashDailyExpense $PettyCashDailyExpense
 * @property PaginatorComponent $Paginator
 */
class PettyCashReportsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');
		
	public $uses=array("PettyCashDailyExpense","AccountBalance","CompanySublocation","OwnerCompany","PettyCashMonthlyBalance","User");
	
	public $pettySublocations=array(
			1=>"trigon_office_report",
			2=>"jpharma_factory_report",
			3=>"trigon_warehouse_report",
			4=>"jpharma_office_report",
			5=>"jpharma_warehouse_report",
			6=>"jpharmapvtltd_office_report",
			7=>"jpharmapvtltd_factory_report",
			8=>"jpharmapvtltd_warehouse_report"			
		);	

/**
 * index method
 *
 *
 * @return void
 */
	public function index() {
							
        $this->set(compact('pettyCashDailyExpenses'));
        $this->set('_serialize', ['pettyCashDailyExpenses']);
		
		$this->request->data["Search"]=$this->request->query;
		$user=$this->request->data["Search"]["_user"]=isset($this->request->data["Search"]["_user"])?$this->request->data["Search"]["_user"]:"";
				
		$sublocation=$this->request->data["Search"]["_sublocation"]=isset($this->request->data["Search"]["_sublocation"])?$this->request->data["Search"]["_sublocation"]:"";		
				
		$this->loadModel('OwnerCompanies');
		$OwnerCompanies=$this->OwnerCompanies->find("all",array(
				"conditions"=>array("OwnerCompanies.id"=>$sublocation)
			)
		);
		$OwnerCompanies = $OwnerCompanies->first();
		$this->set('OwnerCompanyInfo', $OwnerCompanies);
		
		$ownerCompanies = $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name']);
		$ownerCompanies = $ownerCompanies->toArray();
		
		$this->loadModel('OwnerCompanyOffices');
		$ownerCompanyoffice = $this->OwnerCompanyOffices->find('all');
		$ownerCompanyoffice = $ownerCompanyoffice->toArray();
		
		foreach($ownerCompanyoffice as $office){
			
			$OwnerCompanies=$this->OwnerCompanies->find("all",array(
					"conditions"=>array("OwnerCompanies.id"=>$office['owner_company_id']) //
				)
			);
			$OwnerCompanies = $OwnerCompanies->first();
			
			if(isset($office['address']))
				$detailsOfc[$office['id']] = $OwnerCompanies['Company_name'].', '.$office['address'];
			else
				$detailsOfc[$office['id']] = $OwnerCompanies['Company_name'];
		}
		$this->set('detailsOfc', $detailsOfc);
		
		
		$ownercomp="";
 		if($sublocation== "1")
 		{
 			$ownercomp="2";
 		}
 		if($sublocation== "2")
 		{
 			$ownercomp="5";
 		}
		if($sublocation== "3")
 		{
 			$ownercomp="3";
 		}
		if($sublocation== "4")
 		{
 			$ownercomp="1";
 		}
 		if($sublocation== "5" || $sublocation== "6")
 		{
 			$ownercomp="6";
		}
		if($sublocation== "9")
 		{
 			$ownercomp="7";
 		}
		
		if(!empty($_GET['_year']) && ($_GET['_month']))
			$this->request->data["Search"]["selectmonth"]=$_GET['_year'].'-'.$_GET['_month'];
			
		$selectmonth=$this->request->data["Search"]["selectmonth"]=isset($this->request->data["Search"]["selectmonth"])?$this->request->data["Search"]["selectmonth"]:date("Y-m");		
		
		$this->request->data["Search"]["_year"]=substr($selectmonth,0,4);
		$this->request->data["Search"]["_month"]=substr($selectmonth,5,2);
		
		$this->loadModel('CompanyMaster');
		$this->loadModel('OwnerCompanies');
		$this->loadModel('CompanySublocation');
		$this->loadModel('PettyCashDailyExpenses');				
		
		$companySublocation=$this->CompanySublocation->find("all",array(
					"conditions"=>array("CompanySublocation.id"=>$sublocation),
					"joins"=>array(
						array(
							"table"=>"owner_companies",
							"alias"=>"OwnerCompany",
							"conditions"=>"OwnerCompany.id=CompanySublocation.company_id",
							"type"=>"left"		
						)
					)
				)
			);			

		$companySublocation = $companySublocation->first();
		
		/*
		$data = array(
					"PettyCashDailyExpenses.owner_company_id"=>$ownercomp,								
					"PettyCashDailyExpenses.sublocation"=>$sublocation,
					"PettyCashDailyExpenses.transaction_date like '$selectmonth-%'"
					);
		*/
		
		if($user==""){
			
			$this->loadModel('PettyCashDailyExpenses');	
			$pettyCashExpenses=$this->PettyCashDailyExpenses->find("all",array(
						"conditions"=>array(
								"PettyCashDailyExpenses.owner_company_id"=>$ownercomp,								
								"PettyCashDailyExpenses.sublocation"=>$sublocation,
								"PettyCashDailyExpenses.transaction_date like '$selectmonth-%'"
								),
						"order"=>"PettyCashDailyExpenses.id desc",
					)
				);

			$balanceData = $this->getBalance($ownercomp, $sublocation, $selectmonth);
								
			$this->set("pettyCashExpenses",$pettyCashExpenses);
			$this->set("monthlyData",$this->getBalance($ownercomp, $sublocation, $selectmonth));
		}
		else {
			
			$this->loadModel('PettyCashDailyExpenses');						
			$pettyCashExpenses=$this->PettyCashDailyExpenses->find("all",array(
					"conditions"=>array(
								"PettyCashDailyExpenses.owner_company_id"=>$ownercomp,
								'PettyCashDailyExpenses.created_by'=>$user,
								"PettyCashDailyExpenses.sublocation"=>$sublocation,
								"PettyCashDailyExpenses.transaction_date like '$selectmonth-%'"
						),
					"order"=>"PettyCashDailyExpenses.id desc",
					)
				);
			
			$this->set("pettyCashExpenses",$pettyCashExpenses);
			$this->set("monthlyData",$this->getBalance_userwise($ownercomp, $sublocation, $selectmonth));			
		}
		
		$this->set("companySublocation",$companySublocation);
		$this->set("sublocations",$sublocation);
		
		$this->loadModel('Users');
		$users = $this->Users->find('list', ['keyField' => 'id','valueField' => 'username', 'recursive'=>-1]);
		$this->set('users', $users->toArray());
	}
	
	public function getBalance($ownercomp,$sublocation,$month){
		
		$user=$this->request->data["Search"]["_user"]=isset($this->request->data["Search"]["_user"])?$this->request->data["Search"]["_user"]:"";
		$balance_conditions=array(
				"owner_company"=>$ownercomp,
				"sublocation"=>$sublocation,
			
				"account_name"=>"petty_cash"
		);
		
		$this->loadModel('AccountBalances');	
		$AccountBalance=$this->AccountBalances->find("all",array("conditions"=>$balance_conditions));
		
		$AccountBalance = $AccountBalance->first();
		
		if(!isset($AccountBalance->id)){
			//create account balance
			$AccountBalance=array(
					"owner_company"=>$ownercomp,
					"sublocation"=>$sublocation,
					"account_name"=>"petty_cash",
					
					"balance"=>"0"
			);
		}
				
		$MonthlyBalance_exists_conditions=array("month"=>$month,"sublocation"=>$sublocation,"owner_company_id"=>$ownercomp);
		
		$this->loadModel('PettyCashMonthlyBalance');	
		$PettyCashMonthlyBalance=$this->PettyCashMonthlyBalance->find("all",array("conditions"=>$MonthlyBalance_exists_conditions));

		$PettyCashMonthlyBalance=$PettyCashMonthlyBalance->first();
		
		if(!isset($PettyCashMonthlyBalance["PettyCashMonthlyBalance"])){
			// create Petty Cash Monthly Balance for new month
			
			$this->loadModel('PettyCashDailyExpenses');	
			$prevbal=$this->PettyCashMonthlyBalance->find("all",array(
					"conditions"=>array(
							"PettyCashMonthlyBalance.month <= '$month' " ,"sublocation"=>$sublocation,"owner_company_id"=>$ownercomp
						),
					"order"=>"PettyCashMonthlyBalance.month desc",
					));
					
			$prevbal=$prevbal->first();		
			
			$conditions = array(
					"month"=>$month,
					"total_amount"=>"0.00",
					"net_balance_amount"=>isset($prevbal["net_balance_amount"])?$prevbal["net_balance_amount"]:"0.00",
					"sublocation"=>$sublocation,
					"owner_company_id"=>$ownercomp,					
					"entry_status"=>1     // entry status for month = 1 ,0
					// 1 for Allow entry for that month
					// 0 for closed entry for that month and can't enter in future
			);
			
			$PettyCashMonthlyBalance["PettyCashMonthlyBalance"]=array(
					"month"=>$month,
					"total_amount"=>"0.00",
					"net_balance_amount"=>isset($prevbal["net_balance_amount"])?$prevbal["net_balance_amount"]:"0.00",
					"sublocation"=>$sublocation,
					"owner_company_id"=>$ownercomp,
					
					"entry_status"=>1     // entry status for month = 1 ,0
					// 1 for Allow entry for that month
					// 0 for closed entry for that month and can't enter in future
			);
		}
		return array("AccountBalance"=>$AccountBalance,"PettyCashMonthlyBalance"=> $PettyCashMonthlyBalance["PettyCashMonthlyBalance"]);
	}
	
	
	
	public function getBalance_userwise($ownercomp,$sublocation,$month){
				
		$user=$this->request->data["Search"]["_user"]=isset($this->request->data["Search"]["_user"])?$this->request->data["Search"]["_user"]:"";
		$balance_conditions=array(
				"owner_company"=>$ownercomp,
				"sublocation"=>$sublocation,
				"created_by"=>$user,
				"account_name"=>"petty_cash"
		);
		
		$this->loadModel('AccountBalances');	
		$AccountBalance=$this->AccountBalances->find("all",array("conditions"=>$balance_conditions));
		
		$AccountBalance=$AccountBalance->first();		
		
		if(!isset($AccountBalance["id"])){
			//create account balance
			$AccountBalance=array(
					"owner_company"=>$ownercomp,
					"sublocation"=>$sublocation,
					"account_name"=>"petty_cash",
					"created_by"=>$user,
					"balance"=>"0"
			);
		}		
		
		$MonthlyBalance_exists_conditions=array("month"=>$month,"sublocation"=>$sublocation,"owner_company_id"=>$ownercomp,"created_by"=>$user);
		
		$this->loadModel('PettyCashMonthlyBalance');
		$PettyCashMonthlyBalance=$this->PettyCashMonthlyBalance->find("all",array("conditions"=>$MonthlyBalance_exists_conditions));
		
		$PettyCashMonthlyBalance=$PettyCashMonthlyBalance->first();		
				
		if(!isset($PettyCashMonthlyBalance)){
			// create Petty Cash Monthly Balance for new month
			
			$this->loadModel('PettyCashMonthlyBalanc');
			$prevbal=$this->PettyCashMonthlyBalance->find("all",array(
					"conditions"=>array(
							"PettyCashMonthlyBalance.month <= '$month' " ,"sublocation"=>$sublocation,"owner_company_id"=>$ownercomp,"created_by"=>$user
					),
					"order"=>"PettyCashMonthlyBalance.month desc",
			));
			
			$prevbal=$prevbal->first();		
			
			$PettyCashMonthlyBalance["PettyCashMonthlyBalance"]=array(
					"month"=>$month,
					"total_amount"=>"0.00",
					"net_balance_amount"=>isset($prevbal["net_balance_amount"])?$prevbal["net_balance_amount"]:"0.00",
					"sublocation"=>$sublocation,
					"owner_company_id"=>$ownercomp,
					"created_by"=>$user,
					"entry_status"=>1     // entry status for month = 1 ,0
					// 1 for Allow entry for that month
					// 0 for closed entry for that month and can't enter in future
			);
		}
		return array("AccountBalance"=>$AccountBalance,"PettyCashMonthlyBalance"=> $PettyCashMonthlyBalance["PettyCashMonthlyBalance"]);
	}
	
	
	public function printReport($ownercomp = null,$sublocation=null){

		$this->loadModel('OwnerCompanies');
		
		if(empty($_GET['_sublocation'])){	
			$_GET['_sublocation'] = '';
		}		
		

		if($_GET['_sublocation']== "1")
 		{
 			$ownercomp="2";
 		}
		
 		if($_GET['_sublocation']== "2")
 		{
 			$ownercomp="5";
 		}
		
		if($_GET['_sublocation']== "3")
 		{
 			$ownercomp="3";
 		}
		
		if($_GET['_sublocation']== "4")
 		{
 			$ownercomp="1";
 		}
		
 		if($_GET['_sublocation']== "5" || $_GET['_sublocation']== "6")
 		{
 			$ownercomp="6";
		}
		
		if($_GET['_sublocation']== "9")
 		{	
 			$ownercomp="7";
 		}		
		
		$OwnerCompanies=$this->OwnerCompanies->find("all",array(
				"conditions"=>array("OwnerCompanies.id"=>$ownercomp)
			)
		);

		$OwnerCompanies = $OwnerCompanies->first();
		$this->set('ownercompanyinfo', $OwnerCompanies);
		
		$this->set('ownercomp', $ownercomp);
		$this->set('sublocation', $sublocation);
		$this->set('getInfo', $_GET);
		
		$this->index($ownercomp,$sublocation);
		$this->viewBuilder()->setLayout('');
	}
	
	public function trigon_office_report($ownercomp = null) {
		
	}
	
	public function trigon_warehouse_report($ownercomp = null) {
		
	}
	
	public function jpharma_factory_report($ownercomp = null) {
		
	}
	
	public function jpharma_office_report($ownercomp = null) {
		
	}
	
	public function jpharma_warehouse_report($ownercomp = null) {
	}
	
	public function jpharmapvtltd_factory_report($ownercomp = null) {
		
	}
	
	public function jpharmapvtltd_office_report($ownercomp = null) {
		
	}
	
	public function jpharmapvtltd_warehouse_report($ownercomp = null) {
	}
	
	
	
	
	
	
	
}

