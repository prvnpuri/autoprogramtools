<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * LocalPreShipmentTransporter Controller
 *
 * @property \App\Model\Table\LocalPreShipmentTransporterTable $LocalPreShipmentTransporter
 *
 * @method \App\Model\Entity\LocalPreShipmentTransporter[] paginate($object = null, array $settings = [])
 */
class LocalPreShipmentTransporterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'Oas', 'Transports']
        ];
        $localPreShipmentTransporter = $this->paginate($this->LocalPreShipmentTransporter);

        $this->set(compact('localPreShipmentTransporter'));
        $this->set('_serialize', ['localPreShipmentTransporter']);
    }

    /**
     * View method
     *
     * @param string|null $id Local Pre Shipment Transporter id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $localPreShipmentTransporter = $this->LocalPreShipmentTransporter->get($id, [
            'contain' => ['Invoices', 'Oas', 'Transports']
        ]);

        $this->set('localPreShipmentTransporter', $localPreShipmentTransporter);
        $this->set('_serialize', ['localPreShipmentTransporter']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $localPreShipmentTransporter = $this->LocalPreShipmentTransporter->newEntity();
        if ($this->request->is('post')) {
            $localPreShipmentTransporter = $this->LocalPreShipmentTransporter->patchEntity($localPreShipmentTransporter, $this->request->data);
            if ($this->LocalPreShipmentTransporter->save($localPreShipmentTransporter)) {
                $this->Flash->success(__('The {0} has been saved.', 'Local Pre Shipment Transporter'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Local Pre Shipment Transporter'));
            }
        }
        $invoices = $this->LocalPreShipmentTransporter->Invoices->find('list', ['limit' => 200]);
        $oas = $this->LocalPreShipmentTransporter->Oas->find('list', ['limit' => 200]);
        $transports = $this->LocalPreShipmentTransporter->Transports->find('list', ['limit' => 200]);
        $this->set(compact('localPreShipmentTransporter', 'invoices', 'oas', 'transports'));
        $this->set('_serialize', ['localPreShipmentTransporter']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Local Pre Shipment Transporter id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $localPreShipmentTransporter = $this->LocalPreShipmentTransporter->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $localPreShipmentTransporter = $this->LocalPreShipmentTransporter->patchEntity($localPreShipmentTransporter, $this->request->data);
            if ($this->LocalPreShipmentTransporter->save($localPreShipmentTransporter)) {
                $this->Flash->success(__('The {0} has been saved.', 'Local Pre Shipment Transporter'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Local Pre Shipment Transporter'));
            }
        }
        $invoices = $this->LocalPreShipmentTransporter->Invoices->find('list', ['limit' => 200]);
        $oas = $this->LocalPreShipmentTransporter->Oas->find('list', ['limit' => 200]);
        $transports = $this->LocalPreShipmentTransporter->Transports->find('list', ['limit' => 200]);
        $this->set(compact('localPreShipmentTransporter', 'invoices', 'oas', 'transports'));
        $this->set('_serialize', ['localPreShipmentTransporter']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Local Pre Shipment Transporter id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $localPreShipmentTransporter = $this->LocalPreShipmentTransporter->get($id);
        if ($this->LocalPreShipmentTransporter->delete($localPreShipmentTransporter)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Local Pre Shipment Transporter'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Local Pre Shipment Transporter'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
