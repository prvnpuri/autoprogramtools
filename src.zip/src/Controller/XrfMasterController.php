<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;
/**
 * XrfMaster Controller
 *
 * @property \App\Model\Table\XrfMasterTable $XrfMaster
 *
 * @method \App\Model\Entity\XrfMaster[] paginate($object = null, array $settings = [])
 */
class XrfMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ProductsMaster', 'CompanyMaster']
        ];
        $xrfMaster = $this->paginate($this->XrfMaster);

        $this->set(compact('xrfMaster'));
        $this->set('_serialize', ['xrfMaster']);
    }

    /**
     * View method
     *
     * @param string|null $id Xrf Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $xrfMaster = $this->XrfMaster->get($id, [
            'contain' => ['ProductsMaster', 'CompanyMaster']
        ]);

        $this->set('xrfMaster', $xrfMaster);
        $this->set('_serialize', ['xrfMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $xrfMaster = $this->XrfMaster->newEntity();
        if ($this->request->is('post')) {
            $xrfMaster = $this->XrfMaster->patchEntity($xrfMaster, $this->request->data);
            if(isset($this->request->data["file_name"]) &&  $this->request->data["file_name"]["error"]==0)
            {
            	$filename=$this->request->data["file_name"]["name"];
            	$xrfMaster["file_name"]=$filename;
            }else{
            	unset($xrfMaster["file_name"]);
            }
            
            $xrfMaster['created_by'] = $this->Auth->User('id');
            if ($result=$this->XrfMaster->save($xrfMaster)) {
            	if(isset($this->request->data["file_name"]) &&  $this->request->data["file_name"]["error"]==0){
            		$id=$result->id;
            		$filename=$id."_".$this->request->data["file_name"]["name"];
            		$url = Router::url('/',true).'upload/ed-xrf/'.$filename;
            		$uploadpath = 'upload/ed-xrf/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["file_name"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["file_name"]);
            	}
            	
                $this->Flash->success(__('The {0} has been saved.', 'ED XRF'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'ED XRF'));
            }
        }
        $this->set(compact('xrfMaster'));
        $this->set('_serialize', ['xrfMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Xrf Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $xrfMaster = $this->XrfMaster->get($id, [
            'contain' => ['ProductsMaster', 'CompanyMaster']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $xrfMaster = $this->XrfMaster->patchEntity($xrfMaster, $this->request->data);
            
            if(isset($this->request->data["file_name"]) &&  $this->request->data["file_name"]["error"]==0)
            {
            	$filename=$this->request->data["file_name"]["name"];
            	$xrfMaster["file_name"]=$filename;
            }else{
            	unset($xrfMaster["file_name"]);
            }
            
            $xrfMaster['modified_by'] = $this->Auth->User('id');
            
            if ($result=$this->XrfMaster->save($xrfMaster)) {
            	
            	if(isset($this->request->data["file_name"]) &&  $this->request->data["file_name"]["error"]==0){
            		$id=$result->id;
            		$filename=$id."_".$this->request->data["file_name"]["name"];
            		$url = Router::url('/',true).'upload/ed-xrf/'.$filename;
            		$uploadpath = 'upload/ed-xrf/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["file_name"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["file_name"]);
            	}
            	
                $this->Flash->success(__('The {0} has been saved.', 'ED XRF'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'ED XRF'));
            }
        }
        $this->set(compact('xrfMaster'));
        $this->set('_serialize', ['xrfMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Xrf Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $xrfMaster = $this->XrfMaster->get($id);
        if ($this->XrfMaster->delete($xrfMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'ED XRF'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'ED XRF'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
