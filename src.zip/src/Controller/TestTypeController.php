<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TestType Controller
 *
 * @property \App\Model\Table\TestTypeTable $TestType
 *
 * @method \App\Model\Entity\TestType[] paginate($object = null, array $settings = [])
 */
class TestTypeController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $testType = $this->paginate($this->TestType);

        $this->set(compact('testType'));
        $this->set('_serialize', ['testType']);
    }

    /**
     * View method
     *
     * @param string|null $id Test Type id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $testType = $this->TestType->get($id, [
            'contain' => ['TestingMasters']
        ]);

        $this->set('testType', $testType);
        $this->set('_serialize', ['testType']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $testType = $this->TestType->newEntity();
        if ($this->request->is('post')) {
            $testType = $this->TestType->patchEntity($testType, $this->request->data);
            if ($this->TestType->save($testType)) {
                $this->Flash->success(__('The {0} has been saved.', 'Test Type'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Type'));
            }
        }
        $this->set(compact('testType'));
        $this->set('_serialize', ['testType']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Test Type id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $testType = $this->TestType->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $testType = $this->TestType->patchEntity($testType, $this->request->data);
            if ($this->TestType->save($testType)) {
                $this->Flash->success(__('The {0} has been saved.', 'Test Type'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Type'));
            }
        }
        $this->set(compact('testType'));
        $this->set('_serialize', ['testType']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Test Type id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $testType = $this->TestType->get($id);
        if ($this->TestType->delete($testType)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Test Type'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Test Type'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
