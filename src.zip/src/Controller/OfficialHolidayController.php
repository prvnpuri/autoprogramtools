<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OfficialHoliday Controller
 *
 * @property \App\Model\Table\OfficialHolidayTable $OfficialHoliday
 *
 * @method \App\Model\Entity\OfficialHoliday[] paginate($object = null, array $settings = [])
 */
class OfficialHolidayController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $officialHoliday = $this->paginate($this->OfficialHoliday);

        $this->set(compact('officialHoliday'));
        $this->set('_serialize', ['officialHoliday']);
    }

    /**
     * View method
     *
     * @param string|null $id Official Holiday id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $officialHoliday = $this->OfficialHoliday->get($id, [
            'contain' => []
        ]);

        $this->set('officialHoliday', $officialHoliday);
        $this->set('_serialize', ['officialHoliday']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $officialHoliday = $this->OfficialHoliday->newEntity();
        if ($this->request->is('post')) {
            $officialHoliday = $this->OfficialHoliday->patchEntity($officialHoliday, $this->request->data);
            if ($this->OfficialHoliday->save($officialHoliday)) {
                $this->Flash->success(__('The {0} has been saved.', 'Official Holiday'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Official Holiday'));
            }
        }
        $this->set(compact('officialHoliday'));
        $this->set('_serialize', ['officialHoliday']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Official Holiday id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $officialHoliday = $this->OfficialHoliday->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $officialHoliday = $this->OfficialHoliday->patchEntity($officialHoliday, $this->request->data);
            if ($this->OfficialHoliday->save($officialHoliday)) {
                $this->Flash->success(__('The {0} has been saved.', 'Official Holiday'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Official Holiday'));
            }
        }
        $this->set(compact('officialHoliday'));
        $this->set('_serialize', ['officialHoliday']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Official Holiday id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $officialHoliday = $this->OfficialHoliday->get($id);
        if ($this->OfficialHoliday->delete($officialHoliday)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Official Holiday'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Official Holiday'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
