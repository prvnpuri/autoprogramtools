<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ShipTo Controller
 *
 * @property \App\Model\Table\ShipToTable $ShipTo
 *
 * @method \App\Model\Entity\ShipTo[] paginate($object = null, array $settings = [])
 */
class ShipToController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Companies']
        ];
        $shipTo = $this->paginate($this->ShipTo);

        $this->set(compact('shipTo'));
        $this->set('_serialize', ['shipTo']);
    }

    /**
     * View method
     *
     * @param string|null $id Ship To id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $shipTo = $this->ShipTo->get($id, [
            'contain' => ['Orders', 'Companies']
        ]);

        $this->set('shipTo', $shipTo);
        $this->set('_serialize', ['shipTo']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $shipTo = $this->ShipTo->newEntity();
        if ($this->request->is('post')) {
            $shipTo = $this->ShipTo->patchEntity($shipTo, $this->request->data);
            if ($this->ShipTo->save($shipTo)) {
                $this->Flash->success(__('The {0} has been saved.', 'Ship To'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Ship To'));
            }
        }
        $orders = $this->ShipTo->Orders->find('list', ['limit' => 200]);
        $companies = $this->ShipTo->Companies->find('list', ['limit' => 200]);
        $this->set(compact('shipTo', 'orders', 'companies'));
        $this->set('_serialize', ['shipTo']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Ship To id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $shipTo = $this->ShipTo->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $shipTo = $this->ShipTo->patchEntity($shipTo, $this->request->data);
            if ($this->ShipTo->save($shipTo)) {
                $this->Flash->success(__('The {0} has been saved.', 'Ship To'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Ship To'));
            }
        }
        $orders = $this->ShipTo->Orders->find('list', ['limit' => 200]);
        $companies = $this->ShipTo->Companies->find('list', ['limit' => 200]);
        $this->set(compact('shipTo', 'orders', 'companies'));
        $this->set('_serialize', ['shipTo']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Ship To id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $shipTo = $this->ShipTo->get($id);
        if ($this->ShipTo->delete($shipTo)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Ship To'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Ship To'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
