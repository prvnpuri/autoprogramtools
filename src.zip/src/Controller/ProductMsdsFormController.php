<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductMsdsForm Controller
 *
 * @property \App\Model\Table\ProductMsdsFormTable $ProductMsdsForm
 *
 * @method \App\Model\Entity\ProductMsdsForm[] paginate($object = null, array $settings = [])
 */
class ProductMsdsFormController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $productMsdsForm = $this->paginate($this->ProductMsdsForm);

        $this->set(compact('productMsdsForm'));
        $this->set('_serialize', ['productMsdsForm']);
    }

    /**
     * View method
     *
     * @param string|null $id Product Msds Form id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productMsdsForm = $this->ProductMsdsForm->get($id, [
            'contain' => ['ProductMsds']
        ]);

        $this->set('productMsdsForm', $productMsdsForm);
        $this->set('_serialize', ['productMsdsForm']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productMsdsForm = $this->ProductMsdsForm->newEntity();
        if ($this->request->is('post')) {
            $productMsdsForm = $this->ProductMsdsForm->patchEntity($productMsdsForm, $this->request->data);
            if ($this->ProductMsdsForm->save($productMsdsForm)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Msds Form'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Msds Form'));
            }
        }
        $this->set(compact('productMsdsForm'));
        $this->set('_serialize', ['productMsdsForm']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product Msds Form id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productMsdsForm = $this->ProductMsdsForm->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productMsdsForm = $this->ProductMsdsForm->patchEntity($productMsdsForm, $this->request->data);
            if ($this->ProductMsdsForm->save($productMsdsForm)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Msds Form'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Msds Form'));
            }
        }
        $this->set(compact('productMsdsForm'));
        $this->set('_serialize', ['productMsdsForm']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product Msds Form id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productMsdsForm = $this->ProductMsdsForm->get($id);
        if ($this->ProductMsdsForm->delete($productMsdsForm)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product Msds Form'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product Msds Form'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
