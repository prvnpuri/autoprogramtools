<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PostShipmentRegularisation Controller
 *
 * @property \App\Model\Table\PostShipmentRegularisationTable $PostShipmentRegularisation
 *
 * @method \App\Model\Entity\PostShipmentRegularisation[] paginate($object = null, array $settings = [])
 */
class PostShipmentRegularisationController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Oas']
        ];
        $postShipmentRegularisation = $this->paginate($this->PostShipmentRegularisation);

        $this->set(compact('postShipmentRegularisation'));
        $this->set('_serialize', ['postShipmentRegularisation']);
    }

    /**
     * View method
     *
     * @param string|null $id Post Shipment Regularisation id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $postShipmentRegularisation = $this->PostShipmentRegularisation->get($id, [
            'contain' => ['Oas']
        ]);

        $this->set('postShipmentRegularisation', $postShipmentRegularisation);
        $this->set('_serialize', ['postShipmentRegularisation']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $postShipmentRegularisation = $this->PostShipmentRegularisation->newEntity();
        if ($this->request->is('post')) {
            $postShipmentRegularisation = $this->PostShipmentRegularisation->patchEntity($postShipmentRegularisation, $this->request->data);
            if ($this->PostShipmentRegularisation->save($postShipmentRegularisation)) {
                $this->Flash->success(__('The {0} has been saved.', 'Post Shipment Regularisation'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Post Shipment Regularisation'));
            }
        }
        $oas = $this->PostShipmentRegularisation->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postShipmentRegularisation', 'oas'));
        $this->set('_serialize', ['postShipmentRegularisation']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Post Shipment Regularisation id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $postShipmentRegularisation = $this->PostShipmentRegularisation->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $postShipmentRegularisation = $this->PostShipmentRegularisation->patchEntity($postShipmentRegularisation, $this->request->data);
            if ($this->PostShipmentRegularisation->save($postShipmentRegularisation)) {
                $this->Flash->success(__('The {0} has been saved.', 'Post Shipment Regularisation'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Post Shipment Regularisation'));
            }
        }
        $oas = $this->PostShipmentRegularisation->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postShipmentRegularisation', 'oas'));
        $this->set('_serialize', ['postShipmentRegularisation']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Post Shipment Regularisation id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $postShipmentRegularisation = $this->PostShipmentRegularisation->get($id);
        if ($this->PostShipmentRegularisation->delete($postShipmentRegularisation)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Post Shipment Regularisation'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Post Shipment Regularisation'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
