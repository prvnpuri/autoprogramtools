<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CountryOfOrigin Controller
 *
 * @property \App\Model\Table\CountryOfOriginTable $CountryOfOrigin
 *
 * @method \App\Model\Entity\CountryOfOrigin[] paginate($object = null, array $settings = [])
 */
class CountryOfOriginController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $countryOfOrigin = $this->paginate($this->CountryOfOrigin);

        $this->set(compact('countryOfOrigin'));
        $this->set('_serialize', ['countryOfOrigin']);
    }

    /**
     * View method
     *
     * @param string|null $id Country Of Origin id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $countryOfOrigin = $this->CountryOfOrigin->get($id, [
            'contain' => []
        ]);

        $this->set('countryOfOrigin', $countryOfOrigin);
        $this->set('_serialize', ['countryOfOrigin']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $countryOfOrigin = $this->CountryOfOrigin->newEntity();
        if ($this->request->is('post')) {
            $countryOfOrigin = $this->CountryOfOrigin->patchEntity($countryOfOrigin, $this->request->data);
            if ($this->CountryOfOrigin->save($countryOfOrigin)) {
                $this->Flash->success(__('The {0} has been saved.', 'Country Of Origin'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Country Of Origin'));
            }
        }
        $this->set(compact('countryOfOrigin'));
        $this->set('_serialize', ['countryOfOrigin']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Country Of Origin id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $countryOfOrigin = $this->CountryOfOrigin->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $countryOfOrigin = $this->CountryOfOrigin->patchEntity($countryOfOrigin, $this->request->data);
            if ($this->CountryOfOrigin->save($countryOfOrigin)) {
                $this->Flash->success(__('The {0} has been saved.', 'Country Of Origin'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Country Of Origin'));
            }
        }
        $this->set(compact('countryOfOrigin'));
        $this->set('_serialize', ['countryOfOrigin']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Country Of Origin id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $countryOfOrigin = $this->CountryOfOrigin->get($id);
        if ($this->CountryOfOrigin->delete($countryOfOrigin)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Country Of Origin'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Country Of Origin'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
