<?php
namespace App\Controller;

use App\Controller\AppController;
use App\Model\Table\LedgerGroupsTable;

/**
 * LedgerGroups Controller
 *
 * @property \App\Model\Table\LedgerGroupsTable $LedgerGroups
 *
 * @method \App\Model\Entity\LedgerGroup[] paginate($object = null, array $settings = [])
 */
class LedgerGroupsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {   
        $this->paginate = [
            'contain' => ['ParentLedgerGroups'],
            'sortWhitelist' => [
                'id', 'type', 'parent_id', 'ParentLedgerGroups.type'
            ]
        ];
        $ledgerGroups = $this->paginate($this->LedgerGroups);

        $this->set(compact('ledgerGroups'));
        $this->set('_serialize', ['ledgerGroups']);
    }

    /**
     * View method
     *
     * @param string|null $id Ledger Group id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ledgerGroup = $this->LedgerGroups->get($id, [
            'contain' => ['ParentLedgerGroups', 'ChildLedgerGroups']
        ]);

        $this->set('ledgerGroup', $ledgerGroup);
        $this->set('_serialize', ['ledgerGroup']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ledgerGroup = $this->LedgerGroups->newEntity();
        if ($this->request->is('post')) {
            $ledgerGroup = $this->LedgerGroups->patchEntity($ledgerGroup, $this->request->data);
            if ($this->LedgerGroups->save($ledgerGroup)) {
                $this->Flash->success(__('The {0} has been saved.', 'Ledger Group'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Ledger Group'));
            }
        }
        $parentLedgerGroups = $this->LedgerGroups->ParentLedgerGroups->find('list',[
            "keyField"=>"id",
            "valueField"=>"type"
        ]);
        $this->set(compact('ledgerGroup', 'parentLedgerGroups'));
        $this->set('_serialize', ['ledgerGroup']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Ledger Group id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ledgerGroup = $this->LedgerGroups->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ledgerGroup = $this->LedgerGroups->patchEntity($ledgerGroup, $this->request->data);
            if ($this->LedgerGroups->save($ledgerGroup)) {
                $this->Flash->success(__('The {0} has been saved.', 'Ledger Group'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Ledger Group'));
            }
        }
        $parentLedgerGroups = $this->LedgerGroups->ParentLedgerGroups->find('list',[
            "keyField"=>"id",
            "valueField"=>"type"
        ]);
        $this->set(compact('ledgerGroup', 'parentLedgerGroups'));
        $this->set('_serialize', ['ledgerGroup']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Ledger Group id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ledgerGroup = $this->LedgerGroups->get($id);
        if ($this->LedgerGroups->delete($ledgerGroup)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Ledger Group'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Ledger Group'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
