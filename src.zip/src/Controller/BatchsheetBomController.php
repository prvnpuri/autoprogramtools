<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * BatchsheetBom Controller
 *
 * @property \App\Model\Table\BatchsheetBomTable $BatchsheetBom
 *
 * @method \App\Model\Entity\BatchsheetBom[] paginate($object = null, array $settings = [])
 */
class BatchsheetBomController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['BatchsheetTran', 'ReferenceBom', 'Uoms']
        ];
        $batchsheetBom = $this->paginate($this->BatchsheetBom);

        $this->set(compact('batchsheetBom'));
        $this->set('_serialize', ['batchsheetBom']);
    }

    /**
     * View method
     *
     * @param string|null $id Batchsheet Bom id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $batchsheetBom = $this->BatchsheetBom->get($id, [
            'contain' => ['BatchsheetTran', 'ReferenceBom', 'Uoms']
        ]);

        $this->set('batchsheetBom', $batchsheetBom);
        $this->set('_serialize', ['batchsheetBom']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $batchsheetBom = $this->BatchsheetBom->newEntity();
        if ($this->request->is('post')) {
            $batchsheetBom = $this->BatchsheetBom->patchEntity($batchsheetBom, $this->request->data);
            if ($this->BatchsheetBom->save($batchsheetBom)) {
                $this->Flash->success(__('The {0} has been saved.', 'Batchsheet Bom'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Batchsheet Bom'));
            }
        }
        $batchsheetTran = $this->BatchsheetBom->BatchsheetTran->find('list', ['limit' => 200]);
        $referenceBom = $this->BatchsheetBom->ReferenceBom->find('list', ['limit' => 200]);
        $uoms = $this->BatchsheetBom->Uoms->find('list', ['limit' => 200]);
        $this->set(compact('batchsheetBom', 'batchsheetTran', 'referenceBom', 'uoms'));
        $this->set('_serialize', ['batchsheetBom']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Batchsheet Bom id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $batchsheetBom = $this->BatchsheetBom->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $batchsheetBom = $this->BatchsheetBom->patchEntity($batchsheetBom, $this->request->data);
            if ($this->BatchsheetBom->save($batchsheetBom)) {
                $this->Flash->success(__('The {0} has been saved.', 'Batchsheet Bom'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Batchsheet Bom'));
            }
        }
        $batchsheetTran = $this->BatchsheetBom->BatchsheetTran->find('list', ['limit' => 200]);
        $referenceBom = $this->BatchsheetBom->ReferenceBom->find('list', ['limit' => 200]);
        $uoms = $this->BatchsheetBom->Uoms->find('list', ['limit' => 200]);
        $this->set(compact('batchsheetBom', 'batchsheetTran', 'referenceBom', 'uoms'));
        $this->set('_serialize', ['batchsheetBom']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Batchsheet Bom id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $batchsheetBom = $this->BatchsheetBom->get($id);
        if ($this->BatchsheetBom->delete($batchsheetBom)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Batchsheet Bom'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Batchsheet Bom'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
