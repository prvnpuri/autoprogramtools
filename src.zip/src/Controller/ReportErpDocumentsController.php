<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ReportErpDocuments Controller
 *
 * @property \App\Model\Table\ReportErpDocumentsTable $ReportErpDocuments
 *
 * @method \App\Model\Entity\ReportErpDocument[] paginate($object = null, array $settings = [])
 */
class ReportErpDocumentsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ReportErpIssues', 'ReportErpActivities']
        ];
        $reportErpDocuments = $this->paginate($this->ReportErpDocuments);

        $this->set(compact('reportErpDocuments'));
        $this->set('_serialize', ['reportErpDocuments']);
    }

    /**
     * View method
     *
     * @param string|null $id Report Erp Document id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $reportErpDocument = $this->ReportErpDocuments->get($id, [
            'contain' => ['ReportErpIssues', 'ReportErpActivities']
        ]);

        $this->set('reportErpDocument', $reportErpDocument);
        $this->set('_serialize', ['reportErpDocument']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $reportErpDocument = $this->ReportErpDocuments->newEntity();
        if ($this->request->is('post')) {
            $reportErpDocument = $this->ReportErpDocuments->patchEntity($reportErpDocument, $this->request->data);
            if ($this->ReportErpDocuments->save($reportErpDocument)) {
                $this->Flash->success(__('The {0} has been saved.', 'Report Erp Document'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Report Erp Document'));
            }
        }
        $reportErpIssues = $this->ReportErpDocuments->ReportErpIssues->find('list', ['limit' => 200]);
        $reportErpActivities = $this->ReportErpDocuments->ReportErpActivities->find('list', ['limit' => 200]);
        $this->set(compact('reportErpDocument', 'reportErpIssues', 'reportErpActivities'));
        $this->set('_serialize', ['reportErpDocument']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Report Erp Document id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $reportErpDocument = $this->ReportErpDocuments->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $reportErpDocument = $this->ReportErpDocuments->patchEntity($reportErpDocument, $this->request->data);
            if ($this->ReportErpDocuments->save($reportErpDocument)) {
                $this->Flash->success(__('The {0} has been saved.', 'Report Erp Document'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Report Erp Document'));
            }
        }
        $reportErpIssues = $this->ReportErpDocuments->ReportErpIssues->find('list', ['limit' => 200]);
        $reportErpActivities = $this->ReportErpDocuments->ReportErpActivities->find('list', ['limit' => 200]);
        $this->set(compact('reportErpDocument', 'reportErpIssues', 'reportErpActivities'));
        $this->set('_serialize', ['reportErpDocument']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Report Erp Document id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $reportErpDocument = $this->ReportErpDocuments->get($id);
        if ($this->ReportErpDocuments->delete($reportErpDocument)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Report Erp Document'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Report Erp Document'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
