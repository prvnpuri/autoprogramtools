<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * KeyResultAreaRating Controller
 *
 * @property \App\Model\Table\KeyResultAreaRatingTable $KeyResultAreaRating
 *
 * @method \App\Model\Entity\KeyResultAreaRating[] paginate($object = null, array $settings = [])
 */
class KeyResultAreaRatingController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['KeyResultAreas']
        ];
        $keyResultAreaRating = $this->paginate($this->KeyResultAreaRating);

        $this->set(compact('keyResultAreaRating'));
        $this->set('_serialize', ['keyResultAreaRating']);
    }

    /**
     * View method
     *
     * @param string|null $id Key Result Area Rating id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $keyResultAreaRating = $this->KeyResultAreaRating->get($id, [
            'contain' => ['KeyResultAreas']
        ]);

        $this->set('keyResultAreaRating', $keyResultAreaRating);
        $this->set('_serialize', ['keyResultAreaRating']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $keyResultAreaRating = $this->KeyResultAreaRating->newEntity();
        if ($this->request->is('post')) {
            $keyResultAreaRating = $this->KeyResultAreaRating->patchEntity($keyResultAreaRating, $this->request->data);
            if ($this->KeyResultAreaRating->save($keyResultAreaRating)) {
                $this->Flash->success(__('The {0} has been saved.', 'Key Result Area Rating'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Key Result Area Rating'));
            }
        }
        $keyResultAreas = $this->KeyResultAreaRating->KeyResultAreas->find('list', ['limit' => 200]);
        $this->set(compact('keyResultAreaRating', 'keyResultAreas'));
        $this->set('_serialize', ['keyResultAreaRating']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Key Result Area Rating id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $keyResultAreaRating = $this->KeyResultAreaRating->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $keyResultAreaRating = $this->KeyResultAreaRating->patchEntity($keyResultAreaRating, $this->request->data);
            if ($this->KeyResultAreaRating->save($keyResultAreaRating)) {
                $this->Flash->success(__('The {0} has been saved.', 'Key Result Area Rating'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Key Result Area Rating'));
            }
        }
        $keyResultAreas = $this->KeyResultAreaRating->KeyResultAreas->find('list', ['limit' => 200]);
        $this->set(compact('keyResultAreaRating', 'keyResultAreas'));
        $this->set('_serialize', ['keyResultAreaRating']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Key Result Area Rating id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $keyResultAreaRating = $this->KeyResultAreaRating->get($id);
        if ($this->KeyResultAreaRating->delete($keyResultAreaRating)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Key Result Area Rating'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Key Result Area Rating'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
