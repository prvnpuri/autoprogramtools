<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Chronos\Date;

/**
 * OfficeInward Controller
 *
 * @property \App\Model\Table\OfficeInwardTable $OfficeInward
 *
 * @method \App\Model\Entity\OfficeInward[] paginate($object = null, array $settings = [])
 */
class MyPageController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index($companyid = Null)
    {
        
        if(!isset($companyid)){
            $companyid=1;
        }
        
        $userid= $this->Auth->user('id');
        $this->loadModel('OfficeInward');
        $officeInward = $this->paginate($this->OfficeInward);
        $officeInward = $this->OfficeInward->find('all', ['keyField'=>'id',
            "conditions"=>array("OfficeInward.document_for"=>$userid, 'OfficeInward.status'=>0),
            
        ]);
       // debug($officeInward); exit();
        //$myPage = $this->paginate($this->MyPage);
        $this->loadModel('Users');
        $users = $this->Users->find('list', ['keyField'=>'id', 'valueField'=>'userfullname','order'=>'userfullname']);
        
        $this->loadModel('OwnerCompanies');
        $ownerCompanies= $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
        $this->set(compact($officeInward,'myPage','ownerCompanies','users','officeInward'));
        $this->set('_serialize', ['officeInward']);
    }
    
    public function isDelivered($id = null)
    {
        $this->loadModel('OfficeInward');
        $userid=$this->Auth->user('id');
        $delivered_date=date('Y-m-d');
        $data=array('id'=>$id,'is_delivered'=>'1','delivered_date'=>$delivered_date);
       // $data["OfficeInward"]["id"]=$id;
        //$data["OfficeInward"]["is_delivered"]='1';
        $officeInward = $this->OfficeInward->get($id, [
            'contain' => []
        ]);
        
        $officeInwards = $this->OfficeInward->patchEntity($officeInward, $data);
        if($this->OfficeInward->save($officeInwards)){

            $this->loadModel('Notifications');
			
			$notifications= $this->Notifications->find()->where(['notification_by' => 'MyPage','transaction_id'=>$id])->first();
			
			$data = array('transaction_id' => $id , 'status' => "2",'action_taken_by'=>$userid,'action_taken_on'=>date('Y-m-d'));
            $notification= $this->Notifications->patchEntity($notifications, $data);
           // debug($notification);exit();
			$this->Notifications->save($notification);

        $this->Flash->success(__('The office inward has been delivered'));
        return $this->redirect(['action' => 'index']);
        }else{
            $this->Flash->error(__('The office inward could not be  delivered.. Please, try again.'));
        }
    }
    public function officeInwardActivity($id = null)
    {
        $userid= $this->Auth->user('id');
        $this->loadModel('OfficeInward');
        $officeInward = $this->OfficeInward->find('all', ['keyField'=>'id',
            "conditions"=>array("OfficeInward.id"=>$id),
            
        ]);
        $officeInwardsss = $this->OfficeInward->get($id, [
            'contain' => ['OwnerCompanies','Users']
        ]);
        
     
        
        
        $officeInwards = $officeInward->first();
        
        $this->loadModel('Users');
        $users = $this->Users->find('list', ['keyField'=>'id', 'valueField'=>'userfullname','order'=>'userfullname']);
        
        $this->loadModel('OwnerCompanies');
        $ownerCompanies= $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
        
        
        if(isset($this->request->data['forward_to'])){
            $this->loadModel('OfficeInwardActivity');
            $data=array('id'=>$id);
            
            if(isset($this->request->data['forward_to'])){
                $this->request->data['office_inward_activity']['forward_to']= $this->request->data['forward_to'];
            }
            //debug($this->request->data['office_inward_activity']['forward_to']);exit;
            if(isset($this->request->data['status'])){
                $this->request->data['office_inward_activity']['status']= $this->request->data['status'];
            }
            if(isset($this->request->data['comment'])){
                $this->request->data['office_inward_activity']['comment']= $this->request->data['comment'];
            }
            if(isset($this->request->data['office_inward_id'])){
                $this->request->data['office_inward_activity']['office_inward_id']= $this->request->data['office_inward_id'];
            }
            //  debug($this->request->data);exit;
            //debug($this->request->data);exit;
            $officeInwardactivity = $this->OfficeInwardActivity->newEntity();
            
            $officeInwardActivity = $this->OfficeInwardActivity->patchEntity($officeInwardactivity, $this->request->data);
            
            
            $this->request->data['status']=$this->request->data['status'];
			$this->request->data['document_for']=$this->request->data['document_for'];
           // debug($this->request->data); exit();
            
            $officeInwardsInsert = $this->OfficeInward->get($id, [
                'contain' => []
            ]);
            $officeInwardActivityInsert = $this->OfficeInwardActivity->patchEntity($officeInwardsInsert, $this->request->data);
            $officeInwardActivityInsert['status']==1;
			$officeInwardActivityInsert['document_for']=$officeInwardActivityInsert['forward_to'];
            //debug($officeInwardActivity);exit;
            //debug($officeInwardActivityInsert); exit();
            if($this->OfficeInwardActivity->save($officeInwardActivity) && $this->OfficeInward->save($officeInwardActivityInsert)){
                $this->Flash->success(__('The office inward has been delivered'));
                return $this->redirect(['action' => 'index']);
            }
            
            
        }
        $this->set(compact($officeInward,'myPage','ownerCompanies','users','officeInwards','officeInwardsss'));
        $this->set('_serialize', ['officeInward']);
        
        
        
        
    }
    
    /**
     * View method
     *
     * @param string|null $id Office Inward id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
   
}
