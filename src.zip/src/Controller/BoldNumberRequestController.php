<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Mailer\Email;
/**
 * BoldNumberRequest Controller
 *
 * @property \App\Model\Table\BoldNumberRequestTable $BoldNumberRequest
 *
 * @method \App\Model\Entity\BoldNumberRequest[] paginate($object = null, array $settings = [])
 */
class BoldNumberRequestController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$ownercomp= $this->request->session()->read('OwnerCompany.id');
    
    	//$condn=array('boldNumberRequest.owner_company_id'=>$ownercomp);
    	//$condn=array('boldNumberRequest.del_status !='=>1);
    	
    	$condn= array(['AND' => [
    			'BoldNumberRequest.owner_company_id' => $ownercomp,
    			'BoldNumberRequest.del_status' => "0"
    	]]);
        $this->paginate = [
        	'conditions'=>$condn,
        	'fields'=>['id','owner_company_id','unique_series','bold_number_from','bold_number_to','is_approved','vendor_id','del_status','is_delivered','vendor_accepted','vendor_accepted_date','quality_accepted','quality_accepted_date','quality_accepted_by','quantity_reject','Vendor.id','Vendor.username','QualityAcceptedBy.id','QualityAcceptedBy.username'],
            'contain' => ['OwnerCompanies'],
        		'join'=>[
        		
        				'Vendor' => [
        						'table' => 'users',
        						'type' => 'LEFT',
        						'conditions' =>'BoldNumberRequest.vendor_id = Vendor.id',
        				],
        				'QualityAcceptedBy' => [
        						'table' => 'users',
        						'type' => 'LEFT',
        						'conditions' =>'BoldNumberRequest.quality_accepted_by = QualityAcceptedBy.id',
        				]
        		],

        ];
        $boldNumberRequest = $this->paginate($this->BoldNumberRequest);

        $this->set(compact('boldNumberRequest'));
        $this->set('_serialize', ['boldNumberRequest']);
    }
    
    public function indexVendor()
    {
    	$ownercomp= $this->request->session()->read('OwnerCompany.id');

    	$condn= array(['AND' => [
    			'BoldNumberRequest.owner_company_id' => $ownercomp,
    			'BoldNumberRequest.del_status' => "0",
    			'BoldNumberRequest.is_approved'=>1
    	]]);
    	$this->paginate = [
    			'conditions'=>$condn,
    			'fields'=>['id','owner_company_id','unique_series','bold_number_from','bold_number_to','is_approved','vendor_id','del_status','is_delivered','vendor_accepted','vendor_accepted_date','quality_accepted','quality_accepted_date','quality_accepted_by','quantity_reject','Vendor.id','Vendor.username','QualityAcceptedBy.id','QualityAcceptedBy.username'],
    			'contain' => ['OwnerCompanies'],
    			'join'=>[
    	
    					'Vendor' => [
    							'table' => 'users',
    							'type' => 'LEFT',
    							'conditions' =>'BoldNumberRequest.vendor_id = Vendor.id',
    					],
    					'QualityAcceptedBy' => [
    							'table' => 'users',
    							'type' => 'LEFT',
    							'conditions' =>'BoldNumberRequest.quality_accepted_by = QualityAcceptedBy.id',
    					]
    			],
    	
    	];
    	$boldNumberRequest = $this->paginate($this->BoldNumberRequest);
    
    	$this->set(compact('boldNumberRequest'));
    	$this->set('_serialize', ['boldNumberRequest']);

    }

    /**
     * View method
     *
     * @param string|null $id Bold Number Request id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $boldNumberRequest = $this->BoldNumberRequest->get($id, [
            'contain' => ['OwnerCompanies', 'BoldNumberInventory']
        ]);

        $this->set('boldNumberRequest', $boldNumberRequest);
        $this->set('_serialize', ['boldNumberRequest']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
    	
        $boldNumberRequest = $this->BoldNumberRequest->newEntity();
        if ($this->request->is('post')) {
        	$ownercomp=$this->request->session()->read('OwnerCompany.id');
        	$this->request->data['owner_company_id']=$ownercomp;
        	$week=Configure::read("UniqueNoSeries.$ownercomp");
        	
        	$condn= array("owner_company_id"=>$ownercomp);
        	$this->request->data['is_approved']="1";
        	$getdata = $this->BoldNumberRequest->find('list', ['keyFields'=>'id','valueField'=>'unique_series','limit' => 200,'conditions'=>$condn])->toArray();
        	$lastdata = end($getdata);

        	if($lastdata !=null){
        		$lastdata2 = \DateTime::createFromFormat('dmy', $lastdata)->format('Y-m-d');
        		$nextSaturday = new \DateTime("$lastdata2 next $week");
        		$firstSat=$nextSaturday->format("m/d/y");
        	}else{
        		$firstSat= date("m/d/y", strtotime("first $week of last month"));
        	}
        	
        	$start = new \DateTime($firstSat);// date format should be m/d/y
        	$end = new \DateTime($firstSat);
        	$end = $end->add(new \DateInterval('P35D'));
        	
        	$satPeriod = new \DatePeriod ($start,\DateInterval::createFromDateString("next $week"),$end);
        	foreach ($satPeriod as $key=>$saturday) {
        		$satdatenew=$saturday->format("Y-m-d");
        		$today = date('Y-m-d');
        		if(strtotime($satdatenew) < strtotime($today)){
        			$this->request->data[$key]['bold_number_from']= $this->request->data['bold_number_from'];
        			$this->request->data[$key]['bold_number_to']= $this->request->data['bold_number_to'];
        			$this->request->data[$key]['is_approved']= $this->request->data['is_approved'];
        			$this->request->data[$key]['unique_series']= $saturday->format("dmy");
        			$this->request->data[$key]['del_status']= '0';
        			$this->request->data[$key]['created_by']= $this->Auth->User('id');
        			$this->request->data[$key]['owner_company_id']= $this->request->data['owner_company_id'];
        		}
        	}
        	unset($this->request->data['bold_number_from']);
        	unset($this->request->data['bold_number_to']);
        	unset($this->request->data['is_approved']);
        	unset($this->request->data['owner_company_id']);
        	
        	
            //$boldNumberRequest = $this->BoldNumberRequest->patchEntity($boldNumberRequest, $this->request->data);


            $entities = $this->BoldNumberRequest->newEntities($this->request->data);
            //$this->BoldNumberRequest->saveMany($entities);
          // debug($entities);exit;
            $data=$this->request->data;
            
            if ($this->BoldNumberRequest->saveMany($entities)) {
            	$this->sendEmail($data,1);
                $this->Flash->success(__('The {0} has been saved.', 'Bold Number Request'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bold Number Request'));
            }
        }
        $ownerCompanies = $this->BoldNumberRequest->OwnerCompanies->find('list', ['fields'=>['id','Company_name'],'limit' => 200]);
        $this->set(compact('boldNumberRequest', 'ownerCompanies'));
        $this->set('_serialize', ['boldNumberRequest']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Bold Number Request id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $boldNumberRequest = $this->BoldNumberRequest->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
        	$this->request->data['modified_by']= $this->Auth->User('id');
            $boldNumberRequest = $this->BoldNumberRequest->patchEntity($boldNumberRequest, $this->request->data);
            if ($this->BoldNumberRequest->save($boldNumberRequest)) {
                $this->Flash->success(__('The {0} has been saved.', 'Bold Number Request'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bold Number Request'));
            }
        }
        $this->set(compact('boldNumberRequest'));
        $this->set('_serialize', ['boldNumberRequest']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Bold Number Request id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $boldNumberRequest = $this->BoldNumberRequest->get($id);
        $data = array('id' => $id , 'del_status' => "1");
         
        $boldNumberRequest = $this->BoldNumberRequest->patchEntity($boldNumberRequest, $data);

        if ( $this->BoldNumberRequest->save($boldNumberRequest)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Bold Number Request'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Bold Number Request'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    public function requestApproval($id,$approvalId,$owner){

    	$data = ['id' => $id , 'is_approved' => $approvalId];
        $boldNumberRequest = $this->BoldNumberRequest->get($id, [
    			'contain' => []
    	]);
    	$boldNumberRequest = $this->BoldNumberRequest->patchEntity($boldNumberRequest, $data);
    	
    	$this->BoldNumberRequest->save($boldNumberRequest);
    	if($approvalId==1){
    		$this->sendEmail($boldNumberRequest,3);
    	}
    
    	return $this->redirect(['action' => 'index',$owner]);
    }
    
    public function isDelivered($id){
    
    	$delAccDate = date('Y-m-d');
    	$data = array('id' => $id , 'is_delivered' => "1", 'vendor_accepted_date'=>$delAccDate);
    	$boldNumberRequest = $this->BoldNumberRequest->get($id, [
    			'contain' => []
    	]);
    	$boldNumberRequest = $this->BoldNumberRequest->patchEntity($boldNumberRequest, $data);
    	 
    	$this->BoldNumberRequest->save($boldNumberRequest);
    	$this->sendEmail($boldNumberRequest,2);
    
    	return $this->redirect(['action' => 'index_vendor']);
    
    }
    
    public function vendorAccept($id,$acceptedId){
    	$vendorAccDate = date('Y-m-d');
    	$vendorAccBy = $this->Auth->user('id');
    	$data = array('id' => $id , 'vendor_accepted' => $acceptedId, 'vendor_accepted_date'=>$vendorAccDate,'vendor_id'=>$vendorAccBy);
    	
    	$boldNumberRequest = $this->BoldNumberRequest->get($id, [
    			'contain' => []
    	]);
    	$boldNumberRequest = $this->BoldNumberRequest->patchEntity($boldNumberRequest, $data);
    
    	$this->BoldNumberRequest->save($boldNumberRequest);
    	/*  if($approvalId==1){
    	 $this->sendEmail($boldnumberReq,3);
    	 }  */
    
    	return $this->redirect(['action' => 'index_vendor']);
    }
    
    public function qualityAccept($id,$acceptedId){
    	$qualityAccDate = date('Y-m-d');
    	$qualityAccBy = $this->Auth->user('id');
    	$data = array('id' => $id , 'quality_accepted' => $acceptedId, 'quality_accepted_date'=>$qualityAccDate,'quality_accepted_by'=>$qualityAccBy);
    	$boldNumberRequest = $this->BoldNumberRequest->get($id, [
    			'contain' => []
    	]);
    	$boldNumberRequest = $this->BoldNumberRequest->patchEntity($boldNumberRequest, $data); 	
    	
    	
    	$query = $this->BoldNumberRequest->find('all', [
    			'conditions' => ['id' =>$id]
    	]);
    	$firstdata = $query->first();
    	
    	
    	$inventry=[
    			        "unique_series"=>$firstdata['unique_series'],
    					"from"=>$firstdata['bold_number_from'],
    					"to"=>$firstdata["bold_number_to"],
    					"bold_number_request_id"=>$firstdata["id"],
    					"owner_company_id"=>$firstdata["owner_company_id"],
    			        "delete_status"=>"0",
                  ];
    
    	//debug($inventry);exit;
    	$this->BoldNumberRequest->save($boldNumberRequest);
    	if($data['quality_accepted']==1){
    		$this->loadModel('BoldNumberInventory');
    		$boldNumberInventory = $this->BoldNumberInventory->newEntity();
    		$boldNumberInventoryAdd = $this->BoldNumberInventory->patchEntity($boldNumberInventory, $inventry);
    		$this->BoldNumberInventory->save($boldNumberInventoryAdd);
    	}
    	return $this->redirect(array('controller'=>'BoldNumberRequest','action' => 'index'));
    }
    
    
    
    public function quantityAccept($id = null) {
    	$boldNumberRequest = $this->BoldNumberRequest->get($id, [
    			'contain' => []
    	]);
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		//debug($this->request->data);exit;
    		$boldNumberRequest = $this->BoldNumberRequest->patchEntity($boldNumberRequest, $this->request->data);
    		if ($this->BoldNumberRequest->save($boldNumberRequest)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Bold Number Request'));
    			return $this->redirect(['action' => 'index']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bold Number Request'));
    		}
    	}
    	$this->set(compact('boldNumberRequest', 'ownerCompanies'));
    	$this->set('_serialize', ['boldNumberRequest']);
    }
    
    
    public function sendEmail($data,$flag){

        $ownercompID=$this->request->session()->read('OwnerCompany.id');
        //send bold number request to vendor
    	if($flag==1){
    		$subject= "Bold Number Request for - ";
    		$flash="Bold Number Request mail has been send to Vendor.";
    		$actionName="erpuser";
    		if(Configure::read('productionMode')){
    			// uncomment when deployee in production
    			$to=array("dkvastrakar18@gmail.com");
    			$cc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    		} else {
    			$to=array("dkvastrakar18@gmail.com");
    			$cc=array("dkvastrakar18@gmail.com");
    		}
    		$action=array("action"=>"index");
    
    	}
    	//vendor accept and deliver and send mail back to erp user
    	if($flag==2){
    		$subject= "Bold Number is Delivered by Vendor for - ";
    		$flash="Bold Number is Delivered by Vendor.";
    		$actionName="vendor";
    		$action=array("action"=>"index_vendor");
    		if(Configure::read('productionMode')){
    			// uncomment when deployee in production
    			$to=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    			$cc=array("dkvastrakar18@gmail.com");
    		} else {
    			$to=array("dkvastrakar18@gmail.com");
    			$cc=array("dkvastrakar18@gmail.com");
    		}
    			
    			
    	}
    	//user bold number accept
    	if($flag==3){
    		$subject= "Bold Number Request for - ";
    		$flash="Bold Number Request mail has been send to Vendor.";
    		$actionName="vendor";
    		$action=array("action"=>"index");
    		if(Configure::read('productionMode')){
    			// uncomment when deployee in production
    			$to=array("dkvastrakar18@gmail.com");
    			$cc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    		} else {
    			$to=array("dkvastrakar18@gmail.com");
    			$cc=array("dkvastrakar18@gmail.com");
    		}
    	}
    	$this->loadModel('OwnerCompanies');
    	$query = $this->OwnerCompanies->find('all', [
    			'conditions' => ['id' =>$ownercompID]
    	]);
    	$ownercompany = $query->first();
    	
    	if($ownercompany["company_email"]!=""){
    		$fromid=$ownercompany["company_email"];
    	}
    	
    	if(!isset($fromid)){
    		throw new NotFoundException("Your Seller Company maild is empty. please fill up your Seller company email id first after then we can send mail.");
    	}
    
    
    	$this->set('data', $data);
    	
    	
    	try{
    		$companyname=$ownercompany["Company_name"];
    		$data['owner']=$companyname;
    		$data['action']=$actionName;
    		$data['todayDate']=date('d-m-Y');
    		$settings=$ownercompany["OwnerCompany"]["email_setting"];
    		$companyId=$ownercompany["OwnerCompany"]["id"];
    		$this->set('companyname', $companyname);
    
    		
    		$email = new Email('default');
    		$email
    		//->setTransport($name)
    		->template('boldnumber_mail','default')
    		->from($fromid)
    		->to($to)
    		->cc($cc)
    		->subject("$subject.$companyname")
    		->emailFormat('html')
    		->viewVars([ 'data'=> $data])
    		->send();
    		$this->Flash->success(__($flash));
    		$this->redirect($action);
    	}catch(Exception $e){
    		throw $e;
    		$this->Flash->error(__('The {0} could not be sent. Please, try again.', 'Bold Number Request mail'));
    		//return false;
    	}
    		
    }
}
