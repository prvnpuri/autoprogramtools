<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductDiscussed Controller
 *
 * @property \App\Model\Table\ProductDiscussedTable $ProductDiscussed
 *
 * @method \App\Model\Entity\ProductDiscussed[] paginate($object = null, array $settings = [])
 */
class ProductDiscussedController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products', 'Attendees']
        ];
        $productDiscussed = $this->paginate($this->ProductDiscussed);

        $this->set(compact('productDiscussed'));
        $this->set('_serialize', ['productDiscussed']);
    }

    /**
     * View method
     *
     * @param string|null $id Product Discussed id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productDiscussed = $this->ProductDiscussed->get($id, [
            'contain' => ['Products', 'Attendees']
        ]);

        $this->set('productDiscussed', $productDiscussed);
        $this->set('_serialize', ['productDiscussed']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productDiscussed = $this->ProductDiscussed->newEntity();
        if ($this->request->is('post')) {
            $productDiscussed = $this->ProductDiscussed->patchEntity($productDiscussed, $this->request->data);
            if ($this->ProductDiscussed->save($productDiscussed)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Discussed'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Discussed'));
            }
        }
        $products = $this->ProductDiscussed->Products->find('list', ['limit' => 200]);
        $attendees = $this->ProductDiscussed->Attendees->find('list', ['limit' => 200]);
        $this->set(compact('productDiscussed', 'products', 'attendees'));
        $this->set('_serialize', ['productDiscussed']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product Discussed id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productDiscussed = $this->ProductDiscussed->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productDiscussed = $this->ProductDiscussed->patchEntity($productDiscussed, $this->request->data);
            if ($this->ProductDiscussed->save($productDiscussed)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Discussed'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Discussed'));
            }
        }
        $products = $this->ProductDiscussed->Products->find('list', ['limit' => 200]);
        $attendees = $this->ProductDiscussed->Attendees->find('list', ['limit' => 200]);
        $this->set(compact('productDiscussed', 'products', 'attendees'));
        $this->set('_serialize', ['productDiscussed']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product Discussed id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productDiscussed = $this->ProductDiscussed->get($id);
        if ($this->ProductDiscussed->delete($productDiscussed)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product Discussed'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product Discussed'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
