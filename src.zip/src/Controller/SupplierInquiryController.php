<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Cache\Cache;
use Cake\Core\Configure; 
use Cake\ORM\toArray;
use Cake\Mailer\Email;
use PhpParser\Node\Stmt\Foreach_;

/**
 * SupplierInquiry Controller
 *
 * @property \App\Model\Table\SupplierInquiryTable $SupplierInquiry
 *
 * @method \App\Model\Entity\SupplierInquiry[] paginate($object = null, array $settings = [])
 */
class SupplierInquiryController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
	
	
    public function index()
    {
    	$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
    	
    	$condn=array('SupplierInquiry.owner_companies_id'=>$ownercomp);
    	
    	$supplierinquires = $this->SupplierInquiry->find('all',
    			[
    					//'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','id','status','company_ids'],
    					'conditions'=>[['inquiry_type'=>'Chemical Product'],$condn],
    					'contain'=>['PurchaseRequisionInquiry','PurchaseRequisionInquiry.PurchaseRequisition','SupplierInquiryProducts','SupplierInquiryProducts.ProductsMaster','SupplierInquiryProducts.Uom','SupplierInquiryProducts.PackingMaster','SupplierInquiryProducts.PackingMaster.PackingType','SupplierOffer', 'OwnerCompanies', 'SupplierOffer.Uom','SupplierOffer.CompanyMaster', 'SupplierOffer.Currency' ],
    					'order'=>['SupplierInquiry.id' => 'DESC']
    			]
    			);
    	
    	
    	
    	$supplierInquiry = $this->paginate($supplierinquires);
    	
    	foreach ($supplierinquires as $ks=>$vals){
    		$companyMaster =  $this->SupplierInquiry->CompanyMaster->find('all',
    				array('fields'=>array('id','company_name')	,
    						'conditions'=>array('id IN '=> explode(",",$vals['company_ids']))
    				))->toArray();
    				
    				$vals['CompanyMaster']=$companyMaster;
    	}
    	$supplierinquires=$supplierinquires->toArray();
    	// echo '<pre>',print_r($supplierinquires);die;
        $this->set(compact('supplierInquiry'));
        $this->set('_serialize', ['supplierInquiry']);
    }
    
    public function indexPacking() {
    	
    	 $supplierinquires = $this->SupplierInquiry->find('all',
    			[
    					'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','is_local','Uom.unit_symbol','validity_of_inquiry','id','status','company_ids',
    								'PackingType.packing_type','PackingSubtype.sub_type','PackingMaster.specification','PackingMaster.description','PackingMaster.color','raised_on'
    							
    							
    					],
    					'conditions'=>['inquiry_type'=>'Packing Product'],
    					'contain'=>['SupplierOffer', 'OwnerCompanies','Uom','PackingMaster', 'PackingMaster.PackingType', 'PackingMaster.PackingSubtype','SupplierOffer.Uom','SupplierOffer.CompanyMaster', 'SupplierOffer.Currency' ],
    					'order'=>['SupplierInquiry.id' => 'DESC']
    			]
    			); 
    	
 
    	 /*$supplierinquires = $this->SupplierInquiry->find()
    	->where(['inquiry_type'=>'Packing Product'])
    	->contain(['OwnerCompanies', 'Uom', 'Currency', 'PackingMaster', 'PackingMaster.PackingSubType', 'PackingMaster.PackingType'])
    	->order(['SupplierInquiry.id' => 'DESC']); */
    	$supplierInquiry = $this->paginate($supplierinquires);
    	
    	
    	foreach ($supplierinquires as $ks=>$vals){
    		$companyMaster =  $this->SupplierInquiry->CompanyMaster->find('all',
    				array('fields'=>array('id','company_name')	,
    						'conditions'=>array('id IN '=> explode(",",$vals['company_ids']))
    				))->toArray();
    	
    				$vals['CompanyMaster']=$companyMaster;
    	}
    	$supplierinquires=$supplierinquires->toArray();

    	$this->set(compact('supplierInquiry'));
    	$this->set('_serialize', ['supplierInquiry']);
    	
    }
    public function indexConsumable() {

    	$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
    	 
    	$condn=array('SupplierInquiry.owner_companies_id'=>$ownercomp);
 	    $supplierinquires = $this->SupplierInquiry->find('all',
    			[
    					//'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','id','status','company_ids'],
    					'conditions'=>[['inquiry_type'=>'Consumable'],$condn],
    					'contain'=>['PurchaseRequisionInquiry','PurchaseRequisionInquiry.PurchaseRequisition','SupplierInquiryProducts','SupplierInquiryProducts.ConsumablesMaster','SupplierInquiryProducts.Uom','SupplierInquiryProducts.PackingMaster','SupplierInquiryProducts.PackingMaster.PackingType','SupplierOffer', 'OwnerCompanies','Uom', 'SupplierOffer.Uom','SupplierOffer.CompanyMaster', 'SupplierOffer.Currency' ],
    					'order'=>['SupplierInquiry.id' => 'DESC']
    			]
    			);
    	 
    	 
    	 
    	$supplierInquiry = $this->paginate($supplierinquires);
    	 
    	foreach ($supplierinquires as $ks=>$vals){
    		$companyMaster =  $this->SupplierInquiry->CompanyMaster->find('all',
    				array('fields'=>array('id','company_name')	,
    						'conditions'=>array('id IN '=> explode(",",$vals['company_ids']))
    				))->toArray();
    	
    				$vals['CompanyMaster']=$companyMaster;
    	}
    	$supplierinquires=$supplierinquires->toArray();
    	// echo '<pre>',print_r($supplierinquires);die;
    	$this->set(compact('supplierInquiry'));
    	$this->set('_serialize', ['supplierInquiry']);
    	 
    }
    public function indexAsset() {
    	 
    	$supplierinquires = $this->SupplierInquiry->find('all',
    			[
    					'fields'=>['OwnerCompanies.Company_name','raised_on','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','AssetsMaster.asset_name','id','status','company_ids'],
    					'conditions'=>['inquiry_type'=>'Asset'],
    					'contain'=>['SupplierOffer','AssetsMaster', 'OwnerCompanies','Uom', 'SupplierOffer.Uom','SupplierOffer.CompanyMaster', 'SupplierOffer.Currency' ],
    					'order'=>['SupplierInquiry.id' => 'DESC']
    			]
    			);
    	 
    	 
    	 
    	$supplierInquiry = $this->paginate($supplierinquires);
    	 
    	foreach ($supplierinquires as $ks=>$vals){
    		$companyMaster =  $this->SupplierInquiry->CompanyMaster->find('all',
    				array('fields'=>array('id','company_name')	,
    						'conditions'=>array('id IN '=> explode(",",$vals['company_ids']))
    				))->toArray();
    	
    				$vals['CompanyMaster']=$companyMaster;
    	}
    	$supplierinquires=$supplierinquires->toArray();
    	// echo '<pre>',print_r($supplierinquires);die;
    	$this->set(compact('supplierInquiry'));
    	$this->set('_serialize', ['supplierInquiry']);
    	
    	

    	 
    }
    
    /**
     * View method
     *
     * @param string|null $id Supplier Inquiry id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $supplierInquiry = $this->SupplierInquiry->get($id, [
        		
        		/* 'fields'=> ['status','reference_number','company_contact_persons','is_local','inquiry_type','raised_on','owner_companies_id','products_master_id','qty_required','company_ids',
        				'product_specifications','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no',
        				'packingMaster_id','validity_of_inquiry','company_ids','cc_email','comments',
        				'OwnerCompanies.Company_name','qty_required','Uom.unit_symbol','SelectedProductSpecs.transaction_id'
        		], */
        		'contain'=>['PurchaseRequisionInquiry','PurchaseRequisionInquiry.PurchaseRequisition','SupplierInquiryProducts','SupplierInquiryProducts.ProductsMaster','SupplierInquiryProducts.Uom','SupplierInquiryProducts.PackingMaster','SupplierInquiryProducts.PackingMaster.PackingType','SupplierOffer', 'OwnerCompanies','Uom', 'SupplierOffer.Uom','SupplierOffer.CompanyMaster', 'SupplierOffer.Currency' ],
          //  'contain' => ['ProductsMaster','OwnerCompanies', 'Uom', 'Currency', 'PackingMaster','PackingMaster.PackingType', 'SupplierOffer','SelectedProductSpecs']     
          ]);
        $companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
        $companyids=explode(",",$companyidsval);
        
        $companycontactIdval=isset($supplierInquiry['company_contact_persons'])?$supplierInquiry['company_contact_persons']:"";
        $companycontactIds=explode(",",$companycontactIdval);
        
      //echo '<pre>',print_r($supplierInquiry);die;
        $companyMaster =  $this->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->
        contain([
        		'CompanyContactPersons' => function ($q)use ($companycontactIds){
        		return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
        		},
        
        
        		]);
        $this->set('companyMaster', $companyMaster);

    
        $options = array(
        		'contain' => ['PackingType'],
        		'fields' => array('id','color','PackingType.packing_type','specification'),
        		'conditions' => array(
        				'PackingMaster.id ' => $supplierInquiry->packingMaster_id,
        		),
        );
        $packingMaster = $this->SupplierInquiry->PackingMaster->find('all', $options)->toArray();
        
        $this->set('packingMaster', $packingMaster);
        
        $this->set('supplierInquiry', $supplierInquiry);
        $this->set('_serialize', ['supplierInquiry']);
    }
    public function viewConsumable($id = null)
    {
    	$supplierInquiry = $this->SupplierInquiry->get($id, [
    	
    			/* 'fields'=> ['status','reference_number','company_contact_persons','is_local','inquiry_type','raised_on','owner_companies_id','products_master_id','qty_required','company_ids',
    			 'product_specifications','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no',
    					'packingMaster_id','validity_of_inquiry','company_ids','cc_email','comments',
    					'OwnerCompanies.Company_name','qty_required','Uom.unit_symbol','SelectedProductSpecs.transaction_id'
    			], */
    			'contain' => ['OwnerCompanies', 'Uom', 'Currency', 'PackingMaster','PackingMaster.PackingType', 'SupplierOffer','SelectedProductSpecs','SupplierInquiryProducts.ConsumablesMaster','SupplierInquiryProducts.Uom','SupplierInquiryProducts.PackingMaster','SupplierInquiryProducts.PackingMaster.PackingType']        ]);
    	$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    	$companyids=explode(",",$companyidsval);
    	
    	$companycontactIdval=isset($supplierInquiry['company_contact_persons'])?$supplierInquiry['company_contact_persons']:"";
    	$companycontactIds=explode(",",$companycontactIdval);
    	
    	//echo '<pre>',print_r($supplierInquiry);die;
    	$companyMaster =  $this->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->
    	contain([
    			'CompanyContactPersons' => function ($q)use ($companycontactIds){
    			return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
    			},
    	
    	
    			]);
    	$this->set('companyMaster', $companyMaster);

    	$options = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id ' => $supplierInquiry->packingMaster_id,
    			),
    	);
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('all', $options)->toArray();
    	
    	$this->set('packingMaster', $packingMaster);
    	
    	$this->set('supplierInquiry', $supplierInquiry);
    	$this->set('_serialize', ['supplierInquiry']);
    }
    public function viewAsset($id = null)
    {
    	$supplierInquiry = $this->SupplierInquiry->get($id, [
    			'contain' => ['FactoryQcequipment', 'OwnerCompanies', 'Uom', 'Currency']
    	]);
    	$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    	$companyids=explode(",",$companyidsval);
    	$companyMaster =  $this->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons']);
    	$this->set('companyMaster', $companyMaster);
    	
    	$this->set('supplierInquiry', $supplierInquiry);
    	$this->set('_serialize', ['supplierInquiry']);
    }
    public function viewpacking($id = null)
    {
    	$supplierInquiry = $this->SupplierInquiry->get($id, [
    			'fields'=> ['status','inquiry_type','raised_on','reference_number','owner_companies_id','products_master_id','qty_required','company_ids',
    					'PackingMaster.paking_type_id','PackingType.packing_type','PackingSubtype.sub_type','PackingMaster.specification','PackingMaster.description','PackingMaster.color',
    					'packingMaster_id','validity_of_inquiry','company_ids','cc_email','comments','is_local','company_contact_persons','Uom.unit_symbol',
    					'OwnerCompanies.Company_name'
    			],
    			'contain' => ['PackingMaster','PackingMaster.PackingType','PackingMaster.PackingSubtype','Uom','OwnerCompanies','CompanyMaster','CompanyContactPersons']
    	]);

    	$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    	$companyids=explode(",",$companyidsval);
    	$companyMaster =  $this->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons']);
    	$this->set('companyMaster', $companyMaster);
    	 
    	$this->set('supplierInquiry', $supplierInquiry);
    	$this->set('_serialize', ['supplierInquiry']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
    	
       // $supplierInquiry = $this->SupplierInquiry->newEntity();
        
        $supplierInquiry = $this->SupplierInquiry->newEntity($this->request->getData(),[
        		"associated"=>[
        				"SelectedProductSpecs"
        		]
        ]);
        
        if ($this->request->is('post')) {
        	$this->request->data['company_ids']='';
        	if(isset($this->request->data['company_id'])){
        		$ptr=0;
        		foreach ($this->request->data['company_id'] as $contact_id){
        			$this->request->data['company_ids'].=$ptr>0?",":"";
        			$this->request->data['company_ids'].=$contact_id;
        			$ptr++;
        		}
        	}
        	$this->request->data['company_contact_persons'] ='';
        	if(isset($this->request->data['company_contact_person'])){
        		$ptr=0;
        		foreach ($this->request->data['company_contact_person'] as $contact_id){
        			$this->request->data['company_contact_persons'].=$ptr>0?",":"";
        			$this->request->data['company_contact_persons'].=$contact_id;
        			$ptr++;
        		}
        	
        	}
        	//echo '<pre>',print_r($this->request->data);die;
        	 if(isset($this->request->data['selected_product_specs'])){
	        	 foreach ($this->request->data['selected_product_specs'] as $key=>&$det){
	        		//$det['test_id'] = trim($det['test_id']);
	        		//if($det['product_data_tests_id'] !== '' && $det['product_data_tests'] !== 0){
	        		//echo $det['product_data_tests_id'];die;	
	        	 	if($det['product_data_tests_id'] == '0'){
	        				unset($this->request->data['selected_product_specs'][$key]); 
	        			}
	        		//}
	        	}
        	 }
        	//debug($this->request->data);die;
        	 
        /*unset($this->request->data['test_request_det']); */
        	// die;
        	//$this->request->data['test_request_det'] = $details;
        	 
        	/* if(isset($details)){
        		$testId=implode(", ", $details);
        		$this->request->data['product_specifications'] = $testId;
        	}else{
        		unset($this->request->data['product_specifications']);
        	} */
        	
    		$this->loadModel('ReferenceNumberCounter');
    		$this->loadComponent('ReferenceNumber');
    		
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'sup_inq');
    		//echo '<pre>',print_r($next_ref);
    		$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
        	//echo '<pre>',print_r($supplierInquiry);
        //	die;
    		//echo '<pre>',print_r($this->request->data);
    		//die;
        	if(!isset($next_ref['full_next_ref_no'])){
        		//echo 'sdfsg';die;
        		$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Inquiry'));
        		//return $this->redirect(['action' => 'index']);
        	}else{
	            //$supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->data);
	            $supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->getData(),[
	            		"associated"=>[
	            				"SelectedProductSpecs"
	            		]
	            ]);
	            
	            
	            //debug($this->request->data);die;
	             
	            if ($this->SupplierInquiry->save($supplierInquiry)) {
	            	# To insert data in ReferenceNumberCounter table
	            	$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
	            	
	            	# End insert data in ReferenceNumberCounter table
	            	    
	            	
	                $this->Flash->success(__('The {0} has been saved.', 'Supplier Inquiry'));
	                return $this->redirect(['action' => 'index']);
	            } else {
	                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Inquiry'));
	            }
        	}
        }
       // $productsMaster = $this->SupplierInquiry->ProductsMaster->find('list', ['limit' => 200]);
    	$ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	//$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    	//$packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => array('specification'),'order'=>'specification'], ['limit' => 200]);
    	
    	//$packingMaster =  $this->SupplierInquiry->PackingMaster->find();
    	 
      
        $this->set(compact('supplierInquiry', 'ownerCompanies', 'uom','packingMaster'));
        $this->set('_serialize', ['supplierInquiry']);
    }
    public function addpacking()
    {
    	$supplierInquiry = $this->SupplierInquiry->newEntity();
    	if ($this->request->is('post')) {
    		
    		/* foreach ($this->request->data['supplier_inquiry'] as $key => $productDataCheck){
    			
    			$this->request->data["company_idsnewww"][]= $productDataCheck["company_ids"];
    		}
    		
    		$this->request->data["company_ids"]= implode(", ",$this->request->data["company_idsnewww"]);
    		 */
    		
    		$this->request->data['company_ids']='';
    		if(isset($this->request->data['company_id'])){
    			$ptr=0;
    			foreach ($this->request->data['company_id'] as $contact_id){
    				$this->request->data['company_ids'].=$ptr>0?",":"";
    				$this->request->data['company_ids'].=$contact_id;
    				$ptr++;
    			}
    		}
    		$this->request->data['company_contact_persons'] ='';
    		if(isset($this->request->data['company_contact_person'])){
    			$ptr=0;
    			foreach ($this->request->data['company_contact_person'] as $contact_id){
    				$this->request->data['company_contact_persons'].=$ptr>0?",":"";
    				$this->request->data['company_contact_persons'].=$contact_id;
    				$ptr++;
    			}
    		
    		}
    		$this->loadComponent('ReferenceNumber');
    		
    		//echo '<pre>',print_r($this->request->data); exit();
    		$this->loadModel('ReferenceNumberCounter');
    		
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'sup_inq');
    		$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    		
    		if(!isset($next_ref['full_next_ref_no'])){
    			//echo 'sdfsg';die;
    			$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Inquiry'));
    			//return $this->redirect(['action' => 'index']);
    		}else{
    		$supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->data);
    		
    		//echo '<pre>',print_r($this->request->data); exit();
    		if ($this->SupplierInquiry->save($supplierInquiry)) {
    			# To insert data in ReferenceNumberCounter table
    				
    			$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    			
    			# End insert data in ReferenceNumberCounter table
    			    
    			$this->Flash->success(__('The {0} has been saved.', 'Supplier Inquiry'));
    			return $this->redirect(['action' => 'index_packing']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Inquiry'));
    		}
    		}
    	}
    	$this->loadModel('PackingType');
    	$this->loadModel('PackingSubtype');
    	//$productsMaster = $this->SupplierInquiry->ProductsMaster->find('list', ['limit' => 200]);
    	$companyMaster = $this->SupplierInquiry->CompanyMaster->find('list',['valueField' => 'Company_name','order'=>'Company_name'] , ['limit' => 200]);
    	$ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$packingtype = $this->PackingType->find('list',['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type'], ['limit' => 200]);
    	$packingsubtype = $this->PackingSubtype->find('list',['keyField' => 'id','valueField' => 'sub_type'], ['limit' => 200]);
    	$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    	$this->set(compact('supplierInquiry','ownerCompanies', 'uom', 'currency', 'packingMaster','companyMaster','packingtype','packingsubtype'));
    	$this->set('_serialize', ['supplierInquiry']);
    }
    
    public function addconsumable()
    {
    	$supplierInquiry = $this->SupplierInquiry->newEntity($this->request->getData(),[
    			"associated"=>[
    					"SupplierInquiryProducts",
    			]]);
    	 
    	if ($this->request->is('post')) {
    		 
    		/* foreach ($this->request->data['supplier_inquiry'] as $key => $productDataCheck){
    
    		$this->request->data["company_idsnewww"][]= $productDataCheck["company_ids"];
    		}
    		 
    		$this->request->data["company_ids"]= implode(", ",$this->request->data["company_idsnewww"]);
    		*/
    		 
    		$this->request->data['company_ids']='';
    		if(isset($this->request->data['company_id'])){
    			$ptr=0;
    			foreach ($this->request->data['company_id'] as $contact_id){
    				$this->request->data['company_ids'].=$ptr>0?",":"";
    				$this->request->data['company_ids'].=$contact_id;
    				$ptr++;
    			}
    		}
    		$this->request->data['company_contact_persons'] ='';
    		if(isset($this->request->data['company_contact_person'])){
    			$ptr=0;
    			foreach ($this->request->data['company_contact_person'] as $contact_id){
    				$this->request->data['company_contact_persons'].=$ptr>0?",":"";
    				$this->request->data['company_contact_persons'].=$contact_id;
    				$ptr++;
    			}
    			 
    		}
    		$this->loadModel('ReferenceNumberCounter');
    		$this->loadComponent('ReferenceNumber');
    
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'sup_inq');
    		//echo '<pre>',print_r($next_ref);
    		$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    		if(!isset($next_ref['full_next_ref_no'])){
    			//echo 'sdfsg';die;
    			$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Inquiry'));
    			//return $this->redirect(['action' => 'index']);
    		}else{
    			$supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->data);
    			//debug($supplierInquiry);exit;
    			if ($this->SupplierInquiry->save($supplierInquiry)) {
    				# To insert data in ReferenceNumberCounter table
    				 
    				$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    
    				# End insert data in ReferenceNumberCounter table
    
    				$this->Flash->success(__('The {0} has been saved.', 'Supplier Inquiry'));
    				return $this->redirect(['action' => 'index_consumable']);
    			} else {
    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Inquiry'));
    			}
    		}
    	}
    	$ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name','conditions'=>array('id'=>$this->request->session()->read('Auth.User.owner_company_id'))], ['limit' => 200]);
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    
    	$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    	$this->set(compact('supplierInquiry','ownerCompanies', 'uom', 'currency','packingMaster'));
    	$this->set('_serialize', ['supplierInquiry']);
    	 
    	 
    }
    
    public function addasset()
    {
    	$supplierInquiry = $this->SupplierInquiry->newEntity();
    	if ($this->request->is('post')) {
    	
    		/* foreach ($this->request->data['supplier_inquiry'] as $key => $productDataCheck){
    		  
    		$this->request->data["company_idsnewww"][]= $productDataCheck["company_ids"];
    		}
    	
    		$this->request->data["company_ids"]= implode(", ",$this->request->data["company_idsnewww"]);
    		*/
    	
    		$this->request->data['company_ids']='';
    		if(isset($this->request->data['company_id'])){
    			$ptr=0;
    			foreach ($this->request->data['company_id'] as $contact_id){
    				$this->request->data['company_ids'].=$ptr>0?",":"";
    				$this->request->data['company_ids'].=$contact_id;
    				$ptr++;
    			}
    		}
    		$this->request->data['company_contact_persons'] ='';
    		if(isset($this->request->data['company_contact_person'])){
    			$ptr=0;
    			foreach ($this->request->data['company_contact_person'] as $contact_id){
    				$this->request->data['company_contact_persons'].=$ptr>0?",":"";
    				$this->request->data['company_contact_persons'].=$contact_id;
    				$ptr++;
    			}
    	
    		}
    		$this->loadModel('ReferenceNumberCounter');
    		$this->loadComponent('ReferenceNumber');
    		
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'sup_inq');
    		//echo '<pre>',print_r($next_ref);
    		$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    		
    		if(!isset($next_ref['full_next_ref_no'])){
    			//echo 'sdfsg';die;
    			$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Inquiry'));
    			//return $this->redirect(['action' => 'index']);
    		}else{
    			$supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->data);
    		
    			
    		
    		//echo '<pre>',print_r($this->request->data); exit();
    		if ($this->SupplierInquiry->save($supplierInquiry)) {
    			# To insert data in ReferenceNumberCounter table
    	
    			$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    			 
    			# End insert data in ReferenceNumberCounter table
    				
    			$this->Flash->success(__('The {0} has been saved.', 'Supplier Inquiry'));
    			return $this->redirect(['action' => 'index_asset']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Inquiry'));
    		}
    		}
    	}
    	$ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    	 
    	$this->set(compact('supplierInquiry','ownerCompanies', 'uom', 'currency','packingMaster'));
    	$this->set('_serialize', ['supplierInquiry']);
    	
    	
    }
    
    /**
     * Edit method
     *
     * @param string|null $id Supplier Inquiry id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $supplierInquiry = $this->SupplierInquiry->get($id, [
        	/* 'fields'=> ['status','inquiry_type','raised_on','uom_id','is_local','company_contact_persons','owner_companies_id','products_master_id','qty_required','company_ids',
        			'product_specifications','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no',
        			'packingMaster_id','validity_of_inquiry','company_ids','cc_email','comments'
        	], */
        		'contain' => ['OwnerCompanies','Uom','SupplierInquiryProducts','SupplierInquiryProducts.ProductsMaster','SupplierInquiryProducts.Uom','SupplierInquiryProducts.PackingMaster','SupplierInquiryProducts.PackingMaster.PackingType','PurchaseRequisition','PurchaseRequisition.PurchaseRequisitionProducts']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
        	
        	$this->request->data['company_ids']='';
        	if(isset($this->request->data['company_id'])){
        		$ptr=0;
        		foreach ($this->request->data['company_id'] as $contact_id){
        			$this->request->data['company_ids'].=$ptr>0?",":"";
        			$this->request->data['company_ids'].=$contact_id;
        			$ptr++;
        		}
        	}
        	$this->request->data['company_contact_persons'] ='';
        	if(isset($this->request->data['company_contact_person'])){
        		$ptr=0;
        		foreach ($this->request->data['company_contact_person'] as $contact_id){
        			$this->request->data['company_contact_persons'].=$ptr>0?",":"";
        			$this->request->data['company_contact_persons'].=$contact_id;
        			$ptr++;
        		}
        	
        	}
                	 if(isset($this->request->data['selected_product_specs'])){
	        	 foreach ($this->request->data['selected_product_specs'] as $key=>&$det){
	        	 	if($det['product_data_tests_id'] == '0'){
	        				unset($this->request->data['selected_product_specs'][$key]); 
	        			}
	        		//}
	        	}
        	 }
        	
        	 $this->loadModel('SelectedProductSpecs');
        	 $this->SelectedProductSpecs->deleteAll(
        	 		[
        	 				'SelectedProductSpecs.transaction_id' => $id,
        	 				'SelectedProductSpecs.type' => 'SUP_INQ'
        	 		]
        	 		);
        	 
        	 
        //	echo '<pre>',print_r($this->request->data);die;
        	$supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->getData(),[
        	]);
        	
           // $supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->data);
         // debug($supplierInquiry);die;
            if ($this->SupplierInquiry->save($supplierInquiry)) {
                $this->Flash->success(__('The {0} has been saved.', 'Supplier Inquiry'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Inquiry'));
            }
        }
        $companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
         
        $companyids=explode(",",$companyidsval);
        
        $companyMaster =  $this->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons']);
         
        $productsMaster = $this->SupplierInquiry->ProductsMaster->find('all',
        		
        		['fields'=>array('product_name','cas_no','grade_name'),
        		'conditions'=>['ProductsMaster.id' => $supplierInquiry->products_master_id],
        		//'order' => ['CompanyMaster.id' => 'ASC']
        ]);
        $this->loadModel('ProductDataTests');
        $productDataTest = $this->ProductDataTests->find('all', [
        		'conditions' => array('products_master_id' => $supplierInquiry->products_master_id ,'purpose LIKE'=> "%Purchase"),
        		'order' => ['ProductDataTests.id' => 'ASC']
        ]);
    	$ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    	//$packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    	$options = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id ' => $supplierInquiry->packingMaster_id,
    			),
    	);
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('all', $options)->toArray();
    	
    	
    	$this->set(compact('supplierInquiry','productDataTest', 'productsMaster', 'ownerCompanies', 'uom', 'currency', 'companyMaster','packingMaster'));
        $this->set('_serialize', ['supplierInquiry']);
    }
    public function editpacking($id = null)
    {
    	$supplierInquiry = $this->SupplierInquiry->get($id, [
    			/* 'fields'=> ['status','inquiry_type','raised_on','owner_companies_id','products_master_id','qty_required','company_ids',
    					'PackingMaster.paking_type_id','PackingMaster.packing_subtype_id','PackingMaster.specification','PackingMaster.description','PackingMaster.color',
    					'packingMaster_id','validity_of_inquiry','company_ids','cc_email','comments','is_local','company_contact_persons'
    			], */
    			
    			'contain' => ['PackingMaster','CompanyMaster','CompanyContactPersons']
    	]);
    	
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		
    		$this->request->data['company_ids']='';
    		if(isset($this->request->data['company_id'])){
    			$ptr=0;
    			foreach ($this->request->data['company_id'] as $contact_id){
    				$this->request->data['company_ids'].=$ptr>0?",":"";
    				$this->request->data['company_ids'].=$contact_id;
    				$ptr++;
    			}
    		}
    		$this->request->data['company_contact_persons'] ='';
    		if(isset($this->request->data['company_contact_person'])){
    			$ptr=0;
    			foreach ($this->request->data['company_contact_person'] as $contact_id){
    				$this->request->data['company_contact_persons'].=$ptr>0?",":"";
    				$this->request->data['company_contact_persons'].=$contact_id;
    				$ptr++;
    			}
    		
    		}
    		$supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->data);
    		//debug($supplierInquiry);exit;
    		if ($this->SupplierInquiry->save($supplierInquiry)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Supplier Inquiry'));
    			return $this->redirect(['action' => 'index_packing']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Inquiry'));
    		}
    	}
    	$this->loadModel('PackingType');
    	$this->loadModel('PackingSubtype');
    	$productsMaster = $this->SupplierInquiry->ProductsMaster->find('list', ['limit' => 200]);
    	
    	
    	//$supplierInquiry=$this->request->data["SupplierInquiry"];
    	
    	$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    	
    	$companyids=explode(",",$companyidsval);
        
    	$companyMaster =  $this->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons']);
    	
    	$ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$packingtype = $this->PackingType->find('list',['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type'], ['limit' => 200]);
    	$packingsubtype = $this->PackingSubtype->find('list',['keyField' => 'id','valueField' => 'sub_type'], ['limit' => 200]);
    	$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    	$this->set(compact('companycontactPersons','supplierInquiry', 'productsMaster', 'ownerCompanies', 'uom', 'currency', 'packingMaster','companyMaster','packingtype','packingsubtype'));
    	$this->set('_serialize', ['supplierInquiry']);
    }
    public function editasset($id = null)
    {
    	$supplierInquiry = $this->SupplierInquiry->get($id, [
    			 
    			'contain' => ['PackingMaster','CompanyMaster','CompanyContactPersons']
    	]);
    	 
    	if ($this->request->is(['patch', 'post', 'put'])) {
    
    		$this->request->data['company_ids']='';
    		if(isset($this->request->data['company_id'])){
    			$ptr=0;
    			foreach ($this->request->data['company_id'] as $contact_id){
    				$this->request->data['company_ids'].=$ptr>0?",":"";
    				$this->request->data['company_ids'].=$contact_id;
    				$ptr++;
    			}
    		}
    		$this->request->data['company_contact_persons'] ='';
    		if(isset($this->request->data['company_contact_person'])){
    			$ptr=0;
    			foreach ($this->request->data['company_contact_person'] as $contact_id){
    				$this->request->data['company_contact_persons'].=$ptr>0?",":"";
    				$this->request->data['company_contact_persons'].=$contact_id;
    				$ptr++;
    			}
    
    		}
    		$supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->data);
    
    		if ($this->SupplierInquiry->save($supplierInquiry)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Supplier Inquiry'));
    			return $this->redirect(['action' => 'index_asset']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Inquiry'));
    		}
    	}
    	$this->loadModel('FactoryQcequipment');
    	// echo $supplierInquiry['product_id'];
    	$productsMaster = $this->FactoryQcequipment->find()->where(['id'  => $supplierInquiry['products_master_id']]);
    	 
    	 //echo '<pre>',print_r($productsMaster);die;
    	//$supplierInquiry=$this->request->data["SupplierInquiry"];
    	 
    	$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    	 
    	$companyids=explode(",",$companyidsval);
    
    	$companyMaster =  $this->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons']);
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    	$ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    	$this->set(compact('companycontactPersons','supplierInquiry', 'productsMaster', 'ownerCompanies', 'uom', 'currency', 'packingMaster','companyMaster'));
    	$this->set('_serialize', ['supplierInquiry']);
    }
    public function editconsumable($id = null)
    {
    
    	$supplierInquiry = $this->SupplierInquiry->get($id, [
    			/* 'fields'=> ['status','inquiry_type','raised_on','uom_id','is_local','company_contact_persons','owner_companies_id','products_master_id','qty_required','company_ids',
    			 'product_specifications','ProductsMaster.product_name','ProductsMaster.grade_name','ProductsMaster.cas_no',
    					'packingMaster_id','validity_of_inquiry','company_ids','cc_email','comments'
    			], */
    			'contain' => ['Uom','SupplierInquiryProducts','SupplierInquiryProducts.ConsumablesMaster','SupplierInquiryProducts.Uom','SupplierInquiryProducts.PackingMaster','SupplierInquiryProducts.PackingMaster.PackingType','PurchaseRequisition','PurchaseRequisition.PurchaseRequisitionProducts','PurchaseRequisition.PurchaseRequisitionProducts.ConsumablesMaster','PurchaseRequisition.PurchaseRequisitionProducts.Uom']
    	]);
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		 
    		$this->request->data['company_ids']='';
    		if(isset($this->request->data['company_id'])){
    			$ptr=0;
    			foreach ($this->request->data['company_id'] as $contact_id){
    				$this->request->data['company_ids'].=$ptr>0?",":"";
    				$this->request->data['company_ids'].=$contact_id;
    				$ptr++;
    			}
    		}
    		$this->request->data['company_contact_persons'] ='';
    		if(isset($this->request->data['company_contact_person'])){
    			$ptr=0;
    			foreach ($this->request->data['company_contact_person'] as $contact_id){
    				$this->request->data['company_contact_persons'].=$ptr>0?",":"";
    				$this->request->data['company_contact_persons'].=$contact_id;
    				$ptr++;
    			}
    
    		}

    		$supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->getData(),[
    				"associated"=>[
    						"SupplierInquiryProducts"
    				]
    		]);
    		 
    		// $supplierInquiry = $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->data);
    		 //debug($supplierInquiry);die;
    		if ($this->SupplierInquiry->save($supplierInquiry)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Supplier Inquiry'));
    			return $this->redirect(['action' => 'index-consumable']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Inquiry'));
    		}
    		
    	}
    	$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    
    	$companyids=explode(",",$companyidsval);
    	 
    	$companyMaster =  $this->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons']);
    
    	$productsMaster = $this->SupplierInquiry->ProductsMaster->find('all',
    			 
    			['fields'=>array('product_name','cas_no','grade_name'),
    					'conditions'=>['ProductsMaster.id' => $supplierInquiry->products_master_id],
    					//'order' => ['CompanyMaster.id' => 'ASC']
    			]);
    	$this->loadModel('ProductDataTests');
    	$productDataTest = $this->ProductDataTests->find('all', [
    			'conditions' => array('products_master_id' => $supplierInquiry->products_master_id ,'purpose LIKE'=> "%Purchase"),
    			'order' => ['ProductDataTests.id' => 'ASC']
    	]);
    	$ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name','conditions'=>array('id'=>$this->request->session()->read('Auth.User.owner_company_id'))], ['limit' => 200]);
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    	//$packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    	$options = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id ' => $supplierInquiry->packingMaster_id,
    			),
    	);
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('all', $options)->toArray();
    
    
    	$this->set(compact('supplierInquiry','productDataTest', 'productsMaster', 'ownerCompanies', 'uom', 'currency', 'companyMaster','packingMaster'));
    	$this->set('_serialize', ['supplierInquiry']);
    }
    /**
     * Delete method
     *
     * @param string|null $id Supplier Inquiry id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null,$module=null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $supplierInquiry = $this->SupplierInquiry->get($id);
        if ($this->SupplierInquiry->delete($supplierInquiry)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Supplier Inquiry'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Supplier Inquiry'));
        }
        if($module == "packing"){
        	return $this->redirect(['action' => 'index-packing']);
        }elseif($module == "chemical"){
        	return $this->redirect(['action' => 'index']);
        }
        elseif($module == "consumable"){
        	return $this->redirect(['action' => 'index-consumable']);
        }
        elseif($module == "assets"){
        	return $this->redirect(['action' => 'index-asset']);
        }
        else{
        	return $this->redirect(['action' => 'index']);
        }
       
    }
    public function sendmailPacking($module=null,$supplierInquiryid = null,$compId=null,$isView=null){
    	
    				
    	if($isView==="1"){
    		$supplierinquires = $this->SupplierInquiry->get($supplierInquiryid, [
    				/* 'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','id','status','company_ids',
    								'PackingType.packing_type','PackingMaster.specification','PackingMaster.description','PackingMaster.color'
    		
    		
    					], */
    				'contain' => ['OwnerCompanies','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerContactPersons.Users', 'Uom', 'Currency', 'PackingMaster', 'PackingMaster.PackingType','PackingMaster.PackingSubtype']
    		]);
    		 
    		$html="supplierenquirypacking";
    		$SupplierInquiry = $supplierinquires;
    		$Uom = $supplierinquires['uom'];
    		$PackingMaster = $supplierinquires['packing_master'];
    		$PackingType = $PackingMaster['packing_type'];
    		$PackingSubtype = $PackingMaster['packing_subtype'];
    		$OwnerCompany=$supplierinquires['owner_company'];
    			
    		//debug($OwnerCompany);die();
    		$this->loadModel('CompanyMaster');
    		$this->loadModel('CompanyContactPersons');
    		$companyOne =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $compId])->contain(['CompanyContactPersons']);
    		$CompanyMaster = $companyOne->first();
    			
    		$suppliercontact = "";
    		$supplieremail = array();
    		$vpercount=0;
    		foreach ($CompanyMaster["company_contact_persons"] as $contact["CompanyContactPerson"]){
    			$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
    					ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
    					ucfirst($contact["CompanyContactPerson"]["last_name"]);
    					if(trim($personname," ")!=""){
    						$suppliercontact.=$vpercount>0?",":"";
    						$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
    						$vpercount++;
    					}
    						
    					$contactemail=$contact["CompanyContactPerson"]["email_id"];
    						
    					if(trim($contactemail," ")!=""){
    						array_push($supplieremail, $contactemail);
    					}else{
    						$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
    						return false;
    					}
    		}
    		
    		//debug($CompanyMaster);exit;
    		$CompanyMaster["contact_persons"]=$suppliercontact;
    			
    		 
    		$this->set(compact('CompanyContactPersons','CompanyMaster','OwnerCompany','SupplierInquiry','Uom','supplierinquires','PackingMaster','PackingType','PackingSubtype'));
    		$Subject = 'Supplier Inquiry from '.$OwnerCompany->Company_name;
    		
    		
    		
    		$cc[]=$SupplierInquiry["cc_email"];
    		$to = array();
    		$cc = array();
    		$bcc=array();
    		if(Configure::read("productionMode")){
    			/*******Production Mode*******************/
    			$to=$contactemail;
    			$cc=array($supplierinquires['cc_email']);
    			$bcc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    		}else{
    			/*******Dev Mode*******************/
    			$to=$contactemail;
    			$cc=array("devendra.vastrakar@pitonsystems.com");
    			$bcc=array("dkvastrakar18@gmail.com");
    			/**************************/
    		}
    		//echo '<pre>',print_r($supplierinquires);
    		if($isView==="1"){
    			/*******Email Preview Mode*******************/
    			  
    			/*******For local*******************/
    			 
    			$this->set("isView",$isView);
    			$this->set("mails",array(
    					"from"=>$supplierinquires->owner_company->company_email,
    					"to" =>$to,
    					"cc" => $cc,
    					"bcc"=> $bcc,
    					"subject"=>$Subject
    			));
    			 
    			/**************************/
    			 
    		
    			$this->set("title_for_layout","Suppiler Inquiry");
    			$this->set(	"mailSendAction",array(
    					"send"=>array("action"=>"sendmail",$module,$supplierinquires->id,"false"),
    					"cancel"=>array("action"=>"index-packing")
    			));
    			 
    			//$this->layout = 'emailpreview';
    			 
    			$this->viewBuilder()->setLayout("/Email/html/emailpreview");
    			$this->render('/Email/html/'.$html);
    			/**************************/
    		}
    		
    	}
    	else{
    		
    	    $supplierinc = $this->SupplierInquiry->get($supplierInquiryid, [
	    			'contain' => ['OwnerCompanies','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerContactPersons.Users', 'Uom', 'Currency', 'PackingMaster', 'PackingMaster.PackingType','PackingMaster.PackingSubtype']
	    	])->toArray();
	    	
	    	$supplierInquiry=$supplierinc;
	    	$supplierinc[0]['PackingMaster']=$supplierinc['packing_master'];
	    	$supplierinc[0]['PackingSubtype']=$supplierinc['packing_master']['packing_subtype'];
	    	$supplierinc[0]['PackingType']=$supplierinc['packing_master']['packing_type'];
	    	$supplierinc[0]['OwnerCompany']=$supplierinc['owner_company'];
	    	$supplierinc[0]['Uom']=$supplierinc['uom'];
	    	$supplierinc[0]['SupplierInquiry']=$supplierinc;
    	
    	$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    	$companyids=explode(",",$companyidsval);
    	$companypersons=isset($supplierInquiry['company_contact_persons'])?
    	explode(",",$supplierInquiry['company_contact_persons']): array();
    	
    	
    	
    	$this->loadModel('CompanyMaster');
    	$this->loadModel('CompanyContactPerson');

    	$supplierCompanies =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons'])->toArray();
    	$supplierinc[0]["CompanyMaster"]=$supplierCompanies;
    	//debug($supplierinc);exit;
    	foreach ($supplierCompanies as $supplier){
    		$comapnyName=$supplier["Company_name"];
    		
    		$supplieremail=array();
    		foreach ($supplier["company_contact_persons"] as $contact["CompanyContactPerson"]){
    			$contactemail=$contact["CompanyContactPerson"]["email_id"];
    			
    			if(trim($contactemail," ")!=""){
    				array_push($supplieremail, $contactemail);
    			}else{
    				$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email for Supplier company '".$comapnyName."' .");
    				if($isredirect){
    					$this->redirect(array("action"=>"edit",$id));
    				}else return false;
    			}
    		}
    		if(count($supplieremail)==0){
    			$this->Flash->error("Please select atleast one contact for Supplier company '$comapnyName'.");
    			if($isredirect){
    				$this->redirect(array("action"=>"edit",$id));
    			}else return false;
    		}
    	}
    	
    	/**********************************************************************/

    	$supplierinquires = $this->SupplierInquiry->get($supplierInquiryid, [
    			'contain' => ['OwnerCompanies', 'Uom', 'Currency', 'PackingMaster', 'PackingMaster.PackingType','PackingMaster.PackingSubtype']
    	]);
    	
    	
    	$this->set(compact('isView','supplierinquires','comapnyName','productDataTest','productTestData','companyMaster', 'ownerCompanies', 'productsMasters'));
    	//echo "<pre>",print_r($comapnyName);exit;
    	
    	$emailvar=$supplierinc[0];

    	$ret=false;
    	$companyname = $supplierinc['owner_company']['Company_name'];
    	
    	if($this->doSendMail_packing($emailvar,$isView)){
    	
    		$this->request->data['status'] = '1';
    		//echo "<pre>",print_r($supplierinc[0]['SupplierInquiry']);exit;
    		//echo "<pre>",print_r($supplierinc[0]['SupplierInquiry']);exit;
    		$supplierinquirysave = $this->SupplierInquiry->patchEntity($supplierinquires, $this->request->data);
    		$this->SupplierInquiry->save($supplierinquirysave);
    		
    		$this->Flash->success(__('The {0} has been sent successfully.', "Supplier Inquiry for $companyname"));
    		return $this->redirect(['action' => 'index-packing']);
    		$ret=true;
    	}else {
    			$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "Supplier Inquiry for  $companyname"));
    		}
    	/* if($isView !== "1"){
    		//	return $this->redirect(array("action"=>"index"));
    	}
    	return $ret; */
    		exit;
    	}
    }
    
    
    private function doSendMail_packing($supplierinc,$isView=null){
    	try{
    		//$settings=$supplierinc["OwnerCompany"]["email_setting"];
    		$companyname=$supplierinc["OwnerCompany"]["Company_name"];
    		$fromid=$supplierinc["OwnerCompany"]["company_email"];
    		$Subject = 'Supplier Inquiry from '.$companyname;
    		if(trim($supplierinc["SupplierInquiry"]["cc_email"]," ")!=""){
    			$cc[]=$supplierinc["SupplierInquiry"]["cc_email"];
    			
    		}
    		$suppliercompanies=$supplierinc["CompanyMaster"];
    		
    		foreach($suppliercompanies as $company){
    			
    			$supplierinc["CompanyMaster"]=$company;
    			$comapnyName=$company["Company_name"];
    			//debug($comapnyName);exit;
    			$suppliercontact = "";
    			$supplieremail = array();
    			$vpercount=0;
    			// for dynamic contacts//
    			foreach ($company["company_contact_persons"] as $contact["CompanyContactPerson"]){
    				$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
    						ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
    						ucfirst($contact["CompanyContactPerson"]["last_name"]);
    						if(trim($personname," ")!=""){
    							$suppliercontact.=$vpercount>0?",":"";
    							$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
    							$vpercount++;
    						}
    
    						$contactemail=$contact["CompanyContactPerson"]["email_id"];
    						
    						if(trim($contactemail," ")!=""){
    							array_push($supplieremail, $contactemail);
    						}else{
    							$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
    							return false;
    						}
    			}
    			
    			$supplierinc["CompanyMaster"]["contact_persons"]=$suppliercontact;
    			$supplierinc["SupplierInquiry"]["mailto"]=$supplieremail;
    
    			$supplierinc["isView"]=$isView;
    			
    			$to = array();
    			$cc = array();
    			$bcc=array();
    			if(Configure::read("productionMode")){
    				/*******Production Mode*******************/
    				$to=$contactemail;
    				$cc=$cc;
    				$bcc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    			}else{
    				/*******Dev Mode*******************/
    				$to=$contactemail;
    				$cc=$cc;
    				$bcc=array("dkvastrakar18@gmail.com");
    				/**************************/
    			}
    			
    
    			/***************tester end*******************/
    			
    				 
    				$email = new Email('default');
    				$email
    				//->setTransport($name)
    				->template("supplierenquirypacking","supplierenquirypacking")
    				->from($fromid)
    				->to($contactemail)
    				->cc($cc)
    				->subject($Subject)
    				->emailFormat('html')
    				->viewVars($supplierinc);
    				$email->send();

    		}
    
    
    		return true;
    	}catch(Exception $e){
    		echo $e->getMessage();
    
    		exit("Error : on send email in ");
    		return false;
    	}
    }
    
    
    public function sendmailChemical($module=null,$supplierInquiryid = null,$compId=null,$isView=null){
    	 
    	if($isView==="1"){
    		$supplierinquires = $this->SupplierInquiry->get($supplierInquiryid, [
    				'contain' => ['OwnerCompanies','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerContactPersons.Users', 'Uom', 'Currency', 'PackingMaster', 'PackingMaster.PackingType','PackingMaster.PackingSubtype','ProductsMaster','SelectedProductSpecs']
    		]);
    		 
    		$html="supplierenquirychemprod";
    		$SupplierInquiry = $supplierinquires;
    		$Uom = $supplierinquires['uom'];
    		$PackingMaster = $supplierinquires['packing_master'];
    		$PackingType = $PackingMaster['packing_type'];
    		$PackingSubtype = $PackingMaster['packing_subtype'];
    		$OwnerCompany=$supplierinquires['owner_company'];
    		 
    		//debug($OwnerCompany);die();
    		$this->loadModel('CompanyMaster');
    		$this->loadModel('CompanyContactPersons');
    		$companyOne =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $compId])->contain(['CompanyContactPersons']);
    		$CompanyMaster = $companyOne->first();
    		 
    		$suppliercontact = "";
    		$supplieremail = array();
    		$vpercount=0;
    		foreach ($CompanyMaster["company_contact_persons"] as $contact["CompanyContactPerson"]){
    			$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
    					ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
    					ucfirst($contact["CompanyContactPerson"]["last_name"]);
    					if(trim($personname," ")!=""){
    						$suppliercontact.=$vpercount>0?",":"";
    						$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
    						$vpercount++;
    					}
    
    					$contactemail=$contact["CompanyContactPerson"]["email_id"];
    
    					if(trim($contactemail," ")!=""){
    						array_push($supplieremail, $contactemail);
    					}else{
    						//$this->Flash->error(__("Please check email_id for contact_name is not valid email."));
    						
    						$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
	                		//return $this->redirect(['action' => 'index']);
    					}
    		}
    
    		//debug($CompanyMaster);exit;
    		$CompanyMaster["contact_persons"]=$suppliercontact;
    		
    		//$producttestdataid=$supplierinquires['product_specifications'];
    		/* $this->loadModel('ProductDataTests');
    		
    		$productTestData =  $this->ProductDataTests->find()->where(['id IN' => explode(",",$producttestdataid)])->toArray();
 */
    		foreach($SupplierInquiry['selected_product_specs'] as $pk=>$pv){
    			$arrdetails[]=$pv['product_data_tests_id'];
    		}
    		$producttestids=implode(", ", $arrdetails);
    		$this->loadModel('ProductDataTests');
    		$productTestData =  $this->ProductDataTests->find()->where(['id IN' => explode(",",$producttestids)])->toArray();
    		$this->set('ProductDataTest', $productTestData);
    		
    		
    		
    		 
    		$this->set(compact('CompanyContactPersons','CompanyMaster','OwnerCompany','SupplierInquiry','Uom','supplierinquires','PackingMaster','PackingType','PackingSubtype'));
    		$Subject = 'Supplier Inquiry from '.$OwnerCompany->Company_name;
    
    
    
    		$cc[]=$SupplierInquiry["cc_email"];
    		$to = array();
    		$cc = array();
    		$bcc=array();
    		if(Configure::read("productionMode")){
    			/*******Production Mode*******************/
    			$to=$contactemail;
    			$cc=array($SupplierInquiry['cc_email']);
    			//$bcc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    		}else{
    			/*******Dev Mode*******************/
    			$to=$contactemail;
    			$cc=array($SupplierInquiry['cc_email']);
    			$bcc=array("dkvastrakar18@gmail.com");
    			/**************************/
    		}
    		//echo '<pre>',print_r($supplierinquires);
    		if($isView==="1"){
    			/*******Email Preview Mode*******************/
    			 	
    			/*******For local*******************/
    
    			$this->set("isView",$isView);
    			$this->set("mails",array(
    					"from"=>$supplierinquires->owner_company->company_email,
    					"to" =>$to,
    					"cc" => $cc,
    					"bcc"=> $bcc,
    					"subject"=>$Subject
    			));
    
    			/**************************/
    
    
    			$this->set("title_for_layout","Suppiler Inquiry");
    			$this->set(	"mailSendAction",array(
    					"send"=>array("action"=>"sendmail",$module,$supplierinquires->id,"false"),
    					"cancel"=>array("action"=>"index")
    			));
    
    			//$this->layout = 'emailpreview';
    
    			$this->viewBuilder()->setLayout("/Email/html/emailpreview");
    			$this->render('/Email/html/'.$html);
    			/**************************/
    		}
    
    	}
    	else{
    
    		$supplierinc = $this->SupplierInquiry->get($supplierInquiryid, [
    				'contain' => ['OwnerCompanies','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerContactPersons.Users', 'Uom', 'Currency', 'PackingMaster', 'PackingMaster.PackingType','PackingMaster.PackingSubtype','ProductsMaster']
    		])->toArray();
    
    		$supplierInquiry=$supplierinc;
    		$supplierinc[0]['PackingMaster']=$supplierinc['packing_master'];
    		$supplierinc[0]['PackingSubtype']=$supplierinc['packing_master']['packing_subtype'];
    		$supplierinc[0]['PackingType']=$supplierinc['packing_master']['packing_type'];
    		$supplierinc[0]['OwnerCompany']=$supplierinc['owner_company'];
    		$supplierinc[0]['Uom']=$supplierinc['uom'];
    		$supplierinc[0]['SupplierInquiry']=$supplierinc;
    		 
    		$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    		$companyids=explode(",",$companyidsval);
    		$companypersons=isset($supplierInquiry['company_contact_persons'])?
    		explode(",",$supplierInquiry['company_contact_persons']): array();
    		 
    		 
    		 
    		$this->loadModel('CompanyMaster');
    		$this->loadModel('CompanyContactPerson');
    
    		$supplierCompanies =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons'])->toArray();
    		$supplierinc[0]["CompanyMaster"]=$supplierCompanies;
    		//debug($supplierinc);exit;
    		foreach ($supplierCompanies as $supplier){
    			$comapnyName=$supplier["Company_name"];
    
    			$supplieremail=array();
    			foreach ($supplier["company_contact_persons"] as $contact["CompanyContactPerson"]){
    				$contactemail=$contact["CompanyContactPerson"]["email_id"];
    				 
    				if(trim($contactemail," ")!=""){
    					array_push($supplieremail, $contactemail);
    				}else{
    				//	echo 'pppp';die;
    					//$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email for Supplier company '".$comapnyName."' .");
    					$this->Flash->error("Please check email_id '$contactemail' for contact_name ","Supplier Inquiry");
    					//return $this->redirect(array("action"=>"edit",$supplierInquiryid));
    					
    					//$this->redirect(array("action"=>"index"));
    				}
    			}
    			if(count($supplieremail)==0){
    				$this->Flash->error("Please select atleast one contact for Supplier company","Supplier Inquiry");
    				if($isredirect){
    					$this->redirect(array("action"=>"edit",$supplierInquiryid));
    				}else return false;
    			}
    		}
    		 
    		/**********************************************************************/
    
    		$supplierinquires = $this->SupplierInquiry->get($supplierInquiryid, [
    				'contain' => ['OwnerCompanies', 'Uom', 'Currency', 'PackingMaster', 'PackingMaster.PackingType','PackingMaster.PackingSubtype']
    		]);
    		
    		$producttestdataid=$supplierinquires['product_specifications'];
    		$this->loadModel('ProductDataTests');
    		
    		$ProductDataTest =  $this->ProductDataTests->find()->where(['id IN' => explode(",",$producttestdataid)])->toArray();
    		 
    		//debug($productTestData);exit;
    		$this->set(compact('ProductDataTest','isView','supplierinquires','comapnyName','productDataTest','productTestData','companyMaster', 'ownerCompanies', 'productsMasters'));
    		//echo "<pre>",print_r($comapnyName);exit;
    		 
    		$emailvar=$supplierinc[0];
    
    		$ret=false;
    		$companyname = $supplierinc['owner_company']['Company_name'];
    		 
    		if($this->doSendMail_Chemical($emailvar,$isView,$ProductDataTest)){
    			 
    			$this->request->data['status'] = '1';
    			//echo "<pre>",print_r($supplierinc[0]['SupplierInquiry']);exit;
    			//echo "<pre>",print_r($supplierinc[0]['SupplierInquiry']);exit;
    			$supplierinquirysave = $this->SupplierInquiry->patchEntity($supplierinquires, $this->request->data);
    			$this->SupplierInquiry->save($supplierinquirysave);
    
    			$this->Flash->success(__('The {0} has been sent successfully.', "Supplier Inquiry for $companyname"));
    			return $this->redirect(['action' => 'index']);
    			$ret=true;
    		}else {
    			$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "Supplier Inquiry for  $companyname"));
    		}
    		/* if($isView !== "1"){
    		 //	return $this->redirect(array("action"=>"index"));
    		 }
    		 return $ret; */
    		exit;
    	}
    }
    
    
    private function doSendMail_Chemical($supplierinc,$isView=null,$ProductDataTest){
    	try{
    		//debug($ProductDataTest);exit;
    		//$settings=$supplierinc["OwnerCompany"]["email_setting"];
    		$companyname=$supplierinc["OwnerCompany"]["Company_name"];
    		$fromid=$supplierinc["OwnerCompany"]["company_email"];
    		$Subject = 'Supplier Inquiry from '.$companyname;
    		if(trim($supplierinc["SupplierInquiry"]["cc_email"]," ")!=""){
    			$cc[]=$supplierinc["SupplierInquiry"]["cc_email"];
    			 
    		}
    		$suppliercompanies=$supplierinc["CompanyMaster"];
    
    		foreach($suppliercompanies as $company){
    			 
    			$supplierinc["CompanyMaster"]=$company;
    			$comapnyName=$company["Company_name"];
    			//debug($comapnyName);exit;
    			$suppliercontact = "";
    			$supplieremail = array();
    			$vpercount=0;
    			// for dynamic contacts//
    			foreach ($company["company_contact_persons"] as $contact["CompanyContactPerson"]){
    				$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
    						ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
    						ucfirst($contact["CompanyContactPerson"]["last_name"]);
    						if(trim($personname," ")!=""){
    							$suppliercontact.=$vpercount>0?",":"";
    							$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
    							$vpercount++;
    						}
    
    						$contactemail=$contact["CompanyContactPerson"]["email_id"];
    
    						if(trim($contactemail," ")!=""){
    							array_push($supplieremail, $contactemail);
    						}else{
    							$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
    							return false;
    						}
    			}
    			 
    			$supplierinc["CompanyMaster"]["contact_persons"]=$suppliercontact;
    			$supplierinc["SupplierInquiry"]["mailto"]=$supplieremail;
    
    			$supplierinc["isView"]=$isView;
    			
    		    $supplierinc["ProductDataTest"]=$ProductDataTest;
    		    //debug($ProductDataTest);exit;

    			$to = array();
    			$cc = array();
    			$bcc=array();
    			if(Configure::read("productionMode")){
    				/*******Production Mode*******************/
    				$to=$contactemail;
    				$cc=$cc;
    				$bcc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    			}else{
    				/*******Dev Mode*******************/
    				$to=$contactemail;
    				$cc=$cc;
    				$bcc=array("dkvastrakar18@gmail.com");
    				/**************************/
    			}
    			 
    
    			/***************tester end*******************/
    			 
    				
    			$email = new Email('default');
    			$email
    			//->setTransport($name)
    			->template("supplierenquirychemprod","supplierenquirychemprod")
    			->from($fromid)
    			->to($contactemail)
    			->cc($cc)
    			->subject($Subject)
    			->emailFormat('html')
    			->viewVars($supplierinc);
    			$email->send();
    
    		}
    
    
    		return true;
    	}catch(Exception $e){
    		echo $e->getMessage();
    
    		exit("Error : on send email in ");
    		return false;
    	}
    }
    
    
    public function sendmailConsumable($module=null,$supplierInquiryid = null,$compId=null,$isView=null){
    
    	if($isView==="1"){
    		$supplierinquires = $this->SupplierInquiry->get($supplierInquiryid, [
    				'contain' => ['SupplierInquiryProducts','SupplierInquiryProducts.ConsumablesMaster','SupplierInquiryProducts.Uom','SupplierInquiryProducts.PackingMaster','SupplierInquiryProducts.PackingMaster.PackingType','OwnerCompanies','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerContactPersons.Users', 'ProductsMaster']
    		]);
    		 
    		$html="supplierenquiryconsumable";
    		$SupplierInquiry = $supplierinquires;
    		$Uom = $supplierinquires['uom'];
    		$PackingMaster = $supplierinquires['packing_master'];
    		$PackingType = $PackingMaster['packing_type'];
    		$PackingSubtype = $PackingMaster['packing_subtype'];
    		$OwnerCompany=$supplierinquires['owner_company'];
    		 
    		//debug($OwnerCompany);die();
    		$this->loadModel('CompanyMaster');
    		$this->loadModel('CompanyContactPersons');
    		$companyOne =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $compId])->contain(['CompanyContactPersons']);
    		$CompanyMaster = $companyOne->first();
    		 
    		$suppliercontact = "";
    		$supplieremail = array();
    		$vpercount=0;
    		foreach ($CompanyMaster["company_contact_persons"] as $contact["CompanyContactPerson"]){
    			$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
    					ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
    					ucfirst($contact["CompanyContactPerson"]["last_name"]);
    					if(trim($personname," ")!=""){
    						$suppliercontact.=$vpercount>0?",":"";
    						$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
    						$vpercount++;
    					}
    
    					$contactemail=$contact["CompanyContactPerson"]["email_id"];
    
    					if(trim($contactemail," ")!=""){
    						array_push($supplieremail, $contactemail);
    					}else{
    						//$this->Flash->error(__("Please check email_id for contact_name is not valid email."));
    
    						$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
    						//return $this->redirect(['action' => 'index']);
    					}
    		}
    
    		//debug($CompanyMaster);exit;
    		$CompanyMaster["contact_persons"]=$suppliercontact;
    
    
    
    
    		 
    		$this->set(compact('CompanyContactPersons','CompanyMaster','OwnerCompany','SupplierInquiry','Uom','supplierinquires','PackingMaster','PackingType','PackingSubtype'));
    		$Subject = 'Supplier Inquiry from '.$OwnerCompany->Company_name;
    
    
    
    		$cc[]=$SupplierInquiry["cc_email"];
    		$to = array();
    		$cc = array();
    		$bcc=array();
    		if(Configure::read("productionMode")){
    			/*******Production Mode*******************/
    			$to=$contactemail;
    			$cc=array($SupplierInquiry['cc_email']);
    			//$bcc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    		}else{
    			/*******Dev Mode*******************/
    			$to=$contactemail;
    			$cc=array($SupplierInquiry['cc_email']);
    			$bcc=array("dkvastrakar18@gmail.com");
    			/**************************/
    		}
    		//echo '<pre>',print_r($supplierinquires);
    		if($isView==="1"){
    			/*******Email Preview Mode*******************/
    			 	
    			/*******For local*******************/
    
    			$this->set("isView",$isView);
    			$this->set("mails",array(
    					"from"=>$supplierinquires->owner_company->company_email,
    					"to" =>$to,
    					"cc" => $cc,
    					"bcc"=> $bcc,
    					"subject"=>$Subject
    			));
    
    			/**************************/
    
    
    			$this->set("title_for_layout","Suppiler Inquiry");
    			$this->set(	"mailSendAction",array(
    					"send"=>array("action"=>"sendmail_consumable",$module,$supplierinquires->id,"false"),
    					"cancel"=>array("action"=>"index-consumable")
    			));
    
    			//$this->layout = 'emailpreview';
    
    			$this->viewBuilder()->setLayout("/Email/html/emailpreview");
    			$this->render('/Email/html/'.$html);
    			/**************************/
    		}
    
    	}
    	else{
    
    		$supplierinc = $this->SupplierInquiry->get($supplierInquiryid, [
    				'contain' => ['OwnerCompanies','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerContactPersons.Users', 'Uom', 'Currency', 'PackingMaster', 'PackingMaster.PackingType','PackingMaster.PackingSubtype','ProductsMaster']
    		])->toArray();
    
    		$supplierInquiry=$supplierinc;
    		$supplierinc[0]['PackingMaster']=$supplierinc['packing_master'];
    		$supplierinc[0]['PackingSubtype']=$supplierinc['packing_master']['packing_subtype'];
    		$supplierinc[0]['PackingType']=$supplierinc['packing_master']['packing_type'];
    		$supplierinc[0]['OwnerCompany']=$supplierinc['owner_company'];
    		$supplierinc[0]['Uom']=$supplierinc['uom'];
    		$supplierinc[0]['SupplierInquiry']=$supplierinc;
    		 
    		$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    		$companyids=explode(",",$companyidsval);
    		$companypersons=isset($supplierInquiry['company_contact_persons'])?
    		explode(",",$supplierInquiry['company_contact_persons']): array();
    		 
    		 
    		 
    		$this->loadModel('CompanyMaster');
    		$this->loadModel('CompanyContactPerson');
    
    		$supplierCompanies =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons'])->toArray();
    		$supplierinc[0]["CompanyMaster"]=$supplierCompanies;
    		//debug($supplierinc);exit;
    		foreach ($supplierCompanies as $supplier){
    			$comapnyName=$supplier["Company_name"];
    
    			$supplieremail=array();
    			foreach ($supplier["company_contact_persons"] as $contact["CompanyContactPerson"]){
    				$contactemail=$contact["CompanyContactPerson"]["email_id"];
    					
    				if(trim($contactemail," ")!=""){
    					array_push($supplieremail, $contactemail);
    				}else{
    					//	echo 'pppp';die;
    					//$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email for Supplier company '".$comapnyName."' .");
    					$this->Flash->error("Please check email_id '$contactemail' for contact_name ","Supplier Inquiry");
    					//return $this->redirect(array("action"=>"edit",$supplierInquiryid));
    						
    					//$this->redirect(array("action"=>"index"));
    				}
    			}
    			if(count($supplieremail)==0){
    				$this->Flash->error("Please select atleast one contact for Supplier company","Supplier Inquiry");
    				if($isredirect){
    					$this->redirect(array("action"=>"edit_consumable",$supplierInquiryid));
    				}else return false;
    			}
    		}
    		 
    		/**********************************************************************/
    
    		$supplierinquires = $this->SupplierInquiry->get($supplierInquiryid, [
    				'contain' => ['OwnerCompanies', 'Uom', 'Currency', 'PackingMaster', 'PackingMaster.PackingType','PackingMaster.PackingSubtype']
    		]);
    

    		//debug($productTestData);exit;
    		$this->set(compact('ProductDataTest','isView','supplierinquires','comapnyName','productDataTest','productTestData','companyMaster', 'ownerCompanies', 'productsMasters'));
    		//echo "<pre>",print_r($comapnyName);exit;
    		 
    		$emailvar=$supplierinc[0];
    
    		$ret=false;
    		$companyname = $supplierinc['owner_company']['Company_name'];
    		 
    		if($this->doSendMail_Consumable($emailvar,$isView)){
    
    			$this->request->data['status'] = '1';
    			//echo "<pre>",print_r($supplierinc[0]['SupplierInquiry']);exit;
    			//echo "<pre>",print_r($supplierinc[0]['SupplierInquiry']);exit;
    			$supplierinquirysave = $this->SupplierInquiry->patchEntity($supplierinquires, $this->request->data);
    			$this->SupplierInquiry->save($supplierinquirysave);
    
    			$this->Flash->success(__('The {0} has been sent successfully.', "Supplier Inquiry for $companyname"));
    			return $this->redirect(['action' => 'index-consumable']);
    			$ret=true;
    		}else {
    			$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "Supplier Inquiry for  $companyname"));
    		}
    		/* if($isView !== "1"){
    		 //	return $this->redirect(array("action"=>"index"));
    		 }
    		 return $ret; */
    		exit;
    	}
    }
    
    
    private function doSendMail_Consumable($supplierinc,$isView=null){
    	try{
    		//debug($ProductDataTest);exit;
    		//$settings=$supplierinc["OwnerCompany"]["email_setting"];
    		$companyname=$supplierinc["OwnerCompany"]["Company_name"];
    		$fromid=$supplierinc["OwnerCompany"]["company_email"];
    		$Subject = 'Supplier Inquiry from '.$companyname;
    		if(trim($supplierinc["SupplierInquiry"]["cc_email"]," ")!=""){
    			$cc[]=$supplierinc["SupplierInquiry"]["cc_email"];
    
    		}
    		$suppliercompanies=$supplierinc["CompanyMaster"];
    
    		foreach($suppliercompanies as $company){
    
    			$supplierinc["CompanyMaster"]=$company;
    			$comapnyName=$company["Company_name"];
    			//debug($comapnyName);exit;
    			$suppliercontact = "";
    			$supplieremail = array();
    			$vpercount=0;
    			// for dynamic contacts//
    			foreach ($company["company_contact_persons"] as $contact["CompanyContactPerson"]){
    				$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
    						ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
    						ucfirst($contact["CompanyContactPerson"]["last_name"]);
    						if(trim($personname," ")!=""){
    							$suppliercontact.=$vpercount>0?",":"";
    							$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
    							$vpercount++;
    						}
    
    						$contactemail=$contact["CompanyContactPerson"]["email_id"];
    
    						if(trim($contactemail," ")!=""){
    							array_push($supplieremail, $contactemail);
    						}else{
    							$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
    							return false;
    						}
    			}
    
    			$supplierinc["CompanyMaster"]["contact_persons"]=$suppliercontact;
    			$supplierinc["SupplierInquiry"]["mailto"]=$supplieremail;
    
    			$supplierinc["isView"]=$isView;
    			 
    			//$supplierinc["ProductDataTest"]=$ProductDataTest;
    			//debug($ProductDataTest);exit;
    
    			$to = array();
    			$cc = array();
    			$bcc=array();
    			if(Configure::read("productionMode")){
    				/*******Production Mode*******************/
    				$to=$contactemail;
    				$cc=$cc;
    				$bcc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    			}else{
    				/*******Dev Mode*******************/
    				$to=$contactemail;
    				$cc=$cc;
    				$bcc=array("dkvastrakar18@gmail.com");
    				/**************************/
    			}
    
    
    			/***************tester end*******************/
    
    
    			$email = new Email('default');
    			$email
    			//->setTransport($name)
    			->template("supplierenquiryconsumable","supplierenquiryconsumable")
    			->from($fromid)
    			->to($contactemail)
    			->cc($cc)
    			->subject($Subject)
    			->emailFormat('html')
    			->viewVars($supplierinc);
    			$email->send();
    
    		}
    
    
    		return true;
    	}catch(Exception $e){
    		echo $e->getMessage();
    
    		exit("Error : on send email in ");
    		return false;
    	}
    }

}
