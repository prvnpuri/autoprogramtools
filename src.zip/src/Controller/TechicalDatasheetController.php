<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TechicalDatasheet Controller
 *
 * @property \App\Model\Table\TechicalDatasheetTable $TechicalDatasheet
 *
 * @method \App\Model\Entity\TechicalDatasheet[] paginate($object = null, array $settings = [])
 */
class TechicalDatasheetController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products']
        ];
        $techicalDatasheet = $this->paginate($this->TechicalDatasheet);

        $this->set(compact('techicalDatasheet'));
        $this->set('_serialize', ['techicalDatasheet']);
    }

    /**
     * View method
     *
     * @param string|null $id Techical Datasheet id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $techicalDatasheet = $this->TechicalDatasheet->get($id, [
            'contain' => ['Products']
        ]);

        $this->set('techicalDatasheet', $techicalDatasheet);
        $this->set('_serialize', ['techicalDatasheet']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $techicalDatasheet = $this->TechicalDatasheet->newEntity();
        if ($this->request->is('post')) {
            $techicalDatasheet = $this->TechicalDatasheet->patchEntity($techicalDatasheet, $this->request->data);
            if ($this->TechicalDatasheet->save($techicalDatasheet)) {
                $this->Flash->success(__('The {0} has been saved.', 'Techical Datasheet'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Techical Datasheet'));
            }
        }
        $products = $this->TechicalDatasheet->Products->find('list', ['limit' => 200]);
        $this->set(compact('techicalDatasheet', 'products'));
        $this->set('_serialize', ['techicalDatasheet']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Techical Datasheet id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $techicalDatasheet = $this->TechicalDatasheet->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $techicalDatasheet = $this->TechicalDatasheet->patchEntity($techicalDatasheet, $this->request->data);
            if ($this->TechicalDatasheet->save($techicalDatasheet)) {
                $this->Flash->success(__('The {0} has been saved.', 'Techical Datasheet'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Techical Datasheet'));
            }
        }
        $products = $this->TechicalDatasheet->Products->find('list', ['limit' => 200]);
        $this->set(compact('techicalDatasheet', 'products'));
        $this->set('_serialize', ['techicalDatasheet']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Techical Datasheet id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $techicalDatasheet = $this->TechicalDatasheet->get($id);
        if ($this->TechicalDatasheet->delete($techicalDatasheet)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Techical Datasheet'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Techical Datasheet'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
