<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Network\Exception\NotFoundException;
use Cake\Log\Log;
use Cake\Cache\Cache;
use Cake\Event\EventManager;
use App\Event\InvoiceLedgerTransactionListener;


/**
 * Invoice Controller
 *
 * @property \App\Model\Table\InvoicesTable $Invoices
 * @property \App\Model\Table\InvoiceTypesTable $InvoiceTypes
 * @method \App\Model\Entity\Invoice[] paginate($object = null, array $settings = [])
 */
class InvoicesController extends AppController
{
   
    public function initialize(){
        parent::initialize();
        
        EventManager::instance()->on(new InvoiceLedgerTransactionListener());
        
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanies','Buyer', 'Currency', ]
        ];
        $invoice = $this->paginate($this->Invoices);
        $invoiceTypes= $this->Invoices-> InvoiceTypes->find("list",[
            "keyField"=>"id",
            "valueField"=>"type"
        ]);
        
        $this->set(compact('invoice','invoiceTypes'));
        $this->set('_serialize', ['invoice','invoiceTypes']);
    }
    public function pendingPoInvoice()
    {
    	$ids=array("0"=>"3","1"=>"4");//Invoice Type For Purchase
    	 
    	$invoice = $this->Invoices->find('all',[
    			'fields'=>['OwnerCompanies.Company_name','CompanyMaster.Company_name','is_local','id','invoice_no','invoice_date','invoice_types_id','grand_total_amount','send_to_payment','send_to_inward'],
    			'conditions'=>['invoice_types_id IN'=>$ids],
    			'contain'=>['OwnerCompanies','CompanyMaster'],
    			]);
    	
    	
    	
    	/* $this->paginate = [
    			'fields'=> ['OwnerCompanies.Company_name','CompanyMaster.Company_name','is_local','id','invoice_no','invoice_date','invoice_types_id','grand_total_amount'],
    			'contain' => ['OwnerCompanies','CompanyMaster'],
    			'conditions'=>['invoice_types_id IN'=>$ids]
    	];
    	$invoice = $this->paginate($this->Invoices);
    	$invoiceTypes= $this->Invoices-> InvoiceTypes->find("list",[
    			"keyField"=>"id",
    			"valueField"=>"type"
    	]);
     */
    	
    	$this->loadModel('UploadDocumentList');
    	 
    	 
    	$this->loadModel('UploadsScancopy');
  
    	
    	Foreach($invoice as $ks=>$vs){
    	
    		$uploadsdoclist = $this->UploadDocumentList->find('all', [
    				'fields'=>['UploadDocumentList.id'],
    				'conditions'=>['is_local'=>$vs->is_local],
    				'order' => ['UploadDocumentList.id'=>'asc'],
    	
    		])->toArray();
    	
    		$uploadsscancopylist = $this->UploadsScancopy->find('all', [
    				'fields'=>['UploadsScancopy.upload_document_id'],
    				'conditions'=>['invoice_id'=>$vs->id],
    				'order' => ['UploadsScancopy.upload_document_id'=>'asc'],
    					
    		])->toArray();
    		$cnt=0;
    		foreach ($uploadsdoclist as $k=>$v){
    			 
    			
    			if(isset($uploadsscancopylist[$k]['upload_document_id'])){
    				if($v['id']==$uploadsscancopylist[$k]['upload_document_id']){
    		    
    					$cnt++;
    				}else{
    					$cnt=0;
    				}
    			}else{
    				$cnt=0;
    			}
    			 
    		}
    		if($cnt==0){
    			 
    			$vs['document_uploads']='NotCompleted';
    		}else{
    			$vs['document_uploads']='Completed';
    		}
    	
    	
    	
    	}
    	
    	
    	$this->set(compact('invoice','invoiceTypes'));
    	$this->set('_serialize', ['invoice','invoiceTypes']);
    }
    public function pendingSalesInvoice()
    {
    	$ids=array("0"=>"1","1"=>"2"); //Invoice Type For Sales
    
    	$invoice = $this->Invoices->find('all',[
    			'fields'=>['OwnerCompanies.Company_name','CompanyMaster.Company_name','is_local','id','invoice_no','invoice_date','invoice_types_id','grand_total_amount','send_to_payment','send_to_postshipment'],
    			'conditions'=>['invoice_types_id IN'=>$ids],
    			'contain'=>['OwnerCompanies','CompanyMaster'],
    	]);
    	 
    	 
    	 
    	/* $this->paginate = [
    	 'fields'=> ['OwnerCompanies.Company_name','CompanyMaster.Company_name','is_local','id','invoice_no','invoice_date','invoice_types_id','grand_total_amount'],
    	 'contain' => ['OwnerCompanies','CompanyMaster'],
    	 'conditions'=>['invoice_types_id IN'=>$ids]
    	 ];
    	$invoice = $this->paginate($this->Invoices);
    	$invoiceTypes= $this->Invoices-> InvoiceTypes->find("list",[
    	"keyField"=>"id",
    	"valueField"=>"type"
    	]);
    	*/
    	 
    	$this->loadModel('UploadDocumentList');
    
    
    	$this->loadModel('UploadsScancopy');
    
    	 
    	Foreach($invoice as $ks=>$vs){
    		 
    		$uploadsdoclist = $this->UploadDocumentList->find('all', [
    				'fields'=>['UploadDocumentList.id'],
    				'conditions'=>['is_local'=>$vs->is_local],
    				'order' => ['UploadDocumentList.id'=>'asc'],
    				 
    		])->toArray();
    		 
    		$uploadsscancopylist = $this->UploadsScancopy->find('all', [
    				'fields'=>['UploadsScancopy.upload_document_id'],
    				'conditions'=>['invoice_id'=>$vs->id],
    				'order' => ['UploadsScancopy.upload_document_id'=>'asc'],
    					
    		])->toArray();
    		$cnt=0;
    		foreach ($uploadsdoclist as $k=>$v){
    
    			 
    			if(isset($uploadsscancopylist[$k]['upload_document_id'])){
    				if($v['id']==$uploadsscancopylist[$k]['upload_document_id']){
    
    					$cnt++;
    				}else{
    					$cnt=0;
    				}
    			}else{
    				$cnt=0;
    			}
    
    		}
    		if($cnt==0){
    
    			$vs['document_uploads']='NotCompleted';
    		}else{
    			$vs['document_uploads']='Completed';
    		}
    		 
    		 
    		 
    	}
    	 
    	 
    	$this->set(compact('invoice','invoiceTypes'));
    	$this->set('_serialize', ['invoice','invoiceTypes']);
    }
    public function poDocument($invoiceId)
    {
    	//$purchaseOrder = $this->paginate($this->PurchaseOrder);
    	
    	$this->loadModel('Invoices');
    	
    	$invoiceData=$this->Invoices->find('all')
    	->select([
    			'id','is_local','invoice_no','invoice_date'
    	])
    	->contain([
    			'InvoiceProducts' => function($q) {
    			return $q
    			->select([
    					'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.product_id','InvoiceProducts.order_id'
    			])
    			->contain([
    					'ProductsMaster' => function($q) {
    					return $q
    					->select([
    							'ProductsMaster.id', 'ProductsMaster.product_name'
    					]);
    					},
    					'PurchaseOrder' => function($q) {
    					return $q
    					->select([
    							'PurchaseOrder.id', 'PurchaseOrder.po_number','PurchaseOrder.po_date'
    					]);
    					}
    					
    					]);
    	
    			},
    			
    			'CompanyMaster'=> function ($q) {
    			return $q
    			->select([
    					'CompanyMaster.id','CompanyMaster.Company_name'
    			]);
    	
    			},
    			
    			])
    			->where(['Invoices.id'=>$invoiceId])
    			//->order(['PurchaseOrder.id'=>'DESC'])
    	
    			->toArray();
	    
    		$this->loadModel('UploadDocumentList');
	    	$docList = $this->UploadDocumentList->find('all',[
	    			'fields'=>['id','document_name','is_local','purchase_entry'],
	    			'conditions'=>['module_name'=>'PurchaseOrder','is_local'=>$invoiceData[0]['is_local']],
	    			'contain'=>['UploadsScancopy']
	    
	    
	    	])->toArray();
    	
    	
    	$this->loadModel('InvoiceShippingDocuments');
    	$shippingDoc=$this->InvoiceShippingDocuments->find(
    			'all',[
    				'fields'=>['invoice_id','id','bill_of_landing_no','bill_of_lading_date','bill_of_lading_ocean_vessel','packing_list_gross_weight','insurance_policy_no','insurance_company_id','insurance_code','lr_no','lr_vehicle_number','lr_transporter_id','international_transporter_company_id','international_transporter_from_locaton','international_transporter_to_location'],
    				'conditions'=>['invoice_id'=>$invoiceId]	
    					
    			]
    		
    			
    	)->toArray() ;
    	//debug($shippingDoc);die;
    	
    	
    	$this->set(compact('docList','invoiceId','shippingDoc','invoiceData'));
    	$this->set('_serialize', ['purchaseOrder']);
    }
    public function salesDocument($invoiceId)
    {
    	//$purchaseOrder = $this->paginate($this->PurchaseOrder);
    	
    	$this->loadModel('Invoices');
    	
    	
    	$invoiceData = $this->Invoices->get($invoiceId, [
    			'contain' => ['CompanyMaster','Currency','OwnerCompanies','OwnerCompanies.OwnerCompanyOffices','InvoiceProducts','InvoiceProducts.Order','InvoiceProducts.ProductsMaster'],
    	])->toArray();
	    
    	//debug($invoiceData);die;
    	
    		$this->loadModel('UploadDocumentList');
	    	$docList = $this->UploadDocumentList->find('all',[
	    			'fields'=>['id','document_name','is_local','sales_entry'],
	    			'conditions'=>['module_name'=>'Preshipment','is_local'=>$invoiceData['is_local']],
	    			'contain'=>['UploadsScancopy']
	    
	    
	    	])->toArray();
    	
    	
	    	$invoiceData=$this->Invoices->find('all')
	    	->select([
	    			'id','is_local','invoice_no','invoice_date'
	    	])
	    	->contain([
	    			'InvoiceProducts' => function($q) {
	    			return $q
	    			->select([
	    					'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.product_id','InvoiceProducts.order_id'
	    			])
	    			->contain([
	    					'InvoiceProductBatches' => function($q) {
	    					return $q
	    					->select([
	    							'InvoiceProductBatches.id','InvoiceProductBatches.invoice_products_id', 'InvoiceProductBatches.batch_size'
	    					])
	    					/* ->contain([
	    							'CoaResults' => function($q){
		    							return $q
		    							->select([
		    									'CoaResults.id', 'CoaResults.result'
		    							]);
	    							
	    							
	    							}
	    							
	    							
	    							
	    					]) */;
	    					},
	    					'ProductsMaster' => function($q) {
	    					return $q
	    					->select([
	    							'ProductsMaster.id', 'ProductsMaster.product_name'
	    					]);
	    					},
	    					'Order' => function($q) {
	    					return $q
	    					->select([
	    							'Order.id', 'Order.order_no','Order.order_date'
	    					]);
	    					}
	    						
	    					]);
	    			 
	    			},
	    			 
	    			'CompanyMaster'=> function ($q) {
	    			return $q
	    			->select([
	    					'CompanyMaster.id','CompanyMaster.Company_name'
	    			]);
	    			 
	    			},
	    			 
	    			])
	    			->where(['Invoices.id'=>$invoiceId])
	    	->toArray();
	    	
	    	
    	$this->loadModel('InvoiceShippingDocuments');
    	$shippingDoc=$this->InvoiceShippingDocuments->find(
    			'all',[
    				//'fields'=>['invoice_id','id','bill_of_landing_no','bill_of_lading_date','bill_of_lading_ocean_vessel','packing_list_gross_weight','insurance_policy_no','insurance_company_id','insurance_code','lr_no','lr_vehicle_number','lr_transporter_id','international_transporter_company_id','international_transporter_from_locaton','international_transporter_to_location'],
    				'conditions'=>['invoice_id'=>$invoiceId]	
    					
    			]
    		
    			
    	)->toArray() ;
    			
    	$this->loadModel('PackingShipingData');
    	$packingDoc=$this->PackingShipingData->find(
    			'all',[
    					//'fields'=>['invoice_id','id','bill_of_landing_no','bill_of_lading_date','bill_of_lading_ocean_vessel','packing_list_gross_weight','insurance_policy_no','insurance_company_id','insurance_code','lr_no','lr_vehicle_number','lr_transporter_id','international_transporter_company_id','international_transporter_from_locaton','international_transporter_to_location'],
    					'conditions'=>['invoice_id'=>$invoiceId]
    						
    			]
    	
    			 
    			)->toArray() ;
    			
    	$this->loadModel('InvoiceProductBatches');
    	 
    	$coaDoc=$this->InvoiceProductBatches->find(
    			'all',[
    					//'fields'=>['InvoiceProductBatches.invoice_id'],
    					'conditions'=>['invoice_id'=>$invoiceId],
    					'contain'=>['CoaResults']
    						
    						
    			]
    	
    			 
    			)->toArray() ;
    	//debug($coaDoc);die;
    	
    	
    	$this->set(compact('docList','invoiceId','packingDoc','shippingDoc','coaDoc','invoiceData'));
    	$this->set('_serialize', ['purchaseOrder']);
    }
    public function postshipmentDocument()
    {
    	//$purchaseOrder = $this->paginate($this->PurchaseOrder);
    	 
    	$this->loadModel('Invoices');
   
    	$ids=array("0"=>"1","1"=>"2"); //Invoice Type For Sales
    	
    	$invoice = $this->Invoices->find('all',[
    			'fields'=>['OwnerCompanies.Company_name','CompanyMaster.Company_name','is_local','id','invoice_no','invoice_date','invoice_types_id','grand_total_amount','send_to_payment','send_to_postshipment'],
    			'conditions'=>['send_to_postshipment'=>"YES"],
    			'contain'=>['OwnerCompanies','CompanyMaster'],
    	]);
    	
    /*	
    	$this->loadModel('UploadDocumentList');
    	$docList = $this->UploadDocumentList->find('all',[
    			'fields'=>['id','document_name','is_local','sales_entry'],
    			'conditions'=>['module_name'=>'Postshipment','is_local'=>$invoiceData[0]['is_local']],
    			'contain'=>['UploadsScancopy']
    			 
    			 
    	])->toArray();
    	 
    	 
    	$this->loadModel('InvoiceShippingDocuments');
    	$shippingDoc=$this->InvoiceShippingDocuments->find(
    			'all',[
    					//'fields'=>['invoice_id','id','bill_of_landing_no','bill_of_lading_date','bill_of_lading_ocean_vessel','packing_list_gross_weight','insurance_policy_no','insurance_company_id','insurance_code','lr_no','lr_vehicle_number','lr_transporter_id','international_transporter_company_id','international_transporter_from_locaton','international_transporter_to_location'],
    					'conditions'=>['invoice_id'=>$invoiceId]
    						
    			]
    
    			 
    			)->toArray() ;*/
    			 
    			
    							 
    							 
    	$this->set(compact('invoice'));
    	$this->set('_serialize', ['purchaseOrder']);
    }
    
    public function postshipmentDocumentView($invoiceId)
    {
    	$this->loadModel('Invoices');
    	
    	
    	$invoiceData = $this->Invoices->get($invoiceId, [
    			'contain' => ['CompanyMaster','Currency','OwnerCompanies','OwnerCompanies.OwnerCompanyOffices','InvoiceProducts','InvoiceProducts.Order','InvoiceProducts.ProductsMaster'],
    	])->toArray();
	    
    	//debug($invoiceData);die;
    	
    		$this->loadModel('UploadDocumentList');
	    	$docList = $this->UploadDocumentList->find('all',[
	    			'fields'=>['id','document_name','is_local','sales_entry'],
	    			'conditions'=>['module_name'=>'Postshipment','is_local'=>$invoiceData['is_local']],
	    			'contain'=>['UploadsScancopy']    
	    
	    	])->toArray();
	    	$invoiceData=$this->Invoices->find('all')
	    	->select([
	    			'id','is_local','invoice_no','invoice_date'
	    	])
	    	->contain([
	    			'InvoiceProducts' => function($q) {
	    			return $q
	    			->select([
	    					'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.product_id','InvoiceProducts.order_id'
	    			])
	    			->contain([
	    					'InvoiceProductBatches' => function($q) {
	    					return $q
	    					->select([
	    							'InvoiceProductBatches.id','InvoiceProductBatches.invoice_products_id', 'InvoiceProductBatches.batch_size'
	    					])
	    					/* ->contain([
	    					 'CoaResults' => function($q){
	    							return $q
	    							->select([
	    									'CoaResults.id', 'CoaResults.result'
	    							]);
	    	
	    	
	    							}
	    	
	    	
	    	
	    					]) */;
	    					},
	    					'ProductsMaster' => function($q) {
	    					return $q
	    					->select([
	    							'ProductsMaster.id', 'ProductsMaster.product_name'
	    					]);
	    					},
	    					'Order' => function($q) {
	    					return $q
	    					->select([
	    							'Order.id', 'Order.order_no','Order.order_date'
	    					]);
	    					}
	    						
	    					]);
	    			 
	    			},
	    			 
	    			'CompanyMaster'=> function ($q) {
	    			return $q
	    			->select([
	    					'CompanyMaster.id','CompanyMaster.Company_name'
	    			]);
	    			 
	    			},
	    			 
	    			])
	    			->where(['Invoices.id'=>$invoiceId])
	    			->toArray();
	    	
	    	
	    			$this->loadModel('PostsipmentDocuments');
	    			$shippingDoc=$this->PostsipmentDocuments->find(
	    					'all',[
	    							//'fields'=>['invoice_id','id','bill_of_landing_no','bill_of_lading_date','bill_of_lading_ocean_vessel','packing_list_gross_weight','insurance_policy_no','insurance_company_id','insurance_code','lr_no','lr_vehicle_number','lr_transporter_id','international_transporter_company_id','international_transporter_from_locaton','international_transporter_to_location'],
	    							'conditions'=>['invoice_id'=>$invoiceId]
	    								
	    					]
	    	
	    					 
	    					)->toArray() ;
	    					 
	    					


	    			$this->set(compact('docList','invoiceId','packingDoc','shippingDoc','coaDoc','invoiceData'));
	    			$this->set('_serialize', ['purchaseOrder']);
	    					
    }
    
    
    public function createPoDocument($isLocal,$invoiceId){
    	
    	$this->loadModel('UploadDocumentList');
    	$docList = $this->UploadDocumentList->find('all',[
    			'fields'=>['id','document_name','is_local'],
    			'conditions'=>['module_name'=>'PurchaseOrder','is_local'=>$isLocal,
    							'purchase_entry'=>'1'
    					
    			],
    			'contain'=>['UploadsScancopy']
    	
    	
    	])->toArray();
    	$this->loadModel('Invoices');
    	if($isLocal=="1"){
    		$invoiceTypeId="4";
    	}else{
    		$invoiceTypeId="3";
    	}
    	/* $purchaseOrder = $this->Invoices->find('all',[
    	 'fields'=>['id','document_name','is_local'],
    	 'conditions'=>['invoice_types_id'=>$invoiceTypeId],
    	 'contain'=>['InvoiceProducts']
    	  
    	  
    	 ])->toArray();
    	 */
    	$this->set(compact('docList','invoiceId'));
    	
    }
    /**
     * View method
     *
     * @param string|null $id Invoice id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $invoice = $this->Invoice->get($id, [
            'contain' => ['OwnerCompanies', 'Orders', 'Consignees', 'Notifies', 'Buyers', 'Currencies', 'Uoms', 'Taxinvoices', 'CompanyBankMaster', 'CertificateOfAnalyses', 'ExciseTaxInvoice', 'ExportValueDeclaration', 'LedgerTransactions', 'LocalPreShipmentAttachment', 'LocalPreShipmentTransporter', 'PreShipmentAttachment', 'PreShipmentBase', 'PreShipmentInsurance', 'PreShipmentPacking', 'PreShipmentSdf', 'PreShipmentShipperDeclaration', 'PreShipmentShipperInstruction', 'PreShipmentTransporter', 'PreshipmentTsca', 'ShippingDocumentsPhysical', 'TaxInvoice']
        ]);
        
        
        $this->set('invoice', $invoice);
        $this->set('_serialize', ['invoice']);
    }
    public function viewPurchaseInvoice($id = null)
    {
    	$invoice = $this->Invoices->get($id, [
    			'contain' => ['CompanyMaster','Currency','OwnerCompanies','OwnerCompanies.OwnerCompanyOffices','InvoiceProducts','InvoiceProducts.InvoiceTaxes','InvoiceProducts.InvoiceTaxes.TaxMaster','InvoiceProducts.PurchaseOrder','InvoiceProducts.Uom','InvoiceProducts.Currency','InvoiceProducts.ProductsMaster','PaymentTerm'],
    			]);
    
    
    	$this->set('invoice', $invoice);
    	$this->set('_serialize', ['invoice']);
    }
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        //debug( $this->request->getData()); die();
        
        $this->loadModel("Uom");
        
        $invoiceTypeID=$this->request->getQuery("invoicetype_id");
        if(!isset($invoiceTypeID)){
            throw new NotFoundException("Invoice type not found");
        }
        $invoiceTypes=$this->Invoices->InvoiceTypes->find("all",["conditions"=>["id"=>$invoiceTypeID]])->first();
        $invoice = $this->Invoices->newEntity($this->request->getData(),[
            "associated"=>[
                "InvoiceProducts","InvoiceProducts.InvoiceTaxes"
            ]
        ]);
        $purchaseOrderId=$this->request->getQuery("po_id");
        
        if ($this->request->is('post')) {
            $invoice = $this->Invoices->patchEntity($invoice, $this->request->getData(),[
                "associated"=>[
                    "InvoiceProducts","InvoiceProducts.InvoiceTaxes"
                ]
            ]);
            if ($this->Invoices->save($invoice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Invoice'));
                if($invoiceTypeID=="3" || $invoiceTypeID=="4"){
                	$controllerName="purchase-order";
                	$action="po-document";
                	($invoiceTypeID=="3")?$isLocal="0":$isLocal="1";
                	$id=$purchaseOrderId;
                	return $this->redirect(['controller'=>$controllerName,'action' => $action,$isLocal,$id]);
                	 
                	return $this->redirect(['action' => 'index']);
                }else{
                	return $this->redirect(['action' => 'index']);
                }
            } else {
                Log::error("Enable to save invoice");
                Log::debug($invoice->errors());
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice'));
            }
        }
        $ownerCompanies = $this->Invoices->OwnerCompanies->find('list', ['limit' => 200,
            "keyField"=>"id",
            "valueField"=>"Company_name"
        ]);
        $this->loadModel("TaxMaster");
        $taxmasters=$this->TaxMaster->find('list',[
            "valueField"=>"tax_name",
            "keyField"=>"id"
        ]);
        $currencies = $this->Invoices->Currency->find('list', ['limit' => 200]);
        $uoms = $this->Uom->find('list', ['limit' => 200]);
        $this->set(compact('invoice', 'ownerCompanies','invoiceTypes','currencies', 'uoms','taxmasters'));
        $this->set('_serialize', ['invoice', 'ownerCompanies','invoiceTypes','currencies', 'uoms','taxmasters']);
      
    }
    public function addSalesInvoice()
    {
    
        // debug($this->request->data);
    	if(isset($this->request->data['frmName']) && $this->request->data['frmName']=="pendingpo"){
    		 
    	    	Foreach($this->request->data['quantity'] as $k=>$vals)
		    	{
		    		 if(($vals!="0")){
		    			$orderId=$this->request->data['order_id'][$k]; 
		    			 
		    			$order_ids[]=$orderId;
		    	
		    	 	} 
		    	}
    		//echo $this->request->data['isLocal'];die;
   	//	debug($order_ids);die;
    		//through pending PO invoice
    		$ownerCompanies = $this->Invoices->OwnerCompanies->find('list', ['limit' => 200,
    				"keyField"=>"id",
    				"valueField"=>"Company_name"
    		]);
    		$this->loadModel("TaxMaster");
    		$taxmasters=$this->TaxMaster->find('list',[
    				"valueField"=>"tax_name",
    				"keyField"=>"id"
    		])->toArray();
    		
    		$invoiceTypes=$this->Invoices->InvoiceTypes->find("all",["conditions"=>["is_local"=>$this->request->data['isLocal'],"type like"=>"Sel%"]])->first();
    		//  debug($invoiceTypes);die;
    
    		
    		//$currencies = $this->Invoices->Currency->find('list', ['limit' => 200]);
    		$this->loadModel("Uom");
    		$uoms = $this->Uom->find('list', ['limit' => 200]);
    		$this->set(compact('invoice', 'ownerCompanies','invoiceTypes','currencies', 'uoms','taxmasters'));
    		$this->set('_serialize', ['invoice', 'ownerCompanies','invoiceTypes','currencies', 'uoms','taxmasters']);
    		//Get data from Purchase Order
    		$this->loadModel('Order');
    		$salesOrder=$this->Order->find('all')
    		->select([
    				'id','order_no', 'order_date','consignee','buyer_company','consignee_address','port_of_discharge_id','country_final_destination','country_of_origin_of_goods','buyer_company','notify_party_address','notify_to','consignee' ,'reference_number','quantity_ordered','rate','total_order_price','is_local'
    		])
    		->contain([
    				'OwnerCompanies' => function($q) {
    				return $q
    				->select([
    						'OwnerCompanies.id','OwnerCompanies.Company_name','OwnerCompanies.iec_no'
    				])
    				->contain([
    						'OwnerCompanyOffices' => function($q) {
    						return $q
    						->select([
    								'OwnerCompanyOffices.id','OwnerCompanyOffices.name', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
    						])
    						->contain([
    								'City' => function($q) {
    								return $q
    								->select([
    										'City.city_name'
    								]);
    								}
    								])
    								->contain([
    										'Countries' => function($q) {
    										return $q
    										->select([
    												'Countries.country_name'
    										]);
    										}
    										])
    										->contain([
    												'State' => function($q) {
    												return $q
    												->select([
    														'State.state_name'
    												]);
    												}
    												]);
    						}
    						]);
    
    				},
    				'Uom'=> function ($q) {
    				return $q
    				->select([
    						'Uom.id','Uom.unit_symbol'
    				]);
    				 
    				},
    				'OrderAcceptance'=> function ($q) {
    				return $q
    				->select([
    						'OrderAcceptance.order_id','OrderAcceptance.end_use'
    				]);
    					
    				},
    				'Currency'=> function ($q) {
    				return $q
    				->select([
    						'Currency.id','Currency.sign'
    				]);
    				 
    				},
    				/* 'CompanyMaster'=> function ($q) {
    				return $q
    				->select([
    						'CompanyMaster.id','CompanyMaster.Company_name'
    				]);
    
    				}, */
    				'ProductsMaster'=> function ($q) {
    				return $q
    				->select([
    						'ProductsMaster.id','ProductsMaster.product_name','ProductsMaster.hs_code','ProductsMaster.ritc_code','ProductsMaster.cas_no'
    				]);
    
    				},
    				'BoldNoInventoryTran'=> function ($q) {
    				return $q
    				->select([
    						'id','bold_number_inventory_id','order_id'
    				])
    				->contain([
    						'BoldNumberInventory' => function($q) {
    						return $q
    						->select([
    								'unique_series','from','to'
    						]);
    				
    				}
    				
    				
    				]);
    				}
    				
    				
    				,
    				'PaymentTerm'=> function ($q) {
    				return $q
    				->select([
    						'PaymentTerm.id','PaymentTerm.term'
    				]);
    
    				},
    				
    				
    				])
    				->where(['Order.id In'=>$order_ids])
    				->order(['Order.id'=>'DESC'])
    
    				->toArray();

    				//debug($salesOrder);die;
    				//Company Matser Entry
    				
    				$this->loadModel('CompanyMaster');
    				$consigneeCompany=$this->CompanyMaster->find('all',[
    						"fields"=>["Company_name","id"],    				
    						"conditions"=>['id'=>$salesOrder[0]['consignee']]
    				])->toArray();
    				
    				
					$notifyCompany=$this->CompanyMaster->find('all',[
    						"fields"=>["Company_name","id"],    				
    						"conditions"=>['id'=>$salesOrder[0]['notify_to']]
    				])->toArray();    				
    				
    				
    				//Ends Company Master Entry
    				
    				$this->loadModel('Countries');
    				$this->loadModel('PortOfDischarge');
    				//debug($salesOrder);
    			//	echo $salesOrder[0]['country_of_origin_of_goods'];die;
    				$countryoforigineofgoods=$this->Countries->find('all',[
    						"Fields"=>["country_name","id"],
    						
    						"conditions"=>['id'=>$salesOrder[0]['country_of_origin_of_goods']]
    				])->toArray();
    				
    				$portofdischarge=$this->PortOfDischarge->find('all',[
    						"Fields"=>["port_of_discharge","id"],
    				
    						"conditions"=>['id'=>$salesOrder[0]['port_of_discharge_id']]
    				])->toArray();
    				
    				$countryoffinaldestination=$this->Countries->find('all',[
    						"Fields"=>["country_name","id"],
    				
    						"conditions"=>['id'=>$salesOrder[0]['country_final_destination']]
    				])->toArray();
    				
    				//$countryoforigineofgoods= $this->Countries->find('all', [['Fields'] => ['id','country_name'],['conditions']=>['id'=>$salesOrder[0]['country_of_origin_of_goods']]]);
    				
    				$this->set(compact('invoiceTypes','salesOrder','consigneeCompany','notifyCompany','countryoforigineofgoods','countryoffinaldestination','countries','portofdischarge'));
    				 
    				 
    	}else{
    		 
    		//Post through Invoice add
    		//debug($this->request->data);die;
    		$this->loadModel('ReferenceNumberCounter');
    		$this->loadComponent('ReferenceNumber');
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_company_id'],'invoice');
    		$this->request->data['invoice_no'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    		if(!isset($next_ref['full_next_ref_no'])){
    			//echo 'sdfsg';die;
    			$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Offer'));
    			//return $this->redirect(['action' => 'index']);
    		}else{
    		
    			
	//debug($this->request->getData());die;
    			
    		if ($this->request->is('post')) {
    			//debug($this->request->getData());die;
    			$invoice = $this->Invoices->newEntity($this->request->getData(),[
    					"associated"=>[
    							"InvoiceProducts","InvoiceProducts.InvoiceTaxes","InvoiceProducts.InvoiceProductBatches"
    					]
    			]);
    			$invoice = $this->Invoices->patchEntity($invoice, $this->request->getData(),[
    					"associated"=>[
    							"InvoiceProducts","InvoiceProducts.InvoiceTaxes","InvoiceProducts.InvoiceProductBatches","InvoiceProducts.InvoiceProductBoldno"
    							]
    			]);
    
    			
    			if ($this->Invoices->save($invoice)) {
    				 
    				//Update despatch and balance Qty
    				 
    				$this->loadModel('Order');
    				foreach ($invoice['invoice_products'] as $invk=>$invvals){
    
    					$purchaseOrder = $this->Order->get($invvals['order_id'], [
    							'contain' => []
    					]);
    					$balanceQty=$purchaseOrder['quantity_ordered']-$invvals['qty'];
    					$data = array('id' => $invvals['order_id'],'balance_qty'=>$balanceQty , 'quantity_despatch' => $invvals['qty']);
    					//debug($data);
    					    	
    					
    					
    					$this->Order->patchEntity($purchaseOrder,$data);
    					//	debug($purchaseOrder);die;
    					    	
    					$this->Order->save($purchaseOrder);
    					//debug($data);
    				}
    				//debug($invoice);die;
    				$this->Flash->success(__('The {0} has been saved.', 'Invoice'));
    				 
    				$controllerName="invoices";
    				$action="pending_sales_invoice";
    				return $this->redirect(['controller'=>$controllerName,'action' => $action]);
    				 
    			} else {
    				Log::error("Enable to save invoice");
    				Log::debug($invoice->errors());
    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice'));
    			}
    		}
    		}
    		 
    	}
    	
    
    	 
    	 
    
    
    }
    
    public function editSalesInvoice($id)
    {
    
    		$invoice = $this->Invoices->get($id, [
        			'contain' => ['CompanyMaster','Currency','OwnerCompanies','OwnerCompanies.OwnerCompanyOffices',
        			    'InvoiceProducts','InvoiceProducts.InvoiceProductBatches',
        			    'InvoiceProducts.Order','InvoiceProducts.Order.NotifyCompany',
        			    'InvoiceProducts.Order.ShippingCompany','InvoiceProducts.Order.BoldNoInventoryTran',
        			    'InvoiceProducts.Order.BoldNoInventoryTran.BoldNumberInventory',
        			    'InvoiceProducts.Uom','InvoiceProducts.Currency',
        			    'InvoiceProducts.ProductsMaster','PaymentTerm','InvoiceProducts.InvoiceTaxes'],
        	]);
    			 
    		if ($this->request->is('post')) {
    	
    			    $invoice = $this->Invoices->patchEntity($invoice, $this->request->getData(),[
    						"associated"=>[
    								"InvoiceProducts","InvoiceProducts.InvoiceTaxes","InvoiceProducts.Order","InvoiceProducts.InvoiceProductBatches","InvoiceProducts.InvoiceProductBoldno"
    						]
    				]);
    
    				if ($this->Invoices->save($invoice)) {
    						
   						
    					$this->loadModel('Order');
    					foreach ($invoice['invoice_products'] as $invk=>$invvals){
    
    						$purchaseOrder = $this->Order->get($invvals['order_id'], [
    								'contain' => []
    						]);
    					
    					}
    					$this->Flash->success(__('The {0} has been saved.', 'Invoice'));
    						
    					$controllerName="invoices";
    					$action="pending_sales_invoice";
    					return $this->redirect(['controller'=>$controllerName,'action' => $action]);
    						
    				} else {
    					Log::error("Enable to save invoice");
    					Log::debug($invoice->errors());
    					$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice'));
    				}
    		}else{
    				
    				
    				$this->loadModel('CompanyMaster');
    				$consigneeCompany=$this->CompanyMaster->find('all',[
    						"fields"=>["Company_name","id"],
    						"conditions"=>['id'=>$invoice['consignee_id']]
    				])->toArray();
    				
    				
    				$notifyCompany=$this->CompanyMaster->find('all',[
    						"fields"=>["Company_name","id"],
    						"conditions"=>['id'=>$invoice['notify_id']]
    				])->toArray();
    				
    				$this->loadModel('Countries');
    				$this->loadModel('PortOfDischarge');
    				$countryoforigineofgoods=$this->Countries->find('all',[
    						"Fields"=>["country_name","id"],
    				
    						"conditions"=>['id'=>$invoice['country_origin_goods']]
    				])->toArray();
    				
    				$portofdischarge=$this->PortOfDischarge->find('all',[
    						"Fields"=>["port_of_discharge","id"],
    				
    						"conditions"=>['id'=>$invoice['port_of_discharge']]
    				])->toArray();
    				
    				$countryoffinaldestination=$this->Countries->find('all',[
    						"Fields"=>["country_name","id"],
    				
    						"conditions"=>['id'=>$invoice['country_final_destination']]
    				])->toArray();
    				
    				
    				$this->set(compact('invoice','consigneeCompany','notifyCompany','countryoforigineofgoods','countryoffinaldestination','countries','portofdischarge'));
    				$this->set('_serialize', ['invoice']);
    			}
    			
    			$this->loadModel("TaxMaster");
    			$taxmasters=$this->TaxMaster->find('list',[
    			    "valueField"=>"tax_name",
    			    "keyField"=>"id"
    			])->where([''])->toArray();
    			$this->set('taxmasters',$taxmasters);
    			
    }
    
    public function addPurchaseInvoice()
    {
    
    
    if(isset($this->request->data['frmName']) && $this->request->data['frmName']=="pendingpo"){
    	
   //  debug($this->request->data);die; 
    	Foreach($this->request->data['quantity'] as $k=>$vals)
    	{
    		 if(($vals!="0")){
    			$orderId=$this->request->data['quantity'][$k]; 
    			 
    			$order_ids[]=$vals;
    	
    	 	} 
    	}
    	// debug($order_ids); 
    	//through pending PO invoice
    	$ownerCompanies = $this->Invoices->OwnerCompanies->find('list', ['limit' => 200,
    			"keyField"=>"id",
    			"valueField"=>"Company_name"
    	]);
    	$this->loadModel("TaxMaster");
    	$taxmasters=$this->TaxMaster->find('list',[
    			"valueField"=>"tax_name",
    			"keyField"=>"id"
    	]);
    	$invoiceTypes=$this->Invoices->InvoiceTypes->find("all",["conditions"=>["is_local"=>$this->request->data['isLocal'],"type like"=>"Purchase%"]])->first();
    	//   debug($invoiceTypes);die;
    	   
    	//$currencies = $this->Invoices->Currency->find('list', ['limit' => 200]);
    	$this->loadModel("Uom");
    	$uoms = $this->Uom->find('list', ['limit' => 200]);
    	$this->set(compact('invoice', 'ownerCompanies','invoiceTypes','currencies', 'uoms','taxmasters'));
    	$this->set('_serialize', ['invoice', 'ownerCompanies','invoiceTypes','currencies', 'uoms','taxmasters']);
    	//Get data from Purchase Order
    	$this->loadModel('PurchaseOrder');
    	$purchaseOrder=$this->PurchaseOrder->find('all')
    	->select([
    			'id', 'po_date', 'po_number','quantity_ordered','rate','total_order_price','is_local','owner_companies_id'
    	])
    	->contain([
    			'OwnerCompanies' => function($q) {
    			return $q
    			->select([
    					'OwnerCompanies.id','OwnerCompanies.Company_name'
    			])
    			->contain([
    					'OwnerCompanyOffices' => function($q) {
    					return $q
    					->select([
    							'OwnerCompanyOffices.id', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
    					])
    					->contain([
    							'City' => function($q) {
    							return $q
    							->select([
    									'City.city_name'
    							]);
    							}
    							])
    							->contain([
    									'Countries' => function($q) {
    									return $q
    									->select([
    											'Countries.country_name'
    									]);
    									}
    									])
    									->contain([
    											'State' => function($q) {
    											return $q
    											->select([
    													'State.state_name'
    											]);
    											}
    											]);
    					}
    					]);
    				
    			},
    			'Uom'=> function ($q) {
    			return $q
    			->select([
    					'Uom.id','Uom.unit_symbol'
    			]);
    	
    			},
    			'Currency'=> function ($q) {
    			return $q
    			->select([
    					'Currency.id','Currency.sign'
    			]);
    	
    			},
    			'CompanyMaster'=> function ($q) {
    			return $q
    			->select([
    					'CompanyMaster.id','CompanyMaster.Company_name'
    			]);
    				
    			},
    			'ProductsMaster'=> function ($q) {
    			return $q
    			->select([
    					'ProductsMaster.id','ProductsMaster.product_name','ProductsMaster.hs_code'
    			]);
    				
    			},
    			'PaymentTerm'=> function ($q) {
    			return $q
    			->select([
    					'PaymentTerm.id','PaymentTerm.term'
    			]);
    				
    			}
    			])
    			->where(['PurchaseOrder.id In'=>$order_ids])
    			->order(['PurchaseOrder.id'=>'DESC'])
    			 
    			->toArray();
    			
    			//Get precisions from cache
    			$PrecisionKey=$purchaseOrder[0]['owner_companies_id'].'_'.'precision';
    			$precision = Cache::read($PrecisionKey, $config = 'default');
    			//Ends precisions from cache
    			$this->set(compact('purchaseOrder','precision'));
    	
    	
    }else{
    	
    	//Post through Invoice add
    	if ($this->request->is('post')) {
    		$invoice = $this->Invoices->newEntity($this->request->getData(),[
    				"associated"=>[
    						"InvoiceProducts","InvoiceProducts.InvoiceTaxes"
    				]
    		]);
    		$invoice = $this->Invoices->patchEntity($invoice, $this->request->getData(),[
    				"associated"=>[
    						"InvoiceProducts","InvoiceProducts.InvoiceTaxes"
    				]
    		]);    	
    		
    			//debug($invoice);die;	
    		if ($this->Invoices->save($invoice)) {
    			
    			//Update despatch and balance Qty
    		
    			
    			$this->loadModel('PurchaseOrder');
    			foreach ($invoice['invoice_products'] as $invk=>$invvals){
    				
    				$purchaseOrder = $this->PurchaseOrder->get($invvals['order_id'], [
    						'contain' => []
    				]);
    				//debug($data);die;
    				$balanceQty=$purchaseOrder['quantity_ordered']-$invvals['qty'];
    				$data = array('id' => $invvals['order_id'],'balance_qty'=>$balanceQty , 'invoice_qty' => $invvals['qty']);
    				$this->PurchaseOrder->patchEntity($purchaseOrder,$data);
    				$this->PurchaseOrder->save($purchaseOrder);
    				//debug($data);
    			}
    			//debug($invoice);die;
    			$this->Flash->success(__('The {0} has been saved.', 'Invoice'));
    			
    				$controllerName="invoices";
    				$action="pending_po_invoice";
    				return $this->redirect(['controller'=>$controllerName,'action' => $action]);
    			
    		} else {
    			Log::error("Enable to save invoice");
    			Log::debug($invoice->errors());
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice'));
    		}
    	}
    	
    }
    
    	
    	
  
    
    }
    /**
     * Edit method
     *
     * @param string|null $id Invoice id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $invoice = $this->Invoices->find("all", [
            'contain' => ['CompanyMaster','InvoiceProducts','InvoiceProducts.InvoiceTaxes','InvoiceProducts.ProductsMaster'],
        ])
        ->where(["Invoices.id"=>$id])->first();
        
        $invoiceTypes=$this->Invoices->InvoiceTypes->find("all",[ "conditions"=>["Invoices.id"=>$id]])
        ->join([
            "Invoices"=>[
                "table"=>"invoices",
                "type"=>"left",
                "conditions"=>"InvoiceTypes.id=Invoices.invoice_types_id"
            ]
        ])
        ->first();
        if ($this->request->is(['patch', 'post', 'put'])) {
            $invoice = $this->Invoices->patchEntity($invoice, $this->request->getData(),[
                "associated"=>[
                    "InvoiceProducts","InvoiceProducts.InvoiceTaxes"
                ]
            ]);
            if ($this->Invoices->save($invoice)) {
                
                //<Deleting invoice products>
                
                $invoiceProductsId=$this->request->getData('delete');
                
                Log::debug($invoiceProductsId);
                
                if(isset($invoiceProductsId["invoice_products"]["id"]) && count($invoiceProductsId["invoice_products"]["id"])>0){
                    
                    $this->Invoices->InvoiceProducts->deleteAll(["id  IN ( " . implode(",", $invoiceProductsId["invoice_products"]["id"] ) ." )" ]);
                    Log::debug("Invoice product deleted.");
                }else{
                    Log::debug("Invoice product cannot not deleted. Id count = 0");
                    
                }
               
                //</Deleting invoice products>
                
                $this->Flash->success(__('The {0} has been saved.', 'Invoice'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice'));
            }
        }
        
        $ownerCompanies = $this->Invoices->OwnerCompanies->find('list', ['limit' => 200,
            "keyField"=>"id",
            "valueField"=>"Company_name"
        ]);
        $this->loadModel("TaxMaster");
        $taxmasters=$this->TaxMaster->find('list',[
            "valueField"=>"tax_name",
            "keyField"=>"id"
        ]);
    	
        
      //  $currencies = $this->Invoices->Currency->find('list', ['limit' => 200]);
      //  $this->loadModel("Uom");
        //$uoms = $this->Uom->find('list', ['limit' => 200]);
        $this->set(compact('invoice', 'ownerCompanies','invoiceTypes','taxmasters'));
        $this->set('_serialize', ['invoice', 'ownerCompanies','invoiceTypes','currencies', 'uoms','taxmasters']);
        //debug($invoiceTypes);
        
        
    }
    public function editPurchaseInvoice($id = null)
    {
    	/* $invoice = $this->Invoices->find("all", [
    			//'fields'=>[''],
    			'contain' => ['CompanyMaster','OwnerCompanies','OwnerCompanies.OwnerCompanyOffices','InvoiceProducts','InvoiceProducts.InvoiceTaxes','InvoiceProducts.PurchaseOrder','InvoiceProducts.Uom','InvoiceProducts.Currency','InvoiceProducts.ProductsMaster','PaymentTerm'],
    	])
    	->where(["Invoices.id"=>$id])->first(); */
    	
    	 $invoice = $this->Invoices->get($id, [
    			'contain' => ['CompanyMaster','Currency','OwnerCompanies','OwnerCompanies.OwnerCompanyOffices','InvoiceProducts','InvoiceProducts.InvoiceTaxes','InvoiceProducts.InvoiceTaxes.TaxMaster','InvoiceProducts.PurchaseOrder','InvoiceProducts.Uom','InvoiceProducts.Currency','InvoiceProducts.ProductsMaster','PaymentTerm'],
    	]); 
    	
     
    	/* $invoice=$this->Invoices->find('all')
    	->select([
    			'id' ,'invoice_date', 'invoice_no','challan_no','challan_date','grand_total_amount','is_local'
    	])
    	->contain([
    			'OwnerCompanies' => function($q) {
			    			return $q
			    			->select([
			    					'OwnerCompanies.id','OwnerCompanies.Company_name'
			    			]);
    	
    			},
    			
    			'OwnerCompanyOffices'=> function ($q) {
    			return $q
    					->select([
    							'OwnerCompanyOffices.id', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
    					])
    					->contain([
    							'City' => function($q) {
    							return $q
    							->select([
    									'City.city_name'
    							]);
    							}
    							])
    							->contain([
    									'Countries' => function($q) {
    									return $q
    									->select([
    											'Countries.country_name'
    									]);
    									}
    									])
    									->contain([
    											'State' => function($q) {
    											return $q
    											->select([
    													'State.state_name'
    											]);
    											}
    											]);
    			
    			},
    			'Currency'=> function ($q) {
		    			return $q
		    			->select([
		    					'Currency.id','Currency.sign'
		    			]);
    			 
    			},
    			'CompanyMaster'=> function ($q) {
	    			return $q
	    			->select([
	    					'CompanyMaster.id','CompanyMaster.Company_name'
	    			]);
    	
    			},
    			'InvoiceProducts'=> function ($q) {
	    			return $q
	    			->select([
	    					'id','order_id','rate','qty','amount_wo_tax','product_id','uom_id','total_amount_wi_discount','invoice_id',
	    					'discount','discount_amount','total_amount_wi_discount'
	    					])
	    			->contain([
	    					'ProductsMaster' => function($q) {
	    					return $q
	    					->select([
	    							'ProductsMaster.product_name'
	    					]);
	    			   					
	    				},
	    				'Uom' => function($q) {
	    				return $q
	    				->select([
	    						'Uom.unit_symbol'
	    				]);
	    				 
	    				},
	    				'Currency'=> function ($q) {
		    			return $q
		    			->select([
		    					'Currency.id','Currency.sign'
		    			]);
    			 
    					},
	    				'PurchaseOrder' => function($q) {
	    				return $q
	    				->select([
	    						'PurchaseOrder.po_number','PurchaseOrder.po_date'
	    				]);
	    				
	    				},
	    				'InvoiceTaxes' => function($q) {
	    				return $q
	    				->select([
	    						'InvoiceTaxes.id','invoice_products_id','amount'
	    				])
	    				->contain([
	    						'TaxMaster' => function($q) {
	    						return $q
	    						->select([
	    								'TaxMaster.tax_name','tax_type','rate'
	    						]);
	    						}
	    						]);
	    				 
	    				}
	    				
	    			]);
    	
    			},
    			'PaymentTerm'=> function ($q) {
    			return $q
    			->select([
    					'PaymentTerm.id','PaymentTerm.term'
    			]);
    	
    			}
    			])
    			->where(['Invoices.id'=>$id])
    		->toArray();    */  			
    			
    			//debug($invoice);
    	
    	$invoiceTypes=$this->Invoices->InvoiceTypes->find("all",[ "conditions"=>["Invoices.id"=>$id]])
    	->join([
    			"Invoices"=>[
    					"table"=>"invoices",
    					"type"=>"left",
    					"conditions"=>"InvoiceTypes.id=Invoices.invoice_types_id"
    			]
    	])
    	->first();
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		
    		
    		//debug($this->request->getData());die;
    		$invoice = $this->Invoices->patchEntity($invoice, $this->request->getData(),[
    				 "associated"=>[
    						"InvoiceProducts","InvoiceProducts.InvoiceTaxes"
    				] 
    		]);
    		if ($this->Invoices->save($invoice)) {
    
    			//debug($invoice);die;
    			//<Deleting invoice products>
    
    		/* 	$invoiceProductsId=$this->request->getData('delete');
    
    			Log::debug($invoiceProductsId);
    
    			if(isset($invoiceProductsId["invoice_products"]["id"]) && count($invoiceProductsId["invoice_products"]["id"])>0){
    
    				$this->Invoices->InvoiceProducts->deleteAll(["id  IN ( " . implode(",", $invoiceProductsId["invoice_products"]["id"] ) ." )" ]);
    				Log::debug("Invoice product deleted.");
    			}else{
    				Log::debug("Invoice product cannot not deleted. Id count = 0");
    
    			} */
    			 
    			//</Deleting invoice products>
    
    			$this->Flash->success(__('The {0} has been saved.', 'Invoice'));
    				$controllerName="invoices";
    				$action="pending-po-invoice";
    				return $this->redirect(['controller'=>$controllerName,'action' => $action]);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice'));
    		}
    	}
    
    	/* $ownerCompanies = $this->Invoices->OwnerCompanies->find('list', ['limit' => 200,
    			"keyField"=>"id",
    			"valueField"=>"Company_name"
    	]); */
    	$this->loadModel("TaxMaster");
    	$taxmasters=$this->TaxMaster->find('list',[
    			"valueField"=>"tax_name",
    			"keyField"=>"id"
    	]);
    	 
    
    	$currencies = $this->Invoices->Currency->find('list', ['limit' => 200]);
    	$this->loadModel("Uom");
    	$uoms = $this->Uom->find('list', ['limit' => 200]);
    	$this->set(compact('invoice', 'ownerCompanies','invoiceTypes','currencies', 'uoms','taxmasters'));
    	$this->set('_serialize', ['invoice', 'ownerCompanies','invoiceTypes','currencies', 'uoms','taxmasters']);
    	//debug($invoiceTypes);
    
    
    }
    /**
     * Delete method
     *
     * @param string|null $id Invoice id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $invoice = $this->Invoices->get($id);
        if ($this->Invoices->delete($invoice)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Invoice'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Invoice'));
        }
        return $this->redirect(['action' => 'index']);
    }
    public function deletePurchaseorder($id = null)
    {
    	$this->request->allowMethod(['post', 'delete']);
    	$invoice = $this->Invoices->get($id);
    	if ($this->Invoices->delete($invoice)) {
    		$this->Flash->success(__('The {0} has been deleted.', 'Invoice'));
    	} else {
    		$this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Invoice'));
    	}
    	$controllerName="invoices";
    	$action="pending-po-invoice";
    	return $this->redirect(['controller'=>$controllerName,'action' => $action]);
    	 
    //	return $this->redirect(['action' => 'index']);
    }
    public function deleteSalesorder($id = null)
    {
    	$this->request->allowMethod(['post', 'delete']);
    	$invoice = $this->Invoices->get($id);
    	if ($this->Invoices->delete($invoice)) {
    		
    		
    		
    		$this->Flash->success(__('The {0} has been deleted.', 'Invoice'));
    	} else {
    		$this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Invoice'));
    	}
    	
    	
    	$controllerName="invoices";
    	$action="pending-sales-invoice";
    	return $this->redirect(['controller'=>$controllerName,'action' => $action]);
    
    	//	return $this->redirect(['action' => 'index']);
    }
    public function sendtopayment($id){
    
    	//echo $id;die;
    	$invoices = $this->Invoices->get($id, [
    			'contain' => []
    	]);
    	//echo '<pre>',print_r($purchaseOrder);die;
    
    	$data = array('id' => $id , 'send_to_payment' => "YES");
    	//print_r($data);die;
    	if($this->Invoices->patchEntity($invoices,$data)){
    		//echo '<pre>',print_r($data);die;
    		//	print_r($purchaseOrder);die;
    		$this->Invoices->save($invoices);
    
    		$this->Flash->success(__('Invoice has been sent to Payment.', 'Invoice'));
    		$controllerName="invoices";
    		$action="pending-po-invoice";
    		return $this->redirect(['controller'=>$controllerName,'action' => $action]);
    		
    
    	}else{
    
    		$this->Flash->success(__('Invoice has not 	been sent to Payment.', 'Invoice'));
    
    	}
    }
    public function sendtopostshipment($id){
    
    	//echo $id;die;
    	$invoices = $this->Invoices->get($id, [
    			'contain' => []
    	]);
    	//echo '<pre>',print_r($purchaseOrder);die;
    
    	$data = array('id' => $id , 'send_to_postshipment' => "YES");
    	//print_r($data);die;
    	if($this->Invoices->patchEntity($invoices,$data)){
    		//echo '<pre>',print_r($data);die;
    		//	print_r($invoices);die;
    		$this->Invoices->save($invoices);
    
    		$this->Flash->success(__('Invoice has been sent to Postshipment.', 'Invoice'));
    		$controllerName="invoices";
    		$action="pending-sales-invoice";
    		return $this->redirect(['controller'=>$controllerName,'action' => $action]);
    
    
    	}else{
    
    		$this->Flash->success(__('Invoice has not 	been sent to Payment.', 'Invoice'));
    
    	}
    }
    public function pendingGdn()
    {
    	
    	
    	$this->loadModel('PurchaseOrder');
    	 
    	$pendingpurchaseorder = $this->PurchaseOrder->find('all',[
    			'fields'=>['OwnerCompanies.Company_name','CompanyMaster.Company_name','Currency.sign','GoodsDeliveryNote.id','is_local','id','po_number','po_date','product_id','total_order_price','send_to_inward','inward_status','qc_status'],
    			'conditions'=>['send_to_inward'=>'Y'],
    			'contain'=>['OwnerCompanies','CompanyMaster','Currency','GoodsDeliveryNote','PurchaseOrderProducts'],
    			]);
    	
    
    	$this->set(compact('pendingpurchaseorder'));
    	$this->set('_serialize', ['pendingpurchaseorder']);
    }
    
    public function getInvoiceData($invoiceId = null){
    	$invoiceData = $this->Invoices->find('all')
    	->select([
    		'Invoices.id','Invoices.instruction','Invoices.port_load','Invoices.end_use' ,'Invoices.invoice_no', 'Invoices.invoice_date','Invoices.pre_carriage','Invoices.place_of_receipt','Invoices.vessel_no','Invoices.port_of_discharge','Invoices.country_final_destination','Invoices.country_origin_goods'
    	])
    	->contain([
    		'OwnerCompanies'=> function ($q) {
    			return $q
    			->select([
    				'OwnerCompanies.id','OwnerCompanies.Company_name','OwnerCompanies.gstin','OwnerCompanies.iec_no'
    			])
    			->contain([
    				'OwnerCompanyOffices' => function($q) {
    				return $q
    				->select([
    					'OwnerCompanyOffices.id','OwnerCompanyOffices.phone_no','OwnerCompanyOffices.postal_code','OwnerCompanyOffices.name', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_companies_id'
    				])
    				->contain([
    					'City' => function($q) {
    					return $q
    					->select([
    						'City.city_name'
    					]);
    					}
    				])
    				->contain([
    					'Countries' => function($q) {
    					return $q
    					->select([
    						'Countries.country_name'
    					]);
    					}
    				])
    				->contain([
    					'State' => function($q) {
    					return $q
    					->select([
    						'State.state_name'
    					]);
    					}
    				]);
    				}
    			]);
    	
    		},
    		'NotifyMaster'=> function ($q) {
    			return $q
    			->select([
    				'NotifyMaster.id','NotifyMaster.Company_name'
    			])
    			->contain([
    				'CompanySublocation' => function($q) {
    				return $q
    				->select([
    					'CompanySublocation.id','CompanySublocation.sublocation_name','CompanySublocation.postal_code','CompanySublocation.address','CompanySublocation.company_master_id'
    				])
    				->contain([
    					'City' => function($q) {
    					return $q
    					->select([
    						'City.city_name'
    					]);
    					}
    				])
    				->contain([
    					'Countries' => function($q) {
    					return $q
    					->select([
    						'Countries.country_name'
    					]);
    					}
    				])
    				->contain([
    					'State' => function($q) {
    					return $q
    					->select([
    						'State.state_name'
    					]);
    					}
    				]);
    				},
    					/* 'CompanyContactPerson' => function($q) {
    					 return $q
    					->select([
    							'CompanyContactPerson.prefix_name','CompanyContactPerson.first_name','CompanyContactPerson.middle_name','CompanyContactPerson.last_name'
    					]);
    					} */
    			])
    			->contain([
    				'CompanyContactPersons' => function($q){
    				return $q
    				->select([
    					'CompanyContactPersons.id','CompanyContactPersons.prefix_name','CompanyContactPersons.first_name','CompanyContactPersons.middle_name','CompanyContactPersons.last_name','CompanyContactPersons.phone','CompanyContactPersons.mobile','CompanyContactPersons.company_master_id'
    				]);
    				}
    			]);
    	
    		},
    		'BuyerMaster'=> function ($q) {
    			return $q
    			->select([
    				'BuyerMaster.id','BuyerMaster.Company_name'
    			])
    			->contain([
    				'CompanySublocation' => function($q) {
    				return $q
    				->select([
    					'CompanySublocation.id','CompanySublocation.sublocation_name','CompanySublocation.postal_code','CompanySublocation.address','CompanySublocation.company_master_id'
    				])
    				->contain([
    					'City' => function($q) {
    					return $q
    					->select([
    						'City.city_name'
    					]);
    					}
    				])
    				->contain([
    					'Countries' => function($q) {
    					return $q
    					->select([
    						'Countries.country_name'
    					]);
    					}
    				])
    				->contain([
    					'State' => function($q) {
    					return $q
    					->select([
    						'State.state_name'
    					]);
    					}
    				]);
    					},
    					/* 'CompanyContactPerson' => function($q) {
    					 return $q
    					->select([
    							'CompanyContactPerson.prefix_name','CompanyContactPerson.first_name','CompanyContactPerson.middle_name','CompanyContactPerson.last_name'
    					]);
    					} */
    	
    					]);
    			 
    		},
    		'ConsigneeMaster'=> function ($q) {
    			return $q
    			->select([
    				'ConsigneeMaster.id','ConsigneeMaster.Company_name'
    			])
    			->contain([
    				'CompanySublocation' => function($q) {
    				return $q
    				->select([
    					'CompanySublocation.id','CompanySublocation.sublocation_name','CompanySublocation.postal_code','CompanySublocation.address','CompanySublocation.company_master_id'
    				])
    				->contain([
    					'City' => function($q) {
    					return $q
    					->select([
    						'City.city_name'
    					]);
    					}
    				])
    				->contain([
    					'Countries' => function($q) {
    					return $q
    					->select([
    						'Countries.country_name'
    					]);
    					}
    				])
    				->contain([
    					'State' => function($q) {
    					return $q
    					->select([
    						'State.state_name'
    					]);
    					}
    				]);
    				}
    			])
    			->contain([
    				'CompanyContactPersons' => function($q){
    				return $q
    				->select([
    					'CompanyContactPersons.id','CompanyContactPersons.prefix_name','CompanyContactPersons.first_name','CompanyContactPersons.middle_name','CompanyContactPersons.last_name','CompanyContactPersons.phone','CompanyContactPersons.mobile','CompanyContactPersons.company_master_id'
    				]);
    				}
    			]);
    		},
    		'PaymentTerm'=> function ($q) {
    			return $q
    			->select([
    				'PaymentTerm.id','PaymentTerm.term'
    			]);
    		},
    		'DeliveryTerm'=> function ($q) {
    			return $q
    			->select([
    				'DeliveryTerm.id','DeliveryTerm.term'
    			]);
    		},
    		'InvoiceProducts' => function($q) {
    			return $q
    			->select([
    				'InvoiceProducts.id', 'InvoiceProducts.qty', 'InvoiceProducts.invoice_id','InvoiceProducts.marks_nos',
    				'InvoiceProducts.kind_of_pkg','InvoiceProducts.qty','InvoiceProducts.rate','InvoiceProducts.uom_id','InvoiceProducts.currency_id',
    				'InvoiceProducts.amount_wo_tax'
    			])
    			->contain([
    				'Order' => function($q) {
	    				return $q
	    				->select([
	    					'Order.order_no','Order.order_date'
    				]);
    				},
    				'ProductsMaster' => function($q) {
    					return $q
    					->select([
    						'ProductsMaster.id', 'ProductsMaster.product_name', 'ProductsMaster.cas_no', 'ProductsMaster.grade_name','ProductsMaster.cas_no','ProductsMaster.ritc_code','ProductsMaster.hs_code'
    					]);
    				},
    				'Uom' => function($q) {
    					return $q
    					->select([
    						'Uom.id', 'Uom.unit_symbol'
    					]);
    				},
    				'InvoiceProductBoldno' => function($q) {
    					return $q
    					->select([
    						'InvoiceProductBoldno.id', 'bold_number_tran_id','invoice_products_id'
    					])
    					->contain([
    						'BoldNoInventoryTran'=> function ($q) {
    						return $q
    						->select([
    							'id','bold_number_inventory_id','order_id'
    						])
    						->contain([
    							'BoldNumberInventory' => function($q) {
    							return $q
    							->select([
    								'unique_series','from','to'
    							]);
    						}
    						]);
    						}
    					]);
    				},
    				'Currency' => function($q) {
    				return $q
    				->select([
    						'Currency.id', 'Currency.iso_code'
    				]);
    				},
    				'InvoiceTaxes' => function($q) {
    				return $q
    				->select([
    						//'InvoiceTaxes.id', 'InvoiceTaxes.unit_symbol'
    				]);
    				},
    			]);
    		},
    	])
    	->where(['Invoices.id'=>$invoiceId])
    	->toArray();
    	
    	return $invoiceData;
    }
    
    public function exportInvoiceView($invoice_id){
    	$exportInvoiceData = $this->getInvoiceData($invoice_id);
    	
    	$this->loadModel('Countries');
    	$this->loadModel('PortOfDischarge');
    	$countryOfOrigineOfGoods=$this->Countries->find('all',[
    		"Fields"=>["country_name","id"],
    	    "conditions"=>['id'=>$exportInvoiceData['0']->country_origin_goods]
    	])->first();
    	 
    	$countryOfFinalDestination=$this->Countries->find('all',[
    	    "Fields"=>["country_name","id"],
    	    "conditions"=>['id'=>$exportInvoiceData[0]->country_final_destination]
    	])->first();
    	
    	$portOfDischarge=$this->PortOfDischarge->find('all',[
    	    "Fields"=>["port_of_discharge","id"],
    	    "conditions"=>['id'=>$exportInvoiceData[0]->port_of_discharge]
    	])->first();
    	
    	$this->set(compact('exportInvoiceData','countryOfOrigineOfGoods','countryOfFinalDestination','portOfDischarge'));
    	$this->set('_serialize', ['exportInvoiceData']);
    }      
    
    public function localInvoiceView($invoice_id){  
    	
    }
    
    public function exportInvoicePrint(){
    	 
    }
    
    public function localInvoicePrint(){ 
    	
    }
    
}
