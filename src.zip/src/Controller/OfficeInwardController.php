<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Chronos\Date;

/**
 * OfficeInward Controller
 *
 * @property \App\Model\Table\OfficeInwardTable $OfficeInward
 *
 * @method \App\Model\Entity\OfficeInward[] paginate($object = null, array $settings = [])
 */
class OfficeInwardController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        
        $this->paginate = [
            'contain' => ['OwnerCompanies','Users']
        ];
        $officeInward = $this->paginate($this->OfficeInward);
        $this->loadModel('Users');
        $users = $this->Users->find('list', ['keyField'=>'id', 'valueField'=>'userfullname','order'=>'userfullname']);
        
        $this->loadModel('OwnerCompanies');
        $ownerCompanies= $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
        $this->set(compact('officeInward','ownerCompanies','users'));
        $this->set('_serialize', ['officeInward']);
    }

    /**
     * View method
     *
     * @param string|null $id Office Inward id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        
        $officeInward = $this->OfficeInward->get($id, [
            'contain' => ['OwnerCompanies', 'OfficeInwardActivity','Users']
        ]);

        if(isset($this->request->data['forward_to'])){
        $this->loadModel('OfficeInwardActivity');
        $data=array('id'=>$id);
        
        if(isset($this->request->data['forward_to'])){
            $this->request->data['office_inward_activity']['forward_to']= $this->request->data['forward_to'];
        }
        //debug($this->request->data['office_inward_activity']['forward_to']);exit;
        if(isset($this->request->data['status'])){
            $this->request->data['office_inward_activity']['status']= $this->request->data['status'];
        }
        if(isset($this->request->data['comment'])){
            $this->request->data['office_inward_activity']['comment']= $this->request->data['comment'];
        }
        if(isset($this->request->data['office_inward_id'])){
            $this->request->data['office_inward_activity']['office_inward_id']= $this->request->data['office_inward_id'];
        }

        $officeInwardactivity = $this->OfficeInwardActivity->newEntity();

        
        
        $officeInwardActivity = $this->OfficeInwardActivity->patchEntity($officeInwardactivity, $this->request->data);
       
		$officeInwardsInsert = $this->OfficeInward->get($id, [
                'contain' => []
            ]);
			
            $officeInwardInsert = $this->OfficeInward->patchEntity($officeInwardsInsert, $this->request->data);			
			$officeInwardsInsert['document_for']=$this->request->data['office_inward_activity']['forward_to'];
			$officeInwardsInsert['status']=false;
      
          
         if($this->OfficeInwardActivity->save($officeInwardActivity) && $this->OfficeInward->save($officeInwardInsert)){
            $this->Flash->success(__('The office inward has been delivered'));
            return $this->redirect(['action' => 'index']);
        } 
      }
        $this->loadModel('Users');
        $users = $this->Users->find('list', ['keyField'=>'id', 'valueField'=>'userfullname','order'=>'userfullname']);
        $this->set(compact('officeInward', 'ownerCompanies','users'));
        $this->set('_serialize', ['officeInward']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $officeInward = $this->OfficeInward->newEntity();
        if ($this->request->is('post')) {

           // $this->request->data['delivered_date']=date_create($this->request->data['delivered_date']);
            $this->request->data['inward_date']=date_create($this->request->data['inward_date']);
            $this->request->data['created_by']= $this->Auth->user('id');
          
            $company_id=$this->request->data["owner_company_id"];
            $this->loadModel('OfficeInward');
            $maxS_number=$this->OfficeInward->find("list",array(
                'keyField' =>'id','valueField'=>'s_no','order'=>'s_no'
                )
                )->toArray();
               $maxS_no = end($maxS_number);
          
            
             //  debug($maxS_no);exit();
             $this->request->data["s_no"]= $maxS_no+1;
           //  debug($this->request->data["OfficeInward"]["s_no"]);exit();
            $this->loadModel('ReferenceNumberCounter');
            $this->loadComponent('ReferenceNumber');
            $next_ref =
            $this->ReferenceNumber->get_next_ref_number($this->request->data['owner_company_id'],'office_inward');
            
            $this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
            
           // debug($next_ref);exit();
            if(!isset($next_ref['full_next_ref_no'])){
              //  debug($this->request->data);exit();
             
                $this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Inquiry'));
                //return $this->redirect(['action' => 'index']);
            }else{
                
            $officeInward = $this->OfficeInward->patchEntity($officeInward, $this->request->data);
          //  debug($officeInward);exit();
            if ($this->OfficeInward->save($officeInward)) {
                
                $this->Flash->success(__('The {0} has been saved.', 'Office Inward'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Office Inward'));
            }
        }
        }
        $this->loadModel('Users');
        $users = $this->Users->find('list', ['keyField'=>'id', 'valueField'=>'userfullname','order'=>'userfullname']);
        $ownerCompanies = $this->OfficeInward->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('officeInward', 'ownerCompanies','users'));
        $this->set('_serialize', ['officeInward']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Office Inward id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
    $officeInward = $this->OfficeInward->get($this->request->data['id'], [
            'contain' => []
        ]);
        $this->request->data['modified_by']= $this->Auth->user('id');
        if ($this->request->is(['patch', 'post', 'put'])) {
            $this->request->data['modified_by']= $this->Auth->user('id');
            $this->request->data['inward_date']=date_create($this->request->data['inward_date']);
            $officeInward = $this->OfficeInward->patchEntity($officeInward, $this->request->data);
            if ($this->OfficeInward->save($officeInward)) {
                $this->Flash->success(__('The {0} has been saved.', 'Office Inward'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Office Inward'));
            }
        }
        $this->loadModel('Users');
        $users = $this->Users->find('list', ['keyField'=>'id', 'valueField'=>'userfullname','order'=>'userfullname']);
        $ownerCompanies = $this->OfficeInward->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('officeInward', 'ownerCompanies','users'));
        $this->set('_serialize', ['officeInward']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Office Inward id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $officeInward = $this->OfficeInward->get($id);
        if ($this->OfficeInward->delete($officeInward)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Office Inward'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Office Inward'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
