<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ReferenceBom Controller
 *
 * @property \App\Model\Table\ReferenceBomTable $ReferenceBom
 *
 * @method \App\Model\Entity\ReferenceBom[] paginate($object = null, array $settings = [])
 */
class ReferenceBomController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ProductsMaster', 'Materials']
        ];
        $referenceBom = $this->paginate($this->ReferenceBom);

        $this->set(compact('referenceBom'));
        $this->set('_serialize', ['referenceBom']);
    }

    /**
     * View method
     *
     * @param string|null $id Reference Bom id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $referenceBom = $this->ReferenceBom->get($id, [
            'contain' => ['ProductsMaster', 'Materials', 'BatchsheetBom']
        ]);

        $this->set('referenceBom', $referenceBom);
        $this->set('_serialize', ['referenceBom']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $referenceBom = $this->ReferenceBom->newEntity();
        if ($this->request->is('post')) {
            $referenceBom = $this->ReferenceBom->patchEntity($referenceBom, $this->request->data);
            if ($this->ReferenceBom->save($referenceBom)) {
                $this->Flash->success(__('The {0} has been saved.', 'Reference Bom'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Reference Bom'));
            }
        }
        $productsMaster = $this->ReferenceBom->ProductsMaster->find('list', ['limit' => 200]);
        $materials = $this->ReferenceBom->Materials->find('list', ['limit' => 200]);
        $this->set(compact('referenceBom', 'productsMaster', 'materials'));
        $this->set('_serialize', ['referenceBom']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Reference Bom id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $referenceBom = $this->ReferenceBom->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $referenceBom = $this->ReferenceBom->patchEntity($referenceBom, $this->request->data);
            if ($this->ReferenceBom->save($referenceBom)) {
                $this->Flash->success(__('The {0} has been saved.', 'Reference Bom'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Reference Bom'));
            }
        }
        $productsMaster = $this->ReferenceBom->ProductsMaster->find('list', ['limit' => 200]);
        $materials = $this->ReferenceBom->Materials->find('list', ['limit' => 200]);
        $this->set(compact('referenceBom', 'productsMaster', 'materials'));
        $this->set('_serialize', ['referenceBom']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Reference Bom id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $referenceBom = $this->ReferenceBom->get($id);
        if ($this->ReferenceBom->delete($referenceBom)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Reference Bom'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Reference Bom'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
