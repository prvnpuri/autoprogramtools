<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * City Controller
 *
 * @property \App\Model\Table\CityTable $City
 *
 * @method \App\Model\Entity\City[] paginate($object = null, array $settings = [])
 */
class CityController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="City.city_name like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['State'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["city_name","State.state_name"]
    	];

        
       $city = $this->paginate($this->City);
       $this->set("paging",$this->request->getParam("paging"));
        $this->set(compact('city'));
       // $this->set('_serialize', ['city']);
        $this->set( '_serialize', ['city','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id City id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $city = $this->City->get($id, [
            'contain' => ['State']
        ]);

        $this->set('city', $city);
        $this->set('_serialize', ['city']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $city = $this->City->newEntity();
        if ($this->request->is('post')) {
            $city = $this->City->patchEntity($city, $this->request->data,
            		[
            		'associated' => ['State']
            		]
            		);
            if ($this->City->save($city)) {
                $this->Flash->success(__('The {0} has been saved.', 'City'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'City'));
            }
        }
        $state = $this->City->State->find('list',['keyField' => 'id','valueField' => 'state_name','order'=>'state_name'], ['limit' => 200]);
        $this->set(compact('city', 'state'));
        $this->set('_serialize', ['city']);
    }

    /**
     * Edit method
     *
     * @param string|null $id City id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $city = $this->City->get($id, [
            'contain' => ['State']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $city = $this->City->patchEntity($city, $this->request->data);
            if ($this->City->save($city)) {
                $this->Flash->success(__('The {0} has been saved.', 'City'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'City'));
            }
        }
        $state = $this->City->State->find('list',['keyField' => 'id','valueField' => 'state_name','order'=>'state_name'], ['limit' => 200]);
        $this->set(compact('city', 'state'));
        $this->set('_serialize', ['city']);
    }

    /**
     * Delete method
     *
     * @param string|null $id City id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $city = $this->City->get($id);
        if ($this->City->delete($city)) {
            $this->Flash->success(__('The {0} has been deleted.', 'City'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'City'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
