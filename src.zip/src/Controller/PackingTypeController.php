<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PackingType Controller
 *
 * @property \App\Model\Table\PackingTypeTable $PackingType
 *
 * @method \App\Model\Entity\PackingType[] paginate($object = null, array $settings = [])
 */
class PackingTypeController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="PackingType.packing_type like '%$query%'";
    	}
    	$this->paginate = [
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","packing_type"]
    	];
    	
    	
    	$packingType = $this->paginate($this->PackingType);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('packingType'));
    	// $this->set('_serialize', ['city']);
    	$this->set( '_serialize', ['packingType','paging']);
    	
        
    }

    /**
     * View method
     *
     * @param string|null $id Packing Type id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $packingType = $this->PackingType->get($id, [
            'contain' => []
        ]);

        $this->set('packingType', $packingType);
        $this->set('_serialize', ['packingType']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $packingType = $this->PackingType->newEntity();
        if ($this->request->is('post')) {
            $packingType = $this->PackingType->patchEntity($packingType, $this->request->data);
            if ($this->PackingType->save($packingType)) {
                $this->Flash->success(__('The {0} has been saved.', 'Packing Type'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Packing Type'));
            }
        }
        $this->set(compact('packingType'));
        $this->set('_serialize', ['packingType']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Packing Type id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $packingType = $this->PackingType->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
        	$packingType = $this->PackingType->patchEntity($packingType, $this->request->getData());
        	
            if ($this->PackingType->save($packingType)) {
                $this->Flash->success(__('The {0} has been saved.', 'Packing Type'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Packing Type'));
            }
        }
        $this->set(compact('packingType'));
        $this->set('_serialize', ['packingType']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Packing Type id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $packingType = $this->PackingType->get($id);
        if ($this->PackingType->delete($packingType)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Packing Type'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Packing Type'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
