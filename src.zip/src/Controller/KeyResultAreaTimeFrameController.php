<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * KeyResultAreaTimeFrame Controller
 *
 * @property \App\Model\Table\KeyResultAreaTimeFrameTable $KeyResultAreaTimeFrame
 *
 * @method \App\Model\Entity\KeyResultAreaTimeFrame[] paginate($object = null, array $settings = [])
 */
class KeyResultAreaTimeFrameController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['KeyResultAreas']
        ];
        $keyResultAreaTimeFrame = $this->paginate($this->KeyResultAreaTimeFrame);

        $this->set(compact('keyResultAreaTimeFrame'));
        $this->set('_serialize', ['keyResultAreaTimeFrame']);
    }

    /**
     * View method
     *
     * @param string|null $id Key Result Area Time Frame id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $keyResultAreaTimeFrame = $this->KeyResultAreaTimeFrame->get($id, [
            'contain' => ['KeyResultAreas']
        ]);

        $this->set('keyResultAreaTimeFrame', $keyResultAreaTimeFrame);
        $this->set('_serialize', ['keyResultAreaTimeFrame']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $keyResultAreaTimeFrame = $this->KeyResultAreaTimeFrame->newEntity();
        if ($this->request->is('post')) {
            $keyResultAreaTimeFrame = $this->KeyResultAreaTimeFrame->patchEntity($keyResultAreaTimeFrame, $this->request->data);
            if ($this->KeyResultAreaTimeFrame->save($keyResultAreaTimeFrame)) {
                $this->Flash->success(__('The {0} has been saved.', 'Key Result Area Time Frame'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Key Result Area Time Frame'));
            }
        }
        $keyResultAreas = $this->KeyResultAreaTimeFrame->KeyResultAreas->find('list', ['limit' => 200]);
        $this->set(compact('keyResultAreaTimeFrame', 'keyResultAreas'));
        $this->set('_serialize', ['keyResultAreaTimeFrame']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Key Result Area Time Frame id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $keyResultAreaTimeFrame = $this->KeyResultAreaTimeFrame->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $keyResultAreaTimeFrame = $this->KeyResultAreaTimeFrame->patchEntity($keyResultAreaTimeFrame, $this->request->data);
            if ($this->KeyResultAreaTimeFrame->save($keyResultAreaTimeFrame)) {
                $this->Flash->success(__('The {0} has been saved.', 'Key Result Area Time Frame'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Key Result Area Time Frame'));
            }
        }
        $keyResultAreas = $this->KeyResultAreaTimeFrame->KeyResultAreas->find('list', ['limit' => 200]);
        $this->set(compact('keyResultAreaTimeFrame', 'keyResultAreas'));
        $this->set('_serialize', ['keyResultAreaTimeFrame']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Key Result Area Time Frame id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $keyResultAreaTimeFrame = $this->KeyResultAreaTimeFrame->get($id);
        if ($this->KeyResultAreaTimeFrame->delete($keyResultAreaTimeFrame)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Key Result Area Time Frame'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Key Result Area Time Frame'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
