<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanyContactPersons Controller
 *
 * @property \App\Model\Table\CompanyContactPersonsTable $CompanyContactPersons
 *
 * @method \App\Model\Entity\CompanyContactPerson[] paginate($object = null, array $settings = [])
 */
class CompanyContactPersonsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['CompanyMaster']
        ];
        $companyContactPersons = $this->paginate($this->CompanyContactPersons);

        $this->set(compact('companyContactPersons'));
        $this->set('_serialize', ['companyContactPersons']);
    }

    /**
     * View method
     *
     * @param string|null $id Company Contact Person id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companyContactPerson = $this->CompanyContactPersons->get($id, [
            'contain' => ['CompanyMaster']
        ]);

        $this->set('companyContactPerson', $companyContactPerson);
        $this->set('_serialize', ['companyContactPerson']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companyContactPerson = $this->CompanyContactPersons->newEntity();
        if ($this->request->is('post')) {
            $companyContactPerson = $this->CompanyContactPersons->patchEntity($companyContactPerson, $this->request->data);
            if ($this->CompanyContactPersons->save($companyContactPerson)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Contact Person'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Contact Person'));
            }
        }
        $companyMaster = $this->CompanyContactPersons->CompanyMaster->find('list', ['limit' => 200]);
       // $emails = $this->CompanyContactPersons->Emails->find('list', ['limit' => 200]);
        $this->set(compact('companyContactPerson', 'companyMaster'));
        $this->set('_serialize', ['companyContactPerson']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Contact Person id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companyContactPerson = $this->CompanyContactPersons->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companyContactPerson = $this->CompanyContactPersons->patchEntity($companyContactPerson, $this->request->data);
            if ($this->CompanyContactPersons->save($companyContactPerson)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Contact Person'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Contact Person'));
            }
        }
        $companyMaster = $this->CompanyContactPersons->CompanyMaster->find('list', ['limit' => 200]);
       // $emails = $this->CompanyContactPersons->Emails->find('list', ['limit' => 200]);
        $this->set(compact('companyContactPerson', 'companyMaster'));
        $this->set('_serialize', ['companyContactPerson']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Contact Person id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyContactPerson = $this->CompanyContactPersons->get($id);
        if ($this->CompanyContactPersons->delete($companyContactPerson)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Contact Person'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Contact Person'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
