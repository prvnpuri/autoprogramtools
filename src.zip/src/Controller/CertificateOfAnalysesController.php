<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CertificateOfAnalyses Controller
 *
 * @property \App\Model\Table\CertificateOfAnalysesTable $CertificateOfAnalyses
 *
 * @method \App\Model\Entity\CertificateOfAnalysis[] paginate($object = null, array $settings = [])
 */
class CertificateOfAnalysesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Invoices', 'Tests']
        ];
        $certificateOfAnalyses = $this->paginate($this->CertificateOfAnalyses);

        $this->set(compact('certificateOfAnalyses'));
        $this->set('_serialize', ['certificateOfAnalyses']);
    }

    /**
     * View method
     *
     * @param string|null $id Certificate Of Analysis id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $certificateOfAnalysis = $this->CertificateOfAnalyses->get($id, [
            'contain' => ['Orders', 'Invoices', 'Tests']
        ]);

        $this->set('certificateOfAnalysis', $certificateOfAnalysis);
        $this->set('_serialize', ['certificateOfAnalysis']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $certificateOfAnalysis = $this->CertificateOfAnalyses->newEntity();
        if ($this->request->is('post')) {
            $certificateOfAnalysis = $this->CertificateOfAnalyses->patchEntity($certificateOfAnalysis, $this->request->data);
            if ($this->CertificateOfAnalyses->save($certificateOfAnalysis)) {
                $this->Flash->success(__('The {0} has been saved.', 'Certificate Of Analysis'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Certificate Of Analysis'));
            }
        }
        $orders = $this->CertificateOfAnalyses->Orders->find('list', ['limit' => 200]);
        $invoices = $this->CertificateOfAnalyses->Invoices->find('list', ['limit' => 200]);
        $tests = $this->CertificateOfAnalyses->Tests->find('list', ['limit' => 200]);
        $this->set(compact('certificateOfAnalysis', 'orders', 'invoices', 'tests'));
        $this->set('_serialize', ['certificateOfAnalysis']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Certificate Of Analysis id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $certificateOfAnalysis = $this->CertificateOfAnalyses->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $certificateOfAnalysis = $this->CertificateOfAnalyses->patchEntity($certificateOfAnalysis, $this->request->data);
            if ($this->CertificateOfAnalyses->save($certificateOfAnalysis)) {
                $this->Flash->success(__('The {0} has been saved.', 'Certificate Of Analysis'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Certificate Of Analysis'));
            }
        }
        $orders = $this->CertificateOfAnalyses->Orders->find('list', ['limit' => 200]);
        $invoices = $this->CertificateOfAnalyses->Invoices->find('list', ['limit' => 200]);
        $tests = $this->CertificateOfAnalyses->Tests->find('list', ['limit' => 200]);
        $this->set(compact('certificateOfAnalysis', 'orders', 'invoices', 'tests'));
        $this->set('_serialize', ['certificateOfAnalysis']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Certificate Of Analysis id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $certificateOfAnalysis = $this->CertificateOfAnalyses->get($id);
        if ($this->CertificateOfAnalyses->delete($certificateOfAnalysis)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Certificate Of Analysis'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Certificate Of Analysis'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
