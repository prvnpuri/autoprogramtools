<?php
namespace App\Controller;
use Cake\Routing\Router;
use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
/**
 * TestReports Controller
 *
 * @property \App\Model\Table\TestReportsTable $TestReports
 *
 * @method \App\Model\Entity\TestReport[] paginate($object = null, array $settings = [])
 */
class TestReportsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
    	 
    	$condn=array('TestRequest.owner_companies_id'=>$ownercomp);
        $this->paginate = [
        	'conditions'=>$condn,
            'contain' => ['CompanyMaster', 'TestRequestDet', 'Payments','ProductsMaster','lab_name','supplier','TestingMasters','TestRequestDet.TestRequest']
        ];
        $testReports = $this->paginate($this->TestReports);

        $this->set(compact('testReports'));
        $this->set('_serialize', ['testReports']);
    }

    /**
     * View method
     *
     * @param string|null $id Test Report id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $testReport = $this->TestReports->get($id, [
            'contain' => ['TestRequestDet.TestRequest',"Payments",'ProductsMaster','CompanyMaster','TestingMasters']
        ]);

        $this->set('testReport', $testReport);
        $this->set('_serialize', ['testReport']);
        $labs = $this->TestReports->CompanyMaster->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions'=>['CompanyMaster.id' => $testReport ->test_request_det->lab_id],
        		'order' => ['CompanyMaster.id' => 'ASC']
        ]);
        $labs = $labs->first();
        $this->set('labs', $labs);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($test_request_det_id=null,$redirectFrom=null)
    {
    	
    	
        $testReport = $this->TestReports->newEntity();
        if ($this->request->is('post')) {
        	
            $testReport = $this->TestReports->patchEntity($testReport, $this->request->data);
            if(isset($this->request->data["test_result"]) &&  $this->request->data["test_result"]["error"]==0){
            	$filename=$this->request->data["test_result"]["name"];
            	$testReport["test_result"]=$filename;
            }else{
            	unset($this->request->data["test_result"]);
            }
            $testReport['created_by'] = $this->Auth->User('id');
              if ($this->TestReports->save($testReport)) {
            	if(isset($this->request->data['test_request_det_id'])){
            		$productDataTest = $this->TestReports->TestRequestDet->find('all', [
            				'conditions'=>['TestRequestDet.id' => $test_request_det_id],
            		]);
            		$test_dt_request_detail = $productDataTest->first();
            		$request_id = $test_dt_request_detail['test_request_id'];
            		$this->requestStatusUpdate($request_id);
            	}

            	
            	if(isset($this->request->data["test_result"]) &&  $this->request->data["test_result"]["error"]==0){
            		$id= $testReport["id"];
            		$filename=$id."_".$this->request->data["test_result"]["name"];
            		$url = Router::url('/',true).'upload/test-reports/'.$filename;
            		$uploadpath = 'upload/test-reports/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["test_result"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["msds_attachment"]);
            	}
            	
            	if(isset($this->request->data['amount']) && $this->request->data['amount'] != Null){
            		$data['payment_head_id']='1';
            		$data['description']=$this->request->data['description'];
            		$data['bill_no']=$this->request->data['bill_no'];
            		$data['amount']=$this->request->data['amount'];
            		$data['created_by'] = $this->Auth->User('id');
            		if(isset($this->request->data['bill_date']) && $this->request->data['bill_date'] != Null){
            			$data['bill_date']=$this->request->data['bill_date'];
            		}else{
            			$data['bill_date']=date('Y-m-d H:i:s');
            		}
            			$this->loadModel('Payments');
            			$payment = $this->Payments->newEntity();
            			$payment = $this->Payments->patchEntity($payment, $data);
            			//debug($payments);exit;
            			$this->Payments->save($payment);
            			
            			$connection = ConnectionManager::get('default');
            			$connection->update('test_reports', ['payments_id' => $payment->id], ['id' => $testReport["id"]]);
            			
            	}
            	
                $this->Flash->success(__('The {0} has been saved.', 'Test Report'));
                return $this->redirect(['controller'=>'test-request','action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Report'));
            }
        }
        $this->loadModel('TestRequestDet');
        $this->loadModel('ProductsMaster');
        $this->loadModel('CompanyMaster');
        $this->loadModel('TestingMasters');
        $this->loadModel('LabMaster');
        
        $TestRequesDet = $this->TestRequestDet->get($test_request_det_id, [
        		'contain' => ['TestRequest','TestRequest.ProductsMaster','CompanyMaster']
        ]);

        
        $suppliers = $this->CompanyMaster->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions'=>['CompanyMaster.id' => $TestRequesDet->test_request->manufacturer_by],
        		'order' => ['CompanyMaster.id' => 'ASC']
        ]);
        $suppliers = $suppliers->first();
        
        $testname = $this->TestingMasters->find('list', [
        		'keyField' => 'id',
        		'valueField' => 'test_name',
        		'order' => ['TestingMasters.test_name' => 'ASC']
        ]);
        
        
        $this->set(compact('testname','TestRequesDet','testReport', 'suppliers'));
        $this->set('_serialize', ['testReport']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Test Report id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null,$redirectFrom=null)
    {
        $testReport = $this->TestReports->get($id, [
            'contain' => ['TestRequestDet.TestReports','TestRequestDet.TestRequest',"Payments"]
        ]);
        
        
        if ($this->request->is(['patch', 'post', 'put'])) {
        	if(empty($this->request->data['test_result']['name'])){
        		unset($this->request->data['test_result']);
        	}
        	
        	
        	
            $testReport = $this->TestReports->patchEntity($testReport, $this->request->data);
            
            if(isset($this->request->data["test_result"]) &&  $this->request->data["test_result"]["error"]==0){
            	$filename=$this->request->data["test_result"]["name"];
            	$testReport["test_result"]=$filename;
            }else{
            	unset($this->request->data["test_result"]);
            }
            $testReport['modified_by'] = $this->Auth->User('id');
           // print "<pre>";print_r($this->request->data);print "</pre>"; exit;
            if ($this->TestReports->save($testReport)) {
            	$this->requestStatusUpdate($testReport->test_request_det->test_request_id);

            	if(isset($this->request->data["test_result"]) &&  $this->request->data["test_result"]["error"]==0){
            	
            	$id= $testReport["id"];
            	$filename=$id."_".$this->request->data["test_result"]["name"];
            	$url = Router::url('/',true).'upload/test-reports/'.$filename;
            	$uploadpath = 'upload/test-reports/';
            	$uploadfile = $uploadpath.$filename;
            	move_uploaded_file($this->request->data["test_result"]['tmp_name'], $uploadfile);         	
            	}
            	
            	
            	if(isset($this->request->data['amount']) && $this->request->data['amount'] != Null){
            		$data['id']=$testReport->payments_id;
            		$data['payment_head_id']='1';
            		$data['description']=$this->request->data['description'];
            		$data['bill_no']=$this->request->data['bill_no'];
            		$data['amount']=$this->request->data['amount'];
            		$data['modified_by'] = $this->Auth->User('id');
            		if(isset($this->request->data['bill_date']) && $this->request->data['bill_date'] != Null){
            			$data['bill_date']=$this->request->data['bill_date'];
            		}else{
            			$data['bill_date']=date('Y-m-d H:i:s');
            		}
            		$this->loadModel('Payments');
            		$payment = $this->Payments->get($testReport->payments_id, [
            				'contain' => []
            		]);
            		$payment = $this->Payments->patchEntity($payment, $data);
            		//debug($payments);exit;
            		$this->Payments->save($payment);
            		  
            	}
            	
            	
            	
                $this->Flash->success(__('The {0} has been saved.', 'Test Report'));
                
                
                if(isset($redirectFrom) && $redirectFrom="test-request"){
                	return $this->redirect(array( "controller"=>"TestRequest", 'action' => 'index'));
                }
                
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Report'));
            }
        }
       $products = $this->TestReports->ProductsMaster->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'product_name',
        		'conditions'=>['ProductsMaster.id' => $testReport->product_master_id],
        		'order' => ['ProductsMaster.id' => 'ASC']
        ]);
        $productsMaster = $products->first();
        
        
        $suppliers = $this->TestReports->CompanyMaster->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions'=>['CompanyMaster.id' => $testReport->test_request_det->test_request->manufacturer_by],
        		'order' => ['CompanyMaster.id' => 'ASC']
        ]);
        $suppliers = $suppliers->first();
        
        $this->loadModel('TestingMasters');
        $testname = $this->TestingMasters->find('list', [
        		'keyField' => 'id',
        		'valueField' => 'test_name',
        		'order' => ['TestingMasters.test_name' => 'ASC']
        ]);
        
        $labs = $this->TestReports->CompanyMaster->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions'=>['CompanyMaster.id' => $testReport ->test_request_det->lab_id],
        		'order' => ['CompanyMaster.id' => 'ASC']
        ]);
        $labs = $labs->first();
        
        
       //$testRequestDet = $this->TestReports->TestRequestDet->find('list', ['limit' => 200]);
       // $labMaster = $this->TestReports->LabMaster->find('list', ['limit' => 200]);
       // $payments = $this->TestReports->Payments->find('list', ['limit' => 200]);
        $this->set(compact('labs','testname','testReport', 'productsMaster', 'suppliers', 'testRequestDet', 'labMaster', 'payments'));
        $this->set('_serialize', ['testReport']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Test Report id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $testReport = $this->TestReports->get($id);
        if ($this->TestReports->delete($testReport)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Test Report'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Test Report'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    public function requestStatusUpdate($id){
    	$this->loadModel('TestRequest');
    	$testRequests = $this->TestRequest->get($id, [
    			'contain' => ['TestRequestDet','TestRequestDet.TestReports']
    	]);
    	
    	$counter=0;
    	$counter2=0;
    	foreach ($testRequests['test_request_det'] as $testRequest){
    		if($testRequest['lab_id']!=''){
    			$counter++;
    		}
    
    	}
    	
    	foreach ($testRequests['test_request_det'] as $testRequest){
    		if(isset($testRequest['test_reports'][0]['id'])) {
    			$counter2++;
    		}
    
    	}
    	//debug($counter);
    	//debug($counter2);
        //debug($testRequests);exit;
    	if($counter==$counter2){
    		$data = array('id' => $testRequests->id , 'isCompletedStatus' => 1);
    		 
    		$testReq = $this->TestRequest->get($testRequests->id, [
    				'contain' => []
    		]);
    		$testReq = $this->TestRequest->patchEntity($testReq, $data);
    		$this->TestRequest->save($testReq);

    	}
    
    }
}
