<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PortOfDischarge Controller
 *
 * @property \App\Model\Table\PortOfDischargeTable $PortOfDischarge
 *
 * @method \App\Model\Entity\PortOfDischarge[] paginate($object = null, array $settings = [])
 */
class PortOfDischargeController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="PortOfDischarge.port_of_discharge like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['Countries'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","port_of_discharge","Countries.country_name"]
    	];
    	
    	
    	$portOfDischarge = $this->paginate($this->PortOfDischarge);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('portOfDischarge'));
    	$this->set( '_serialize', ['portOfDischarge','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Port Of Discharge id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $portOfDischarge = $this->PortOfDischarge->get($id, [
            'contain' => ['Countries']
        ]);

        $this->set('portOfDischarge', $portOfDischarge);
        $this->set('_serialize', ['portOfDischarge']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $portOfDischarge = $this->PortOfDischarge->newEntity();
        if ($this->request->is('post')) {
            $portOfDischarge = $this->PortOfDischarge->patchEntity($portOfDischarge, $this->request->data);
            if ($this->PortOfDischarge->save($portOfDischarge)) {
                $this->Flash->success(__('The {0} has been saved.', 'Port Of Discharge'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Port Of Discharge'));
            }
        }
        $countries = $this->PortOfDischarge->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name'], ['limit' => 200]);
        $this->set(compact('portOfDischarge', 'countries'));
        $this->set('_serialize', ['portOfDischarge']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Port Of Discharge id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $portOfDischarge = $this->PortOfDischarge->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $portOfDischarge = $this->PortOfDischarge->patchEntity($portOfDischarge, $this->request->data);
            if ($this->PortOfDischarge->save($portOfDischarge)) {
                $this->Flash->success(__('The {0} has been saved.', 'Port Of Discharge'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Port Of Discharge'));
            }
        }
        $countries = $this->PortOfDischarge->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name'], ['limit' => 200]);
        $this->set(compact('portOfDischarge', 'countries'));
        $this->set('_serialize', ['portOfDischarge']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Port Of Discharge id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $portOfDischarge = $this->PortOfDischarge->get($id);
        if ($this->PortOfDischarge->delete($portOfDischarge)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Port Of Discharge'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Port Of Discharge'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
