<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PreShipmentInsurance Controller
 *
 * @property \App\Model\Table\PreShipmentInsuranceTable $PreShipmentInsurance
 *
 * @method \App\Model\Entity\PreShipmentInsurance[] paginate($object = null, array $settings = [])
 */
class PreShipmentInsuranceController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'Currencies']
        ];
        $preShipmentInsurance = $this->paginate($this->PreShipmentInsurance);

        $this->set(compact('preShipmentInsurance'));
        $this->set('_serialize', ['preShipmentInsurance']);
    }

    /**
     * View method
     *
     * @param string|null $id Pre Shipment Insurance id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $preShipmentInsurance = $this->PreShipmentInsurance->get($id, [
            'contain' => ['Invoices', 'Currencies']
        ]);

        $this->set('preShipmentInsurance', $preShipmentInsurance);
        $this->set('_serialize', ['preShipmentInsurance']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $preShipmentInsurance = $this->PreShipmentInsurance->newEntity();
        if ($this->request->is('post')) {
            $preShipmentInsurance = $this->PreShipmentInsurance->patchEntity($preShipmentInsurance, $this->request->data);
            if ($this->PreShipmentInsurance->save($preShipmentInsurance)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Insurance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Insurance'));
            }
        }
        $invoices = $this->PreShipmentInsurance->Invoices->find('list', ['limit' => 200]);
        $currencies = $this->PreShipmentInsurance->Currencies->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentInsurance', 'invoices', 'currencies'));
        $this->set('_serialize', ['preShipmentInsurance']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Pre Shipment Insurance id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $preShipmentInsurance = $this->PreShipmentInsurance->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $preShipmentInsurance = $this->PreShipmentInsurance->patchEntity($preShipmentInsurance, $this->request->data);
            if ($this->PreShipmentInsurance->save($preShipmentInsurance)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Insurance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Insurance'));
            }
        }
        $invoices = $this->PreShipmentInsurance->Invoices->find('list', ['limit' => 200]);
        $currencies = $this->PreShipmentInsurance->Currencies->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentInsurance', 'invoices', 'currencies'));
        $this->set('_serialize', ['preShipmentInsurance']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Pre Shipment Insurance id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $preShipmentInsurance = $this->PreShipmentInsurance->get($id);
        if ($this->PreShipmentInsurance->delete($preShipmentInsurance)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Pre Shipment Insurance'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Pre Shipment Insurance'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
