<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OwnerContactPersons Controller
 *
 * @property \App\Model\Table\OwnerContactPersonsTable $OwnerContactPersons
 *
 * @method \App\Model\Entity\OwnerContactPerson[] paginate($object = null, array $settings = [])
 */
class OwnerContactPersonsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users', 'OwnerCompanies']
        ];
        $ownerContactPersons = $this->paginate($this->OwnerContactPersons);

        $this->set(compact('ownerContactPersons'));
        $this->set('_serialize', ['ownerContactPersons']);
    }

    /**
     * View method
     *
     * @param string|null $id Owner Contact Person id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ownerContactPerson = $this->OwnerContactPersons->get($id, [
            'contain' => ['Users', 'OwnerCompanies']
        ]);

        $this->set('ownerContactPerson', $ownerContactPerson);
        $this->set('_serialize', ['ownerContactPerson']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ownerContactPerson = $this->OwnerContactPersons->newEntity();
        if ($this->request->is('post')) {
            $ownerContactPerson = $this->OwnerContactPersons->patchEntity($ownerContactPerson, $this->request->data);
            if ($this->OwnerContactPersons->save($ownerContactPerson)) {
                $this->Flash->success(__('The {0} has been saved.', 'Owner Contact Person'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Owner Contact Person'));
            }
        }
        $users = $this->OwnerContactPersons->Users->find('list', ['limit' => 200]);
        $ownerCompanies = $this->OwnerContactPersons->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('ownerContactPerson', 'users', 'ownerCompanies'));
        $this->set('_serialize', ['ownerContactPerson']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Owner Contact Person id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ownerContactPerson = $this->OwnerContactPersons->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ownerContactPerson = $this->OwnerContactPersons->patchEntity($ownerContactPerson, $this->request->data);
            if ($this->OwnerContactPersons->save($ownerContactPerson)) {
                $this->Flash->success(__('The {0} has been saved.', 'Owner Contact Person'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Owner Contact Person'));
            }
        }
        $users = $this->OwnerContactPersons->Users->find('list', ['limit' => 200]);
        $ownerCompanies = $this->OwnerContactPersons->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('ownerContactPerson', 'users', 'ownerCompanies'));
        $this->set('_serialize', ['ownerContactPerson']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Owner Contact Person id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ownerContactPerson = $this->OwnerContactPersons->get($id);
        if ($this->OwnerContactPersons->delete($ownerContactPerson)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Owner Contact Person'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Owner Contact Person'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
