<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * DeliveryChallanEwayBillPhoto Controller
 *
 * @property \App\Model\Table\DeliveryChallanEwayBillPhotoTable $DeliveryChallanEwayBillPhoto
 *
 * @method \App\Model\Entity\DeliveryChallanEwayBillPhoto[] paginate($object = null, array $settings = [])
 */
class DeliveryChallanEwayBillPhotoController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'DeliveryChallans']
        ];
        $deliveryChallanEwayBillPhoto = $this->paginate($this->DeliveryChallanEwayBillPhoto);

        $this->set(compact('deliveryChallanEwayBillPhoto'));
        $this->set('_serialize', ['deliveryChallanEwayBillPhoto']);
    }

    /**
     * View method
     *
     * @param string|null $id Delivery Challan Eway Bill Photo id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $deliveryChallanEwayBillPhoto = $this->DeliveryChallanEwayBillPhoto->get($id, [
            'contain' => ['Invoices', 'DeliveryChallans']
        ]);

        $this->set('deliveryChallanEwayBillPhoto', $deliveryChallanEwayBillPhoto);
        $this->set('_serialize', ['deliveryChallanEwayBillPhoto']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $deliveryChallanEwayBillPhoto = $this->DeliveryChallanEwayBillPhoto->newEntity();
        if ($this->request->is('post')) {
            $deliveryChallanEwayBillPhoto = $this->DeliveryChallanEwayBillPhoto->patchEntity($deliveryChallanEwayBillPhoto, $this->request->data);
            if ($this->DeliveryChallanEwayBillPhoto->save($deliveryChallanEwayBillPhoto)) {
                $this->Flash->success(__('The {0} has been saved.', 'Delivery Challan Eway Bill Photo'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Delivery Challan Eway Bill Photo'));
            }
        }
        $invoices = $this->DeliveryChallanEwayBillPhoto->Invoices->find('list', ['limit' => 200]);
        $deliveryChallans = $this->DeliveryChallanEwayBillPhoto->DeliveryChallans->find('list', ['limit' => 200]);
        $this->set(compact('deliveryChallanEwayBillPhoto', 'invoices', 'deliveryChallans'));
        $this->set('_serialize', ['deliveryChallanEwayBillPhoto']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Delivery Challan Eway Bill Photo id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $deliveryChallanEwayBillPhoto = $this->DeliveryChallanEwayBillPhoto->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $deliveryChallanEwayBillPhoto = $this->DeliveryChallanEwayBillPhoto->patchEntity($deliveryChallanEwayBillPhoto, $this->request->data);
            if ($this->DeliveryChallanEwayBillPhoto->save($deliveryChallanEwayBillPhoto)) {
                $this->Flash->success(__('The {0} has been saved.', 'Delivery Challan Eway Bill Photo'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Delivery Challan Eway Bill Photo'));
            }
        }
        $invoices = $this->DeliveryChallanEwayBillPhoto->Invoices->find('list', ['limit' => 200]);
        $deliveryChallans = $this->DeliveryChallanEwayBillPhoto->DeliveryChallans->find('list', ['limit' => 200]);
        $this->set(compact('deliveryChallanEwayBillPhoto', 'invoices', 'deliveryChallans'));
        $this->set('_serialize', ['deliveryChallanEwayBillPhoto']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Delivery Challan Eway Bill Photo id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $deliveryChallanEwayBillPhoto = $this->DeliveryChallanEwayBillPhoto->get($id);
        if ($this->DeliveryChallanEwayBillPhoto->delete($deliveryChallanEwayBillPhoto)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Delivery Challan Eway Bill Photo'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Delivery Challan Eway Bill Photo'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
