<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CustomerSatisfactionSurvey Controller
 *
 * @property \App\Model\Table\CustomerSatisfactionSurveyTable $CustomerSatisfactionSurvey
 *
 * @method \App\Model\Entity\CustomerSatisfactionSurvey[] paginate($object = null, array $settings = [])
 */
class CustomerSatisfactionSurveyController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Companies', 'OwnerCompanies']
        ];
        $customerSatisfactionSurvey = $this->paginate($this->CustomerSatisfactionSurvey);

        $this->set(compact('customerSatisfactionSurvey'));
        $this->set('_serialize', ['customerSatisfactionSurvey']);
    }

    /**
     * View method
     *
     * @param string|null $id Customer Satisfaction Survey id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $customerSatisfactionSurvey = $this->CustomerSatisfactionSurvey->get($id, [
            'contain' => ['Companies', 'OwnerCompanies']
        ]);

        $this->set('customerSatisfactionSurvey', $customerSatisfactionSurvey);
        $this->set('_serialize', ['customerSatisfactionSurvey']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $customerSatisfactionSurvey = $this->CustomerSatisfactionSurvey->newEntity();
        if ($this->request->is('post')) {
            $customerSatisfactionSurvey = $this->CustomerSatisfactionSurvey->patchEntity($customerSatisfactionSurvey, $this->request->data);
            if ($this->CustomerSatisfactionSurvey->save($customerSatisfactionSurvey)) {
                $this->Flash->success(__('The {0} has been saved.', 'Customer Satisfaction Survey'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Customer Satisfaction Survey'));
            }
        }
        $companies = $this->CustomerSatisfactionSurvey->Companies->find('list', ['limit' => 200]);
        $ownerCompanies = $this->CustomerSatisfactionSurvey->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('customerSatisfactionSurvey', 'companies', 'ownerCompanies'));
        $this->set('_serialize', ['customerSatisfactionSurvey']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Customer Satisfaction Survey id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $customerSatisfactionSurvey = $this->CustomerSatisfactionSurvey->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $customerSatisfactionSurvey = $this->CustomerSatisfactionSurvey->patchEntity($customerSatisfactionSurvey, $this->request->data);
            if ($this->CustomerSatisfactionSurvey->save($customerSatisfactionSurvey)) {
                $this->Flash->success(__('The {0} has been saved.', 'Customer Satisfaction Survey'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Customer Satisfaction Survey'));
            }
        }
        $companies = $this->CustomerSatisfactionSurvey->Companies->find('list', ['limit' => 200]);
        $ownerCompanies = $this->CustomerSatisfactionSurvey->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('customerSatisfactionSurvey', 'companies', 'ownerCompanies'));
        $this->set('_serialize', ['customerSatisfactionSurvey']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Customer Satisfaction Survey id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $customerSatisfactionSurvey = $this->CustomerSatisfactionSurvey->get($id);
        if ($this->CustomerSatisfactionSurvey->delete($customerSatisfactionSurvey)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Customer Satisfaction Survey'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Customer Satisfaction Survey'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
