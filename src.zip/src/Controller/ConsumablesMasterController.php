<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
/**
 * ConsumablesMaster Controller
 *
 * @property \App\Model\Table\ConsumablesMasterTable $ConsumablesMaster
 *
 * @method \App\Model\Entity\ConsumablesMaster[] paginate($object = null, array $settings = [])
 */
class ConsumablesMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */

    
    public function index()
    {
    	 
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="ConsumablesMaster.product_name like '%$query%'";
    	}
    	$this->paginate = [
    			"conditions" => $conditions,
    			"sortWhitelist"=>["product_name","classification","description","type"]
    	];
    
    
    	$consumablesMaster = $this->paginate($this->ConsumablesMaster);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('consumablesMaster'));
    	// $this->set('_serialize', ['city']);
    	$this->set( '_serialize', ['consumablesMaster','paging']);
    }
    

    /**
     * View method
     *
     * @param string|null $id Consumables Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $consumablesMaster = $this->ConsumablesMaster->get($id, [
            
        ]);

        $this->set('consumablesMaster', $consumablesMaster);
        $this->set('_serialize', ['consumablesMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $consumablesMaster = $this->ConsumablesMaster->newEntity();
        if ($this->request->is('post')) {
            $consumablesMaster = $this->ConsumablesMaster->patchEntity($consumablesMaster, $this->request->data);
            $consumablesMaster['created_by'] = $this->Auth->User('id');
            //echo '<pre>';print_r($consumablesMaster);die;
            if ($this->ConsumablesMaster->save($consumablesMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Consumable'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Consumable'));
            }
        }
        $this->set(compact('consumablesMaster'));
        $this->set('_serialize', ['consumablesMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Consumables Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $consumablesMaster = $this->ConsumablesMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $consumablesMaster = $this->ConsumablesMaster->patchEntity($consumablesMaster, $this->request->data);
            $consumablesMaster['created_by'] = $this->Auth->User('id');
            if ($this->ConsumablesMaster->save($consumablesMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Consumable'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Consumable'));
            }
        }
        $this->set(compact('consumablesMaster'));
        $this->set('_serialize', ['consumablesMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Consumables Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $consumablesMaster = $this->ConsumablesMaster->get($id);
        if ($this->ConsumablesMaster->delete($consumablesMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Consumable'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Consumable'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
