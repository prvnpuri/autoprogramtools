<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Application Controller
 *
 * @property \App\Model\Table\ApplicationTable $Application
 *
 * @method \App\Model\Entity\Application[] paginate($object = null, array $settings = [])
 */
class ApplicationController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => []
        ];
        $application = $this->paginate($this->Application);

        $this->set(compact('application'));
        $this->set('_serialize', ['application']);
    }

    /**
     * View method
     *
     * @param string|null $id Application id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $application = $this->Application->get($id, [
            'contain' => []
        ]);

        $this->set('application', $application);
        $this->set('_serialize', ['application']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $application = $this->Application->newEntity();
        if ($this->request->is('post')) {
            $application = $this->Application->patchEntity($application, $this->request->data);
            if ($this->Application->save($application)) {
                $this->Flash->success(__('The {0} has been saved.', 'Application'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Application'));
            }
        }
        $this->set(compact('application'));
        $this->set('_serialize', ['application']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Application id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $application = $this->Application->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $application = $this->Application->patchEntity($application, $this->request->data);
            if ($this->Application->save($application)) {
                $this->Flash->success(__('The {0} has been saved.', 'Application'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Application'));
            }
        }
       
        $this->set(compact('application'));
        $this->set('_serialize', ['application']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Application id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $application = $this->Application->get($id);
        if ($this->Application->delete($application)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Application'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Application'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
