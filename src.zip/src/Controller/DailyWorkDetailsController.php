<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * DailyWorkDetails Controller
 *
 * @property \App\Model\Table\DailyWorkDetailsTable $DailyWorkDetails
 *
 * @method \App\Model\Entity\DailyWorkDetail[] paginate($object = null, array $settings = [])
 */
class DailyWorkDetailsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['DailyWorks', 'KeyResultAreas']
        ];
        $dailyWorkDetails = $this->paginate($this->DailyWorkDetails);

        $this->set(compact('dailyWorkDetails'));
        $this->set('_serialize', ['dailyWorkDetails']);
    }

    /**
     * View method
     *
     * @param string|null $id Daily Work Detail id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $dailyWorkDetail = $this->DailyWorkDetails->get($id, [
            'contain' => ['DailyWorks', 'KeyResultAreas']
        ]);

        $this->set('dailyWorkDetail', $dailyWorkDetail);
        $this->set('_serialize', ['dailyWorkDetail']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $dailyWorkDetail = $this->DailyWorkDetails->newEntity();
        if ($this->request->is('post')) {
            $dailyWorkDetail = $this->DailyWorkDetails->patchEntity($dailyWorkDetail, $this->request->data);
            if ($this->DailyWorkDetails->save($dailyWorkDetail)) {
                $this->Flash->success(__('The {0} has been saved.', 'Daily Work Detail'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Daily Work Detail'));
            }
        }
        $dailyWorks = $this->DailyWorkDetails->DailyWorks->find('list', ['limit' => 200]);
        $keyResultAreas = $this->DailyWorkDetails->KeyResultAreas->find('list', ['limit' => 200]);
        $this->set(compact('dailyWorkDetail', 'dailyWorks', 'keyResultAreas'));
        $this->set('_serialize', ['dailyWorkDetail']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Daily Work Detail id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $dailyWorkDetail = $this->DailyWorkDetails->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $dailyWorkDetail = $this->DailyWorkDetails->patchEntity($dailyWorkDetail, $this->request->data);
            if ($this->DailyWorkDetails->save($dailyWorkDetail)) {
                $this->Flash->success(__('The {0} has been saved.', 'Daily Work Detail'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Daily Work Detail'));
            }
        }
        $dailyWorks = $this->DailyWorkDetails->DailyWorks->find('list', ['limit' => 200]);
        $keyResultAreas = $this->DailyWorkDetails->KeyResultAreas->find('list', ['limit' => 200]);
        $this->set(compact('dailyWorkDetail', 'dailyWorks', 'keyResultAreas'));
        $this->set('_serialize', ['dailyWorkDetail']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Daily Work Detail id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $dailyWorkDetail = $this->DailyWorkDetails->get($id);
        if ($this->DailyWorkDetails->delete($dailyWorkDetail)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Daily Work Detail'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Daily Work Detail'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
