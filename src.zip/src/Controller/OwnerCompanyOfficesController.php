<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OwnerCompanyOffices Controller
 *
 * @property \App\Model\Table\OwnerCompanyOfficesTable $OwnerCompanyOffices
 *
 * @method \App\Model\Entity\OwnerCompanyOffice[] paginate($object = null, array $settings = [])
 */
class OwnerCompanyOfficesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanies','City','State','Countries']
        ];
        $ownerCompanyOffices = $this->paginate($this->OwnerCompanyOffices);

        $this->set(compact('ownerCompanyOffices'));
        $this->set('_serialize', ['ownerCompanyOffices']);
    }

    /**
     * View method
     *
     * @param string|null $id Owner Company Office id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ownerCompanyOffice = $this->OwnerCompanyOffices->get($id, [
            'contain' => ['OwnerCompanies', 'PreShipmentBase','City','State']
        ]);

        $this->set('ownerCompanyOffice', $ownerCompanyOffice);
        $this->set('_serialize', ['ownerCompanyOffice']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ownerCompanyOffice = $this->OwnerCompanyOffices->newEntity();
        if ($this->request->is('post')) {
            $ownerCompanyOffice = $this->OwnerCompanyOffices->patchEntity($ownerCompanyOffice, $this->request->data);
            if ($this->OwnerCompanyOffices->save($ownerCompanyOffice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Owner Company Office'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Owner Company Office'));
            }
        }
        $ownerCompanies = $this->OwnerCompanyOffices->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('ownerCompanyOffice', 'ownerCompanies'));
        $this->set('_serialize', ['ownerCompanyOffice']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Owner Company Office id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ownerCompanyOffice = $this->OwnerCompanyOffices->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ownerCompanyOffice = $this->OwnerCompanyOffices->patchEntity($ownerCompanyOffice, $this->request->data);
            if ($this->OwnerCompanyOffices->save($ownerCompanyOffice)) {
                $this->Flash->success(__('The {0} has been saved.', 'Owner Company Office'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Owner Company Office'));
            }
        }
        $ownerCompanies = $this->OwnerCompanyOffices->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('ownerCompanyOffice', 'ownerCompanies'));
        $this->set('_serialize', ['ownerCompanyOffice']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Owner Company Office id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ownerCompanyOffice = $this->OwnerCompanyOffices->get($id);
        if ($this->OwnerCompanyOffices->delete($ownerCompanyOffice)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Owner Company Office'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Owner Company Office'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
