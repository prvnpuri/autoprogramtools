<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * FinancialYearMaster Controller
 *
 * @property \App\Model\Table\FinancialYearMasterTable $FinancialYearMaster
 *
 * @method \App\Model\Entity\FinancialYearMaster[] paginate($object = null, array $settings = [])
 */
class FinancialYearMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="FinancialYearMaster.start_date like '%$query%'";
    	}
    	$this->paginate = [
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","start_date","end_date","year_code","current_year"]
    	];
    	
    	$financialYearMaster = $this->paginate($this->FinancialYearMaster);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('financialYearMaster'));
    	$this->set( '_serialize', ['financialYearMaster','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Financial Year Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $financialYearMaster = $this->FinancialYearMaster->get($id, [
            'contain' => []
        ]);

        $this->set('financialYearMaster', $financialYearMaster);
        $this->set('_serialize', ['financialYearMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $financialYearMaster = $this->FinancialYearMaster->newEntity();
        if ($this->request->is('post')) {
            $financialYearMaster = $this->FinancialYearMaster->patchEntity($financialYearMaster, $this->request->data);
            if ($this->FinancialYearMaster->save($financialYearMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Financial Year Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Financial Year Master'));
            }
        }
        $this->set(compact('financialYearMaster'));
        $this->set('_serialize', ['financialYearMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Financial Year Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $financialYearMaster = $this->FinancialYearMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $financialYearMaster = $this->FinancialYearMaster->patchEntity($financialYearMaster, $this->request->data);
            if ($this->FinancialYearMaster->save($financialYearMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Financial Year Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Financial Year Master'));
            }
        }
        $this->set(compact('financialYearMaster'));
        $this->set('_serialize', ['financialYearMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Financial Year Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $financialYearMaster = $this->FinancialYearMaster->get($id);
        if ($this->FinancialYearMaster->delete($financialYearMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Financial Year Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Financial Year Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
