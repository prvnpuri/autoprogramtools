<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TaxMaster Controller
 *
 * @property \App\Model\Table\TaxMasterTable $TaxMaster
 *
 * @method \App\Model\Entity\TaxMaster[] paginate($object = null, array $settings = [])
 */
class TaxMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="TaxMaster.tax_name like '%$query%'";
    	}
    	$this->paginate = [
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","tax_name","rate",'_applicability']
    	];
    	
    	$taxMasterQuery=$this->TaxMaster->query()->select(['id',"tax_name","rate",
    	    '_applicability'=>$this->TaxMaster->query()->func()->concat([ "CASE `applicability` WHEN 2 THEN  'INETER STATE' WHEN 1 THEN 'LOCAL' ELSE 'EXPORT' END "=>'literal']) 
    	]);
    	$taxMaster = $this->paginate($taxMasterQuery);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('taxMaster'));
    	$this->set( '_serialize', ['taxMaster','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Tax Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $taxMaster = $this->TaxMaster->get($id, [
            'contain' => ['OwnerCompanies']
        ]);

        $this->set('taxMaster', $taxMaster);
        $this->set('_serialize', ['taxMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $taxMaster = $this->TaxMaster->newEntity();
        if ($this->request->is('post')) {
            $taxMaster = $this->TaxMaster->patchEntity($taxMaster, $this->request->data);
            
            $taxMaster['created_by'] = $this->Auth->User('id');
            if ($this->TaxMaster->save($taxMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Tax Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Tax Master'));
            }
        }
        
        $this->loadModel('OwnerCompanies');
        $owner_company = $this->OwnerCompanies->find('list',['keyField'=>'id','valueField'=>'Company_name']);
        $this->set(compact('taxMaster','owner_company'));
        $this->set('_serialize', ['taxMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Tax Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $taxMaster = $this->TaxMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $taxMaster = $this->TaxMaster->patchEntity($taxMaster, $this->request->data);
            $taxMaster['modified_by'] = $this->Auth->User('id');
            if ($this->TaxMaster->save($taxMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Tax Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Tax Master'));
            }
        }
        $this->loadModel('OwnerCompanies');
        $owner_company = $this->OwnerCompanies->find('list',['keyField'=>'id','valueField'=>'Company_name']);
        $this->set(compact('taxMaster','owner_company'));
        $this->set('_serialize', ['taxMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Tax Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $taxMaster = $this->TaxMaster->get($id);
        if ($this->TaxMaster->delete($taxMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Tax Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Tax Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
