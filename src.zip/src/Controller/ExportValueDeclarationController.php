<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ExportValueDeclaration Controller
 *
 * @property \App\Model\Table\ExportValueDeclarationTable $ExportValueDeclaration
 *
 * @method \App\Model\Entity\ExportValueDeclaration[] paginate($object = null, array $settings = [])
 */
class ExportValueDeclarationController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'Oas']
        ];
        $exportValueDeclaration = $this->paginate($this->ExportValueDeclaration);

        $this->set(compact('exportValueDeclaration'));
        $this->set('_serialize', ['exportValueDeclaration']);
    }

    /**
     * View method
     *
     * @param string|null $id Export Value Declaration id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $exportValueDeclaration = $this->ExportValueDeclaration->get($id, [
            'contain' => ['Invoices', 'Oas']
        ]);

        $this->set('exportValueDeclaration', $exportValueDeclaration);
        $this->set('_serialize', ['exportValueDeclaration']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $exportValueDeclaration = $this->ExportValueDeclaration->newEntity();
        if ($this->request->is('post')) {
            $exportValueDeclaration = $this->ExportValueDeclaration->patchEntity($exportValueDeclaration, $this->request->data);
            if ($this->ExportValueDeclaration->save($exportValueDeclaration)) {
                $this->Flash->success(__('The {0} has been saved.', 'Export Value Declaration'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Export Value Declaration'));
            }
        }
        $invoices = $this->ExportValueDeclaration->Invoices->find('list', ['limit' => 200]);
        $oas = $this->ExportValueDeclaration->Oas->find('list', ['limit' => 200]);
        $this->set(compact('exportValueDeclaration', 'invoices', 'oas'));
        $this->set('_serialize', ['exportValueDeclaration']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Export Value Declaration id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $exportValueDeclaration = $this->ExportValueDeclaration->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $exportValueDeclaration = $this->ExportValueDeclaration->patchEntity($exportValueDeclaration, $this->request->data);
            if ($this->ExportValueDeclaration->save($exportValueDeclaration)) {
                $this->Flash->success(__('The {0} has been saved.', 'Export Value Declaration'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Export Value Declaration'));
            }
        }
        $invoices = $this->ExportValueDeclaration->Invoices->find('list', ['limit' => 200]);
        $oas = $this->ExportValueDeclaration->Oas->find('list', ['limit' => 200]);
        $this->set(compact('exportValueDeclaration', 'invoices', 'oas'));
        $this->set('_serialize', ['exportValueDeclaration']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Export Value Declaration id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $exportValueDeclaration = $this->ExportValueDeclaration->get($id);
        if ($this->ExportValueDeclaration->delete($exportValueDeclaration)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Export Value Declaration'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Export Value Declaration'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
