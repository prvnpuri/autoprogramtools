<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PreShipmentPacking Controller
 *
 * @property \App\Model\Table\PreShipmentPackingTable $PreShipmentPacking
 *
 * @method \App\Model\Entity\PreShipmentPacking[] paginate($object = null, array $settings = [])
 */
class PreShipmentPackingController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'Oas', 'Orders']
        ];
        $preShipmentPacking = $this->paginate($this->PreShipmentPacking);

        $this->set(compact('preShipmentPacking'));
        $this->set('_serialize', ['preShipmentPacking']);
    }

    /**
     * View method
     *
     * @param string|null $id Pre Shipment Packing id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $preShipmentPacking = $this->PreShipmentPacking->get($id, [
            'contain' => ['Invoices', 'Oas', 'Orders']
        ]);

        $this->set('preShipmentPacking', $preShipmentPacking);
        $this->set('_serialize', ['preShipmentPacking']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $preShipmentPacking = $this->PreShipmentPacking->newEntity();
        if ($this->request->is('post')) {
            $preShipmentPacking = $this->PreShipmentPacking->patchEntity($preShipmentPacking, $this->request->data);
            if ($this->PreShipmentPacking->save($preShipmentPacking)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Packing'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Packing'));
            }
        }
        $invoices = $this->PreShipmentPacking->Invoices->find('list', ['limit' => 200]);
        $oas = $this->PreShipmentPacking->Oas->find('list', ['limit' => 200]);
        $orders = $this->PreShipmentPacking->Orders->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentPacking', 'invoices', 'oas', 'orders'));
        $this->set('_serialize', ['preShipmentPacking']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Pre Shipment Packing id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $preShipmentPacking = $this->PreShipmentPacking->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $preShipmentPacking = $this->PreShipmentPacking->patchEntity($preShipmentPacking, $this->request->data);
            if ($this->PreShipmentPacking->save($preShipmentPacking)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Packing'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Packing'));
            }
        }
        $invoices = $this->PreShipmentPacking->Invoices->find('list', ['limit' => 200]);
        $oas = $this->PreShipmentPacking->Oas->find('list', ['limit' => 200]);
        $orders = $this->PreShipmentPacking->Orders->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentPacking', 'invoices', 'oas', 'orders'));
        $this->set('_serialize', ['preShipmentPacking']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Pre Shipment Packing id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $preShipmentPacking = $this->PreShipmentPacking->get($id);
        if ($this->PreShipmentPacking->delete($preShipmentPacking)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Pre Shipment Packing'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Pre Shipment Packing'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
