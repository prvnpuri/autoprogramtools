<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanyBankMaster Controller
 *
 * @property \App\Model\Table\CompanyBankMasterTable $CompanyBankMaster
 *
 * @method \App\Model\Entity\CompanyBankMaster[] paginate($object = null, array $settings = [])
 */
class CompanyBankMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="CompanyBankMaster.bank_name like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['OwnerCompanies', 'Currency'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","OwnerCompanies.Company_name","name","account_no","account_name","status","bank_name","Currency.name"]
    	];
    	
    	$companyBankMaster = $this->paginate($this->CompanyBankMaster);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('companyBankMaster'));
    	$this->set( '_serialize', ['companyBankMaster','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Company Bank Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companyBankMaster = $this->CompanyBankMaster->get($id, [
            'contain' => ['OwnerCompanies', 'Currency', 'Invoices']
        ]);

        $this->set('companyBankMaster', $companyBankMaster);
        $this->set('_serialize', ['companyBankMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
    	
        $companyBankMaster = $this->CompanyBankMaster->newEntity();
        if ($this->request->is('post')) {
            $companyBankMaster = $this->CompanyBankMaster->patchEntity($companyBankMaster, $this->request->data,
            		[
            				'associated' =>['Currency']
            		]
            		);
            if ($this->CompanyBankMaster->save($companyBankMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Bank Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Bank Master'));
            }
        }
        $ownerCompanies= $this->CompanyBankMaster->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
        $currency = $this->CompanyBankMaster->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'sign'],['limit' => 200]);
        $this->set(compact('companyBankMaster', 'ownerCompanies', 'currency'));
        $this->set('_serialize', ['companyBankMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Bank Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companyBankMaster = $this->CompanyBankMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companyBankMaster = $this->CompanyBankMaster->patchEntity($companyBankMaster, $this->request->data);
            if ($this->CompanyBankMaster->save($companyBankMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Bank Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Bank Master'));
            }
        }
        $ownerCompanies= $this->CompanyBankMaster->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name'], ['limit' => 200]);
        $currency = $this->CompanyBankMaster->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'sign'],['limit' => 200]);
        $this->set(compact('companyBankMaster', 'ownerCompanies', 'currency'));
        $this->set('_serialize', ['companyBankMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Bank Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyBankMaster = $this->CompanyBankMaster->get($id);
        if ($this->CompanyBankMaster->delete($companyBankMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Bank Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Bank Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
