<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * EmployeeMonthlySalaries Controller
 *
 * @property \App\Model\Table\EmployeeMonthlySalariesTable $EmployeeMonthlySalaries
 * @property \App\Model\Table\EmployeeSalaryMastersTable $EmployeeSalaryMaster
 * @property \App\Model\Table\EmployeeDetailsTable $EmployeeDetails
 * @method \App\Model\Entity\EmployeeMonthlySalary[] paginate($object = null, array $settings = [])
 */
class EmployeeMonthlySalariesController extends AppController
{
    public function initialize(){
        parent::initialize();
        $this->loadModel('EmployeeSalaryMasters');
        $this->loadModel('EmployeeDetails');
    }

    /**
     * Index method
     * @property \App\Model\Table\EmployeeSalaryMastersTable $EmployeeSalaryMaster
     * @property \App\Model\Table\EmployeeDetailsTable $EmployeeDetails
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['EmployeeMonthlySalaries','OwnerCompanies'],
            'fields'=>[
                'EmployeeMonthlySalaries.id', 'EmployeeMonthlySalaries.employee_salary_master_id', 'EmployeeMonthlySalaries.month', 'EmployeeMonthlySalaries.basic_sal', 'EmployeeMonthlySalaries.hra', 'EmployeeMonthlySalaries.conveyance_allowance', 'EmployeeMonthlySalaries.medical_allowance', 'EmployeeMonthlySalaries.professional_tax', 'EmployeeMonthlySalaries.leave_travel_allowance', 'EmployeeMonthlySalaries.special_allowance', 'EmployeeMonthlySalaries.telephone_reimbursement', 'EmployeeMonthlySalaries.chidlren_education_allowance', 'EmployeeMonthlySalaries.city_compensation_allowance', 'EmployeeMonthlySalaries.total_ctc', 'EmployeeMonthlySalaries.employee_details_id', 'EmployeeMonthlySalaries.advanced_payment', 'EmployeeMonthlySalaries.leave_taken', 'EmployeeMonthlySalaries.paid_leave_deduction', 'EmployeeMonthlySalaries.net_amount', 'EmployeeMonthlySalaries.total_deduction', 'EmployeeMonthlySalaries.present_day', 'EmployeeMonthlySalaries.total_payment', 'EmployeeMonthlySalaries.employee_advance_payment_id', 'EmployeeMonthlySalaries.employee_monthly_salariescol', 'EmployeeMonthlySalaries.incentive_amount', 'EmployeeMonthlySalaries.modified_by', 'EmployeeMonthlySalaries.date_of_modification', 'EmployeeMonthlySalaries.date_of_creation', 'EmployeeMonthlySalaries.created_by', 'EmployeeMonthlySalaries.income_tax', 'id','first_name','middle_name','last_name','pan_no',
                'OwnerCompanies.company_name',
                'full_name'=> $this->EmployeeDetails->query()->func()->concat(['first_name',' ','middle_name',' ','last_name']),
                'base_company'=>'OwnerCompanies.company_name',
            ],
            'sortWhitelist'=>['id','first_name','middle_name','last_name','full_name','OwnerCompanies.company_name','base_company'],
            
        ];
        $employeeDetails = $this->paginate($this->EmployeeDetails);
        
        $this->set(compact('employeeDetails'));
        $this->set('_serialize', ['employeeDetails']);
    }

    /**
     * View method
     *
     * @param string|null $id Employee Monthly Salary id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $employeeMonthlySalary = $this->EmployeeMonthlySalaries->get($id, [
            'contain' => ['EmployeeSalaryMasters', 'EmployeeDetails', 'EmployeeAdvancePayments']
        ]);

        $this->set('employeeMonthlySalary', $employeeMonthlySalary);
        $this->set('_serialize', ['employeeMonthlySalary']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $employeeMonthlySalary = $this->EmployeeMonthlySalaries->newEntity();
        if ($this->request->is('post')) {
            $employeeMonthlySalary = $this->EmployeeMonthlySalaries->patchEntity($employeeMonthlySalary, $this->request->data);
            if ($this->EmployeeMonthlySalaries->save($employeeMonthlySalary)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Monthly Salary'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Monthly Salary'));
            }
        }
        $employeeSalaryMasters = $this->EmployeeMonthlySalaries->EmployeeSalaryMasters->find('list', ['limit' => 200]);
        $employeeDetails = $this->EmployeeMonthlySalaries->EmployeeDetails->find('list', ['limit' => 200]);
        $employeeAdvancePayments = $this->EmployeeMonthlySalaries->EmployeeAdvancePayments->find('list', ['limit' => 200]);
        $this->set(compact('employeeMonthlySalary', 'employeeSalaryMasters', 'employeeDetails', 'employeeAdvancePayments'));
        $this->set('_serialize', ['employeeMonthlySalary']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Employee Monthly Salary id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $employeeMonthlySalary = $this->EmployeeMonthlySalaries->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $employeeMonthlySalary = $this->EmployeeMonthlySalaries->patchEntity($employeeMonthlySalary, $this->request->data);
            if ($this->EmployeeMonthlySalaries->save($employeeMonthlySalary)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Monthly Salary'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Monthly Salary'));
            }
        }
        $employeeSalaryMasters = $this->EmployeeMonthlySalaries->EmployeeSalaryMasters->find('list', ['limit' => 200]);
        $employeeDetails = $this->EmployeeMonthlySalaries->EmployeeDetails->find('list', ['limit' => 200]);
        $employeeAdvancePayments = $this->EmployeeMonthlySalaries->EmployeeAdvancePayments->find('list', ['limit' => 200]);
        $this->set(compact('employeeMonthlySalary', 'employeeSalaryMasters', 'employeeDetails', 'employeeAdvancePayments'));
        $this->set('_serialize', ['employeeMonthlySalary']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Employee Monthly Salary id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $employeeMonthlySalary = $this->EmployeeMonthlySalaries->get($id);
        if ($this->EmployeeMonthlySalaries->delete($employeeMonthlySalary)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Employee Monthly Salary'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Employee Monthly Salary'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
   
}
