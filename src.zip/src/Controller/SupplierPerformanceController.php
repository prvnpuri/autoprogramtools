<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * SupplierPerformance Controller
 *
 * @property \App\Model\Table\SupplierPerformanceTable $SupplierPerformance
 *
 * @method \App\Model\Entity\SupplierPerformance[] paginate($object = null, array $settings = [])
 */
class SupplierPerformanceController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Suppliers', 'OwnerCompanies']
        ];
        $supplierPerformance = $this->paginate($this->SupplierPerformance);

        $this->set(compact('supplierPerformance'));
        $this->set('_serialize', ['supplierPerformance']);
    }

    /**
     * View method
     *
     * @param string|null $id Supplier Performance id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $supplierPerformance = $this->SupplierPerformance->get($id, [
            'contain' => ['Suppliers', 'OwnerCompanies']
        ]);

        $this->set('supplierPerformance', $supplierPerformance);
        $this->set('_serialize', ['supplierPerformance']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $supplierPerformance = $this->SupplierPerformance->newEntity();
        if ($this->request->is('post')) {
            $supplierPerformance = $this->SupplierPerformance->patchEntity($supplierPerformance, $this->request->data);
            if ($this->SupplierPerformance->save($supplierPerformance)) {
                $this->Flash->success(__('The {0} has been saved.', 'Supplier Performance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Performance'));
            }
        }
        $suppliers = $this->SupplierPerformance->Suppliers->find('list', ['limit' => 200]);
        $ownerCompanies = $this->SupplierPerformance->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('supplierPerformance', 'suppliers', 'ownerCompanies'));
        $this->set('_serialize', ['supplierPerformance']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Supplier Performance id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $supplierPerformance = $this->SupplierPerformance->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $supplierPerformance = $this->SupplierPerformance->patchEntity($supplierPerformance, $this->request->data);
            if ($this->SupplierPerformance->save($supplierPerformance)) {
                $this->Flash->success(__('The {0} has been saved.', 'Supplier Performance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Performance'));
            }
        }
        $suppliers = $this->SupplierPerformance->Suppliers->find('list', ['limit' => 200]);
        $ownerCompanies = $this->SupplierPerformance->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('supplierPerformance', 'suppliers', 'ownerCompanies'));
        $this->set('_serialize', ['supplierPerformance']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Supplier Performance id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $supplierPerformance = $this->SupplierPerformance->get($id);
        if ($this->SupplierPerformance->delete($supplierPerformance)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Supplier Performance'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Supplier Performance'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
