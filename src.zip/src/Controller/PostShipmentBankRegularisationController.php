<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PostShipmentBankRegularisation Controller
 *
 * @property \App\Model\Table\PostShipmentBankRegularisationTable $PostShipmentBankRegularisation
 *
 * @method \App\Model\Entity\PostShipmentBankRegularisation[] paginate($object = null, array $settings = [])
 */
class PostShipmentBankRegularisationController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Oas']
        ];
        $postShipmentBankRegularisation = $this->paginate($this->PostShipmentBankRegularisation);

        $this->set(compact('postShipmentBankRegularisation'));
        $this->set('_serialize', ['postShipmentBankRegularisation']);
    }

    /**
     * View method
     *
     * @param string|null $id Post Shipment Bank Regularisation id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $postShipmentBankRegularisation = $this->PostShipmentBankRegularisation->get($id, [
            'contain' => ['Oas']
        ]);

        $this->set('postShipmentBankRegularisation', $postShipmentBankRegularisation);
        $this->set('_serialize', ['postShipmentBankRegularisation']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $postShipmentBankRegularisation = $this->PostShipmentBankRegularisation->newEntity();
        if ($this->request->is('post')) {
            $postShipmentBankRegularisation = $this->PostShipmentBankRegularisation->patchEntity($postShipmentBankRegularisation, $this->request->data);
            if ($this->PostShipmentBankRegularisation->save($postShipmentBankRegularisation)) {
                $this->Flash->success(__('The {0} has been saved.', 'Post Shipment Bank Regularisation'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Post Shipment Bank Regularisation'));
            }
        }
        $oas = $this->PostShipmentBankRegularisation->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postShipmentBankRegularisation', 'oas'));
        $this->set('_serialize', ['postShipmentBankRegularisation']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Post Shipment Bank Regularisation id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $postShipmentBankRegularisation = $this->PostShipmentBankRegularisation->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $postShipmentBankRegularisation = $this->PostShipmentBankRegularisation->patchEntity($postShipmentBankRegularisation, $this->request->data);
            if ($this->PostShipmentBankRegularisation->save($postShipmentBankRegularisation)) {
                $this->Flash->success(__('The {0} has been saved.', 'Post Shipment Bank Regularisation'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Post Shipment Bank Regularisation'));
            }
        }
        $oas = $this->PostShipmentBankRegularisation->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postShipmentBankRegularisation', 'oas'));
        $this->set('_serialize', ['postShipmentBankRegularisation']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Post Shipment Bank Regularisation id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $postShipmentBankRegularisation = $this->PostShipmentBankRegularisation->get($id);
        if ($this->PostShipmentBankRegularisation->delete($postShipmentBankRegularisation)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Post Shipment Bank Regularisation'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Post Shipment Bank Regularisation'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
