<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PreShipmentAttachment Controller
 *
 * @property \App\Model\Table\PreShipmentAttachmentTable $PreShipmentAttachment
 *
 * @method \App\Model\Entity\PreShipmentAttachment[] paginate($object = null, array $settings = [])
 */
class PreShipmentAttachmentController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'Oas']
        ];
        $preShipmentAttachment = $this->paginate($this->PreShipmentAttachment);

        $this->set(compact('preShipmentAttachment'));
        $this->set('_serialize', ['preShipmentAttachment']);
    }

    /**
     * View method
     *
     * @param string|null $id Pre Shipment Attachment id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $preShipmentAttachment = $this->PreShipmentAttachment->get($id, [
            'contain' => ['Invoices', 'Oas']
        ]);

        $this->set('preShipmentAttachment', $preShipmentAttachment);
        $this->set('_serialize', ['preShipmentAttachment']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $preShipmentAttachment = $this->PreShipmentAttachment->newEntity();
        if ($this->request->is('post')) {
            $preShipmentAttachment = $this->PreShipmentAttachment->patchEntity($preShipmentAttachment, $this->request->data);
            if ($this->PreShipmentAttachment->save($preShipmentAttachment)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Attachment'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Attachment'));
            }
        }
        $invoices = $this->PreShipmentAttachment->Invoices->find('list', ['limit' => 200]);
        $oas = $this->PreShipmentAttachment->Oas->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentAttachment', 'invoices', 'oas'));
        $this->set('_serialize', ['preShipmentAttachment']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Pre Shipment Attachment id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $preShipmentAttachment = $this->PreShipmentAttachment->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $preShipmentAttachment = $this->PreShipmentAttachment->patchEntity($preShipmentAttachment, $this->request->data);
            if ($this->PreShipmentAttachment->save($preShipmentAttachment)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Attachment'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Attachment'));
            }
        }
        $invoices = $this->PreShipmentAttachment->Invoices->find('list', ['limit' => 200]);
        $oas = $this->PreShipmentAttachment->Oas->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentAttachment', 'invoices', 'oas'));
        $this->set('_serialize', ['preShipmentAttachment']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Pre Shipment Attachment id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $preShipmentAttachment = $this->PreShipmentAttachment->get($id);
        if ($this->PreShipmentAttachment->delete($preShipmentAttachment)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Pre Shipment Attachment'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Pre Shipment Attachment'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
