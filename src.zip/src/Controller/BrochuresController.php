<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Brochures Controller
 *
 * @property \App\Model\Table\BrochuresTable $Brochures
 *
 * @method \App\Model\Entity\Brochure[] paginate($object = null, array $settings = [])
 */
class BrochuresController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
      	$query=$this->request->getQuery("search");
        $conditions=array();
        if($query!=null && trim($query," ")!=""){
        	$conditions[]="Brochures.brochure_type like '%$query%'";
        }
        $this->paginate = [
        		'contain' => ['CompanyMaster', 'ProductsMaster', 'IndustryTypeMaster'],
        		"conditions" => $conditions,
        		"sortWhitelist"=>["brochure_type","brochure_reference","description","ProductsMaster.product_name","IndustryTypeMaster.industry_type","CompanyMaster.Company_name"]
        ];
        
        
        $brochures = $this->paginate($this->Brochures);
        $this->set("paging",$this->request->getParam("paging"));
        $this->set(compact('brochures'));
        $this->set( '_serialize', ['brochures','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Brochure id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $brochure = $this->Brochures->get($id, [
            'contain' => ['BrochureFile']
        ]);
		
        $this->loadModel('ProductsMaster');
        $this->loadModel('CompanyMaster');
        $this->loadModel('IndustryTypeMaster');
        $product = $this->ProductsMaster->find('list',['keyField'=>'id','valueField'=>'product_name']);
        if($brochure->brochure_type == 'Product'){
        	$product = $this->ProductsMaster->get($brochure->brochure_reference, [
        			'conditions'=>[$brochure->brochure_reference => 'ProductsMaster.id']
        	]);
        } else if($brochure->brochure_type == 'Industry Type'){
        	$industryType = $this->IndustryTypeMaster->get($brochure->brochure_reference, [
        			'conditions'=>[$brochure->brochure_reference => 'IndustryTypeMaster.id']
        	]);
        } else if($brochure->brochure_type == 'Company'){
        	$company = $this->CompanyMaster->get($brochure->brochure_reference, [
        			'conditions'=>[$brochure->brochure_reference => 'CompanyMaster.id']
        	]);
        }
        
        $this->set(compact('brochure','product','company','industryType'));
        $this->set('_serialize', ['brochure']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
    	$brochure = $this->Brochures->newEntity();
    	if ($this->request->is('post')) {
    		foreach ($this->request->data['BrochureFile'] as $cerkey => $cerfile){
    			if(isset($this->request->data["BrochureFile"][$cerkey]["file"]) &&  $this->request->data["BrochureFile"][$cerkey]["file"]["error"]==0){
    				$filename = $this->request->data["BrochureFile"][$cerkey]["file"]["name"];
    				$this->request->data["brochure_file"][$cerkey]["brochure_filename"] = $filename;
    			}
    			else{
    				unset($this->request->data["BrochureFile"][$cerkey]);
    			}
    		}
    		
    		$brochure['created_by'] = $this->Auth->User('id');
    	
    		$brochure = $this->Brochures->patchEntity($brochure, $this->request->data,
    				[
    						'associated'=>'BrochureFile'
    				]);
    	
    		if ($this->Brochures->save($brochure)) {
    			$id = $brochure->id;
    			foreach ($this->request->data['BrochureFile'] as $key => $value){
    				if(isset($value["file"]) &&  $value["file"]["error"]==0)
    				{
    					$filename = $value["file"]["name"];
    					$uploadpath = 'upload/brochures/';
    					$tmp = $value["file"]['tmp_name'];
    					if (!is_dir($uploadpath."/".$id)) {
    						mkdir($uploadpath."/".$id);
    					}
    					$movefiledir = "upload/brochures/".$id."/".$filename;
    					$uploadpath = WWW_ROOT . "upload".DS."brochures".DS.$id;
    					 
    					move_uploaded_file($tmp, $movefiledir);
    					$this->request->data['files_path'] = $uploadpath;
    				}else{
    					unset($this->request->data['brochure_file']);
    				}
    			}
    			
    			$this->Flash->success(__('The {0} has been saved.', 'Brochure'));
    			return $this->redirect(['action' => 'index']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Brochure'));
    		}
    	}
    	$this->loadModel('IndustryTypeMaster');
    	$industryTypes = $this->IndustryTypeMaster->find('list',['valueField'=>['industry_type'], 'order'=>'industry_type']);
    	$this->set(compact('brochure','industryTypes'));
    	$this->set('_serialize', ['brochure']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Brochure id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $brochure = $this->Brochures->get($id, [
            'contain' => ['BrochureFile']
        ]);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
        	foreach ($this->request->data['BrochureFile'] as $cerkey => $cerfile){
        		if(isset($this->request->data["BrochureFile"][$cerkey]["file"]) &&  $this->request->data["BrochureFile"][$cerkey]["file"]["error"]==0){
        			$filename = $this->request->data["BrochureFile"][$cerkey]["file"]["name"];
        			$this->request->data["brochure_file"][$cerkey]["brochure_filename"] = $filename;
        		}
        		else{
        			unset($this->request->data["BrochureFile"][$cerkey]);
        		}
        	}
        	
        	$brochure['modified_by'] = $this->Auth->User('id');
        	 
        	$brochure = $this->Brochures->patchEntity($brochure, $this->request->data,
        			[
        					'associated'=>'BrochureFile'
        			]);

        	if ($this->Brochures->save($brochure)) {
        		if(isset($this->request->data['Deletecertificate'])){
        			$this->loadModel('BrochureFile');
        			foreach ($this->request->data['Deletecertificate']['id'] as $key => $val){
        				$deleteBrochue = $this->BrochureFile->get($val);
        				$this->BrochureFile->delete($deleteBrochue);
        			}
				}
        		
        		$id = $brochure->id;
        		foreach ($this->request->data['BrochureFile'] as $key => $value){
        			if(isset($value["file"]) &&  $value["file"]["error"]==0)
        			{
        				$filename = $value["file"]["name"];
        				$uploadpath = 'upload/brochures/';
        				$tmp = $value["file"]['tmp_name'];
        				if (!is_dir($uploadpath."/".$id)) {
        					mkdir($uploadpath."/".$id);
        				}
        				$movefiledir = "upload/brochures/".$id."/".$filename;
        				$uploadpath = WWW_ROOT . "upload".DS."brochures".DS.$id;
        	
        				move_uploaded_file($tmp, $movefiledir);
        				$this->request->data['files_path'] = $uploadpath;
        			}else{
        				unset($this->request->data['brochure_file']);
        			}
        		}
        		 
        		$this->Flash->success(__('The {0} has been saved.', 'Brochure'));
        		return $this->redirect(['action' => 'index']);
        	} else {
        		$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Brochure'));
        	}
        }
        
        $this->loadModel('ProductsMaster');
        $this->loadModel('CompanyMaster');
        $this->loadModel('IndustryTypeMaster');
        $product = $this->ProductsMaster->find('list',['keyField'=>'id','valueField'=>'product_name']);
        if($brochure->brochure_type == 'Product'){
	        $product = $this->ProductsMaster->get($brochure->brochure_reference, [
	        		'conditions'=>[$brochure->brochure_reference => 'ProductsMaster.id']
	        ]);
        } else if($brochure->brochure_type == 'Industry Type'){
	        $industryType = $this->IndustryTypeMaster->get($brochure->brochure_reference, [
	        		'conditions'=>[$brochure->brochure_reference => 'IndustryTypeMaster.id']
	        ]);
        } else if($brochure->brochure_type == 'Company'){
	        $company = $this->CompanyMaster->get($brochure->brochure_reference, [
	        		'conditions'=>[$brochure->brochure_reference => 'CompanyMaster.id']
	        ]);
        }
        
        $this->set(compact('brochure','product','company','industryType'));
        $this->set('_serialize', ['brochure']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Brochure id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $brochure = $this->Brochures->get($id);
        if ($this->Brochures->delete($brochure)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Brochure'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Brochure'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
