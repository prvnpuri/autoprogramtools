<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * AssetMaintenanceSchedule Controller
 *
 * @property \App\Model\Table\AssetMaintenanceScheduleTable $AssetMaintenanceSchedule
 *
 * @method \App\Model\Entity\AssetMaintenanceSchedule[] paginate($object = null, array $settings = [])
 */
class AssetMaintenanceScheduleController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanyAssets']
        ];
        $assetMaintenanceSchedule = $this->paginate($this->AssetMaintenanceSchedule);

        $this->set(compact('assetMaintenanceSchedule'));
        $this->set('_serialize', ['assetMaintenanceSchedule']);
    }

    /**
     * View method
     *
     * @param string|null $id Asset Maintenance Schedule id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $assetMaintenanceSchedule = $this->AssetMaintenanceSchedule->get($id, [
            'contain' => ['OwnerCompanyAssets', 'AssetMaintenanceRecords']
        ]);

        $this->set('assetMaintenanceSchedule', $assetMaintenanceSchedule);
        $this->set('_serialize', ['assetMaintenanceSchedule']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $assetMaintenanceSchedule = $this->AssetMaintenanceSchedule->newEntity();
        if ($this->request->is('post')) {
            $assetMaintenanceSchedule = $this->AssetMaintenanceSchedule->patchEntity($assetMaintenanceSchedule, $this->request->data);
            if ($this->AssetMaintenanceSchedule->save($assetMaintenanceSchedule)) {
                $this->Flash->success(__('The {0} has been saved.', 'Asset Maintenance Schedule'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Asset Maintenance Schedule'));
            }
        }
        $ownerCompanyAssets = $this->AssetMaintenanceSchedule->OwnerCompanyAssets->find('list', ['limit' => 200]);
        $this->set(compact('assetMaintenanceSchedule', 'ownerCompanyAssets'));
        $this->set('_serialize', ['assetMaintenanceSchedule']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Asset Maintenance Schedule id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $assetMaintenanceSchedule = $this->AssetMaintenanceSchedule->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $assetMaintenanceSchedule = $this->AssetMaintenanceSchedule->patchEntity($assetMaintenanceSchedule, $this->request->data);
            if ($this->AssetMaintenanceSchedule->save($assetMaintenanceSchedule)) {
                $this->Flash->success(__('The {0} has been saved.', 'Asset Maintenance Schedule'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Asset Maintenance Schedule'));
            }
        }
        $ownerCompanyAssets = $this->AssetMaintenanceSchedule->OwnerCompanyAssets->find('list', ['limit' => 200]);
        $this->set(compact('assetMaintenanceSchedule', 'ownerCompanyAssets'));
        $this->set('_serialize', ['assetMaintenanceSchedule']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Asset Maintenance Schedule id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $assetMaintenanceSchedule = $this->AssetMaintenanceSchedule->get($id);
        if ($this->AssetMaintenanceSchedule->delete($assetMaintenanceSchedule)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Asset Maintenance Schedule'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Asset Maintenance Schedule'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
