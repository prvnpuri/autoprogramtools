<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Statecopy Controller
 *
 * @property \App\Model\Table\StatecopyTable $Statecopy
 *
 * @method \App\Model\Entity\Statecopy[] paginate($object = null, array $settings = [])
 */
class StatecopyController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Countries']
        ];
        $statecopy = $this->paginate($this->Statecopy);

        $this->set(compact('statecopy'));
        $this->set('_serialize', ['statecopy']);
    }

    /**
     * View method
     *
     * @param string|null $id Statecopy id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $statecopy = $this->Statecopy->get($id, [
            'contain' => ['Countries']
        ]);

        $this->set('statecopy', $statecopy);
        $this->set('_serialize', ['statecopy']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $statecopy = $this->Statecopy->newEntity();
        if ($this->request->is('post')) {
            $statecopy = $this->Statecopy->patchEntity($statecopy, $this->request->data);
            if ($this->Statecopy->save($statecopy)) {
                $this->Flash->success(__('The {0} has been saved.', 'Statecopy'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Statecopy'));
            }
        }
        $countries = $this->Statecopy->Countries->find('list', ['limit' => 200]);
        $this->set(compact('statecopy', 'countries'));
        $this->set('_serialize', ['statecopy']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Statecopy id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $statecopy = $this->Statecopy->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $statecopy = $this->Statecopy->patchEntity($statecopy, $this->request->data);
            if ($this->Statecopy->save($statecopy)) {
                $this->Flash->success(__('The {0} has been saved.', 'Statecopy'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Statecopy'));
            }
        }
        $countries = $this->Statecopy->Countries->find('list', ['limit' => 200]);
        $this->set(compact('statecopy', 'countries'));
        $this->set('_serialize', ['statecopy']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Statecopy id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $statecopy = $this->Statecopy->get($id);
        if ($this->Statecopy->delete($statecopy)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Statecopy'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Statecopy'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
