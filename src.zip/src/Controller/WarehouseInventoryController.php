<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * WarehouseInventory Controller
 *
 * @property \App\Model\Table\WarehouseInventoryTable $WarehouseInventory
 *
 * @method \App\Model\Entity\WarehouseInventory[] paginate($object = null, array $settings = [])
 */
class WarehouseInventoryController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products', 'OwnerCompanies', 'WarehouseMasters']
        ];
        $warehouseInventory = $this->paginate($this->WarehouseInventory);

        $this->set(compact('warehouseInventory'));
        $this->set('_serialize', ['warehouseInventory']);
    }

    /**
     * View method
     *
     * @param string|null $id Warehouse Inventory id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $warehouseInventory = $this->WarehouseInventory->get($id, [
            'contain' => ['Products', 'OwnerCompanies', 'WarehouseMasters', 'WarehouseInventoryDetails']
        ]);

        $this->set('warehouseInventory', $warehouseInventory);
        $this->set('_serialize', ['warehouseInventory']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $warehouseInventory = $this->WarehouseInventory->newEntity();
        if ($this->request->is('post')) {
            $warehouseInventory = $this->WarehouseInventory->patchEntity($warehouseInventory, $this->request->data);
            if ($this->WarehouseInventory->save($warehouseInventory)) {
                $this->Flash->success(__('The {0} has been saved.', 'Warehouse Inventory'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Warehouse Inventory'));
            }
        }
        $products = $this->WarehouseInventory->Products->find('list', ['limit' => 200]);
        $ownerCompanies = $this->WarehouseInventory->OwnerCompanies->find('list', ['limit' => 200]);
        $warehouseMasters = $this->WarehouseInventory->WarehouseMasters->find('list', ['limit' => 200]);
        $this->set(compact('warehouseInventory', 'products', 'ownerCompanies', 'warehouseMasters'));
        $this->set('_serialize', ['warehouseInventory']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Warehouse Inventory id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $warehouseInventory = $this->WarehouseInventory->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $warehouseInventory = $this->WarehouseInventory->patchEntity($warehouseInventory, $this->request->data);
            if ($this->WarehouseInventory->save($warehouseInventory)) {
                $this->Flash->success(__('The {0} has been saved.', 'Warehouse Inventory'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Warehouse Inventory'));
            }
        }
        $products = $this->WarehouseInventory->Products->find('list', ['limit' => 200]);
        $ownerCompanies = $this->WarehouseInventory->OwnerCompanies->find('list', ['limit' => 200]);
        $warehouseMasters = $this->WarehouseInventory->WarehouseMasters->find('list', ['limit' => 200]);
        $this->set(compact('warehouseInventory', 'products', 'ownerCompanies', 'warehouseMasters'));
        $this->set('_serialize', ['warehouseInventory']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Warehouse Inventory id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $warehouseInventory = $this->WarehouseInventory->get($id);
        if ($this->WarehouseInventory->delete($warehouseInventory)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Warehouse Inventory'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Warehouse Inventory'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
