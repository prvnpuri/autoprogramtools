<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;
use PhpParser\Node\Expr\Cast\Unset_;
use function Cake\ORM\toArray;

/**
 * OwnerCompanies Controller
 *
 * @property \App\Model\Table\OwnerCompaniesTable $OwnerCompanies
 *
 * @method \App\Model\Entity\OwnerCompany[] paginate($object = null, array $settings = [])
 */
class OwnerCompaniesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="OwnerCompanies.Company_name like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['OwnerCompanyOffices','OwnerCompanyOffices.City','OwnerCompanyOffices.State','OwnerCompanyOffices.Countries'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","Company_name","website_address"]
    	];
    	
    	$ownerCompanies = $this->paginate($this->OwnerCompanies);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->loadModel('City');
    	$this->loadModel('State');
    	$this->loadModel('Countries');
    	$this->loadModel('Users');
    	$city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name']);
    	$state = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name']);
    	$countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
    	$this->set(compact('ownerCompanies','city','state','countries','users'));
    	$this->set(compact('ownerCompanies'));
    	$this->set( '_serialize', ['ownerCompanies','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Owner Company id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ownerCompany = $this->OwnerCompanies->get($id, [
            'contain' => ['CustomerSatisfactionSurvey', 'ExciseTaxInvoice', 'InventorySample', 'Invoices', 'MarketingCampaign', 'OfficeInward', 'OfficeOutward', 'PettyCashDailyExpenses', 'PettyCashMonthlyBalance', 'Photo', 'PreShipmentBase', 'PreshipmentTsca', 'QualityDelPerformanceOfSupplier', 'SubsequentVisits', 'SupplierEvaluationRegistrationTable', 'SupplierPerformance', 'OwnerCompanyOffices', 'OwnerContactPersons','PortOfDischarge']
        ]);
        $this->loadModel('City');
        $this->loadModel('State');
        $this->loadModel('Countries');
        $this->loadModel('Users');
        $this->loadModel('PortOfDischarge');
        $port_of_discharge_air = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['id'=>$ownerCompany->port_of_discharge_air]]);
        $port_of_discharge_sea = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['id'=>$ownerCompany->port_of_discharge_sea]]);
        $city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name']);
        $state = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name']);
        $countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        $users = $this->Users->find('list', ['keyField'=>'id', 'valueField'=>'userfullname','order'=>'userfullname']);
        $this->set(compact('ownerCompany','city','state','countries','users','port_of_discharge_air','port_of_discharge_sea'));
        $this->set('_serialize', ['ownerCompany']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ownerCompany = $this->OwnerCompanies->newEntity();
        if ($this->request->is('post')) {
            $ownerCompany = $this->OwnerCompanies->patchEntity($ownerCompany, $this->request->data, 
            		['associated' => ['OwnerCompanyOffices','OwnerContactPersons']]
            );
            if(isset($this->request->data["logo"]) &&  $this->request->data["logo"]["error"]==0){
            	$filename=$this->request->data["logo"]["name"];
            	$ownerCompany["logo_image"]=$filename;
            }else{
            	unset($this->request->data["logo_image"]);
            }
            if(isset($this->request->data["header"]) &&  $this->request->data["header"]["error"]==0){
            	$filename=$this->request->data["header"]["name"];
            	$ownerCompany["header_image"]=$filename;
            }else{
            	unset($this->request->data["header_image"]);
            }
            if(isset($this->request->data["footer"]) &&  $this->request->data["footer"]["error"]==0){
            	$filename=$this->request->data["footer"]["name"];
            	$ownerCompany["footer_image"]=$filename;
            }else{
            	unset($this->request->data["footer_image"]);
            }
            if(isset($this->request->data["stamp"]) &&  $this->request->data["stamp"]["error"]==0){
            	$filename=$this->request->data["stamp"]["name"];
            	$ownerCompany["stamp_image"]=$filename;
            }else{
            	unset($this->request->data["stamp_image"]);
            }
            //echo "<pre>"; print_r($ownerCompany);exit;
            $ownerCompany['created_by'] = $this->Auth->User('id');
            
            if ($this->OwnerCompanies->save($ownerCompany)) {

            	if(isset($this->request->data["logo"]) &&  $this->request->data["logo"]["error"]==0){
            		$filename=$this->request->data["logo"]["name"];
            		$url = Router::url('/',true).'upload/owner-company-logo/'.$filename;
            		$uploadpath = 'upload/owner-company-logo/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["logo"]['tmp_name'], $uploadfile);
            			
            	}else{
            		unset($this->request->data["logo"]);
            	}
            	if(isset($this->request->data["header"]) &&  $this->request->data["header"]["error"]==0){
            		$filename=$this->request->data["header"]["name"];
            		$url = Router::url('/',true).'upload/owner-company-header/'.$filename;
            		$uploadpath = 'upload/owner-company-header/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["header"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["header"]);
            	}
            	if(isset($this->request->data["footer"]) &&  $this->request->data["footer"]["error"]==0){
            		$filename=$this->request->data["footer"]["name"];
            		$url = Router::url('/',true).'upload/owner-company-footer/'.$filename;
            		$uploadpath = 'upload/owner-company-footer/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["footer"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["footer"]);
            	}
            	if(isset($this->request->data["stamp"]) &&  $this->request->data["stamp"]["error"]==0){
            		$filename=$this->request->data["stamp"]["name"];
            		$url = Router::url('/',true).'upload/owner-company-stamp/'.$filename;
            		$uploadpath = 'upload/owner-company-stamp/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["stamp"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["stamp"]);
            	}
                $this->Flash->success(__('The {0} has been saved.', 'Owner Company'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Owner Company'));
            }
        }
        $this->loadModel('City');
        $this->loadModel('State');
        $this->loadModel('Countries');
        $this->loadModel('PortOfDischarge');
        $this->loadModel('Users');
        $city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name']);
        $state = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name']);
        $countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        $port_of_discharge_sea = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['type like'=>'0']]);
        $port_of_discharge_air = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['type like'=>'1']]);
        $users = $this->Users->find('list', ['keyField'=>'id', 'valueField'=>'userfullname','order'=>'userfullname']);
        $this->set(compact('ownerCompany','city','state','countries','port_of_discharge_sea','port_of_discharge_air','users'));
        $this->set('_serialize', ['ownerCompany']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Owner Company id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ownerCompany = $this->OwnerCompanies->get($id, [
            'contain' => ['OwnerCompanyOffices','OwnerCompanyOffices.State','OwnerCompanyOffices.City','OwnerContactPersons']
        ]);
        $this->loadModel('State');
        $this->loadModel('City');
        foreach ($ownerCompany['owner_company_offices'] as $k => $ownerComp){
        	$states = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name','conditions'=>['State.country_id'=>$ownerComp['country']]]);
        	$states = $states->toArray();
        	$ownerCompany['owner_company_offices'][$k]['states'] = $states;
        	$cities = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name','conditions'=>['City.state_id'=>$ownerComp['state']]]);
        	$cities = $cities->toArray();
        	$ownerCompany['owner_company_offices'][$k]['cities'] = $cities;
        }
        //echo "<pre>"; print_r($ownerCompany['owner_company_offices']);exit;
        if ($this->request->is(['post', 'put'])) {
        	$ownerCompany = $this->OwnerCompanies->patchEntity($ownerCompany, $this->request->getData(),
        			['associated' => ['OwnerCompanyOffices','OwnerContactPersons']]
        	);
        	//echo "<pre>"; print_r($ownerCompany);exit;
        	if(isset($this->request->data["logo"]) &&  $this->request->data["logo"]["error"]==0){
        		$filename=$this->request->data["logo"]["name"];
        		$ownerCompany["logo_image"]=$filename;
        	}else{
        		unset($this->request->data["logo_image"]);
        	}
        	if(isset($this->request->data["header"]) &&  $this->request->data["header"]["error"]==0){
        		$filename=$this->request->data["header"]["name"];
        		$ownerCompany["header_image"]=$filename;
        	}else{
        		unset($this->request->data["header_image"]);
        	}
        	if(isset($this->request->data["footer"]) &&  $this->request->data["footer"]["error"]==0){
        		$filename=$this->request->data["footer"]["name"];
        		$ownerCompany["footer_image"]=$filename;
        	}else{
        		unset($this->request->data["footer_image"]);
        	}
        	if(isset($this->request->data["stamp"]) &&  $this->request->data["stamp"]["error"]==0){
        		$filename=$this->request->data["stamp"]["name"];
        		$ownerCompany["stamp_image"]=$filename;
        	}else{
        		unset($this->request->data["stamp_image"]);
        	}
        	foreach ($ownerCompany['owner_company_offices'] as $key => $compAdd){
        		if(!isset($compAdd['address'])){
        			Unset($ownerCompany['owner_company_offices'][$key]);
        		}
        	}
        //	echo "<pre>"; print_r($this->request->data["data"]["delcontDetail"]);exit;
        	$ownerCompany['modified_by'] = $this->Auth->User('id');
        	
            if ($this->OwnerCompanies->save($ownerCompany)) {
            	if(isset($this->request->data["data"]["deladdDetail"])){
            		//print_r($expression)
            		$this->OwnerCompanies->OwnerCompanyOffices->deleteAll(['id IN'=>$this->request->data["data"]["deladdDetail"]]);
            	}
            	if(isset($this->request->data["data"]["delcontDetail"])){
            		$this->OwnerCompanies->OwnerContactPersons->deleteAll(['id IN'=>$this->request->data["data"]["delcontDetail"]]);
            	}
            	if(isset($this->request->data["logo"]) &&  $this->request->data["logo"]["error"]==0){
            		$filename=$this->request->data["logo"]["name"];
            		$url = Router::url('/',true).'upload/owner-company-logo/'.$filename;
            		$uploadpath = 'upload/owner-company-logo/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["logo"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["logo"]);
            	}
            	if(isset($this->request->data["header"]) &&  $this->request->data["header"]["error"]==0){
            		$filename=$this->request->data["header"]["name"];
            		$url = Router::url('/',true).'upload/owner-company-header/'.$filename;
            		$uploadpath = 'upload/owner-company-header/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["header"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["header"]);
            	}
            	if(isset($this->request->data["footer"]) &&  $this->request->data["footer"]["error"]==0){
            		$filename=$this->request->data["footer"]["name"];
            		$url = Router::url('/',true).'upload/owner-company-footer/'.$filename;
            		$uploadpath = 'upload/owner-company-footer/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["footer"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["footer"]);
            	}
            	if(isset($this->request->data["stamp"]) &&  $this->request->data["stamp"]["error"]==0){
            		$filename=$this->request->data["stamp"]["name"];
            		$url = Router::url('/',true).'upload/owner-company-stamp/'.$filename;
            		$uploadpath = 'upload/owner-company-stamp/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["stamp"]['tmp_name'], $uploadfile);
            		//echo $uploadfile; exit;
            		 
            	}else{
            		unset($this->request->data["stamp"]);
            	}
                $this->Flash->success(__('The {0} has been saved.', 'Owner Company'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Owner Company'));
            }
        }
        $this->loadModel('City');
        $this->loadModel('State');
        $this->loadModel('Countries');
        $this->loadModel('PortOfDischarge');
        $this->loadModel('Users');
        $city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name']);
        $state = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name']);
        $countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        $port_of_discharge_sea = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['type like'=>'0']]);
        $port_of_discharge_air = $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge','conditions'=>['type like'=>'1']]);
        $users = $this->Users->find('list', ['keyField'=>'id', 'valueField'=>'userfullname','order'=>'userfullname']);
        $this->set(compact('ownerCompany','city','state','countries','port_of_discharge_sea','port_of_discharge_air','users'));
        $this->set('_serialize', ['ownerCompany']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Owner Company id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ownerCompany = $this->OwnerCompanies->get($id);
        if ($this->OwnerCompanies->delete($ownerCompany)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Owner Company'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Owner Company'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
