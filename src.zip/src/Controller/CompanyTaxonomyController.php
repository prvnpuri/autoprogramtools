<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanyTaxonomy Controller
 *
 * @property \App\Model\Table\CompanyTaxonomyTable $CompanyTaxonomy
 *
 * @method \App\Model\Entity\CompanyTaxonomy[] paginate($object = null, array $settings = [])
 */
class CompanyTaxonomyController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Companies']
        ];
        $companyTaxonomy = $this->paginate($this->CompanyTaxonomy);

        $this->set(compact('companyTaxonomy'));
        $this->set('_serialize', ['companyTaxonomy']);
    }

    /**
     * View method
     *
     * @param string|null $id Company Taxonomy id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companyTaxonomy = $this->CompanyTaxonomy->get($id, [
            'contain' => ['Companies', 'CompanyTaxonomyAssociation']
        ]);

        $this->set('companyTaxonomy', $companyTaxonomy);
        $this->set('_serialize', ['companyTaxonomy']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companyTaxonomy = $this->CompanyTaxonomy->newEntity();
        if ($this->request->is('post')) {
            $companyTaxonomy = $this->CompanyTaxonomy->patchEntity($companyTaxonomy, $this->request->data);
            if ($this->CompanyTaxonomy->save($companyTaxonomy)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Taxonomy'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Taxonomy'));
            }
        }
        $companies = $this->CompanyTaxonomy->Companies->find('list', ['limit' => 200]);
        $this->set(compact('companyTaxonomy', 'companies'));
        $this->set('_serialize', ['companyTaxonomy']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Taxonomy id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companyTaxonomy = $this->CompanyTaxonomy->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companyTaxonomy = $this->CompanyTaxonomy->patchEntity($companyTaxonomy, $this->request->data);
            if ($this->CompanyTaxonomy->save($companyTaxonomy)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Taxonomy'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Taxonomy'));
            }
        }
        $companies = $this->CompanyTaxonomy->Companies->find('list', ['limit' => 200]);
        $this->set(compact('companyTaxonomy', 'companies'));
        $this->set('_serialize', ['companyTaxonomy']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Taxonomy id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyTaxonomy = $this->CompanyTaxonomy->get($id);
        if ($this->CompanyTaxonomy->delete($companyTaxonomy)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Taxonomy'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Taxonomy'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
