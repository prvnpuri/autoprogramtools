<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Sampledocumentshipment Controller
 *
 * @property \App\Model\Table\SampledocumentshipmentTable $Sampledocumentshipment
 *
 * @method \App\Model\Entity\Sampledocumentshipment[] paginate($object = null, array $settings = [])
 */
class SampledocumentshipmentController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Shippers', 'Consignees']
        ];
        $sampledocumentshipment = $this->paginate($this->Sampledocumentshipment);

        $this->set(compact('sampledocumentshipment'));
        $this->set('_serialize', ['sampledocumentshipment']);
    }

    /**
     * View method
     *
     * @param string|null $id Sampledocumentshipment id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $sampledocumentshipment = $this->Sampledocumentshipment->get($id, [
            'contain' => ['Shippers', 'Consignees']
        ]);

        $this->set('sampledocumentshipment', $sampledocumentshipment);
        $this->set('_serialize', ['sampledocumentshipment']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $sampledocumentshipment = $this->Sampledocumentshipment->newEntity();
        if ($this->request->is('post')) {
            $sampledocumentshipment = $this->Sampledocumentshipment->patchEntity($sampledocumentshipment, $this->request->data);
            if ($this->Sampledocumentshipment->save($sampledocumentshipment)) {
                $this->Flash->success(__('The {0} has been saved.', 'Sampledocumentshipment'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Sampledocumentshipment'));
            }
        }
        $shippers = $this->Sampledocumentshipment->Shippers->find('list', ['limit' => 200]);
        $consignees = $this->Sampledocumentshipment->Consignees->find('list', ['limit' => 200]);
        $this->set(compact('sampledocumentshipment', 'shippers', 'consignees'));
        $this->set('_serialize', ['sampledocumentshipment']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Sampledocumentshipment id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $sampledocumentshipment = $this->Sampledocumentshipment->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $sampledocumentshipment = $this->Sampledocumentshipment->patchEntity($sampledocumentshipment, $this->request->data);
            if ($this->Sampledocumentshipment->save($sampledocumentshipment)) {
                $this->Flash->success(__('The {0} has been saved.', 'Sampledocumentshipment'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Sampledocumentshipment'));
            }
        }
        $shippers = $this->Sampledocumentshipment->Shippers->find('list', ['limit' => 200]);
        $consignees = $this->Sampledocumentshipment->Consignees->find('list', ['limit' => 200]);
        $this->set(compact('sampledocumentshipment', 'shippers', 'consignees'));
        $this->set('_serialize', ['sampledocumentshipment']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Sampledocumentshipment id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $sampledocumentshipment = $this->Sampledocumentshipment->get($id);
        if ($this->Sampledocumentshipment->delete($sampledocumentshipment)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Sampledocumentshipment'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Sampledocumentshipment'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
