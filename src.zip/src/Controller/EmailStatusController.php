<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * EmailStatus Controller
 *
 * @property \App\Model\Table\EmailStatusTable $EmailStatus
 *
 * @method \App\Model\Entity\EmailStatus[] paginate($object = null, array $settings = [])
 */
class EmailStatusController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $emailStatus = $this->paginate($this->EmailStatus);

        $this->set(compact('emailStatus'));
        $this->set('_serialize', ['emailStatus']);
    }

    /**
     * View method
     *
     * @param string|null $id Email Status id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $emailStatus = $this->EmailStatus->get($id, [
            'contain' => []
        ]);

        $this->set('emailStatus', $emailStatus);
        $this->set('_serialize', ['emailStatus']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $emailStatus = $this->EmailStatus->newEntity();
        if ($this->request->is('post')) {
            $emailStatus = $this->EmailStatus->patchEntity($emailStatus, $this->request->data);
            if ($this->EmailStatus->save($emailStatus)) {
                $this->Flash->success(__('The {0} has been saved.', 'Email Status'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Email Status'));
            }
        }
        $this->set(compact('emailStatus'));
        $this->set('_serialize', ['emailStatus']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Email Status id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $emailStatus = $this->EmailStatus->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $emailStatus = $this->EmailStatus->patchEntity($emailStatus, $this->request->data);
            if ($this->EmailStatus->save($emailStatus)) {
                $this->Flash->success(__('The {0} has been saved.', 'Email Status'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Email Status'));
            }
        }
        $this->set(compact('emailStatus'));
        $this->set('_serialize', ['emailStatus']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Email Status id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $emailStatus = $this->EmailStatus->get($id);
        if ($this->EmailStatus->delete($emailStatus)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Email Status'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Email Status'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
