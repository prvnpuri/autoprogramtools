<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OwnerBankMaster Controller
 *
 * @property \App\Model\Table\OwnerBankMasterTable $OwnerBankMaster
 *
 * @method \App\Model\Entity\OwnerBankMaster[] paginate($object = null, array $settings = [])
 */
class OwnerBankMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanies', 'Currency']
        ];
        $ownerBankMaster = $this->paginate($this->OwnerBankMaster);

        $this->set(compact('ownerBankMaster'));
        $this->set('_serialize', ['ownerBankMaster']);
    }

    /**
     * View method
     *
     * @param string|null $id Owner Bank Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ownerBankMaster = $this->OwnerBankMaster->get($id, [
            'contain' => ['OwnerCompanies', 'Currency']
        ]);

        $this->set('ownerBankMaster', $ownerBankMaster);
        $this->set('_serialize', ['ownerBankMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ownerBankMaster = $this->OwnerBankMaster->newEntity();
        if ($this->request->is('post')) {
            $ownerBankMaster = $this->OwnerBankMaster->patchEntity($ownerBankMaster, $this->request->data);
            if ($this->OwnerBankMaster->save($ownerBankMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Owner Bank Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Owner Bank Master'));
            }
        }
        $ownerCompanies = $this->OwnerBankMaster->OwnerCompanies->find('list', ['limit' => 200]);
        $currency = $this->OwnerBankMaster->Currency->find('list', ['limit' => 200]);
        $this->set(compact('ownerBankMaster', 'ownerCompanies', 'currency'));
        $this->set('_serialize', ['ownerBankMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Owner Bank Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ownerBankMaster = $this->OwnerBankMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ownerBankMaster = $this->OwnerBankMaster->patchEntity($ownerBankMaster, $this->request->data);
            if ($this->OwnerBankMaster->save($ownerBankMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Owner Bank Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Owner Bank Master'));
            }
        }
        $ownerCompanies = $this->OwnerBankMaster->OwnerCompanies->find('list', ['limit' => 200]);
        $currency = $this->OwnerBankMaster->Currency->find('list', ['limit' => 200]);
        $this->set(compact('ownerBankMaster', 'ownerCompanies', 'currency'));
        $this->set('_serialize', ['ownerBankMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Owner Bank Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ownerBankMaster = $this->OwnerBankMaster->get($id);
        if ($this->OwnerBankMaster->delete($ownerBankMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Owner Bank Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Owner Bank Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
