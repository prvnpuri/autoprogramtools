<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Lrcopy Controller
 *
 * @property \App\Model\Table\LrcopyTable $Lrcopy
 *
 * @method \App\Model\Entity\Lrcopy[] paginate($object = null, array $settings = [])
 */
class LrcopyController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Oas', 'Currency', 'Products', 'Uoms']
        ];
        $lrcopy = $this->paginate($this->Lrcopy);

        $this->set(compact('lrcopy'));
        $this->set('_serialize', ['lrcopy']);
    }

    /**
     * View method
     *
     * @param string|null $id Lrcopy id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $lrcopy = $this->Lrcopy->get($id, [
            'contain' => ['Oas', 'Currency', 'Products', 'Uoms', 'Photo', 'Transporters']
        ]);

        $this->set('lrcopy', $lrcopy);
        $this->set('_serialize', ['lrcopy']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $lrcopy = $this->Lrcopy->newEntity();
        if ($this->request->is('post')) {
            $lrcopy = $this->Lrcopy->patchEntity($lrcopy, $this->request->data);
            if ($this->Lrcopy->save($lrcopy)) {
                $this->Flash->success(__('The {0} has been saved.', 'Lrcopy'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Lrcopy'));
            }
        }
        $oas = $this->Lrcopy->Oas->find('list', ['limit' => 200]);
        $currency = $this->Lrcopy->Currency->find('list', ['limit' => 200]);
        $products = $this->Lrcopy->Products->find('list', ['limit' => 200]);
        $uoms = $this->Lrcopy->Uoms->find('list', ['limit' => 200]);
        $photo = $this->Lrcopy->Photo->find('list', ['limit' => 200]);
        $this->set(compact('lrcopy', 'oas', 'currency', 'products', 'uoms', 'photo'));
        $this->set('_serialize', ['lrcopy']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Lrcopy id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $lrcopy = $this->Lrcopy->get($id, [
            'contain' => ['Photo']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $lrcopy = $this->Lrcopy->patchEntity($lrcopy, $this->request->data);
            if ($this->Lrcopy->save($lrcopy)) {
                $this->Flash->success(__('The {0} has been saved.', 'Lrcopy'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Lrcopy'));
            }
        }
        $oas = $this->Lrcopy->Oas->find('list', ['limit' => 200]);
        $currency = $this->Lrcopy->Currency->find('list', ['limit' => 200]);
        $products = $this->Lrcopy->Products->find('list', ['limit' => 200]);
        $uoms = $this->Lrcopy->Uoms->find('list', ['limit' => 200]);
        $photo = $this->Lrcopy->Photo->find('list', ['limit' => 200]);
        $this->set(compact('lrcopy', 'oas', 'currency', 'products', 'uoms', 'photo'));
        $this->set('_serialize', ['lrcopy']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Lrcopy id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $lrcopy = $this->Lrcopy->get($id);
        if ($this->Lrcopy->delete($lrcopy)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Lrcopy'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Lrcopy'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
