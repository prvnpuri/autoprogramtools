<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Filesystem\File;

/**
 * FactoryQcequipment Controller
 *
 *
 * @method \App\Model\Entity\FactoryQcequipment[] paginate($object = null, array $settings = [])
 */
class FactoryQcequipmentController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="FactoryQcequipment.qc_type like '%$query%'";
    	}
    	$this->paginate = [
    			
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","classification","qc_type","material_of_construction","capacity","uom","specification"]
    	];
    	$this->loadModel('Uom');
    	$uoms = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_name'], ['limit' => 200]);
    	$factoryQcequipment = $this->paginate($this->FactoryQcequipment);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('factoryQcequipment'));
    	$this->set( '_serialize', ['factoryQcequipment','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Factory Qcequipment id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $factoryQcequipment = $this->FactoryQcequipment->get($id, [
            'contain' => []
        ]);
        
        $this->loadModel('Users');
        $this->loadModel('Uom');
        $this->loadModel('OwnerCompanies');
        $this->loadModel('CompanyMaster');
        
        $uom = $this->Uom->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'unit_name',
        		'conditions'=>['Uom.id' => $factoryQcequipment->uom],
        		'order' => ['Uom.id' => 'ASC']
        ]);
        $uom = $uom->first();
        
        $user = $this->Users->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'userfullname',
        		'conditions'=>['Users.id' => $factoryQcequipment->person_incharge],
        		'order' => ['Users.id' => 'ASC']
        ]);
        $user = $user->first();
        
        $ownerCompany = $this->OwnerCompanies->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions'=>['OwnerCompanies.id' => $factoryQcequipment->owner_company_id],
        		'order' => ['OwnerCompanies.id' => 'ASC']
        ]);
        $ownerCompany = $ownerCompany->first();
        
        $companyName = $this->CompanyMaster->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions'=>['CompanyMaster.id' => $factoryQcequipment->purchased_from],
        		'order' => ['CompanyMaster.id' => 'ASC']
        ]);
        $companyName = $companyName->first();
        
        if(isset($factoryQcequipment->files)){
        	$fileexplode = explode(", ", $factoryQcequipment->files);
        	foreach ($fileexplode as $file){
        		$files[] = array($file);
        	}
        }
        
        
        $this->set(compact('factoryQcequipment','uom','user','ownerCompany','companyName','files'));
        $this->set('_serialize', ['factoryQcequipment']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $factoryQcequipment = $this->FactoryQcequipment->newEntity();
        
        if ($this->request->is('post')) {

        	foreach ($this->request->data['factory_qcequipment'] as $key => $value){
        		$files[]= $value["file"]["name"];	
        	}
        	
        	if(isset($value["file"]) &&  $value["file"]["error"]==0)
        	{
        		$filename=implode(", ", $files);
        		$this->request->data['files'] = $filename;
        	}else{
        		unset($this->request->data['files']);
        	}
        	$factoryQcequipment = $this->FactoryQcequipment->patchEntity($factoryQcequipment, $this->request->data);
        	$factoryQcequipment['created_by'] = $this->Auth->User('id');
            if ($this->FactoryQcequipment->save($factoryQcequipment)) {
            	
            	$id = $factoryQcequipment->id;
            	foreach ($this->request->data['factory_qcequipment'] as $key => $value){
            		if(isset($value["file"]) &&  $value["file"]["error"]==0)
            		{
            			$filename = $value["file"]["name"];         			
            			$uploadpath = 'upload/factory-qcequipment/';
            			$tmp = $value["file"]['tmp_name'];
            			if (!is_dir($uploadpath."/".$id)) {
            				mkdir($uploadpath."/".$id);
            			}
                        $movefiledir = "upload/factory-qcequipment/".$id."/".$filename;
                        $uploadpath = WWW_ROOT . "upload".DS."factory-qcequipment".DS.$id;
                        
            			move_uploaded_file($tmp, $movefiledir);
            			$this->request->data['files_path'] = $uploadpath;
            			$uploadfile = $this->FactoryQcequipment->patchEntity($factoryQcequipment, $this->request->data);
            			 
            			$this->FactoryQcequipment->save($uploadfile);
            		}else{
            			unset($this->request->data['factory_qcequipment']);
            		}	
            	}
                $this->Flash->success(__('The {0} has been saved.', 'Factory Qcequipment'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Factory Qcequipment'));
            }
        }
        $this->loadModel('Users');
        $this->loadModel('Uom');
        $this->loadModel('OwnerCompanies');
        $uoms = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_name'], ['limit' => 200]);
        $users = $this->Users->find('list',['keyField' => 'id', 'valueField' => 'userfullname'], ['limit' => 200]);
        $ownerCompanies = $this->OwnerCompanies->find('list',['keyField'=>'id', 'valueField'=>'Company_name'], ['limit'=>200]);
        $this->set(compact('factoryQcequipment','uoms','users','ownerCompanies'));
        $this->set('_serialize', ['factoryQcequipment']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Factory Qcequipment id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $factoryQcequipment = $this->FactoryQcequipment->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
        	foreach ($this->request->data['factory_qcequipment'] as $key => $value){
        		if(isset($value["file"]) &&  $value["file"]["error"]==0)
        		{
        		$files[]= $value["file"]["name"];
        		}else{
        			unset($this->request->data['factory_qcequipment']);
        		}
        	}
        	if(isset($this->request->data['filenamexisting'])){
        		
        		if(!isset($this->request->data['Delete']['id'])){
        			$existingFile	= $this->request->data['filenamexisting'].", ";
        		}else{

        			$ext = explode(", ",$this->request->data['filenamexisting']);
        			$merge = array_diff($ext, $this->request->data['Delete']['id']);
        			$existing = implode(", ", $merge);
        			$existingFile	= $existing.", ";
        		}
        	}else{
        		$existingFile = null;
        	}
        	
        	if(isset($value["file"]) &&  $value["file"]["error"]==0 && isset($this->request->data['Delete']['id']))
        	{
        		$filename=implode(", ", $files);
        		$this->request->data['files'] = trim($existingFile.$filename,", ");	
        	}elseif(isset($value["file"]) &&  $value["file"]["error"]==0 && !isset($this->request->data['Delete']['id']))
        	{
        		$filename=implode(", ", $files);
        		$this->request->data['files'] = trim($existingFile.$filename,", ");
        	}
        	else if($value["file"]["error"] !=0 && isset($this->request->data['Delete']['id'])){
        		$this->request->data['files'] = trim($existingFile,", ");
        	}else {
        		unset($this->request->data['factory_qcequipment']);
        	}
        	
        	$factoryQcequipment = $this->FactoryQcequipment->patchEntity($factoryQcequipment, $this->request->data);
            $factoryQcequipment['modified_by'] = $this->Auth->User('id');
            
            if ($this->FactoryQcequipment->save($factoryQcequipment)) {
            	if(isset($this->request->data["factory_qcequipment"])){
            	$id = $factoryQcequipment->id;
            	foreach ($this->request->data['factory_qcequipment'] as $key => $value){
            		if(isset($value["file"]) &&  $value["file"]["error"]==0)
            		{
            			$filename = $value["file"]["name"];
            			$uploadpath = 'upload/factory-qcequipment/';
            			$tmp = $value["file"]['tmp_name'];
            			if (!is_dir($uploadpath."/".$id)) {
            				mkdir($uploadpath."/".$id);
            			}
            			$movefiledir = "upload/factory-qcequipment/".$id."/".$filename;
            			$uploadpath = WWW_ROOT . "upload".DS."factory-qcequipment".DS.$id;
            			
            			move_uploaded_file($tmp, $movefiledir);
            			$this->request->data['files_path'] = $uploadpath;
            			$uploadfile = $this->FactoryQcequipment->patchEntity($factoryQcequipment, $this->request->data);
            			
            			$this->FactoryQcequipment->save($uploadfile);
            		}else{
            			unset($this->request->data['factory_qcequipment']);
            		}
            	}
            	}
            	
            	
                $this->Flash->success(__('The {0} has been saved.', 'Factory Qcequipment'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Factory Qcequipment'));
            }
        }
        
        $this->loadModel('Users');
        $this->loadModel('Uom');
        $this->loadModel('OwnerCompanies');
        $this->loadModel('CompanyMaster');
        $uoms = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_name'], ['limit' => 200]);
        $users = $this->Users->find('list',['keyField' => 'id', 'valueField' => 'userfullname'], ['limit' => 200]);
        $ownerCompanies = $this->OwnerCompanies->find('list',['keyField'=>'id', 'valueField'=>'Company_name'], ['limit'=>200]);
        
        $companyName = $this->CompanyMaster->find('all', [
        		'keyField' => 'id',
        		'valueField' => 'Company_name',
        		'conditions'=>['CompanyMaster.id' => $factoryQcequipment->purchased_from],
        		'order' => ['CompanyMaster.id' => 'ASC']
        ]);
        $companyName = $companyName->first();
        
        if(isset($factoryQcequipment->files)){
        $fileexplode = explode(", ", $factoryQcequipment->files);
           foreach ($fileexplode as $file){
        	 $files[] = array($file);
           }
        }
        
        $this->set(compact('factoryQcequipment','uoms','users','ownerCompanies','companyName','files'));
        $this->set('_serialize', ['factoryQcequipment']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Factory Qcequipment id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $factoryQcequipment = $this->FactoryQcequipment->get($id);

        if ($this->FactoryQcequipment->delete($factoryQcequipment)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Factory Qcequipment'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Factory Qcequipment'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
