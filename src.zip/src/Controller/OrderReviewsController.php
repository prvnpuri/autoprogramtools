<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OrderReviews Controller
 *
 * @property \App\Model\Table\OrderReviewsTable $OrderReviews
 *
 * @method \App\Model\Entity\OrderReview[] paginate($object = null, array $settings = [])
 */
class OrderReviewsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$ownercompanyid = $this->Auth->User('owner_company_id');
    	$this->loadModel('Order');
        $options = $this->Order->find("all",[
        		"contain"=>['OrderReviews','CompanyMaster','CustomerMaster','ProductsMaster','Uom','Currency','OwnerCompanies'],
        		"conditions"=>["Order.review_status"=>"SENT","Order.owner_companies_id"=>$ownercompanyid],
        		"order"=>"Order.id"
        ]);
        $this->set('orderReviews',$this->paginate($options));
       
        $this->set('_serialize', ['orderReviews']);
    }

    /**
     * View method
     *
     * @param string|null $id Order Review id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $orderReview = $this->OrderReviews->get($id, [
        		'contain' => ['Order','OrderReviewParticularMaster','Order.CompanyMaster','Order.ShippingCompany',
        				'Order.ProductsMaster','Order.PackingTerm','Order.PackingType','Order.Uom','Order.IncoTerms', 'Order.Currency','Order.OwnerCompanies',
        				'Order.CountryOfFinalDestination','Order.CountryOfOriginOfGood','Order.PortOfDischarge','Order.Countries','Order.PaymentTerm']
        ]);
        $this->loadModel('OrderReviewParticularMaster');
        $this->loadModel('OrderReviewParticular');
        $this->loadModel('IncoTerms');
        $particulars = $this->OrderReviewParticular->find('list',array(
        		'keyField'=>'id', 'valueField'=>'particulars',
        		'order'=>array('position'),
        		"conditions"=>array("active"=>1)
        ));
        $this->set('particulars',$particulars);
       
        $orderparticulars = $this->OrderReviewParticularMaster->find('all',array(
        		'contain'=>['OrderReviewParticular'],
        		'conditions'=>array('OrderReviewParticularMaster.order_review_id'=>$id),
        ));
        $this->set('orderreviewparticular',$orderparticulars);
        $this->set('incoterms', $this->IncoTerms->find("list",array("keyField"=>"id","valueField"=>"inco_term")));
        $this->set(compact('orderReview'));
        $this->set('_serialize', ['orderReview']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($order_id= null)
    {
    	$this->loadModel('Order');
		$order = $this->Order->get($order_id, [
				'contain' => ['CompanyMaster','ShippingCompany',
						'ProductsMaster','PackingTerm','PackingType','Uom','IncoTerms', 'Currency','OwnerCompanies',
						'CountryOfFinalDestination','CountryOfOriginOfGood','PortOfDischarge','Countries','PaymentTerm']
		]);
		$this->set(compact('order'));
        $orderReview = $this->OrderReviews->newEntity();
        
        if ($this->request->is('post')) {
            $orderReview = $this->OrderReviews->patchEntity($orderReview, $this->request->data,
            		['associated' => ['OrderReviewParticularMaster']]
            );
           
            if ($this->OrderReviews->save($orderReview)) {
                $this->Flash->success(__('The {0} has been saved.', 'Order Review'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Order Review'));
            }
        }
        $this->loadModel('OrderReviewParticular');
        $this->loadModel('IncoTerms');
        $particulars = $this->OrderReviewParticular->find('list',array(
        		'keyField'=>'id', 'valueField'=>'particulars',
        		'order'=>array('position'),
        		"conditions"=>array("active"=>1)
        ));
        $this->set('particulars',$particulars);
        $this->set('incoterms', $this->IncoTerms->find("list",array("keyField"=>"inco_term","valueField"=>"inco_term")));
       
        $paymentterm= $this->Order->PaymentTerm->find('list', ['keyField' => 'term','valueField' => 'term','order'=>'term']);
        
        $packingtype= $this->Order->PackingType->find('list', ['keyField' => 'packing_type','valueField' => 'packing_type','order'=>'packing_type']);
        
        $this->set(compact('orderReview','paymentterm','packingtype'));
        $this->set('_serialize', ['orderReview']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Order Review id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $orderReview = $this->OrderReviews->get($id, [
        		'contain' => ['Order','OrderReviewParticularMaster','Order.CompanyMaster','Order.ShippingCompany',
        				'Order.ProductsMaster','Order.PackingTerm','Order.PackingType','Order.Uom','Order.IncoTerms', 'Order.Currency','Order.OwnerCompanies',
        				'Order.CountryOfFinalDestination','Order.CountryOfOriginOfGood','Order.PortOfDischarge','Order.Countries','Order.PaymentTerm']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $orderReview = $this->OrderReviews->patchEntity($orderReview, $this->request->getData(),
            		['associated' => ['OrderReviewParticularMaster']]
            );
            if ($this->OrderReviews->save($orderReview)) {
                $this->Flash->success(__('The {0} has been saved.', 'Order Review'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Order Review'));
            }
        }
        $this->loadModel('OrderReviewParticularMaster');
        $this->loadModel('OrderReviewParticular');
        $this->loadModel('IncoTerms');
        $particulars = $this->OrderReviewParticular->find('list',array(
        		'keyField'=>'id', 'valueField'=>'particulars',
        		'order'=>array('position'),
        		"conditions"=>array("active"=>1)
        ));
        $this->set('particulars',$particulars);
       
        $orderparticulars = $this->OrderReviewParticularMaster->find('all',array(
        		'contain'=>['OrderReviewParticular'],
        		'conditions'=>array('OrderReviewParticularMaster.order_review_id'=>$id),
        ));
        $this->set('orderreviewparticular',$orderparticulars);
        $this->set('incoterms', $this->IncoTerms->find("list",array("keyField"=>"inco_term","valueField"=>"inco_term")));
        $paymentterm= $this->OrderReviews->Order->PaymentTerm->find('list', ['keyField' => 'term','valueField' => 'term','order'=>'term']);
        
        $packingtype= $this->OrderReviews->Order->PackingType->find('list', ['keyField' => 'packing_type','valueField' => 'packing_type','order'=>'packing_type']);
        
        $this->set(compact('orderReview','paymentterm','packingtype'));
        $this->set('_serialize', ['orderReview']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Order Review id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $orderReview = $this->OrderReviews->get($id);
        if ($this->OrderReviews->delete($orderReview)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Order Review'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Order Review'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    public function sendToOrderAcceptance($id=null) {
    	
    	$this->loadModel('Order');
    	
    	$order = $this->Order->get($id);
    	
    	$data = array('id' => $id , 'send_to_oa' => "SENT");
    	$order= $this->Order->patchEntity($order, $data);
    	
    	
    	$this->Order->save($order);
    	$this->Flash->success(__('Order has been sent to Order Acceptance.'));
    	return $this->redirect(['action' => 'index']);
    	
    	
    
    
    }
    
    
    
    
    public function backtoorder($id=null) {
    	
    	
    	$this->loadModel('Order');
    	$order = $this->Order->get($id);
    	
    	$data = array('id' => $id , 'review_status' => "On_hold",'send_to_oa' => NULL);
    	$order= $this->Order->patchEntity($order, $data);
    	
    	
    	$this->Order->save($order);
    	$this->Flash->success(__('Order Review has been sent back to Order Summary.'));
    	return $this->redirect(['action' => 'index']);
    	
    	
    	
    }
    
    
    public function printOrderreview($POId)
    {
    	$this->view($POId);
    	//$this->viewBuilder()->setLayout("blank");
    	
    }
    
    
}
