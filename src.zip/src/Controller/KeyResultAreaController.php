<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * KeyResultArea Controller
 *
 * @property \App\Model\Table\KeyResultAreaTable $KeyResultArea
 *
 * @method \App\Model\Entity\KeyResultArea[] paginate($object = null, array $settings = [])
 */
class KeyResultAreaController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Employees']
        ];
        $keyResultArea = $this->paginate($this->KeyResultArea);

        $this->set(compact('keyResultArea'));
        $this->set('_serialize', ['keyResultArea']);
    }

    /**
     * View method
     *
     * @param string|null $id Key Result Area id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $keyResultArea = $this->KeyResultArea->get($id, [
            'contain' => ['Employees', 'DailyWorkDetails', 'KeyResultAreaRating', 'KeyResultAreaTimeFrame']
        ]);

        $this->set('keyResultArea', $keyResultArea);
        $this->set('_serialize', ['keyResultArea']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $keyResultArea = $this->KeyResultArea->newEntity();
        if ($this->request->is('post')) {
            $keyResultArea = $this->KeyResultArea->patchEntity($keyResultArea, $this->request->data);
            if ($this->KeyResultArea->save($keyResultArea)) {
                $this->Flash->success(__('The {0} has been saved.', 'Key Result Area'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Key Result Area'));
            }
        }
        $employees = $this->KeyResultArea->Employees->find('list', ['limit' => 200]);
        $this->set(compact('keyResultArea', 'employees'));
        $this->set('_serialize', ['keyResultArea']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Key Result Area id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $keyResultArea = $this->KeyResultArea->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $keyResultArea = $this->KeyResultArea->patchEntity($keyResultArea, $this->request->data);
            if ($this->KeyResultArea->save($keyResultArea)) {
                $this->Flash->success(__('The {0} has been saved.', 'Key Result Area'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Key Result Area'));
            }
        }
        $employees = $this->KeyResultArea->Employees->find('list', ['limit' => 200]);
        $this->set(compact('keyResultArea', 'employees'));
        $this->set('_serialize', ['keyResultArea']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Key Result Area id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $keyResultArea = $this->KeyResultArea->get($id);
        if ($this->KeyResultArea->delete($keyResultArea)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Key Result Area'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Key Result Area'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
