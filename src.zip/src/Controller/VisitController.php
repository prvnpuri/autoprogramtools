<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Visit Controller
 *
 * @property \App\Model\Table\VisitTable $Visit
 *
 * @method \App\Model\Entity\Visit[] paginate($object = null, array $settings = [])
 */
class VisitController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
	
	public function index($cond = null)
	{
		$query = $this->Visit->find('all');
		$comp_search=$this->request->getQuery('search');
		$comp_search=$comp_search.'%';
		$this->paginate = [
				'contain' => ['CompanyMaster'],
				'group'=>'company',
				'conditions'=>['CompanyMaster.company_name like ' => $comp_search]
		];
		$this->set('visit', $this->paginate($query));
		$this->set('_serialize', ['visit']);
	}
	
	public function editindex($company = null) {
		$visit = $this->Visit->find()
			->where(['company' => $company])
			->contain(['CompanyMaster']) ;
		
		if ($this->request->is(['patch', 'post', 'put'])) {
			$patched = $this->Visit->patchEntities($visit, $this->request->data());
			
			if($patched){
				foreach ($patched as $entity) {
					$entity['modified_by'] = $this->Auth->User('id');
					$this->Visit->save($entity);
				}
				return $this->redirect(['action' => 'index']);
				$this->Flash->success(__('The {0} has been saved.', 'Visit'));
			}
			else {
				return $this->redirect(['action' => 'index']);
				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Visit'));
			}
		}
		
		$this->set(compact('visit'));
		$this->set('_serialize', ['visit']);
	}
	
	
    /**
     * View method
     *
     * @param string|null $id Visit id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($company = null)
    {
		$visit = $this->Visit->find('all', [
    			'keyField' => 'id',
    			'conditions'=>['company' => $company]
    	]);
    	
		$this->loadModel('CompanyMaster');
    	$companyName = $this->CompanyMaster->find('all', [
    			'keyField' => 'Visit.company',
    			'conditions'=>['CompanyMaster.id' => $company],
    			'order' => ['CompanyMaster.id' => 'ASC']
    	]);
    	$this->set(compact('visit','companyName'));
    	$this->set('_serialize', ['visit']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $visit = $this->Visit->newEntity();
        if ($this->request->is('post')) {
            $visit = $this->Visit->patchEntity($visit, $this->request->data);
            $visit['created_by'] = $this->Auth->User('id');
            if ($this->Visit->save($visit)) {
                $this->Flash->success(__('The {0} has been saved.', 'Visit'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Visit'));
            }
        }
        
        $this->set(compact('visit'));
        $this->set('_serialize', ['visit']);
    }
    
    public function addvisit($company = null) {
    	$visit = $this->Visit->find('all', [
    			'keyField' => 'id',
    			'conditions'=>['company' => $company]
    	]);

    	$visit = $this->Visit->newEntity();
    	if ($this->request->is('post')) { 
    		$visit = $this->Visit->patchEntity($visit, $this->request->data);
    		$visit['created_by'] = $this->Auth->User('id');
    		if ($this->Visit->save($visit)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Visit'));
    			return $this->redirect(['action' => 'index']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Visit'));
    		}
    	}
    	
    	$this->loadModel('CompanyMaster');
    	$companyName = $this->CompanyMaster->find('all', [
    			'keyField' => 'id',
    			'valueField' => ['CompanyMaster.Company_name','Visit.*'],
    			'conditions'=>['CompanyMaster.id' => $company],
    			'order' => ['CompanyMaster.id' => 'ASC']
    	]);
    	$companyName = $companyName->first();
    	
    	$this->set(compact('visit','companyName'));
    	$this->set('_serialize', ['visit']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Visit id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $visit = $this->Visit->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $visit = $this->Visit->patchEntity($visit, $this->request->data);
            if ($this->Visit->save($visit)) {
                $this->Flash->success(__('The {0} has been saved.', 'Visit'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Visit'));
            }
        }
        $this->set(compact('visit'));
        $this->set('_serialize', ['visit']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Visit id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $visit = $this->Visit->get($id);
        if ($this->Visit->delete($visit)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Visit'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Visit'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
