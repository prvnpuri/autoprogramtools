<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * BuyerPurchaseOrder Controller
 *
 * @property \App\Model\Table\BuyerPurchaseOrderTable $BuyerPurchaseOrder
 *
 * @method \App\Model\Entity\BuyerPurchaseOrder[] paginate($object = null, array $settings = [])
 */
class BuyerPurchaseOrderController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Uoms', 'Currencies', 'IncoTerms']
        ];
        $buyerPurchaseOrder = $this->paginate($this->BuyerPurchaseOrder);

        $this->set(compact('buyerPurchaseOrder'));
        $this->set('_serialize', ['buyerPurchaseOrder']);
    }

    /**
     * View method
     *
     * @param string|null $id Buyer Purchase Order id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $buyerPurchaseOrder = $this->BuyerPurchaseOrder->get($id, [
            'contain' => ['Orders', 'Uoms', 'Currencies', 'IncoTerms', 'ExciseTaxInvoice', 'TaxInvoice']
        ]);

        $this->set('buyerPurchaseOrder', $buyerPurchaseOrder);
        $this->set('_serialize', ['buyerPurchaseOrder']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $buyerPurchaseOrder = $this->BuyerPurchaseOrder->newEntity();
        if ($this->request->is('post')) {
            $buyerPurchaseOrder = $this->BuyerPurchaseOrder->patchEntity($buyerPurchaseOrder, $this->request->data);
            if ($this->BuyerPurchaseOrder->save($buyerPurchaseOrder)) {
                $this->Flash->success(__('The {0} has been saved.', 'Buyer Purchase Order'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Buyer Purchase Order'));
            }
        }
        $orders = $this->BuyerPurchaseOrder->Orders->find('list', ['limit' => 200]);
        $uoms = $this->BuyerPurchaseOrder->Uoms->find('list', ['limit' => 200]);
        $currencies = $this->BuyerPurchaseOrder->Currencies->find('list', ['limit' => 200]);
        $incoTerms = $this->BuyerPurchaseOrder->IncoTerms->find('list', ['limit' => 200]);
        $this->set(compact('buyerPurchaseOrder', 'orders', 'uoms', 'currencies', 'incoTerms'));
        $this->set('_serialize', ['buyerPurchaseOrder']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Buyer Purchase Order id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $buyerPurchaseOrder = $this->BuyerPurchaseOrder->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $buyerPurchaseOrder = $this->BuyerPurchaseOrder->patchEntity($buyerPurchaseOrder, $this->request->data);
            if ($this->BuyerPurchaseOrder->save($buyerPurchaseOrder)) {
                $this->Flash->success(__('The {0} has been saved.', 'Buyer Purchase Order'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Buyer Purchase Order'));
            }
        }
        $orders = $this->BuyerPurchaseOrder->Orders->find('list', ['limit' => 200]);
        $uoms = $this->BuyerPurchaseOrder->Uoms->find('list', ['limit' => 200]);
        $currencies = $this->BuyerPurchaseOrder->Currencies->find('list', ['limit' => 200]);
        $incoTerms = $this->BuyerPurchaseOrder->IncoTerms->find('list', ['limit' => 200]);
        $this->set(compact('buyerPurchaseOrder', 'orders', 'uoms', 'currencies', 'incoTerms'));
        $this->set('_serialize', ['buyerPurchaseOrder']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Buyer Purchase Order id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $buyerPurchaseOrder = $this->BuyerPurchaseOrder->get($id);
        if ($this->BuyerPurchaseOrder->delete($buyerPurchaseOrder)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Buyer Purchase Order'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Buyer Purchase Order'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
