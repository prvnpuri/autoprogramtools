<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ErpTexonomyProject Controller
 *
 * @property \App\Model\Table\ErpTexonomyProjectTable $ErpTexonomyProject
 *
 * @method \App\Model\Entity\ErpTexonomyProject[] paginate($object = null, array $settings = [])
 */
class ErpTexonomyProjectController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products', 'PrepareBies', 'Companies']
        ];
        $erpTexonomyProject = $this->paginate($this->ErpTexonomyProject);

        $this->set(compact('erpTexonomyProject'));
        $this->set('_serialize', ['erpTexonomyProject']);
    }

    /**
     * View method
     *
     * @param string|null $id Erp Texonomy Project id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $erpTexonomyProject = $this->ErpTexonomyProject->get($id, [
            'contain' => ['Products', 'PrepareBies', 'Companies']
        ]);

        $this->set('erpTexonomyProject', $erpTexonomyProject);
        $this->set('_serialize', ['erpTexonomyProject']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $erpTexonomyProject = $this->ErpTexonomyProject->newEntity();
        if ($this->request->is('post')) {
            $erpTexonomyProject = $this->ErpTexonomyProject->patchEntity($erpTexonomyProject, $this->request->data);
            if ($this->ErpTexonomyProject->save($erpTexonomyProject)) {
                $this->Flash->success(__('The {0} has been saved.', 'Erp Texonomy Project'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Erp Texonomy Project'));
            }
        }
        $products = $this->ErpTexonomyProject->Products->find('list', ['limit' => 200]);
        $prepareBies = $this->ErpTexonomyProject->PrepareBies->find('list', ['limit' => 200]);
        $companies = $this->ErpTexonomyProject->Companies->find('list', ['limit' => 200]);
        $this->set(compact('erpTexonomyProject', 'products', 'prepareBies', 'companies'));
        $this->set('_serialize', ['erpTexonomyProject']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Erp Texonomy Project id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $erpTexonomyProject = $this->ErpTexonomyProject->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $erpTexonomyProject = $this->ErpTexonomyProject->patchEntity($erpTexonomyProject, $this->request->data);
            if ($this->ErpTexonomyProject->save($erpTexonomyProject)) {
                $this->Flash->success(__('The {0} has been saved.', 'Erp Texonomy Project'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Erp Texonomy Project'));
            }
        }
        $products = $this->ErpTexonomyProject->Products->find('list', ['limit' => 200]);
        $prepareBies = $this->ErpTexonomyProject->PrepareBies->find('list', ['limit' => 200]);
        $companies = $this->ErpTexonomyProject->Companies->find('list', ['limit' => 200]);
        $this->set(compact('erpTexonomyProject', 'products', 'prepareBies', 'companies'));
        $this->set('_serialize', ['erpTexonomyProject']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Erp Texonomy Project id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $erpTexonomyProject = $this->ErpTexonomyProject->get($id);
        if ($this->ErpTexonomyProject->delete($erpTexonomyProject)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Erp Texonomy Project'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Erp Texonomy Project'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
