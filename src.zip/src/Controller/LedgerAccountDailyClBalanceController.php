<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * LedgerAccountDailyClBalance Controller
 *
 * @property \App\Model\Table\LedgerAccountDailyClBalanceTable $LedgerAccountDailyClBalance
 *
 * @method \App\Model\Entity\LedgerAccountDailyClBalance[] paginate($object = null, array $settings = [])
 */
class LedgerAccountDailyClBalanceController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $conditions=[];
        if($this->request->getQuery('search_date')!=null ){
            $conditions['LedgerAccountDailyClBalance.date']=$this->request->getQuery('search_date');
        }
        $this->paginate = [
            'contain' => ['LedgerAccounts','OwnerCompanies'],
            "sortWhitelist"=>[
                "id",'date','side', "LedgerAccounts.account_name",'OwnerCompanies.Company_name'],
            "order"=>["LedgerAccounts.account_name"=>"asc"],
            "conditions"=>$conditions
        ];
        $ledgerAccountDailyClBalance = $this->paginate($this->LedgerAccountDailyClBalance);

        $this->set(compact('ledgerAccountDailyClBalance'));
        $this->set('_serialize', ['ledgerAccountDailyClBalance']);
    }

    
    
    public function getBalance($entry_side,$ledger_account_id){
        
        $balance=$this->LedgerAccountDailyClBalance->find()->select([
                "LedgerAccountDailyClBalance.side","LedgerAccountDailyClBalance.ledger_accounts_id","LedgerAccountDailyClBalance.amount"
            ])->where([
                "LedgerAccountDailyClBalance.side"=>$entry_side,
                "LedgerAccountDailyClBalance.ledger_accounts_id"=>$ledger_account_id
            ])->first();
        
        $this->set(compact('balance'));
        $this->set('_serialize', ['balance']);
    }
    
    
    /**
     * View method
     *
     * @param string|null $id Ledger Account Daily Cl Balance id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ledgerAccountDailyClBalance = $this->LedgerAccountDailyClBalance->get($id, [
            'contain' => ['LedgerAccounts']
        ]);

        $this->set('ledgerAccountDailyClBalance', $ledgerAccountDailyClBalance);
        $this->set('_serialize', ['ledgerAccountDailyClBalance']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ledgerAccountDailyClBalance = $this->LedgerAccountDailyClBalance->newEntity();
        if ($this->request->is('post')) {
            $ledgerAccountDailyClBalance = $this->LedgerAccountDailyClBalance->patchEntity($ledgerAccountDailyClBalance, $this->request->data);
            if ($this->LedgerAccountDailyClBalance->save($ledgerAccountDailyClBalance)) {
                $this->Flash->success(__('The {0} has been saved.', 'Ledger Account Daily Cl Balance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Ledger Account Daily Cl Balance'));
            }
        }
        $ledgerAccounts = $this->LedgerAccountDailyClBalance->LedgerAccounts->find('list', ['limit' => 200]);
        $this->set(compact('ledgerAccountDailyClBalance', 'ledgerAccounts'));
        $this->set('_serialize', ['ledgerAccountDailyClBalance']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Ledger Account Daily Cl Balance id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ledgerAccountDailyClBalance = $this->LedgerAccountDailyClBalance->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ledgerAccountDailyClBalance = $this->LedgerAccountDailyClBalance->patchEntity($ledgerAccountDailyClBalance, $this->request->data);
            if ($this->LedgerAccountDailyClBalance->save($ledgerAccountDailyClBalance)) {
                $this->Flash->success(__('The {0} has been saved.', 'Ledger Account Daily Cl Balance'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Ledger Account Daily Cl Balance'));
            }
        }
        $ledgerAccounts = $this->LedgerAccountDailyClBalance->LedgerAccounts->find('list', ['limit' => 200]);
        $this->set(compact('ledgerAccountDailyClBalance', 'ledgerAccounts'));
        $this->set('_serialize', ['ledgerAccountDailyClBalance']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Ledger Account Daily Cl Balance id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ledgerAccountDailyClBalance = $this->LedgerAccountDailyClBalance->get($id);
        if ($this->LedgerAccountDailyClBalance->delete($ledgerAccountDailyClBalance)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Ledger Account Daily Cl Balance'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Ledger Account Daily Cl Balance'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
