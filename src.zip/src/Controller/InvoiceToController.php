<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * InvoiceTo Controller
 *
 * @property \App\Model\Table\InvoiceToTable $InvoiceTo
 *
 * @method \App\Model\Entity\InvoiceTo[] paginate($object = null, array $settings = [])
 */
class InvoiceToController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Companies']
        ];
        $invoiceTo = $this->paginate($this->InvoiceTo);

        $this->set(compact('invoiceTo'));
        $this->set('_serialize', ['invoiceTo']);
    }

    /**
     * View method
     *
     * @param string|null $id Invoice To id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $invoiceTo = $this->InvoiceTo->get($id, [
            'contain' => ['Orders', 'Companies']
        ]);

        $this->set('invoiceTo', $invoiceTo);
        $this->set('_serialize', ['invoiceTo']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $invoiceTo = $this->InvoiceTo->newEntity();
        if ($this->request->is('post')) {
            $invoiceTo = $this->InvoiceTo->patchEntity($invoiceTo, $this->request->data);
            if ($this->InvoiceTo->save($invoiceTo)) {
                $this->Flash->success(__('The {0} has been saved.', 'Invoice To'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice To'));
            }
        }
        $orders = $this->InvoiceTo->Orders->find('list', ['limit' => 200]);
        $companies = $this->InvoiceTo->Companies->find('list', ['limit' => 200]);
        $this->set(compact('invoiceTo', 'orders', 'companies'));
        $this->set('_serialize', ['invoiceTo']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Invoice To id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $invoiceTo = $this->InvoiceTo->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $invoiceTo = $this->InvoiceTo->patchEntity($invoiceTo, $this->request->data);
            if ($this->InvoiceTo->save($invoiceTo)) {
                $this->Flash->success(__('The {0} has been saved.', 'Invoice To'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice To'));
            }
        }
        $orders = $this->InvoiceTo->Orders->find('list', ['limit' => 200]);
        $companies = $this->InvoiceTo->Companies->find('list', ['limit' => 200]);
        $this->set(compact('invoiceTo', 'orders', 'companies'));
        $this->set('_serialize', ['invoiceTo']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Invoice To id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $invoiceTo = $this->InvoiceTo->get($id);
        if ($this->InvoiceTo->delete($invoiceTo)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Invoice To'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Invoice To'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
