<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;
/**
 * FtirMaster Controller
 *
 * @property \App\Model\Table\FtirMasterTable $FtirMaster
 *
 * @method \App\Model\Entity\FtirMaster[] paginate($object = null, array $settings = [])
 */
class FtirMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ProductsMaster', 'CompanyMaster']
        ];
        $ftirMaster = $this->paginate($this->FtirMaster);

        $this->set(compact('ftirMaster'));
        $this->set('_serialize', ['ftirMaster']);
    }

    /**
     * View method
     *
     * @param string|null $id Ftir Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ftirMaster = $this->FtirMaster->get($id, [
            'contain' => ['ProductsMaster', 'CompanyMaster']
        ]);

        $this->set('ftirMaster', $ftirMaster);
        $this->set('_serialize', ['ftirMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ftirMaster = $this->FtirMaster->newEntity();
        if ($this->request->is('post')) {
        	$ftirMaster = $this->FtirMaster->patchEntity($ftirMaster, $this->request->data);
            if(isset($this->request->data["file_name"]) &&  $this->request->data["file_name"]["error"]==0)
            {
            	$filename=$this->request->data["file_name"]["name"];
            	$ftirMaster["file_name"]=$filename;
            }else{
            	unset($ftirMaster["file_name"]);
            }
			
            $ftirMaster['created_by'] = $this->Auth->User('id');
            
            if ($result=$this->FtirMaster->save($ftirMaster)) {
            	if(isset($this->request->data["file_name"]) &&  $this->request->data["file_name"]["error"]==0){
            		$id=$result->id;
            		$filename=$id."_".$this->request->data["file_name"]["name"];
            		$url = Router::url('/',true).'upload/ftir/'.$filename;
            		$uploadpath = 'upload/ftir/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["file_name"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["file_name"]);
            	}
            	
            	$this->Flash->success(__('The {0} has been saved.', 'Ftir Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Ftir Master'));
            }
        }
        $this->set(compact('ftirMaster'));
        $this->set('_serialize', ['ftirMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Ftir Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ftirMaster = $this->FtirMaster->get($id, [
            'contain' => ['ProductsMaster', 'CompanyMaster']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ftirMaster = $this->FtirMaster->patchEntity($ftirMaster, $this->request->data);
            
            if(isset($this->request->data["file_name"]) &&  $this->request->data["file_name"]["error"]==0)
            {
            	$filename=$this->request->data["file_name"]["name"];
            	$ftirMaster["file_name"]=$filename;
            }else{
            	unset($ftirMaster["file_name"]);
            }
            
            $ftirMaster['modified_by'] = $this->Auth->User('id');
            
            if ($result=$this->FtirMaster->save($ftirMaster)) {
            	if(isset($this->request->data["file_name"]) &&  $this->request->data["file_name"]["error"]==0){
            		$id=$result->id;
            		$filename=$id."_".$this->request->data["file_name"]["name"];
            		$url = Router::url('/',true).'upload/ftir/'.$filename;
            		$uploadpath = 'upload/ftir/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["file_name"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["file_name"]);
            	}
                $this->Flash->success(__('The {0} has been saved.', 'Ftir Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Ftir Master'));
            }
        }
        $this->set(compact('ftirMaster'));
        $this->set('_serialize', ['ftirMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Ftir Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ftirMaster = $this->FtirMaster->get($id);
        if ($this->FtirMaster->delete($ftirMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Ftir Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Ftir Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
