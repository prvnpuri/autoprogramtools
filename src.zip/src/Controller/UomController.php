<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Uom Controller
 *
 * @property \App\Model\Table\UomTable $Uom
 *
 * @method \App\Model\Entity\Uom[] paginate($object = null, array $settings = [])
 */
class UomController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="Uom.unit_name like '%$query%'";
    	}
    	$this->paginate = [
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","unit_name","unit_symbol","unit_type"]
    	];
    	
    	
    	$uom = $this->paginate($this->Uom);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('uom'));
    	$this->set( '_serialize', ['uom','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Uom id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $uom = $this->Uom->get($id, [
            'contain' => []
        ]);

        $this->set('uom', $uom);
        $this->set('_serialize', ['uom']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $uom = $this->Uom->newEntity();
        if ($this->request->is('post')) {
            $uom = $this->Uom->patchEntity($uom, $this->request->data);
            if ($this->Uom->save($uom)) {
                $this->Flash->success(__('The {0} has been saved.', 'Uom'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Uom'));
            }
        }
        $this->set(compact('uom'));
        $this->set('_serialize', ['uom']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Uom id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $uom = $this->Uom->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $uom = $this->Uom->patchEntity($uom, $this->request->data);
            if ($this->Uom->save($uom)) {
                $this->Flash->success(__('The {0} has been saved.', 'Uom'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Uom'));
            }
        }
        $this->set(compact('uom'));
        $this->set('_serialize', ['uom']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Uom id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $uom = $this->Uom->get($id);
        if ($this->Uom->delete($uom)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Uom'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Uom'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
