<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ShippingDocsMaster Controller
 *
 * @property \App\Model\Table\ShippingDocsMasterTable $ShippingDocsMaster
 *
 * @method \App\Model\Entity\ShippingDocsMaster[] paginate($object = null, array $settings = [])
 */
class ShippingDocsMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanies']
        ];
        $shippingDocsMaster = $this->paginate($this->ShippingDocsMaster);

        $this->set(compact('shippingDocsMaster'));
        $this->set('_serialize', ['shippingDocsMaster']);
    }

    /**
     * View method
     *
     * @param string|null $id Shipping Docs Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $shippingDocsMaster = $this->ShippingDocsMaster->get($id, [
            'contain' => ['OwnerCompanies', 'ShippingDocumentsPhysical']
        ]);

        $this->set('shippingDocsMaster', $shippingDocsMaster);
        $this->set('_serialize', ['shippingDocsMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $shippingDocsMaster = $this->ShippingDocsMaster->newEntity();
        if ($this->request->is('post')) {
            $shippingDocsMaster = $this->ShippingDocsMaster->patchEntity($shippingDocsMaster, $this->request->data);
            if ($this->ShippingDocsMaster->save($shippingDocsMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Shipping Docs Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Shipping Docs Master'));
            }
        }
        $ownerCompanies = $this->ShippingDocsMaster->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('shippingDocsMaster', 'ownerCompanies'));
        $this->set('_serialize', ['shippingDocsMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Shipping Docs Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $shippingDocsMaster = $this->ShippingDocsMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $shippingDocsMaster = $this->ShippingDocsMaster->patchEntity($shippingDocsMaster, $this->request->data);
            if ($this->ShippingDocsMaster->save($shippingDocsMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Shipping Docs Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Shipping Docs Master'));
            }
        }
        $ownerCompanies = $this->ShippingDocsMaster->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('shippingDocsMaster', 'ownerCompanies'));
        $this->set('_serialize', ['shippingDocsMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Shipping Docs Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $shippingDocsMaster = $this->ShippingDocsMaster->get($id);
        if ($this->ShippingDocsMaster->delete($shippingDocsMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Shipping Docs Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Shipping Docs Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
