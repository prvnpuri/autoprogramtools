<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * LrcopyPhoto Controller
 *
 * @property \App\Model\Table\LrcopyPhotoTable $LrcopyPhoto
 *
 * @method \App\Model\Entity\LrcopyPhoto[] paginate($object = null, array $settings = [])
 */
class LrcopyPhotoController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Lrs', 'Oas']
        ];
        $lrcopyPhoto = $this->paginate($this->LrcopyPhoto);

        $this->set(compact('lrcopyPhoto'));
        $this->set('_serialize', ['lrcopyPhoto']);
    }

    /**
     * View method
     *
     * @param string|null $id Lrcopy Photo id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $lrcopyPhoto = $this->LrcopyPhoto->get($id, [
            'contain' => ['Orders', 'Lrs', 'Oas']
        ]);

        $this->set('lrcopyPhoto', $lrcopyPhoto);
        $this->set('_serialize', ['lrcopyPhoto']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $lrcopyPhoto = $this->LrcopyPhoto->newEntity();
        if ($this->request->is('post')) {
            $lrcopyPhoto = $this->LrcopyPhoto->patchEntity($lrcopyPhoto, $this->request->data);
            if ($this->LrcopyPhoto->save($lrcopyPhoto)) {
                $this->Flash->success(__('The {0} has been saved.', 'Lrcopy Photo'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Lrcopy Photo'));
            }
        }
        $orders = $this->LrcopyPhoto->Orders->find('list', ['limit' => 200]);
        $lrs = $this->LrcopyPhoto->Lrs->find('list', ['limit' => 200]);
        $oas = $this->LrcopyPhoto->Oas->find('list', ['limit' => 200]);
        $this->set(compact('lrcopyPhoto', 'orders', 'lrs', 'oas'));
        $this->set('_serialize', ['lrcopyPhoto']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Lrcopy Photo id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $lrcopyPhoto = $this->LrcopyPhoto->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $lrcopyPhoto = $this->LrcopyPhoto->patchEntity($lrcopyPhoto, $this->request->data);
            if ($this->LrcopyPhoto->save($lrcopyPhoto)) {
                $this->Flash->success(__('The {0} has been saved.', 'Lrcopy Photo'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Lrcopy Photo'));
            }
        }
        $orders = $this->LrcopyPhoto->Orders->find('list', ['limit' => 200]);
        $lrs = $this->LrcopyPhoto->Lrs->find('list', ['limit' => 200]);
        $oas = $this->LrcopyPhoto->Oas->find('list', ['limit' => 200]);
        $this->set(compact('lrcopyPhoto', 'orders', 'lrs', 'oas'));
        $this->set('_serialize', ['lrcopyPhoto']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Lrcopy Photo id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $lrcopyPhoto = $this->LrcopyPhoto->get($id);
        if ($this->LrcopyPhoto->delete($lrcopyPhoto)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Lrcopy Photo'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Lrcopy Photo'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
