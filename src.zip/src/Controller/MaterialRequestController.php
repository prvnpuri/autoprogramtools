<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * MaterialRequest Controller
 *
 * @property \App\Model\Table\MaterialRequestTable $MaterialRequest
 *
 * @method \App\Model\Entity\MaterialRequest[] paginate($object = null, array $settings = [])
 */
class MaterialRequestController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
         //   'contain' => ['BatchsheetTran']
        ];
        $materialRequest = $this->paginate($this->MaterialRequest);

        $this->set(compact('materialRequest'));
        $this->set('_serialize', ['materialRequest']);
    }

    /**
     * View method
     *
     * @param string|null $id Material Request id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $materialRequest = $this->MaterialRequest->get($id, [
            'contain' => ['MaterialRequestDetails','MaterialRequestDetails.ProductsMaster','MaterialRequestDetails.Uom','MaterialRequestDetails.ConsumablesMaster']
        		]);

        $this->set('materialRequest', $materialRequest);
        $this->set('_serialize', ['materialRequest']);
    }
    public function viewstockupdate($id = null)
    {
    	$materialRequest = $this->MaterialRequest->get($id, [
    			'contain' => ['MaterialRequestDetails','MaterialRequestDetails.ProductsMaster','MaterialRequestDetails.Uom','MaterialRequestDetails.ConsumablesMaster']
    	]);
    	$materialrequestArr="";
    	//debug($materialRequest['material_request_details']);
    	$productType=$materialRequest['product_type'];
    	 
    	foreach($materialRequest['material_request_details'] as $keys=>$vals){
    		//$productArr[]=$vals['product_id'];
    		//$materialrequestArr[]=$vals['id'];
    		
    		//$testId=implode(",", $productArr);
    		//$materialrequestId=implode(",", $materialrequestArr);
    		
    		if($productType=="1"){
    		
    			$this->loadModel('WarehouseInventory');
    			$this->loadModel('WarehouseTran');
    			$this->loadModel('ProductsMaster');
    			$stock = $this->WarehouseInventory
    			->find()
    			->contain(['WarehouseInventoryDetails','WarehouseInventoryDetails.WarehouseUnit','WarehouseInventoryDetails.Uom','WarehouseInventoryDetails.WarehouseUnit.WarehouseMaster'])
    			->select(['id','product_id','balance_qty'])
    			->where(['product_id'=> $vals['product_id']])
    			->toArray();
    		
    		
    			 $warehousetran = $this->WarehouseTran
    			->find()
    			->select(['id','qty','uom_id','warehouse_unit_id','tran_id'])
    			->where(['tran_id'=> $vals['id']])
    			->toArray(); 
    			
    			
    			 foreach ($stock as $stockKeys=>$stockvals){
    		
    			 	$vals['warehouseDetails']=$stockvals['warehouse_inventory_details'];
    				foreach ($stockvals['warehouse_inventory_details'] as $invkeys=>&$invvals){
    					if(!empty($warehousetran)){
    						//debug($warehousetran);
    						foreach ($warehousetran as $trankeys=>$tranval){
    							//echo $vals['id'].'=='.$tranval['tran_id'].'<br/>';
//     							/echo $tranval['warehouse_unit_id'].'=='.$invvals['warehouse_unit_id'].'<br/>';
    							if($vals['id']==$tranval['tran_id'] && $tranval['warehouse_unit_id']==$invvals['warehouse_unit_id'])
    							{
    								$invvals['issueqty']=$tranval['qty'];
    							}
    			    	
    						}
    		
    					}else{
    						$issueQty="0";
    						$invvals['issueqty']=$issueQty;
    					}
    					 
    				}
    		
    				
    			} 
    			
    		
    		
    		
    			 
    		}else{
    			$this->loadModel('ConsumableInventory');
    			$stock = $this->ConsumableInventory
    			->find()
    			->contain(['ConsumableInventoryDetails','ConsumableInventoryDetails.ConsumableStoreMaster'])
    			->select(['id','product_id','balance_qty'])
    			->where(['product_id IN '=> explode(",",$testId)])
    			->toArray();
    			 
    		}
    		
    	
    	}
    	
    	
    	//debug($stock);
    	
    	//  echo $testId;die;
    	/* $unsufficientStock="0";
    	foreach($materialRequest['material_request_details'] as $keys=>&$vals){
    		 
    		foreach ($stock as $stkey=>$stvals){
    			if($stvals['product_id']==$vals['product_id'])
    			{
    				$vals['stock']=$stvals['balance_qty'];
    				if($productType=="1"){
    					$vals['warehouseDetails']=$stvals['warehouse_inventory_details'];
    				}else{
    					//debug($stvals['consumable_inventory_details']);
    					$vals['consumableDetails']=$stvals['consumable_inventory_details'];
    				}
    				//echo '###'.$stvals['balance_qty'].'***'.$vals['qty'];
    				if($stvals['balance_qty']<$vals['qty']){
    					$unsufficientStock="1";
    	
    				}
    	
    			}
    			 
    			 
    		}
    	} */
    	
    	$this->set('materialRequest', $materialRequest);
    	$this->set('_serialize', ['materialRequest']);
    }
    
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $materialRequest = $this->MaterialRequest->newEntity();
        //debug($this->request);
        
        if ($this->request->is('post')) {
        	$this->loadModel('ReferenceNumberCounter');
        	$this->loadComponent('ReferenceNumber');
        ///	echo '@@@'.$this->request->session()->read('Auth.User.owner_company_id');die;
        	$next_ref =
        	$this->ReferenceNumber->get_next_ref_number($this->request->session()->read('Auth.User.owner_company_id'),'material_req');
        	$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
        	$this->request->data['created_by'] = $this->Auth->User('id');
        	$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
        	 
        	$materialRequest = $this->MaterialRequest->newEntity($this->request->getData(),[
        			"associated"=>[
        					"MaterialRequestDetails"
        			]
        	]);
        	$materialRequest = $this->MaterialRequest->patchEntity($materialRequest, $this->request->getData(),[
        			"associated"=>[
        					"MaterialRequestDetails"
        			]
        	]);
        	
        	if(!isset($next_ref['full_next_ref_no'])){
        		
        		$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Material Request'));
        		//return $this->redirect(['action' => 'index']);
        	}else{
        		//debug($materialRequest);exit;
	            if ($this->MaterialRequest->save($materialRequest)) {
	                $this->Flash->success(__('The {0} has been saved.', 'Material Request'));
	                return $this->redirect(['action' => 'index']);
	            } else {
	                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Material Request'));
	            }
        	}
        }
        $this->loadModel('Uom');
        $uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
        
       // $batchsheetTran = $this->MaterialRequest->BatchsheetTran->find('list', ['limit' => 200]);
        $this->set(compact('materialRequest','uom'));
        $this->set('_serialize', ['materialRequest']);
    }
    public function sendtoapprove($id){
    
    	$materialRequest = $this->MaterialRequest->get($id, [
    			'contain' => []
    	]);
    
    	$data = array('id' => $id , 'send_to_approve' => "Y");
    	if($this->MaterialRequest->patchEntity($materialRequest,$data)){
    		$this->MaterialRequest->save($materialRequest);    
    		$this->Flash->success(__('MR  has been sent to Approval.', 'Material Request'));
    	
    		return $this->redirect(['action' => 'index']);    
    
    	}else{
    
    		$this->Flash->success(__('Invoice has not 	been sent to Payment.', 'Invoice'));
    
    	}
    }
    public function rejectpr($id){
    	
    	$materialRequest = $this->MaterialRequest->get($id, [
    			'contain' => []
    	]);
    	
    	$data = array('id' => $id , 'is_approve' => "N","send_to_approve"=>"N","ready_to_pr"=>'Y');
    	if($this->MaterialRequest->patchEntity($materialRequest,$data))
    		$this->MaterialRequest->save($materialRequest);
    	
    		$this->Flash->success(__('The {0} has been Rejected.', 'Material Request'));
    		return $this->redirect(['action' => 'index']);
    }
    public function sendtopr($id){
    
    	$this->loadModel('PurchaseRequisition');
    	
    	$materialRequest = $this->MaterialRequest->get($id, [
    			'contain' => ['MaterialRequestDetails']
    	]);
    	$this->loadModel('ReferenceNumberCounter');
    	$this->loadComponent('ReferenceNumber');
    	
    	$next_ref =
    	$this->ReferenceNumber->get_next_ref_number($this->request->session()->read('Auth.User.owner_company_id'),'requisition');
    	$pr_reference_no = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    	//debug($materialRequest);
    	
    	$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    	
    		$requistionArr['purchase_requisition']['requisition_type']=$materialRequest['product_type'];
    	    $requistionArr['purchase_requisition']['pr_date']=Date('Y-m-d');
    		$requistionArr['purchase_requisition']['pr_reference_no']=$pr_reference_no;
    		$requistionArr['purchase_requisition']['is_materialrequest']='Y';
    		
    		$requistionArr['purchase_requisition']['created_by'] = $this->Auth->User('id');
    		
    		foreach ($materialRequest['material_request_details'] as $keys => $vals){
    			$requistionArr['purchase_requisition']['purchase_requisition_products'][$keys]['product_id']=$vals['product_id'];
    			$requistionArr['purchase_requisition']['purchase_requisition_products'][$keys]['qty']=$vals['qty'];
    			
    		}
    		//debug($requistionArr);
    		
    	$purchaserequisition = $this->PurchaseRequisition->newEntity($requistionArr['purchase_requisition'],[
    			"associated"=>[
    					"PurchaseRequisitionProducts"
    			]
    	]);
    	$purchaserequisition = $this->PurchaseRequisition->patchEntity($purchaserequisition, $requistionArr['purchase_requisition'],[
    			"associated"=>[
    					"PurchaseRequisitionProducts"
    			]
    	]);
    	//Update PR Flag
    	
    	$data = array('id' => $id , 'send_to_pr' => "Y",'send_to_approve' => "Y");
    	if($this->MaterialRequest->patchEntity($materialRequest,$data)){
    		$this->MaterialRequest->save($materialRequest);
    		
    	}
    	//Ends Update PR Flag
    		
    	if($this->PurchaseRequisition->save($purchaserequisition)){
    		$this->Flash->success(__('MR  has been converted to PR.', 'Purchase Requisition'));
    		 
    		return $this->redirect(['action' => 'index']);
    
    	}else{
    
    		$this->Flash->success(__('Purchase Requisition has not 	been save.', 'Purchase Requisition'));
    
    	}
    }
    public function pendingapprovalmaterialrequest()
    {

    	$materialrequest = $this->MaterialRequest->find('all',[
    			'conditions'=>['send_to_approve'=>'Y'],
    	]);
    	
    	
    	$materialRequest = $this->paginate($materialrequest);
    
    	$this->set(compact('materialRequest'));
    	$this->set('_serialize', ['materialRequest']);
    }
    
    public function pendingmaterialrequest()
    {
    
    	$materialrequest = $this->MaterialRequest->find('all',[
    			'conditions'=>['is_approve'=>'Y'],
    	]);
    	 
    	 
    	$materialRequest = $this->paginate($materialrequest);
    
    	$this->set(compact('materialRequest'));
    	$this->set('_serialize', ['materialRequest']);
    }
    public function approvemr($id)
    {
    	$materialRequest = $this->MaterialRequest->get($id, [
    			'contain' => []
    	]);
    	
    	$data = array('id' => $id , 'is_approve' => "Y");
    	if($this->MaterialRequest->patchEntity($materialRequest,$data)){
    		$this->MaterialRequest->save($materialRequest);
    		return $this->redirect(['action' => 'pendingapprovalmaterialrequest']);
    	}	
    }
    public function rejectmr($id)
    {
    	$materialRequest = $this->MaterialRequest->get($id, [
    			'contain' => []
    	]);
    	 
    	$data = array('id' => $id , 'send_to_approve' => "N");
    	if($this->MaterialRequest->patchEntity($materialRequest,$data)){
    		$this->MaterialRequest->save($materialRequest);
    		return $this->redirect(['action' => 'pendingmaterialrequest']);
    	}
    }
    /**
     * Edit method
     *
     * @param string|null $id Material Request id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
    	
        $materialRequest = $this->MaterialRequest->get($id, [
            'contain' => ['MaterialRequestDetails','MaterialRequestDetails.ProductsMaster','MaterialRequestDetails.ConsumablesMaster']
        ]);

         if ($this->request->is(['post', 'put'])) {
         	 
         	if($this->request->getData('sendtopr')=="Y"){//MR Send To PR
         	
         		$this->sendtopr($id);
         	
         	}else{
         	  
         		//Delete Product data
         		$this->loadModel('MaterialRequestDetails');
         		$materialrequestFrm=$this->request->getData();
         		$materialDetailId=array();
         		if(isset($materialrequestFrm["material_request_details"]) && count($materialrequestFrm["material_request_details"])>0){
         			foreach ($materialrequestFrm["material_request_details"] as $mk=>$mv){
    					if(isset($mv['id'])){
         					$materialDetailId[]=$mv['id'];
    					}
	       			}
					if(!empty($materialDetailId)){      
						
						
         				$this->MaterialRequestDetails->deleteAll(["material_request_id"=>$materialrequestFrm['id'],"id not IN ( " . implode(",", $materialDetailId ) ." )" ]);
					}
         		
         		}else{
         			
         			$this->MaterialRequestDetails->deleteAll(["material_request_id",$materialrequestFrm['id'] ]);
         			
         			//Log::debug("Material product cannot not deleted. Id count = 0");
         		
         		}
         		
         		//Ends Delete Product data
	         	//debug($this->request);
	        	$materialRequest = $this->MaterialRequest->patchEntity($materialRequest, $this->request->getData(),[
	        			"associated"=>[
	        					'MaterialRequestDetails','MaterialRequestDetails.ProductsMaster','MaterialRequestDetails.ConsumablesMaster'
	        			]
	        	]);
	            if ($this->MaterialRequest->save($materialRequest)) {
	            	
	            	$this->Flash->success(__('The {0} has been saved.', 'Material Request'));
	                return $this->redirect(['action' => 'index']);
	            } else {
	                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Material Request'));
	            }
         
        	}
         }
        $this->loadModel('Uom');
        $uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
        foreach($materialRequest['material_request_details'] as $keys=>$vals){
        	$productArr[]=$vals['product_id'];
        	$testId=implode(",", $productArr);
        	 
        }
        if(isset($testId)){
	        $this->loadModel('WarehouseInventory');
	         if($materialRequest['product_type']=="1"){
	        	$this->loadModel('ProductsMaster');
	        	$stock = $this->WarehouseInventory
	        	->find()
	        	->contain(['WarehouseInventoryDetails','WarehouseInventoryDetails.WarehouseUnit'])      	 
	        	->select(['id','product_id','balance_qty'])
	        	->where(['product_id IN '=> explode(",",$testId)])
	        	->toArray();
	        		
	        }else{
	        	$this->loadModel('ConsumableInventory');
	        	$stock = $this->ConsumableInventory
	        	->find()
	        	->select(['id','product_id','balance_qty'])
	        	->where(['product_id IN '=> explode(",",$testId)])
	        	->toArray();
	        	
	        } 
        }

      //  echo $testId;die;
        foreach($materialRequest['material_request_details'] as $keys=>&$vals){
        	 
        	foreach ($stock as $stkey=>$stvals){
        		if($stvals['product_id']==$vals['product_id'])
        		{
        			$vals['stock']=$stvals['balance_qty'];
        			$vals['warehouseDetails']=$stvals['warehouse_inventory_details'];
        
        
        		}
        	
        	}
        }
          
  //      debug($materialRequest['material_request_details']);
       // $batchsheetTran = $this->MaterialRequest->BatchsheetTran->find('list', ['limit' => 200]);
        $this->set(compact('materialRequest','uom','unsufficientStock'));
        $this->set('_serialize', ['materialRequest']);
    }

    public function editstockupdate($id = null)
    {
    	$this->loadModel('WarehouseInventory');
    	 
    	$materialRequest = $this->MaterialRequest->get($id, [
    			'contain' => ['MaterialRequestDetails','MaterialRequestDetails.ProductsMaster','MaterialRequestDetails.ConsumablesMaster']
    	]);
    
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		if(($this->request->getData('rejectmr')=="1") && ($this->request->getData('sendtopr')=="N")){//MR Rejected Send These mr with no approval and and rejection
    			 
    			$this->rejectpr($id);
    
    		}
    		else if($this->request->getData('sendtopr')=="Y"){//MR Send To PR
    			 
    			$this->sendtopr($id);
    			 
    		}
    		else{
    			 
    			 
    /* 
    			$materialRequest = $this->MaterialRequest->patchEntity($materialRequest, $this->request->getData(),[
    					"associated"=>[
    							'MaterialRequestDetails','MaterialRequestDetails.ProductsMaster','MaterialRequestDetails.ConsumablesMaster'
    					]
    			]); */
    			/* if ($this->MaterialRequest->save($materialRequest)) {
    			 */	 
    				$MaterialRequest=$this->request->getData()['material_request_details'];
    				//Starts Inventory update in warehouse inventory and details table and new entry in warehouse tran table//

    				//Check Some constraints
    				foreach ($MaterialRequest as $keys=>$vals){
    					$issueQty=0;
    					foreach ($vals['warehouse_tran'] as $transKey=>$transval){
    						if(!empty($transval['issue_qty'])){
    							$issueQty=$issueQty+$transval['issue_qty'];
    				
    						}
    						 
    					}
    				
    					//Starts inventory Details
    					 
    					$WarehouseInventorystock = $this->WarehouseInventory
    					->find()
    					->select(['id','product_id','balance_qty'])
    					->where(['product_id'=>$vals['product_id'] ])
    					->toArray();    					 
    					 
    					//Check issue Qty and Stock
    					if($issueQty>$WarehouseInventorystock[0]['balance_qty']){
    						$this->Flash->error(__('Issue Qty Should not be Greater than Stock Qty. Please, try again.', 'Material Request'));
    						return $this->redirect(['action' => 'pendingmaterialrequest']);
    				    				
    					}
    				
    					//Ends Check issue Qty and Stock
    				
    					//Check issue Qty and Requested Qty
    					if($issueQty>$vals['qty']){
    						$this->Flash->error(__('Issue Qty Should not be Greater than Requested Qty. Please, try again.', 'Material Request'));
    						return $this->redirect(['action' => 'pendingmaterialrequest']);
    				
    				
    					}
    				
    					//Ends Check issue Qty and Stock				
    				
    				
    				}
    				//Ends Check Some constraints
    				
    					
    					if($materialRequest['product_type']=="1"){
    						$this->updateWarehouseStock($MaterialRequest);
    					}else{
    						$this->updateConsumableStock($MaterialRequest);
    					}
    					
    					//Start Status update in material request
    					
    					$data = array('id' => $id , 'status' => "1");
    					if($this->MaterialRequest->patchEntity($materialRequest,$data)){
    						$this->MaterialRequest->save($materialRequest);
    						//return $this->redirect(['action' => 'pendingmaterialrequest']);
    					}
    					
    					//Ends Status update in material request
    				
    				 
    				$this->Flash->success(__('The {0} has been saved.', 'Material Request'));
    				return $this->redirect(['action' => 'pendingmaterialrequest']);
    			
    		}
    	}
    	$this->loadModel('Uom');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	foreach($materialRequest['material_request_details'] as $keys=>$vals){
    		$productArr[]=$vals['product_id'];
    		$testId=implode(",", $productArr);
    
    	}
    	$productType=$materialRequest['product_type'];
    	if($productType=="1"){
    		$this->loadModel('ProductsMaster');
    		$stock = $this->WarehouseInventory
    		->find()
    		->contain(['WarehouseInventoryDetails','WarehouseInventoryDetails.WarehouseUnit','WarehouseInventoryDetails.Uom','WarehouseInventoryDetails.WarehouseUnit.WarehouseMaster'])
    		->select(['id','product_id','balance_qty'])
    		->where(['product_id IN '=> explode(",",$testId)])
    		->toArray();
    
    	}else{
    		$this->loadModel('ConsumableInventory');
    		$stock = $this->ConsumableInventory
    		->find()
    		->contain(['ConsumableInventoryDetails','ConsumableInventoryDetails.ConsumableStoreMaster'])
    		->select(['id','product_id','balance_qty'])
    		->where(['product_id IN '=> explode(",",$testId)])
    		->toArray();
    		 
    	}
    	  //debug($stock);
    
    	//  echo $testId;die;
    	$unsufficientStock="0";
    	foreach($materialRequest['material_request_details'] as $keys=>&$vals){
    		 
    		foreach ($stock as $stkey=>$stvals){
    			if($stvals['product_id']==$vals['product_id'])
    			{
    				$vals['stock']=$stvals['balance_qty'];
    				if($productType=="1"){
    					$vals['warehouseDetails']=$stvals['warehouse_inventory_details'];
    				}else{
    					//debug($stvals['consumable_inventory_details']);
    					$vals['consumableDetails']=$stvals['consumable_inventory_details'];
    				}
    				//echo '###'.$stvals['balance_qty'].'***'.$vals['qty'];
    				if($stvals['balance_qty']<$vals['qty']){
    					$unsufficientStock="1";
    				
    				}
    
    			}
    			
    			
    		}
    	}
    	
    	
    	//debug($materialRequest);die;
    	//      debug($materialRequest['material_request_details']);
    	// $batchsheetTran = $this->MaterialRequest->BatchsheetTran->find('list', ['limit' => 200]);
    	$this->set(compact('materialRequest','uom','unsufficientStock'));
    	$this->set('_serialize', ['materialRequest']);
    }
    
    public  function updateWarehouseStock($MaterialRequest){
    	
    	
    	$this->loadModel('WarehouseTran');
    	$this->loadModel('WarehouseInventory');
    	$this->loadModel('WarehouseInventoryDetails');

    	
    	foreach ($MaterialRequest as $keys=>$vals){
    		$issueQty=0;
    		foreach ($vals['warehouse_tran'] as $transKey=>$transval){
    			if(!empty($transval['issue_qty'])){
    				$warehouseTranArr=array(
    						'type'=>'MR',
    						'product_id'=>$vals['product_id'],
    						'reference_number'=>$this->request->getData()['reference_number'],
    						'qty'=>$transval['issue_qty'],
    						'uom_id'=>$vals['uom_id'],
    						'warehouse_unit_id'=>$transval['warehouse_unit_id'],
    						'warehouse_id'=>$transval['warehouse_id'],
    						'operation_type'=>'s',
    						'tran_id'=>$transval['tran_id'],
	 
    				);
    				$issueQty=$issueQty+$transval['issue_qty'];
    					
    							//debug($warehouseTranArr);
    				$warehousetran = $this->WarehouseTran->newEntity($warehouseTranArr);
    				//debug($warehousetran);
    				$warehousetran = $this->WarehouseTran->patchEntity($warehousetran, $warehouseTranArr,[
    						 
    				]);
    				try{
    					$this->WarehouseTran->save($warehousetran);
    				}
    				catch(exception $e){
    					 
    					echo $e;
    				}
    				
    				$WarehouseInventorystock = $this->WarehouseInventory
    				->find()
    				->select(['id','product_id','balance_qty'])
    				->where(['product_id'=>$vals['product_id'] ])
    				->toArray();
    				
    				$WarehouseInventoryUnitstock = $this->WarehouseInventoryDetails
    				->find()
    				->select(['id','balance_qty'])
    				->where(['warehouse_inventory_id'=>$WarehouseInventorystock[0]['id'],'warehouse_unit_id'=>$transval['warehouse_unit_id'] ])
    				->toArray();
    					
    				$BalanceUnitQty=$WarehouseInventoryUnitstock[0]['balance_qty']-$transval['issue_qty'];
    				$data=array('warehouse_unit_id'=>$transval['warehouse_unit_id'],'balance_qty'=>$BalanceUnitQty);
    	
    				if($this->WarehouseInventoryDetails->patchEntity($WarehouseInventoryUnitstock[0],$data))
    					$this->WarehouseInventoryDetails->save($WarehouseInventoryUnitstock[0]);
    	
    	
    					//Ends Inventory Details
    	
    	
    			}
    	
    		}
    			
    		//Starts Warehouse Inventory
    		$WarehouseInventorystock = $this->WarehouseInventory
    		->find()
    		->select(['id','product_id','balance_qty'])
    		->where(['product_id'=>$vals['product_id'] ])
    		->toArray();
    		$BalanceQty=$WarehouseInventorystock[0]['balance_qty']-$issueQty;
    		$data=array('product_id'=>$vals['product_id'],'balance_qty'=>$BalanceQty);
    			
    		if($this->WarehouseInventory->patchEntity($WarehouseInventorystock[0],$data))
    			$this->WarehouseInventory->save($WarehouseInventorystock[0]);
    	
    			//Ends Warehouse Inventory
    	
    	
    	
    	}
    	//	 debug($warehouseTranArr);die;
    	
    	//$action="pendingmaterialrequest";
    //	return $action;
    	
    }
    
    public  function updateConsumableStock($MaterialRequest){
    	 
    	 
    	$this->loadModel('ConsumableTran');
    	$this->loadModel('ConsumableInventory');
    	$this->loadModel('ConsumableInventoryDetails');
    	 //debug($MaterialRequest);die;
    	foreach ($MaterialRequest as $keys=>$vals){
    		$issueQty=0;
    		foreach ($vals['consumable_tran'] as $transKey=>$transval){
    			if(!empty($transval['issue_qty'])){
    				$consumableTranArr=array(
    						'type'=>'MR',
    						'product_id'=>$vals['product_id'],
    						'reference_number'=>$this->request->getData()['reference_number'],
    						'qty'=>$transval['issue_qty'],
    						'uom_id'=>$vals['uom_id'],
    						'consumable_store_id'=>$transval['consumable_store_id'],
    						'consumable_id'=>$transval['consumable_id'],
    						'operation_type'=>'s'
    
    				);
    				$issueQty=$issueQty+$transval['issue_qty'];
    					
    				//debug($consumableTranArr);die;
    				$consumabletran = $this->ConsumableTran->newEntity($consumableTranArr);
    				//debug($warehousetran);
    				$consumabletran = $this->ConsumableTran->patchEntity($consumabletran, $consumableTranArr,[
    						 
    				]);
    				try{
    					$this->ConsumableTran->save($consumabletran);
    				}
    				catch(exception $e){
    					 
    					echo $e;
    				}
    				 
    				//Starts inventory Details
    					
    				$consumableInventorystock = $this->ConsumableInventory
    				->find()
    				->select(['id','product_id'])
    				->where(['product_id'=>$vals['product_id'] ])
    				->toArray();
    					
    					
    				$ConsumableInventoryUnitstock = $this->ConsumableInventoryDetails
    				->find()
    				->select(['id','balance_qty'])
    				->where(['consumable_inventory_id'=>$consumableInventorystock[0]['id'],'consumable_store_id'=>$transval['consumable_store_id'] ])
    				->toArray();
    					//debug($ConsumableInventoryUnitstock);die;
    				$BalanceUnitQty=$ConsumableInventoryUnitstock[0]['balance_qty']-$transval['issue_qty'];
    				$data=array('consumable_store_id'=>$transval['consumable_store_id'],'balance_qty'=>$BalanceUnitQty);
    				// debug($data);die;
    				if($this->ConsumableInventoryDetails->patchEntity($ConsumableInventoryUnitstock[0],$data))
    					$this->ConsumableInventoryDetails->save($ConsumableInventoryUnitstock[0]);
    					 
    				//die;	 
    					//Ends Inventory Details
    					 
    					 
    			}
    			 
    		}
    		//echo $issueQty;die;
    		 
    		//Starts Warehouse Inventory
    		$ConsumableInventorystock = $this->ConsumableInventory
    		->find()
    		->select(['id','product_id','balance_qty'])
    		->where(['product_id'=>$vals['product_id'] ])
    		->toArray();
    		$BalanceQty=$ConsumableInventorystock[0]['balance_qty']-$issueQty;
    		$data=array('product_id'=>$vals['product_id'],'balance_qty'=>$BalanceQty);
    		 
    		//debug($data);
    		//debug($ConsumableInventorystock[0]);die;
    		if($this->ConsumableInventory->patchEntity($ConsumableInventorystock[0],$data))
    			$this->ConsumableInventory->save($ConsumableInventorystock[0]);
    			 
    			//Ends Warehouse Inventory
    			 
    			 
    			 
    	}
    	//	 debug($warehouseTranArr);die;
    	 
    	//$action="pendingmaterialrequest";
    	//return $action;
    	 
    }
    /**
     * Delete method
     *
     * @param string|null $id Material Request id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $materialRequest = $this->MaterialRequest->get($id);
        if ($this->MaterialRequest->delete($materialRequest)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Material Request'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Material Request'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
