<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanyTaxonomyIndustries Controller
 *
 * @property \App\Model\Table\CompanyTaxonomyIndustriesTable $CompanyTaxonomyIndustries
 *
 * @method \App\Model\Entity\CompanyTaxonomyIndustry[] paginate($object = null, array $settings = [])
 */
class CompanyTaxonomyIndustriesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['IndustryTypes']
        ];
        $companyTaxonomyIndustries = $this->paginate($this->CompanyTaxonomyIndustries);

        $this->set(compact('companyTaxonomyIndustries'));
        $this->set('_serialize', ['companyTaxonomyIndustries']);
    }

    /**
     * View method
     *
     * @param string|null $id Company Taxonomy Industry id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companyTaxonomyIndustry = $this->CompanyTaxonomyIndustries->get($id, [
            'contain' => ['IndustryTypes']
        ]);

        $this->set('companyTaxonomyIndustry', $companyTaxonomyIndustry);
        $this->set('_serialize', ['companyTaxonomyIndustry']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companyTaxonomyIndustry = $this->CompanyTaxonomyIndustries->newEntity();
        if ($this->request->is('post')) {
            $companyTaxonomyIndustry = $this->CompanyTaxonomyIndustries->patchEntity($companyTaxonomyIndustry, $this->request->data);
            if ($this->CompanyTaxonomyIndustries->save($companyTaxonomyIndustry)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Taxonomy Industry'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Taxonomy Industry'));
            }
        }
        $industryTypes = $this->CompanyTaxonomyIndustries->IndustryTypes->find('list', ['limit' => 200]);
        $this->set(compact('companyTaxonomyIndustry', 'industryTypes'));
        $this->set('_serialize', ['companyTaxonomyIndustry']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Taxonomy Industry id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companyTaxonomyIndustry = $this->CompanyTaxonomyIndustries->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companyTaxonomyIndustry = $this->CompanyTaxonomyIndustries->patchEntity($companyTaxonomyIndustry, $this->request->data);
            if ($this->CompanyTaxonomyIndustries->save($companyTaxonomyIndustry)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Taxonomy Industry'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Taxonomy Industry'));
            }
        }
        $industryTypes = $this->CompanyTaxonomyIndustries->IndustryTypes->find('list', ['limit' => 200]);
        $this->set(compact('companyTaxonomyIndustry', 'industryTypes'));
        $this->set('_serialize', ['companyTaxonomyIndustry']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Taxonomy Industry id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyTaxonomyIndustry = $this->CompanyTaxonomyIndustries->get($id);
        if ($this->CompanyTaxonomyIndustries->delete($companyTaxonomyIndustry)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Taxonomy Industry'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Taxonomy Industry'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
