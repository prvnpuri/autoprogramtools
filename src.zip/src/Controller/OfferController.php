<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Mailer\Email;
use DebugKit\Mailer\SentMailResult;
use Cake\Cache\Cache;

/**
 * Offer Controller
 *
 * @property \App\Model\Table\OfferTable $Offer
 *
 * @method \App\Model\Entity\Offer[] paginate($object = null, array $settings = [])
 */
class OfferController extends AppController
{
	
	/**
	 * Index method
	 *
	 * @return \Cake\Http\Response|void
	 */
	public function index()
	{
		
		$ownercompanyid = $this->Auth->User('owner_company_id');
		$this->loadModel('Inquiry');
		
		$query =$this->Inquiry->find('all',
				array('conditions'=>array('inquiry_archive' => 'N','send_to_offer' => 'YES','owner_companies_id'=>$ownercompanyid),'order'=>['Inquiry.id' => 'DESC']));
		
		
		
		
		$this->paginate = [
				'contain' => ['CompanyMaster', 'ProductsMaster', 'OwnerCompanies', 'Uom', 'Currency','Offer'],
				
		];
		
		$this->set('offer', $this->paginate($query));
		$this->set(compact('offer'));
		$this->set('_serialize', ['offer']);
	}
	
	/**
	 * View method
	 *
	 * @param string|null $id Offer id.
	 * @return \Cake\Http\Response|void
	 * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
	 */
	public function view($id = null)
	{
		$offer = $this->Offer->get($id, [
				'contain' => ['CompanyMaster','Inquiry','Inquiry.SelectedProductSpecs','Inquiry.SelectedProductSpecs.ProductDataTests','Countries','PackingTerm','PaymentTerm','IncoTerms','PortOfDischarge','Inquiry.CompanyMaster','Inquiry.OwnerCompanies','Inquiry.ProductsMaster','Inquiry.Uom','Inquiry.Currency','Inquiry.PaymentTerm','Inquiry.PortOfDischarge','Inquiry.Countries','Inquiry.CountryOfOriginOfGood','CountryOfOriginOfGood','Inquiry.CountryOfFinalDestination','CountryOfFinalDestination']
		]);
		
		$this->set('offer', $offer);
		$inquiry_id=$offer->inquiry_id;
		$this->loadModel('Inquiry');
		$inquiry = $this->Inquiry->get($inquiry_id);
		$this->loadModel('CompanyContactPersons');
		$this->set('companycontactpersons',$this->CompanyContactPersons->find("all",array(
				"fields"=>array("id","prefix_name","first_name","middle_name","last_name","email_id"),
				"conditions"=>array("id IN"=>explode(",",$inquiry["company_contact_persons"])),
				
				"order"=>"concat(`first_name`,`middle_name`,`last_name`)"
		)));
		$this->loadModel('ProductDataTests');
		$this->set('prodatatest',$this->ProductDataTests->find("all",array(
				"fields"=>array("id","products_master_id","test","specification","methods","purpose"),
				"conditions"=>array("id IN"=>explode(",",$inquiry["product_specifications"])),
				
		)));
		$this->set('_serialize', ['offer']);
	}
	
	/**
	 * Add method
	 *
	 * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
	 */
	public function add($id=null)
	{
		$this->loadModel('Inquiry');
		
		$inquiry = $this->Inquiry->get($id, [
				'contain' => ['SelectedProductSpecs','SelectedProductSpecs.ProductDataTests','CompanyMaster', 'ProductsMaster','ProductsMaster.ProductDataTests','OwnerCompanies', 'Uom', 'Currency', 'FeasibilityMaster', 'Offer','PaymentTerm','PortOfDischarge','Countries']
		]);
		
		$this->set(compact('inquiry'));
		$offer = $this->Offer->newEntity();
		if ($this->request->is('post')) {
			
			
			
			
			$this->loadModel('ReferenceNumberCounter');
			$this->loadComponent('ReferenceNumber');
			
			$next_ref =
			$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'buy_off');
			$this->request->data['reference_number'] = $next_ref['full_next_ref_no'];
			if(!isset($next_ref['full_next_ref_no'])){
				
				$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Buyer Inquiry'));
				
			}
			
			else{
			
			$offer = $this->Offer->patchEntity($offer, $this->request->data);
			if ($this->Offer->save($offer)) {
				
				$inquiry1 = $this->Inquiry->get($id);
				$data = array('id' => $id, 'isoffered' => "2");
				$inquiry1 = $this->Inquiry->patchEntity($inquiry1, $data);
				$this->Inquiry->save($inquiry1);
				
				
				
				$this->Flash->success(__('The {0} has been saved.', 'Offer'));
				return $this->redirect(['action' => 'index']);
			} else {
				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Offer'));
			}
		}
		}
		
		$this->set(compact('offer'));
		$this->set('_serialize', ['offer']);
		
		
		$this->loadModel('CompanyMaster');
		$this->loadModel('OwnerCompanies');
		$this->loadModel('Uom');
		$this->loadModel('Currency');
		
		$this->loadModel('PackingTerm');
		$this->loadModel('PaymentTerm');
		$this->loadModel('Countries');
		$this->loadModel('PortOfDischarge');
		
		$this->loadModel('CompanyContactPersons');
		$this->loadModel('IncoTerms');
		$companyMaster= $this->CompanyMaster->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
		$ownerCompanies= $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
		
		
		$options='';
		if($inquiry->local_offer==1){
			$CurrencyKey=$inquiry->owner_companies_id.'_'.'currency';
			$currencyId = Cache::read($CurrencyKey, $config = 'default');
			
			$options=array('iso_code'=>$currencyId);
		}
		
		$currency= $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','conditions'=>$options,'limit' => 200]);
		
		
		
		
		
		$uoms= $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
		
		//$currency= $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'sign']);
		$countryoforigineofgoods= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		$packingterm= $this->PackingTerm->find('list', ['keyField' => 'id','valueField' => 'packing_term','order'=>'packing_term']);
		$paymentterm= $this->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
		$countries= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		$portofdischarge= $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge']);
		$incoterm= $this->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','order'=>'inco_term']);
		
		$this->set(compact('companyMaster', 'ownerCompanies', 'uoms', 'currency','countryoforigineofgoods','packingterm','paymentterm','countries','portofdischarge','incoterm'));
		
		
	}
	
	/**
	 * Edit method
	 *
	 * @param string|null $id Offer id.
	 * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
	 * @throws \Cake\Network\Exception\NotFoundException When record not found.
	 */
	public function edit($id = null)
	{
		$offer = $this->Offer->get($id, [
				'contain' => ['CompanyMaster','Inquiry','Inquiry.SelectedProductSpecs','Inquiry.SelectedProductSpecs.ProductDataTests','Inquiry.CompanyMaster','Inquiry.OwnerCompanies','Inquiry.ProductsMaster','Inquiry.Uom','Inquiry.Currency','Inquiry.PaymentTerm']
		]);
		
		if ($this->request->is(['patch', 'post', 'put'])) {
			$offer = $this->Offer->patchEntity($offer, $this->request->data);
			
			if ($this->Offer->save($offer)) {
				
			//----------- check if offer is submitted ----------------------------
				if (isset($this->request->data['Submit'])){
					if($this->request->data['Submit']=="Submit"){
						if ($this->_sendoffermail($this->request->data)) {
							
							$this->Flash->success(__('The {0} has been sent to the client.', 'Offer'));
							
							
							return $this->redirect(array('controller'=>'Offer','action' => 'indexsend'));
						} else {
							$this->loadModel('Inquiry');
							$inquiry_id=$offer->inquiry_id;
							$inquiry = $this->Inquiry->get($inquiry_id);
							$data2 = array('id' => $inquiry_id, 'isoffered' => false);
							$inquiry = $this->Inquiry->patchEntity($inquiry, $data2);
							$this->Inquiry->save($inquiry);
							
							$this->Flash->error(__('The {0} Error sending mail. Pls re-check emails ids / cc ids in this inquiry below, or else contact the administrator.', 'Offer'));
							
							return $this->redirect(array('controller'=>'Offer','action' => 'edit',$inquiry_id));
						}
					}
					if($this->request->data['Submit']=="CreateOrder"){
						
						$this->createorder($id);
					
					}
				}
				$action=$this->request->getData("indexsend")!=null&& trim($this->request->getData("indexsend")," ")!="" ? $this->request->getData("indexsend"):"index";
				$this->Flash->success(__('The {0} has been saved.', 'Offer'));
				return $this->redirect(['action' => $action]);
			} else {
				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Offer'));
			}
		}
		
		$this->set(compact('offer'));
		$this->set('_serialize', ['offer']);
		
		$this->loadModel('CompanyMaster');
		$this->loadModel('OwnerCompanies');
		$this->loadModel('Uom');
		$this->loadModel('Currency');
		
		$this->loadModel('PackingTerm');
		$this->loadModel('PaymentTerm');
		$this->loadModel('Countries');
		$this->loadModel('PortOfDischarge');
	
		$this->loadModel('CompanyContactPersons');
		$this->loadModel('IncoTerms');
		$this->loadModel('Inquiry');
		$inquiry_id=$offer->inquiry_id;
		$inquiry = $this->Inquiry->get($inquiry_id);
		$this->loadModel('CompanyContactPersons');
		$this->set('companycontactpersons',$this->CompanyContactPersons->find("all",array(
				"fields"=>array("id","prefix_name","first_name","middle_name","last_name","email_id"),
				"conditions"=>array("id IN"=>explode(",",$inquiry["company_contact_persons"])),
				
				"order"=>"concat(`first_name`,`middle_name`,`last_name`)"
		)));
		
		
		$companyMaster= $this->CompanyMaster->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
		$ownerCompanies= $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
		$uoms= $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
		
		$options='';
		if($inquiry->local_offer==1){
			$CurrencyKey=$inquiry->owner_companies_id.'_'.'currency';
			$currencyId = Cache::read($CurrencyKey, $config = 'default');
			
			$options=array('iso_code'=>$currencyId);
		}
		
		$currency= $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','conditions'=>$options,'limit' => 200]);
		
		
		
		//$currency= $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'sign']);
		$countryoforigineofgoods= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		$packingterm= $this->PackingTerm->find('list', ['keyField' => 'id','valueField' => 'packing_term','order'=>'packing_term']);
		$paymentterm= $this->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
		$countries= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		$portofdischarge= $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge']);
		$incoterm= $this->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','order'=>'inco_term']);
		
		$this->set(compact('companyMaster', 'ownerCompanies', 'uoms', 'currency','countryoforigineofgoods','packingterm','paymentterm','countries','portofdischarge','incoterm'));
		
	}
	
	/**
	 * Delete method
	 *
	 * @param string|null $id Offer id.
	 * @return \Cake\Network\Response|null Redirects to index.
	 * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
	 */
	public function delete($id = null)
	{
		$this->request->allowMethod(['post', 'delete']);
		$offer = $this->Offer->get($id);
		if ($this->Offer->delete($offer)) {
			$this->Flash->success(__('The {0} has been deleted.', 'Offer'));
		} else {
			$this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Offer'));
		}
		return $this->redirect(['action' => 'index']);
	}
	
	
		
		public function sendToSubmit($offerid, $inqid){
			
			$this->loadModel('Inquiry');
			$offer = $this->Offer->get($offerid);
			$data = array('id' => $offerid, 'send_to_submit' => "YES");
			$offer = $this->Offer->patchEntity($offer, $data);
			$this->Offer->save($offer);
			
			
			$inquiry = $this->Inquiry->get($inqid);
			$data = array('id' => $inqid, 'send_to_offer' => "DON");
			$inquiry = $this->Inquiry->patchEntity($inquiry, $data);
			$this->Inquiry->save($inquiry);
			
			
			$this->Flash->success(__('The {0} has been move to Send offers.', 'Offer'));
			return $this->redirect(['action' => 'index']);
			
			
		}
		
		
		
		
		public function indexsend() {
			
			$ownercompanyid = $this->Auth->User('owner_company_id');
			$this->loadModel('Inquiry');
			
			
			$query =$this->Inquiry->find('all',
					array('conditions'=>array('inquiry_archive' => 'N','send_to_offer' => 'DON','isoffered' => 2,'owner_companies_id'=>$ownercompanyid),'order'=>['Inquiry.id' => 'DESC']));
			
			
			
			
			$this->paginate = [
					'contain' => ['CompanyMaster', 'ProductsMaster', 'OwnerCompanies', 'Uom', 'Currency','Offer'],
					
			];
			
			$this->set('offer', $this->paginate($query));
			$this->set(compact('offer'));
			$this->set('_serialize', ['offer']);
		
		
		
		}
		
		
		
		
		public function createorder($id=Null) {
			
			$this->loadModel('Order');
			$this->loadModel('Inquiry');
			$offer = $this->Offer->get($id, [
					'contain' => ['Order','CompanyMaster','Inquiry','Inquiry.CompanyMaster','Inquiry.OwnerCompanies','Inquiry.ProductsMaster','Inquiry.Uom','Inquiry.Currency','Inquiry.PackingTerm','Inquiry.PaymentTerm',]
			]);
			$ordercreated_by= $this->Auth->User('id');
			$order = $this->Order->newEntity();
			$data = array( 'offer_id' => $offer->id,
					'order_date'=> date('Y-m-d'),
					'buyer_company'=>$offer->company_master_id,
					'owner_companies_id'=>$offer->owner_companies_id,
					'supplier_company'=>$offer->offering_company,
					'products_master_id'=>$offer->products_master_id,
					'quantity_ordered'=>$offer->qty_offered,
					'balance_qty'=>$offer->qty_offered,
					'uom_id'=>$offer->uom_id,
					'rate'=>$offer->offer_price,
					'currency_id'=>$offer->currency_id,
					'total_order_price'=>$offer->total_order_value,
					'is_local' => $offer->local_offer,
					'order_type'=>'0',
					'countries_id'=>$offer->countries_id,
					'port_of_discharge_id'=>$offer->port_of_discharge_id,
					'country_of_origin_of_goods'=>$offer->country_of_origin_of_goods,
					'country_final_destination'=>$offer->country_of_final_destination,
					'packing_required'=>$offer->packing_required,
					'offer_validity'=>$offer->offer_validity,
					'inco_terms_id'=>$offer->inco_terms,
					'created_by'=>$ordercreated_by,
					'reference_number' => $offer->reference_number,
					'status'=>'0','payment_status'=>'0','buyerpo_status'=>'0',
					'so_status'=>'0','outward_status'=>'0');

			$order = $this->Order->patchEntity($order, $data);
						//echo "<pre>";
						//print_r($order);exit;
			if($this->Order->save($order)){
				
				//echo "aaa";exit;
				$offer1 = $this->Offer->get($id);
				$data1 = array('id' => $id, 'status' => 3);
				$inquiry = $this->Offer->patchEntity($offer1, $data1);
				$this->Offer->save($offer1);
				
				
				
				
				//isoffered = 3 means offer accepted by customer
				
				$inquiry_id=$offer->inquiry_id;
				$inquiry = $this->Inquiry->get($inquiry_id);
				$data2 = array('id' => $inquiry_id, 'isoffered' => 3);
				$inquiry = $this->Inquiry->patchEntity($inquiry, $data2);
				$this->Inquiry->save($inquiry);
				
				
				$this->Flash->success(__('The {0} has been saved.', 'Order'));
				
				$action=$this->request->getData("indexPendingClientReply")!=null&& trim($this->request->getData("indexPendingClientReply")," ")!="" ? $this->request->getData("indexPendingClientReply"):"indexsend";
				
				
				
				
				return $this->redirect(array('action' => $action));
			} else {
				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Order'));
			}
		}
		
		public function rejectorder($id=Null) {
			$this->loadModel('Order');
			$this->loadModel('Inquiry');
			
			if($id) {
				$offer1 = $this->Offer->get($id);
				$data1 = ['id' => $id, 'status' => 4];
				$offer1 = $this->Offer->patchEntity($offer1, $data1);
				$this->Offer->save($offer1);
				
				$inquiry_id = $offer1->inquiry_id;
				$inquiry1 = $this->Inquiry->get($inquiry_id);
				$data2 = ['id' => $id, 'isoffered' => 4];
				$inquiry1 = $this->Inquiry->patchEntity($inquiry1, $data2);
				$this->Inquiry->save($inquiry1);
			
				$this->Flash->success(__('The Offer is marked as Lost and sent to archive.'));
				return $this->redirect(array('controller'=>'Offer','action' => 'index_pending_client_reply'));
			}
			else {
				$this->Flash->success(__('The order could not be rejected. Please, try again.'));
			}
		}
	
		private function _sendoffermail($off,$isView=true) {
			
		
			$this->loadModel('Inquiry');
			
			$inquiry_id=$off['inquiry_id'];
			
			$this->request->data['offer_submitted_date'] = date('Y-m-d');
		
			$inq= $this->Inquiry->get($inquiry_id, [
					'contain' => ['SelectedProductSpecs','SelectedProductSpecs.ProductDataTests','CompanyMaster','CompanyMaster.CompanySublocation','CompanyMaster.CompanySublocation.Countries','CompanyMaster.CompanySublocation.City','CompanyMaster.CompanySublocation.State','ProductsMaster','ProductsMaster.ProductDataTests','OwnerCompanies','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerCompanyOffices','OwnerCompanies.OwnerCompanyOffices.State','OwnerCompanies.OwnerCompanyOffices.City','OwnerCompanies.OwnerContactPersons.Users','Uom', 'Currency', 'FeasibilityMaster', 'Offer','PackingTerm','PaymentTerm','PortOfDischarge','Countries']
			]);
			
			$offer = $this->Offer->get($off['id'], [
					'contain' => ['CompanyMaster','Inquiry','Countries','PackingTerm','PaymentTerm','IncoTerms','PortOfDischarge','Inquiry.CompanyMaster','Inquiry.OwnerCompanies','Inquiry.ProductsMaster','Inquiry.Uom','Inquiry.Currency','Inquiry.PackingTerm','Inquiry.PaymentTerm','Inquiry.PortOfDischarge','Inquiry.Countries',]
			]);

			
			
			$this->loadModel('CompanyContactPersons');
			$contacts=$this->CompanyContactPersons->find("all",array(
					"fields"=>array("id","prefix_name","first_name","middle_name","last_name","email_id"),
					"conditions"=>array("id IN"=>explode(",",$inq["company_contact_persons"])),
					
					"order"=>"id"
			));
			
			
			//added for local offers
			if (isset($inq['local_offer']) && $inq['local_offer'] == 1)
			{
				$islocaloff= " Basic Price + GST";
			}
			else{
				$islocaloff= "";
			}
			
			$buyercontact = "";
			$buyeremail = array();
			$vpercount=0;
			// for dynamic contacts//
			foreach ($contacts as $key => $contact){
				$personname=ucfirst($contact["first_name"])." ".
						ucfirst($contact["middle_name"])." ".
						ucfirst($contact["last_name"]);
						if(trim($personname," ")!=""){
							$buyercontact.=$vpercount>0?",":"";
							$buyercontact.= (isset($contact["prefix_name"])?$contact["prefix_name"]:"" )." ".$personname;
							$vpercount++;
						}
						
						$contactemail=$contact["email_id"];
						if(trim($contactemail," ")!=""){
							$buyeremail[]= $contactemail;
						}else{
							
							$this->Flash->error(__('Please check email_id {0} for contact_name {1} is not valid email.',$contactemail,$personname));
							return false;
						}
			}
			
			if(count($buyeremail)==0){
				
				$this->Flash->error(__("Please select atleast one contact for sending mail."));
				
				
				return false;
			}
			$cc = array();
			if(isset($inq['cc_email']) && $inq['cc_email']!='')
				$cc=explode(',', $inq['cc_email']);
				
				
				$emailbody = array();
				$emailbody['header'] = $inq['owner_company']['logo_image'];
				$emailbody['header_image'] = $inq['owner_company']['header_image'];
				$emailbody['footer_image'] = $inq['owner_company']['footer_image'];
				$emailbody['own_company_id'] = $inq['owner_company']['id'];
				$emailbody['own_company_name'] = $inq['owner_company']['Company_name'];
				$emailbody['own_company_website'] = $inq['owner_company']['website_address'];
				$emailbody['own_company_address'] = $inq['owner_company']['owner_company_offices']['0']['address'];
				$emailbody['own_company_city'] = $inq['owner_company']['owner_company_offices']['0']['CityName']['city_name'];
				$emailbody['own_company_state'] = $inq['owner_company']['owner_company_offices']['0']['StateName']['state_name'];
				$emailbody['own_company_country'] = $inq['owner_company']['owner_company_offices']['0']['country'];
				$emailbody['own_company_pincode'] = $inq['owner_company']['owner_company_offices']['0']['postal_code'];
				
				$emailbody['own_company_contact'] = $inq['owner_company']['owner_contact_persons']['0']['user']['userfullname'];
				$emailbody['own_company_phone'] = $inq['owner_company']['owner_company_offices']['0']['phone_no'];
				$emailbody['own_company_email'] = $inq['owner_company']['company_email'];
				
				$emailbody['offer_id']=$off['id'];
				$emailbody['reference_number']=$off['reference_number'];
				$emailbody['offer_date']=date('d-m-Y');
				$emailbody['buyer_name'] = $off['company_name'];
				$emailbody['buyer_address'] = $inq['CompanyMaster']['company_sublocation']['0']['Address'];
				
				$emailbody['buyer_contact'] = $buyercontact;
				$emailbody['buyer_city'] = $inq['CompanyMaster']['company_sublocation']['0']['City']['city_name'];
				$emailbody['buyer_state'] = $inq['CompanyMaster']['company_sublocation']['0']['State']['state_name'];
				$emailbody['buyer_country'] = $inq['CompanyMaster']['company_sublocation']['0']['Country']['country_name'];
				$emailbody['pin_code'] = $inq['CompanyMaster']['company_sublocation']['0']['postal_code'];
				$emailbody['prod_spec'] = $inq['selected_product_specs']['product_data_test'];
				$emailbody['product']=$inq['products_master']['product_name'];
				$emailbody['cas']=$inq['products_master']['cas_no'];
				$emailbody['qty']=$off['qty_offered'];
				$emailbody['uom']= $inq['uom']['unit_symbol'];
				$emailbody['packing']=$off['packing_required'];
				$emailbody['price']=$off['offer_price'];
				$emailbody['currency'] = $inq['currency']['sign'];
				$emailbody['delivery']=$inq['delivery_term']['term'];
				$emailbody['delivery_conditions']=$offer['inco_term']['inco_term'];
				$emailbody['payment_terms']=$inq['payment_terms']['payment_term'];
				$emailbody['validity']=$off['offer_validity'];
				$emailbody['local_offer']=$islocaloff;
				$emailbody['port_of_discharge']=$offer['port_of_discharge']['port_of_discharge'];
				$emailbody['country_of_origin_of_goods']=$inq['country']['country_name'];
				$emailbody['country_of_final_destination']=$offer["country"]['country_name'];
				
				$emailbody["PackingTerm"]=$offer["packing_term"]["packing_term"];
				$emailbody["PaymentTerm"]=$offer['payment_term']['term'];
				$emailbody["DeliveryTerm"]=$inq['delivery_term']['term'];
				$bcc=array();
				if(Configure::read("productionMode")){
					$buyeremaildev = array('sujatasid@gmail.com');
					$cc=array('sonal@pitonsystems.com');
					$bcc=$cc;
				}else{
					$buyeremaildev=$buyeremail;
					$cc=array_merge(array($emailbody['own_company_email']), $cc);
					$bcc=array('sujatasid@gmail.com', 'sonal@pitonsystems.com');
				}
 				
				
				
				if($isView===true){
					$this->set("isView",$isView);
						$this->set(	"mails",array(
							"from"=>$emailbody['own_company_email'],
							"to" =>$buyeremaildev,
							"cc" => $cc,
							"bcc"=> $bcc,
							"subject"=>'Offer from '.$emailbody['own_company_name']
					));
					foreach ($emailbody as  $key=> $data ){
						$this->set($key,$data);
					}
					
					$this->set("title_for_layout","Offer.");
					$this->set(	"mailSendAction",array(
							"send"=>array("action"=>"sendMail",$off["id"],false),
							"cancel"=>array("action"=>"indexsend")
					));
				
					
					$this->viewBuilder()->setLayout("/Email/html/emailpreview");
					$html=$this->render('/Email/html/offer');
					
					echo $html;
					exit();
				}else{
					
					$email = new Email('default');
					$email
					
					->template('offer','offer')
					->from($emailbody['own_company_email'])
					->to($buyeremaildev)
					->cc($cc)
					->bcc($bcc)
					->subject('Offer from '.$emailbody['own_company_name'])
					->emailFormat('html')
					->viewVars($emailbody);
					//->send('sendmail');
					
					
					if ($email->send()) {
						
						//-------------- Make isoffered field in inquiry table true --------------------
						
						$inquiry = $this->Inquiry->get($off['inquiry_id']);
						$data = array('id' => $off['inquiry_id'], 'isoffered' => 1);
						$inquiry = $this->Inquiry->patchEntity($inquiry, $data);
						$this->Inquiry->save($inquiry);
						
						//--------------------------------------------------------------------------------------------------
						//------------- Make status field of offer table submitted ---------------
						
						
						$offer = $this->Offer->get($off['id']);
						$data = array('id' => $off['id'], 'status' => 1,'offer_submitted_date'=>date('Y-m-d'));
						$offer = $this->Offer->patchEntity($offer, $data);
						$this->Offer->save($offer);
						
						$this->Flash->success(__('The {0} has been sent successfully.', "Offer"));
						return $this->redirect(['action' => 'indexsend']);
					} else {
						$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "Offer"));
					}
					
					
				}
				
				
			
				
		}
		
		public function sendMail($offer_id){
			
			$this->request->data= $this->Offer->get($offer_id, [
					'contain' => ['CompanyMaster','Inquiry','Inquiry.CompanyMaster','Inquiry.OwnerCompanies','Inquiry.ProductsMaster','Inquiry.Uom','Inquiry.Currency','Inquiry.PackingTerm','Inquiry.PaymentTerm','Inquiry.PortOfDischarge','Inquiry.Countries',]
			]);
			
			if($this->_sendoffermail($this->request->data,false)){
				
				$this->Flash->success(__('The {0} mail has been sent to client.', 'Offer'));
				return $this->redirect(array('action' => 'indexsend'));
			}else {
				
				$this->Flash->error(__('Error sending mail. Please, try again.'));
			
			};
		}
		
		
		public function indexPendingClientReply() {
			$ownercompanyid = $this->Auth->User('owner_company_id');
			$this->loadModel('Inquiry');
			$query =$this->Inquiry->find('all',
					['conditions'=>['inquiry_archive' => 'N','isoffered' => 1,'owner_companies_id'=>$ownercompanyid],'order'=>['Inquiry.id' => 'DESC']]);
			
			$this->paginate = [
					'contain' => ['CompanyMaster', 'ProductsMaster', 'OwnerCompanies', 'Uom', 'Currency', 'Offer'],
			];
			$this->set('pendinginquiries', $this->paginate($query));
			$this->set(compact('pendinginquiries'));
		}
		
		public function sendReminder(){
			
			$ownercompanyid = $this->Auth->User('owner_company_id');
			if(isset($this->request->data['send_reminder'])){
				$this->sendAgingReminder();
			}
			
			if(isset($this->request->data['send_expire'])){
				$this->sendExpiryReminder();
			}
			
			$agingVal = Configure::read('sendmailAlert.aging');
			$expiryVal = Configure::read ('sendmailAlert.expiring');
		
			$offers = $this->Offer->find ( 'all' ) ->select ( [ 
				'Inquiry.id',
				'Inquiry.isoffered',
				'Inquiry.company_contact_persons',
				'Inquiry.owner_companies_id',
				'Offer.id',
				'validity_reminder_sent_flag',
				'validity_reminder_sent_date',
				'date_age_reminder_sent_flag',
				'date_age_reminder_sent_date',
				'offer_date',
				'offer_validity',
				'about_to_expire_in'=>'(DATEDIFF(CURDATE(), Offer.offer_validity))',
				'ProductsMaster.product_name','ProductsMaster.grade_name',
				'CompanyMaster.Company_name',
				'aging_day'=>'(DATEDIFF(CURDATE(), Offer.offer_date))',
				'offer_archive', 
				'validity_reminder_sent_flag', 
				'validity_reminder_sent_date', 
				'date_age_reminder_sent_flag', 
				'date_age_reminder_sent_date', 
			])
		 	->contain(['Inquiry', 'Inquiry.ProductsMaster', 'CompanyMaster.CompanyContactPersons'])
			->where([
						"OR"=>[
								[
									'Offer.status'=>'1',
									'Offer.offer_archive'=>'N',
									'Inquiry.isoffered <> 3 ',
									'Inquiry.owner_companies_id'=>$ownercompanyid,
									"DATEDIFF(CURDATE() , Offer.offer_date) > $agingVal"
								],
								[
									'Offer.status' => '1',
									'Offer.offer_archive' => 'N',
									'Inquiry.isoffered' <> '3', // isoffered = 3 is offer accepted by customer
									'Inquiry.owner_companies_id'=>$ownercompanyid,
									"(DATEDIFF(CURDATE(), Offer.offer_validity)) <= $expiryVal"
								]
						 ]
				]);
			
			/*
			 * Find the offers which are near expiry (i.e. parameter expired set in bootstrap)
			 */
			$this->set('send_reminder', $this->paginate($offers));
		}
		
		public function sendAgingReminder(){
			if (is_array($this->request->data['send_reminder']))
			{
				foreach($this->request->data['send_reminder'] as $value)
				{
					$offeredData = $this->Offer->get($value, [
							'contain'=>[
									'IncoTerms',
									'OwnerCompanies', 'OwnerCompanies.OwnerCompanyOffices', 'OwnerCompanies.OwnerContactPersons',
									'OwnerCompanies.OwnerCompanyOffices.City', 'OwnerCompanies.OwnerCompanyOffices.State',
									'OwnerCompanies.OwnerCompanyOffices.Countries','OwnerCompanies.OwnerContactPersons.Users',
									'CompanyMaster','CompanyMaster.CompanySublocation', 'CompanyMaster.CompanySublocation.City',
									'CompanyMaster.CompanySublocation.State', 'CompanyMaster.CompanySublocation.Countries',
									'CompanyMaster.CompanyContactPersons',
									'Inquiry','Inquiry.Uom','Inquiry.Currency','Inquiry.PackingTerm','Inquiry.PaymentTerm','Inquiry.ProductsMaster','Inquiry.Countries',
									'PortOfDischarge'
							],
							'conditions'=>['Inquiry.isoffered' => '1']
					]);
			
						$this->loadModel('ProductDataTests');
						$prodspec=$this->ProductDataTests->find("all",array(
								"fields"=>array("id","products_master_id","test","specification","methods","purpose"),
								"conditions"=>array("id IN"=>explode(",",$offeredData->inquiry->product_specifications))
						));
			
						$this->loadModel('CompanyContactPersons');
						$contacts=$this->CompanyContactPersons->find("all",array(
								"fields"=>array("id","prefix_name","first_name","middle_name","last_name","email_id"),
								"conditions"=>array("id IN"=>explode(",",$offeredData->inquiry->company_contact_persons)),
								"order"=>"id"
						));
							
						//for local offers
						if (isset($offeredData['local_offer']) && $offeredData['local_offer'] == 1)
						{
							$islocaloff= " Basic Price + GST";
						}
						else{
							$islocaloff= "";
						}
			
						$emailbody = array();
						$emailbody['prod_spec'] = $prodspec;
						$emailbody['product']=$offeredData->inquiry->products_master->product_name;
						$emailbody['reference_number']=$offeredData->reference_number;
						$emailbody['qty']=$offeredData->qty_offered;
						$emailbody['uom']= $offeredData->inquiry->uom->unit_symbol;
						$emailbody['packing']=$offeredData->inquiry->packing_term->packing_term;
						$emailbody['price']=$offeredData->offer_price;
						$emailbody['currency'] = $offeredData->inquiry->currency->sign;
						$emailbody['delivery']=$offeredData->delivery_terms;
						$emailbody['delivery_conditions']=$offeredData->inco_term->inco_term;
						$emailbody['PaymentTerm']=$offeredData->inquiry->payment_term->term;
						$emailbody['local_offer']=$islocaloff;
							
						$buyercontact = "";
						$buyeremail = array();
						$buyername = array();
						$vpercount=0;
							
						// for dynamic contacts//
			
						foreach ($contacts as $contact){
							$personname=ucfirst($contact->first_name)." ".
									ucfirst($contact->middle_name)." ".
									ucfirst($contact->last_name);
			
									if(trim($personname," ")!=""){
										$buyercontact.=$vpercount>0?",":"";
										$buyercontact.= (isset($contact->prefix_name)?$contact->prefix_name:"" )." ".$personname;
										$vpercount++;
									}
			
									$contactemail=$contact->email_id;
									$contactName=$personname;
									if(trim($contactemail," ")!=""){
										array_push($buyeremail, $contactemail);
										array_push($buyername, $contactName);
									}
						}
							
						$emailbody['buyer_contact'] = $buyercontact;
						$buyernameStr=implode(', ',$buyername);
						$emailbody['header'] = $offeredData->owner_company->logo_image;
						$emailbody['header_image'] = $offeredData->owner_company->header_image;
						$emailbody['footer_image'] = $offeredData->owner_company->footer_image;
						$emailbody['own_company_name'] = $offeredData->owner_company->Company_name;
						$emailbody['own_company_website'] = $offeredData->owner_company->website_address;
						$emailbody['own_company_address'] = $offeredData->owner_company->owner_company_offices['0']->address;
						$emailbody['own_company_city'] = $offeredData->owner_company->owner_company_offices['0']->CityName->city_name;
						$emailbody['own_company_state'] = $offeredData->owner_company->owner_company_offices['0']->StateName->state_name;
						$emailbody['own_company_country'] = $offeredData->owner_company->owner_company_offices['0']->Country->country_name;
						$emailbody['own_company_pincode'] = $offeredData->owner_company->owner_company_offices['0']->postal_code;
						$emailbody['own_company_contact'] = $offeredData->owner_company->owner_contact_persons['0']->user->userfullname;
						$emailbody['own_company_phone'] = $offeredData->owner_company->owner_company_offices['0']->phone_no;
						$emailbody['own_company_email'] = $offeredData->owner_company->company_email;
						$fromOwnerCmp = $offeredData->owner_company->company_email;
			
						$emailbody['buyer_company_name']=$offeredData->company_master->Company_name;
						$emailbody['buyer_address']=$offeredData->company_master->company_sublocation['0']->Address;
						$emailbody['buyer_postal_code']=$offeredData->company_master->company_sublocation['0']->postal_code;
						$emailbody['buyer_company_city'] = $offeredData->company_master->company_sublocation['0']->City->city_name;
						$emailbody['buyer_company_state'] = $offeredData->company_master->company_sublocation['0']->State->state_name;
						$emailbody['buyer_company_country'] = $offeredData->company_master->company_sublocation['0']->Country->country_name;
						
						$emailbody['grade_name']=$offeredData->inquiry->products_master->grade_name;
						$emailbody['cas_no']=$offeredData->inquiry->products_master->cas_no;
						$emailbody['offer_date']=$offeredData->offer_date;
						$emailbody['validity']=$offeredData->offer_validity;
							
						$emailbody['port_of_discharge']=$offeredData->port_of_discharge->port_of_discharge;
						$emailbody['country_of_origin_of_goods']=$offeredData->inquiry->country->country_name;
						$emailbody['country_of_final_destination']=$offeredData->inquiry->country->country_name;
			
						$subject="Reminder to Offer for ".$offeredData->inquiry->products_master->product_name;
			
						$emailbody['subject'] = $subject;
			
						$emailbody['buyer_name']=$buyernameStr;
							
						//Dev version Start.
							
						$Email = new Email('default');
						$Email
						->from($fromOwnerCmp)
						->to('durva.avachat@pitonsystems.com')
						->cc('durva.a90@gmail.com')
						->bcc('durva.a90@gmail.com')
						->subject($subject)
						->template('offer_reminder', 'offer_reminder')
						->emailFormat('html')
						->viewVars($emailbody);
							
						if($Email->send()){
							$offer = $this->Offer->get($value, ['fields' => ['id','date_age_reminder_sent_flag']]);
							$data = array('id' => $value, 'date_age_reminder_sent_flag' => 1,'date_age_reminder_sent_date'=>date('Y-m-d'));
							$offer = $this->Offer->patchEntity($offer, $data);
							$this->Offer->save($offer);
							$this->Flash->success(__('The reminder has been sent successfully.'));
							return $this->redirect(['action' => 'send_reminder']);
						} else {
							$this->Flash->error(__('The reminder could not sent successfully. Please, try again.'));
						}
					}
				}
		}
		
		public function sendExpiryReminder(){
			if (is_array($this->request->data['send_expire']))
			{
				foreach($this->request->data['send_expire'] as $value)
				{
					$offeredData = $this->Offer->get($value, [
							'contain'=>[
									'IncoTerms',
									'OwnerCompanies', 'OwnerCompanies.OwnerCompanyOffices', 'OwnerCompanies.OwnerContactPersons',
									'OwnerCompanies.OwnerCompanyOffices.City', 'OwnerCompanies.OwnerCompanyOffices.State',
									'OwnerCompanies.OwnerCompanyOffices.Countries','OwnerCompanies.OwnerContactPersons.Users',
									'CompanyMaster','CompanyMaster.CompanySublocation', 'CompanyMaster.CompanySublocation.City',
									'CompanyMaster.CompanySublocation.State', 'CompanyMaster.CompanySublocation.Countries',
									'CompanyMaster.CompanyContactPersons',
									'Inquiry','Inquiry.Uom','Inquiry.Currency','Inquiry.PackingTerm','Inquiry.PaymentTerm','Inquiry.ProductsMaster','Inquiry.Countries',
									'PortOfDischarge'
							],
							'conditions'=>['Inquiry.isoffered' => '1']
					]);
						
					$this->loadModel('ProductDataTests');
					$prodspec=$this->ProductDataTests->find("all",array(
							"fields"=>array("id","products_master_id","test","specification","methods","purpose"),
							"conditions"=>array("id IN"=>explode(",",$offeredData->inquiry->product_specifications))
					));
						
					$this->loadModel('CompanyContactPersons');
					$contacts=$this->CompanyContactPersons->find("all",array(
							"fields"=>array("id","prefix_name","first_name","middle_name","last_name","email_id"),
							"conditions"=>array("id IN"=>explode(",",$offeredData->inquiry->company_contact_persons)),
							"order"=>"id"
					));
						
					//for local offers
					if (isset($offeredData['local_offer']) && $offeredData['local_offer'] == 1)
					{
						$islocaloff= " Basic Price + GST";
					}
					else{
						$islocaloff= "";
					}
						
					$emailbody = array();
					$emailbody['prod_spec'] = $prodspec;
					$emailbody['product']=$offeredData->inquiry->products_master->product_name;
					$emailbody['reference_number']=$offeredData->reference_number;
					$emailbody['qty']=$offeredData->qty_offered;
					$emailbody['uom']= $offeredData->inquiry->uom->unit_symbol;
					$emailbody['packing']=$offeredData->inquiry->packing_term->packing_term;
					$emailbody['price']=$offeredData->offer_price;
					$emailbody['currency'] = $offeredData->inquiry->currency->sign;
					$emailbody['delivery']=$offeredData->delivery_terms;
					$emailbody['delivery_conditions']=$offeredData->inco_term->inco_term;
					$emailbody['PaymentTerm']=$offeredData->inquiry->payment_term->term;
					$emailbody['local_offer']=$islocaloff;
						
					$buyercontact = "";
					$buyeremail = array();
					$buyername = array();
					$vpercount=0;
						
					// for dynamic contacts//
						
					foreach ($contacts as $contact){
						$personname=ucfirst($contact->first_name)." ".
								ucfirst($contact->middle_name)." ".
								ucfirst($contact->last_name);
									
								if(trim($personname," ")!=""){
									$buyercontact.=$vpercount>0?",":"";
									$buyercontact.= (isset($contact->prefix_name)?$contact->prefix_name:"" )." ".$personname;
									$vpercount++;
								}
									
								$contactemail=$contact->email_id;
								$contactName=$personname;
								if(trim($contactemail," ")!=""){
									array_push($buyeremail, $contactemail);
									array_push($buyername, $contactName);
								}
					}
						
					$emailbody['buyer_contact'] = $buyercontact;
					$buyernameStr=implode(', ',$buyername);
					$emailbody['header'] = $offeredData->owner_company->logo_image;
					$emailbody['header_image'] = $offeredData->owner_company->header_image;
					$emailbody['footer_image'] = $offeredData->owner_company->footer_image;
					$emailbody['own_company_name'] = $offeredData->owner_company->Company_name;
					$emailbody['own_company_website'] = $offeredData->owner_company->website_address;
					$emailbody['own_company_address'] = $offeredData->owner_company->owner_company_offices['0']->address;
					$emailbody['own_company_city'] = $offeredData->owner_company->owner_company_offices['0']->CityName->city_name;
					$emailbody['own_company_state'] = $offeredData->owner_company->owner_company_offices['0']->StateName->state_name;
					$emailbody['own_company_country'] = $offeredData->owner_company->owner_company_offices['0']->Country->country_name;
					$emailbody['own_company_pincode'] = $offeredData->owner_company->owner_company_offices['0']->postal_code;
					$emailbody['own_company_contact'] = $offeredData->owner_company->owner_contact_persons['0']->user->userfullname;
					$emailbody['own_company_phone'] = $offeredData->owner_company->owner_company_offices['0']->phone_no;
					$emailbody['own_company_email'] = $offeredData->owner_company->company_email;
					$fromOwnerCmp = $offeredData->owner_company->company_email;
						
					$emailbody['buyer_company_name']=$offeredData->company_master->Company_name;
					$emailbody['buyer_address']=$offeredData->company_master->company_sublocation['0']->Address;
					$emailbody['buyer_postal_code']=$offeredData->company_master->company_sublocation['0']->postal_code;
					$emailbody['buyer_company_city'] = $offeredData->company_master->company_sublocation['0']->City->city_name;
					$emailbody['buyer_company_state'] = $offeredData->company_master->company_sublocation['0']->State->state_name;
					$emailbody['buyer_company_country'] = $offeredData->company_master->company_sublocation['0']->Country->country_name;
					
					$emailbody['grade_name']=$offeredData->inquiry->products_master->grade_name;
					$emailbody['cas_no']=$offeredData->inquiry->products_master->cas_no;
					$emailbody['offer_date']=$offeredData->offer_date;
					$emailbody['validity']=$offeredData->offer_validity;
						
					$emailbody['port_of_discharge']=$offeredData->port_of_discharge->port_of_discharge;
					$emailbody['country_of_origin_of_goods']=$offeredData->inquiry->country->country_name;
					$emailbody['country_of_final_destination']=$offeredData->inquiry->country->country_name;
					
					$subject="Offer expiring for ".$offeredData->inquiry->products_master->product_name;
						
					$emailbody['subject'] = $subject;
						
					$emailbody['buyer_name']=$buyernameStr;
						
					//Dev version Start.
						
					$Email = new Email('default');
					$Email
					->from($fromOwnerCmp)
					->to('durva.avachat@pitonsystems.com')
					->cc('durva.a90@gmail.com')
					->bcc('durva.a90@gmail.com')
					->subject($subject)
					->template('offer_expired', 'offer_expired')
					->emailFormat('html')
					->viewVars($emailbody);
						
					if($Email->send()){
						$offer = $this->Offer->get($value, ['fields' => ['id','validity_reminder_sent_flag']]);
						$data = array('id' => $value, 'validity_reminder_sent_flag' => 1,'validity_reminder_sent_date'=>date('Y-m-d'));
						$offer = $this->Offer->patchEntity($offer, $data);
						$this->Offer->save($offer);
						$this->Flash->success(__('The reminder has been sent successfully.'));
						return $this->redirect(['action' => 'send_reminder']);
					} else {
						$this->Flash->error(__('The reminder could not sent successfully. Please, try again.'));
					}
				}
			}
		}
}
		