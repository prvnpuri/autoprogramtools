<?php


namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Cache\Cache;
//use Cake\Controller\ComponentRegistry;
use Cake\ORM\TableRegistry;


class ReferenceNumberComponent extends Component
{
	public function get_reference_number($owner_company_id,$referencekey)
	{
		
		//$companyInfo= $owner_company_id."_iso";
		$RefernceNumberKey=$owner_company_id.'_'.$referencekey;
		$refernceData = Cache::read($RefernceNumberKey, $config = 'default');
		$refernceArr=explode(',',$refernceData);
		
		
		
		return $companysettingData;
	}
	function get_financialyear(){
		
		$this->FinancialYearMaster = TableRegistry::get('FinancialYearMaster');
		$current_year_code = $this->FinancialYearMaster->find('all',
				['fields' => array('year_code','id')])
				->where(['current_year'=>'Y'])->toArray();
		//echo '<pre>',print_r($current_year_code);die;
		/* $month1  = date("m",strtotime('April'));
		$month2  = date("m");
	
		if($pattern == 'YYYY'){
			$year = 'Y';
		}else{
			$year = 'y';
		}
	
		if($month1>$month2){
			$financialyear=date($year, strtotime('last year'));
		}
		else{
			$financialyear=date($year);
		} */
		return $current_year_code;
	}
	public function get_next_ref_number($owner_comp_id, $action){

		$next_ref_no = 0001;
		$financial_year = $this->get_financialyear();
		//echo '<pre>',print_r($financial_year);
		//$year=$financial_year[0]['year_code'];
		$this->ReferenceNumberCounter = TableRegistry::get('ReferenceNumberCounters');
		
							
		$current_ref_no = $this->ReferenceNumberCounter->find('all',
			['fields' => array('reference_counter','id')])
		->where(['activity_name'=>$action])
		->Andwhere(['owner_companies_id'=>$owner_comp_id])
		->Andwhere(['year'=>$financial_year[0]['year_code']])->toArray();
		
						if(!empty($current_ref_no)){
							
							
							$next_ref_no = $current_ref_no[0]['reference_counter'] + 1;
							$RefernceNumberKey=$owner_comp_id.'_'.$action;
							$refernceData = Cache::read($RefernceNumberKey, $config = 'default');
							$refernceArr=explode(',',$refernceData);
							$save_data='';
							//echo '<pre>',print_r($refernceArr);
							if(!empty($refernceArr[0])){
								$refernceData=str_replace($refernceArr[1],$financial_year[0]['year_code'],$refernceData);
								$refernceData=str_replace($refernceArr[2],str_pad($next_ref_no, 4, '0', STR_PAD_LEFT),$refernceData);
								$refernceData=str_replace(",","",$refernceData);
									
								
								
								$save_data = array('ReferenceNumberCounter' =>
										array('id' => $current_ref_no[0]['id'] , 'reference_counter' => $next_ref_no),
										'full_next_ref_no' => $refernceData
								);
							}
						} else {
							$RefernceNumberKey=$owner_comp_id.'_'.$action;
							$refernceData = Cache::read($RefernceNumberKey, $config = 'default');
							$refernceArr=explode(',',$refernceData);
							$save_data='';
							//echo '<pre>',print_r($refernceArr);
							if(!empty($refernceArr[0])){
							$refernceData=str_replace($refernceArr[1],$financial_year[0]['year_code'],$refernceData);
							$refernceData=str_replace($refernceArr[2],str_pad($next_ref_no, 4, '0', STR_PAD_LEFT),$refernceData);
							$refernceData=str_replace(",","",$refernceData);
							
							
							$save_data = array('ReferenceNumberCounter' =>
									array('owner_companies_id'	=> $owner_comp_id,
											'activity_name'     => $action,
											'year'				=> $financial_year[0]['year_code'],
											'reference_counter'	=> $next_ref_no),
									'full_next_ref_no' => $refernceData
							);
							}
						}
						//echo print_r($save_data);die;
						return $save_data;
	}
	public function save_next_ref_number($save_data){
		
		//echo '<pre>',print_r($save_data);die;
		$this->ReferenceNumberCounter = TableRegistry::get('ReferenceNumberCounters');
		if(!isset($save_data['id'])){
			$ReferenceNumberCounter = $this->ReferenceNumberCounter->newEntity();
			$this->ReferenceNumberCounter->patchEntity($ReferenceNumberCounter,$save_data);
			$this->ReferenceNumberCounter->save($ReferenceNumberCounter);
				
		}else{
			$referenceNumberCounter = $this->ReferenceNumberCounter->get($save_data['id'], [
			]);
			
			$ReferenceNumberCounter=$this->ReferenceNumberCounter->patchEntity($referenceNumberCounter,$save_data);
			$this->ReferenceNumberCounter->save($ReferenceNumberCounter);
		}
		
	}
	
}

?>