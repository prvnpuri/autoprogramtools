<?php
namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Core\Configure;

class ProfessionalTaxComponent extends Component
{
    public function getProfessionalTax($gender,$amount,$month){
        
        $professionalTaxData=Configure::read("employeeSalaryDefault.professional_tax_data");
        $month=intval($month);
        if($amount>$professionalTaxData["defaultAmount"]){
            if(isset($professionalTaxData["month"][$month])){
                return $professionalTaxData["month"][$month];
            }else{
                return $professionalTaxData["month"]["default"];
            }
        }else{
            $genderData=$professionalTaxData["gender"][$gender];
            foreach ( $genderData as $data ){
                $fromAmount=$data["amountFrom"];
                $toAmount=$data["amountTo"];
                if($fromAmount<$amount&&$amount<=$toAmount){
                    return $data["professional_tax"];
                }
            }
        }
        
    }
}