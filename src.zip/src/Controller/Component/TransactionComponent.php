<?php
namespace App\Controller\Component;

use Cake\Controller\Component;

class TransactionComponent extends Component{
    
    public function generate(){
        return  date('Ym'). mt_rand(1000000, 9999999);
    }
    
}