<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductInterested Controller
 *
 * @property \App\Model\Table\ProductInterestedTable $ProductInterested
 *
 * @method \App\Model\Entity\ProductInterested[] paginate($object = null, array $settings = [])
 */
class ProductInterestedController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products', 'SubsequentVisits']
        ];
        $productInterested = $this->paginate($this->ProductInterested);

        $this->set(compact('productInterested'));
        $this->set('_serialize', ['productInterested']);
    }

    /**
     * View method
     *
     * @param string|null $id Product Interested id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productInterested = $this->ProductInterested->get($id, [
            'contain' => ['Products', 'SubsequentVisits']
        ]);

        $this->set('productInterested', $productInterested);
        $this->set('_serialize', ['productInterested']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productInterested = $this->ProductInterested->newEntity();
        if ($this->request->is('post')) {
            $productInterested = $this->ProductInterested->patchEntity($productInterested, $this->request->data);
            if ($this->ProductInterested->save($productInterested)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Interested'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Interested'));
            }
        }
        $products = $this->ProductInterested->Products->find('list', ['limit' => 200]);
        $subsequentVisits = $this->ProductInterested->SubsequentVisits->find('list', ['limit' => 200]);
        $this->set(compact('productInterested', 'products', 'subsequentVisits'));
        $this->set('_serialize', ['productInterested']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product Interested id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productInterested = $this->ProductInterested->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productInterested = $this->ProductInterested->patchEntity($productInterested, $this->request->data);
            if ($this->ProductInterested->save($productInterested)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Interested'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Interested'));
            }
        }
        $products = $this->ProductInterested->Products->find('list', ['limit' => 200]);
        $subsequentVisits = $this->ProductInterested->SubsequentVisits->find('list', ['limit' => 200]);
        $this->set(compact('productInterested', 'products', 'subsequentVisits'));
        $this->set('_serialize', ['productInterested']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product Interested id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productInterested = $this->ProductInterested->get($id);
        if ($this->ProductInterested->delete($productInterested)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product Interested'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product Interested'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
