<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductTaxonomy Controller
 *
 * @property \App\Model\Table\ProductTaxonomyTable $ProductTaxonomy
 *
 * @method \App\Model\Entity\ProductTaxonomy[] paginate($object = null, array $settings = [])
 */
class ProductTaxonomyController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products', 'EndUses']
        ];
        $productTaxonomy = $this->paginate($this->ProductTaxonomy);

        $this->set(compact('productTaxonomy'));
        $this->set('_serialize', ['productTaxonomy']);
    }

    /**
     * View method
     *
     * @param string|null $id Product Taxonomy id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productTaxonomy = $this->ProductTaxonomy->get($id, [
            'contain' => ['Products', 'EndUses', 'ProductTaxonomyAssociate']
        ]);

        $this->set('productTaxonomy', $productTaxonomy);
        $this->set('_serialize', ['productTaxonomy']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productTaxonomy = $this->ProductTaxonomy->newEntity();
        if ($this->request->is('post')) {
            $productTaxonomy = $this->ProductTaxonomy->patchEntity($productTaxonomy, $this->request->data);
            if ($this->ProductTaxonomy->save($productTaxonomy)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Taxonomy'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Taxonomy'));
            }
        }
        $products = $this->ProductTaxonomy->Products->find('list', ['limit' => 200]);
        $endUses = $this->ProductTaxonomy->EndUses->find('list', ['limit' => 200]);
        $this->set(compact('productTaxonomy', 'products', 'endUses'));
        $this->set('_serialize', ['productTaxonomy']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product Taxonomy id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productTaxonomy = $this->ProductTaxonomy->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productTaxonomy = $this->ProductTaxonomy->patchEntity($productTaxonomy, $this->request->data);
            if ($this->ProductTaxonomy->save($productTaxonomy)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Taxonomy'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Taxonomy'));
            }
        }
        $products = $this->ProductTaxonomy->Products->find('list', ['limit' => 200]);
        $endUses = $this->ProductTaxonomy->EndUses->find('list', ['limit' => 200]);
        $this->set(compact('productTaxonomy', 'products', 'endUses'));
        $this->set('_serialize', ['productTaxonomy']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product Taxonomy id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productTaxonomy = $this->ProductTaxonomy->get($id);
        if ($this->ProductTaxonomy->delete($productTaxonomy)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product Taxonomy'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product Taxonomy'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
