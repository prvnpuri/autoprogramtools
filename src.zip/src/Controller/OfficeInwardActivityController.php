<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * OfficeInwardActivity Controller
 *
 * @property \App\Model\Table\OfficeInwardActivityTable $OfficeInwardActivity
 *
 * @method \App\Model\Entity\OfficeInwardActivity[] paginate($object = null, array $settings = [])
 */
class OfficeInwardActivityController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OfficeInwards']
        ];
        $officeInwardActivity = $this->paginate($this->OfficeInwardActivity);

        $this->set(compact('officeInwardActivity'));
        $this->set('_serialize', ['officeInwardActivity']);
    }

    /**
     * View method
     *
     * @param string|null $id Office Inward Activity id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $officeInwardActivity = $this->OfficeInwardActivity->get($id, [
            'contain' => ['OfficeInwards']
        ]);

        $this->set('officeInwardActivity', $officeInwardActivity);
        $this->set('_serialize', ['officeInwardActivity']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $officeInwardActivity = $this->OfficeInwardActivity->newEntity();
        if ($this->request->is('post')) {
            $officeInwardActivity = $this->OfficeInwardActivity->patchEntity($officeInwardActivity, $this->request->data);
            if ($this->OfficeInwardActivity->save($officeInwardActivity)) {
                $this->Flash->success(__('The {0} has been saved.', 'Office Inward Activity'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Office Inward Activity'));
            }
        }
        $officeInwards = $this->OfficeInwardActivity->OfficeInwards->find('list', ['limit' => 200]);
        $this->set(compact('officeInwardActivity', 'officeInwards'));
        $this->set('_serialize', ['officeInwardActivity']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Office Inward Activity id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $officeInwardActivity = $this->OfficeInwardActivity->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $officeInwardActivity = $this->OfficeInwardActivity->patchEntity($officeInwardActivity, $this->request->data);
            if ($this->OfficeInwardActivity->save($officeInwardActivity)) {
                $this->Flash->success(__('The {0} has been saved.', 'Office Inward Activity'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Office Inward Activity'));
            }
        }
        $officeInwards = $this->OfficeInwardActivity->OfficeInwards->find('list', ['limit' => 200]);
        $this->set(compact('officeInwardActivity', 'officeInwards'));
        $this->set('_serialize', ['officeInwardActivity']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Office Inward Activity id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $officeInwardActivity = $this->OfficeInwardActivity->get($id);
        if ($this->OfficeInwardActivity->delete($officeInwardActivity)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Office Inward Activity'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Office Inward Activity'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
