<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ControlSampleEntry Controller
 *
 * @property \App\Model\Table\ControlSampleEntryTable $ControlSampleEntry
 *
 * @method \App\Model\Entity\ControlSampleEntry[] paginate($object = null, array $settings = [])
 */
class ControlSampleEntryController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products']
        ];
        $controlSampleEntry = $this->paginate($this->ControlSampleEntry);

        $this->set(compact('controlSampleEntry'));
        $this->set('_serialize', ['controlSampleEntry']);
    }

    /**
     * View method
     *
     * @param string|null $id Control Sample Entry id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $controlSampleEntry = $this->ControlSampleEntry->get($id, [
            'contain' => ['Products']
        ]);

        $this->set('controlSampleEntry', $controlSampleEntry);
        $this->set('_serialize', ['controlSampleEntry']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $controlSampleEntry = $this->ControlSampleEntry->newEntity();
        if ($this->request->is('post')) {
            $controlSampleEntry = $this->ControlSampleEntry->patchEntity($controlSampleEntry, $this->request->data);
            if ($this->ControlSampleEntry->save($controlSampleEntry)) {
                $this->Flash->success(__('The {0} has been saved.', 'Control Sample Entry'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Control Sample Entry'));
            }
        }
        $products = $this->ControlSampleEntry->Products->find('list', ['limit' => 200]);
        $this->set(compact('controlSampleEntry', 'products'));
        $this->set('_serialize', ['controlSampleEntry']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Control Sample Entry id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $controlSampleEntry = $this->ControlSampleEntry->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $controlSampleEntry = $this->ControlSampleEntry->patchEntity($controlSampleEntry, $this->request->data);
            if ($this->ControlSampleEntry->save($controlSampleEntry)) {
                $this->Flash->success(__('The {0} has been saved.', 'Control Sample Entry'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Control Sample Entry'));
            }
        }
        $products = $this->ControlSampleEntry->Products->find('list', ['limit' => 200]);
        $this->set(compact('controlSampleEntry', 'products'));
        $this->set('_serialize', ['controlSampleEntry']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Control Sample Entry id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $controlSampleEntry = $this->ControlSampleEntry->get($id);
        if ($this->ControlSampleEntry->delete($controlSampleEntry)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Control Sample Entry'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Control Sample Entry'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
