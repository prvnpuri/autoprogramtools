<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Network\Exception\NotFoundException;
use Cake\ORM\Table;
use Cake\ORM\Entity;

/**
 * LedgerTransactions Controller
 *
 * @property \App\Model\Table\LedgerTransactionsTable $LedgerTransactions
 *
 * @property \App\Controller\Component\TransactionComponent $Transaction
 *
 * @method \App\Model\Entity\LedgerTransaction[] paginate($object = null, array $settings = [])
 */
class LedgerTransactionsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanies', 'TransactionType', 'LedgerAccounts'],
            "sortWhitelist"=>[
                'id', 'owner_companies_id', 'transaction_id', 'transaction_type_id', 'transaction_date', 'ledger_accounts_id', 'bank_reference_number', 'source', 'narration', 'entry_side', 'ledger_amount', 'created', 'created_by', 
                "OwnerCompanies.Company_name","TransactionType.type","LedgerAccounts.account_name"
            ],
        ];
        $ledgerTransactions = $this->paginate($this->LedgerTransactions);

        $this->set(compact('ledgerTransactions'));
        $this->set('_serialize', ['ledgerTransactions']);
    }

    /**
     * View method
     *
     * @param string|null $id Ledger Transaction id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($transaction_id = null)
    {
        
        $ledgerTransactionList=$this->LedgerTransactions->find("all",[
            "conditions"=>["transaction_id"=> $transaction_id],
            "contain"=>['OwnerCompanies','TransactionType','LedgerAccounts']
        ]);
        
        
        $this->set(compact('ledgerTransactionList'));
        $this->set('_serialize', ['ledgerTransactionList']);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ledgerTransaction = $this->LedgerTransactions->newEntity();
        if ($this->request->is('post')) {
            $data=$this->request->getData();
            foreach ($data["ledger_transactions"] as &$transData){
                $transData=array_merge($transData,$data["common"]);
            }
            
            $ledgerTransactionEntities = $this->LedgerTransactions->newEntities($data["ledger_transactions"]);
            if ($this->LedgerTransactions->saveTransactions($ledgerTransactionEntities)){
                $this->Flash->success(__('The ledger transaction has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The ledger transaction could not be saved. Please, try again.'));
        }
        $ownerCompanies = $this->LedgerTransactions->OwnerCompanies->find('list', [
            "keyField"=>"id",
            "valueField"=>"Company_name",
            'limit' => 200])->orderAsc("Company_Name");
        $transactionType = $this->LedgerTransactions->TransactionType->find('list', [
            "keyField"=>"id",
            "valueField"=>"type",
            'limit' => 200])->orderAsc("type");
        $ledgerAccounts = $this->LedgerTransactions->LedgerAccounts->find('list', [
            "keyField"=>"id",
            "valueField"=>"account_name",
            'limit' => 200])->orderAsc("account_name");
        $this->loadComponent('Transaction');
        $trsactionId=$this->Transaction->generate();
        $this->set(compact('ledgerTransaction','trsactionId', 'ownerCompanies', 'transactions', 'transactionType', 'ledgerAccounts', 'invoice'));
        $this->set('_serialize', ['ledgerTransaction','trsactionId', 'ownerCompanies', 'transactions', 'transactionType', 'ledgerAccounts', 'invoice']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Ledger Transaction id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($transaction_id = null)
    {
        if (!$this->LedgerTransactions->exists([
            "transaction_id"=> $transaction_id
        ])){
            throw new NotFoundException(__("Requested Transcations data  unavailable."));
        }
        
        $ledgerTransaction=$this->LedgerTransactions->find("all",[
            "conditions"=>["transaction_id"=> $transaction_id]
        ]);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data=$this->request->getData();
            foreach ($data["ledger_transactions"] as &$transData){
                $transData=array_merge($transData,$data["common"]);
            }
            $ledgerTransactionEntities = $this->LedgerTransactions->patchEntities( $ledgerTransaction, $data["ledger_transactions"]);
            $ledgerTransactions=$this->LedgerTransactions;
            if(isset($data["delete_transations"]["id"])&& count($data["delete_transations"])>0 ){
               
                $this->LedgerTransactions->deleteTransactions($data["delete_transations"]["id"]);
            }
            $ledgerTransactions=$this->LedgerTransactions;
            
            if ($this->LedgerTransactions->saveTransactions($ledgerTransactionEntities)){
                $this->Flash->success(__('The ledger transaction has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
             
            $this->Flash->error(__('The ledger transaction could not be saved. Please, try again.'));
        }
        
        $ownerCompanies = $this->LedgerTransactions->OwnerCompanies->find('list', [
            "keyField"=>"id",
            "valueField"=>"Company_name",
            'limit' => 200])->orderAsc("Company_Name");
        $transactionType = $this->LedgerTransactions->TransactionType->find('list', [
            "keyField"=>"id",
            "valueField"=>"type",
            'limit' => 200])->orderAsc("type");
        $ledgerAccounts = $this->LedgerTransactions->LedgerAccounts->find('list', [
            "keyField"=>"id",
            "valueField"=>"account_name",
            'limit' => 200])->orderAsc("account_name");
        
        $this->set(compact('ledgerTransaction','common','ownerCompanies', 'transactions', 'transactionType', 'ledgerAccounts', 'invoice'));
        $this->set('_serialize', ['ledgerTransaction',"common"]);
    }

    /**
     * Delete method
     *
     * @param string|null $id Ledger Transaction id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($transaction_id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        if ($this->LedgerTransactions->deleteTransactions($transaction_id)) {
            $this->Flash->success(__('The ledger transaction has been deleted.'));
        } else {
            $this->Flash->error(__('The ledger transaction could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
