<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PackingShipingData Controller
 *
 * @property \App\Model\Table\PackingShipingDataTable $PackingShipingData
 *
 * @method \App\Model\Entity\PackingShipingData[] paginate($object = null, array $settings = [])
 */
class PackingShipingDataController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'InvoiceProducts', 'ProductsMaster']
        ];
        $packingShipingData = $this->paginate($this->PackingShipingData);

        $this->set(compact('packingShipingData'));
        $this->set('_serialize', ['packingShipingData']);
    }

    /**
     * View method
     *
     * @param string|null $id Packing Shiping Data id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */

    public function add($invoiceId)
    {
        $packingShipingData = $this->PackingShipingData->newEntity();
        if ($this->request->is('post')) {
        	
        	
        	foreach ($this->request->data['packing_shiping_data'] as $k=>&$v){
        		$v['created_by'] = $this->Auth->User('id');
        		//$v['invoice_id'] = $this->request->data['invoice_id'];
        		
        		
        	}
        	//echo '<pre>',print_r($this->request->data['packing_shiping_data']);die;
        	$packingShipingData = $this->PackingShipingData->newEntities($this->request->data['packing_shiping_data']);
            $packingShipingData = $this->PackingShipingData->patchEntities($packingShipingData, $this->request->data['packing_shiping_data']);
//             /debug($packingShipingData);die;
            if ($this->PackingShipingData->saveMany($packingShipingData)) {
                $this->Flash->success(__('The {0} has been saved.', 'Packing Shiping Data'));
    				return $this->redirect(['controller'=>'invoices','action' => 'sales_document',$invoiceId]);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Packing Shiping Data'));
            }
        }
        $this->loadModel('Invoices');
     /*    $packingData = $this->Invoices->get($invoiceId, [
        		'contain' => ['InvoiceProducts','InvoiceProducts.Order','InvoiceProducts.Uom','InvoiceProducts.Currency','InvoiceProducts.ProductsMaster'],
        ])->toArray(); */
        
        $packingData=$this->Invoices->find('all')
        ->select([
        		'id','is_local','invoice_no'
        ])
        ->contain([
        		'InvoiceProducts' => function($q) {
        		return $q
        		->select([
        				'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.product_id','InvoiceProducts.order_id','InvoiceProducts.qty','InvoiceProducts.uom_id'
        		])
        		->contain([
        				'ProductsMaster' => function($q) {
        				return $q
        				->select([
        						'ProductsMaster.id', 'ProductsMaster.product_name', 'ProductsMaster.cas_no', 'ProductsMaster.grade_name'
        				]);
        				},
        				'Order' => function($q) {
        				return $q
        				->select([
        						'Order.id', 'Order.order_no','Order.order_date'
        				]);
        				},
        				'Uom' => function($q) {
        				return $q
        				->select([
        						'Uom.id', 'Uom.unit_symbol'
        				]);
        				},
        				'InvoiceProductBoldno' => function($q) {
        				return $q
        				->select([
        						'InvoiceProductBoldno.id', 'bold_number_tran_id','invoice_products_id'
        				])
        				->contain([
        						'BoldNoInventoryTran'=> function ($q) {
				    				return $q
				    				->select([
				    						'id','bold_number_inventory_id','order_id'
				    				])
				    				->contain([
				    						'BoldNumberInventory' => function($q) {
				    						return $q
				    						->select([
				    								'unique_series','from','to'
				    						]);
				    				
				    				}
				    				
				    				
				    				]);
				    				}
        						
        						]);
        				}
        					
        				]);
        		 
        		},
        		 
        		
        		 
        		])
        		->where(['Invoices.id'=>$invoiceId])
        		//->order(['PurchaseOrder.id'=>'DESC'])
         
        ->toArray();
        
        
               
       // echo '<pre>',print_r($packingData);die;
        $this->set(compact('packingData','packingShipingData'));
        $this->set('_serialize', ['packingShipingData']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Packing Shiping Data id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($invoiceId = null)
    {
    	$packingShipingData = $this->PackingShipingData->newEntity();
    	
    	$packingData=$this->PackingShipingData->find('all')
    	->select([
    			'id','gross_weight'
    	])
    	->contain([
    			'Invoices' => function($q) {
    			return $q
    			->select([
    					'Invoices.id', 'Invoices.invoice_no'
    			]);
    			},
    			'InvoiceProducts' => function($q) {
    			return $q
    			->select([
    					'InvoiceProducts.id', 'InvoiceProducts.qty'
    			]);
    			},
    			'ProductsMaster' => function($q) {
    			return $q
    			->select([
    					'ProductsMaster.id', 'ProductsMaster.product_name', 'ProductsMaster.cas_no', 'ProductsMaster.grade_name'
    			]);
    			},
    	
    			'Uom' => function($q) {
    			return $q
    			->select([
    					'Uom.id', 'Uom.unit_symbol'
    			]);
    			}
    			 
    			])
    			->where(['Invoices.id'=>$invoiceId])
    			//->order(['PurchaseOrder.id'=>'DESC'])
    			 
    			->toArray();
    			 
        if ($this->request->is(['patch', 'post', 'put'])) {
        	
            $packingShipingData = $this->PackingShipingData->patchEntities($packingData, $this->request->data['packing_shiping_data']);
            if ($this->PackingShipingData->saveMany($packingShipingData)) {
                $this->Flash->success(__('The {0} has been saved.', 'Packing Shiping Data'));
    				return $this->redirect(['controller'=>'invoices','action' => 'sales_document',$invoiceId]);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Packing Shiping Data'));
            }
        }
        

        
        $this->set(compact('packingData','packingShipingData'));
        $this->set('_serialize', ['packingShipingData']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Packing Shiping Data id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $packingShipingData = $this->PackingShipingData->get($id);
        if ($this->PackingShipingData->delete($packingShipingData)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Packing Shiping Data'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Packing Shiping Data'));
        }
        return $this->redirect(['action' => 'index']);
    }
    public function packinglistview($invoiceId = null,$requiredReturn=null)
    {
    
    	$packingData=$this->PackingShipingData->find('all')
    	->select([
    			'id','gross_weight'
    	])
    	->contain([
    			'ProductsMaster' => function($q) {
    			return $q
    			->select([
    					'ProductsMaster.id', 'ProductsMaster.product_name', 'ProductsMaster.cas_no', 'ProductsMaster.grade_name','ProductsMaster.cas_no','ProductsMaster.ritc_code','ProductsMaster.hs_code'
    			]);
    			},
    			'Uom' => function($q) {
    			return $q
    			->select([
    					'Uom.id', 'Uom.unit_symbol'
    			]);
    			},
    			'Invoices' => function($q) {
    			return $q
    			->select([
    					'Invoices.id','Invoices.instruction','Invoices.port_load','Invoices.end_use' ,'Invoices.invoice_no', 'Invoices.invoice_date','Invoices.pre_carriage','Invoices.place_of_receipt','Invoices.vessel_no','Invoices.port_of_discharge','Invoices.country_final_destination','Invoices.country_origin_goods'
    			])
    			->contain([
    					
    					'OwnerCompanies'=> function ($q) {
    					return $q
    					->select([
    							'OwnerCompanies.id','OwnerCompanies.Company_name','OwnerCompanies.gstin','OwnerCompanies.iec_no'
    					])
    					->contain([
    							'OwnerCompanyOffices' => function($q) {
    							return $q
    							->select([
    									'OwnerCompanyOffices.id','OwnerCompanyOffices.phone_no','OwnerCompanyOffices.postal_code','OwnerCompanyOffices.name', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
    							])
    							->contain([
    									'City' => function($q) {
    									return $q
    									->select([
    											'City.city_name'
    									]);
    									}
    									])
    									->contain([
    											'Countries' => function($q) {
    											return $q
    											->select([
    													'Countries.country_name'
    											]);
    											}
    											])
    											->contain([
    													'State' => function($q) {
    													return $q
    													->select([
    															'State.state_name'
    													]);
    													}
    													]);
    							}
    							]);
    						
    					},
    					'NotifyMaster'=> function ($q) {
    					return $q
    					->select([
    							'NotifyMaster.id','NotifyMaster.Company_name'
    					])->contain([
			                'CompanySublocation' => function($q) {
			                return $q
			                ->select([
			                    'CompanySublocation.id','CompanySublocation.sublocation_name','CompanySublocation.postal_code','CompanySublocation.address','CompanySublocation.company_master_id'
			                ])
			                ->contain([
			                    'City' => function($q) {
			                    return $q
			                    ->select([
			                        'City.city_name'
			                    ]);
			                    }
			                    ])
			                    ->contain([
			                        'Countries' => function($q) {
			                        return $q
			                        ->select([
			                            'Countries.country_name'
			                        ]);
			                        }
			                        ])
			                        ->contain([
			                            'State' => function($q) {
			                            return $q
			                            ->select([
			                                'State.state_name'
			                            ]);
			                            }
			                            ]);
			                },
			                /* 'CompanyContactPerson' => function($q) {
			                return $q
			                ->select([
			                		'CompanyContactPerson.prefix_name','CompanyContactPerson.first_name','CompanyContactPerson.middle_name','CompanyContactPerson.last_name'
			                ]);
			                } */
			                
			                ]);
    						
    					},
    					'BuyerMaster'=> function ($q) {
    					return $q
    					->select([
    							'BuyerMaster.id','BuyerMaster.Company_name'
    					])->contain([
    							'CompanySublocation' => function($q) {
    							return $q
    							->select([
    									'CompanySublocation.id','CompanySublocation.sublocation_name','CompanySublocation.postal_code','CompanySublocation.address','CompanySublocation.company_master_id'
    							])
    							->contain([
    									'City' => function($q) {
    									return $q
    									->select([
    											'City.city_name'
    									]);
    									}
    									])
    									->contain([
    											'Countries' => function($q) {
    											return $q
    											->select([
    													'Countries.country_name'
    											]);
    											}
    											])
    											->contain([
    													'State' => function($q) {
    													return $q
    													->select([
    															'State.state_name'
    													]);
    													}
    													]);
    							},
    							/* 'CompanyContactPerson' => function($q) {
    							 return $q
    							->select([
    									'CompanyContactPerson.prefix_name','CompanyContactPerson.first_name','CompanyContactPerson.middle_name','CompanyContactPerson.last_name'
    							]);
    							} */
    							 
    							]);
    					
    					},
    					'ConsigneeMaster'=> function ($q) {
    					return $q
    					->select([
    							'ConsigneeMaster.id','ConsigneeMaster.Company_name'
    					])->contain([
				                'CompanySublocation' => function($q) {
				                return $q
				                ->select([
				                    'CompanySublocation.id','CompanySublocation.sublocation_name','CompanySublocation.postal_code','CompanySublocation.address','CompanySublocation.company_master_id'
				                ])
				                ->contain([
				                    'City' => function($q) {
				                    return $q
				                    ->select([
				                        'City.city_name'
				                    ]);
				                    }
				                    ])
				                    ->contain([
				                        'Countries' => function($q) {
				                        return $q
				                        ->select([
				                            'Countries.country_name'
				                        ]);
				                        }
				                        ])
				                        ->contain([
				                            'State' => function($q) {
				                            return $q
				                            ->select([
				                                'State.state_name'
				                            ]);
				                            }
				                            ]);
				                }
				                ]);
    					
    					},
    					'PaymentTerm'=> function ($q) {
    					return $q
    					->select([
    							'PaymentTerm.id','PaymentTerm.term'
    					]);
    					
    					},
    					'DeliveryTerm'=> function ($q) {
    					return $q
    					->select([
    							'DeliveryTerm.id','DeliveryTerm.term'
    					]);
    						
    					},
    					]);
    			
    			},
    			'InvoiceProducts' => function($q) {
    			return $q
    			->select([
    					'InvoiceProducts.id', 'InvoiceProducts.qty'
    			])
    			->contain([
    					'Order' => function($q) {
    					return $q
    					->select([
    							'Order.order_no','Order.order_date'
    					]);
    					},
    					'InvoiceProductBoldno' => function($q) {
    					return $q
    					->select([
    							'InvoiceProductBoldno.id', 'bold_number_tran_id','invoice_products_id'
    					])
    					->contain([
    							'BoldNoInventoryTran'=> function ($q) {
    							return $q
    							->select([
    									'id','bold_number_inventory_id','order_id'
    							])
    							->contain([
    									'BoldNumberInventory' => function($q) {
    									return $q
    									->select([
    											'unique_series','from','to'
    									]);
    					
    									}
    					
    					
    									]);
    							}
    					
    							]);
    					}
    					]);
    			},
    			
    	
    			
    			 
    			])
    			->where(['PackingShipingData.invoice_id'=>$invoiceId])
    			//->order(['PurchaseOrder.id'=>'DESC'])
    			 
    			->toArray();
    
    			
    			//Starts 
    			$this->loadModel('Countries');
    			$this->loadModel('PortOfDischarge');
    			//debug($salesOrder);
    			//	echo $salesOrder[0]['country_of_origin_of_goods'];die;
    			$countryoforigineofgoods=$this->Countries->find('all',[
    					"Fields"=>["country_name","id"],
    			
    					"conditions"=>['id'=>$packingData[0]['invoices']['country_origin_goods']]
    			])->toArray();
    			
    			$portofdischarge=$this->PortOfDischarge->find('all',[
    					"Fields"=>["port_of_discharge","id"],
    			
    					"conditions"=>['id'=>$packingData[0]['invoices']['port_of_discharge']]
    			])->toArray();
    			
    			$countryoffinaldestination=$this->Countries->find('all',[
    					"Fields"=>["country_name","id"],
    			
    					"conditions"=>['id'=>$packingData[0]['invoices']['country_final_destination']]
    			])->toArray();
    			
    			
    			//debug($countryoforigineofgoods);
    			//debug($portofdischarge);
    			//debug($countryoffinaldestination);
    			 
    			 
    			//Ends
    			$this->set('packingData', $packingData);
    			$this->set('_serialize', ['packingData']);
    			if($requiredReturn===true){
    				return $packingData;
    			}
    
    }
    
    public function postshipmentpackinglistview($invoiceId = null,$requiredReturn=null)
    {
    	
    	$packingData=$this->packinglistview($id,false);
    	$this->set('packingData', $packingData);
    	$this->set('_serialize', ['packingData']);
    }
    public function packinglistviewprint($id = null)
    {
    	$packingData=$this->packinglistview($id,true);
    
    	$this->set('packingData', $packingData);
    	$this->set('_serialize', ['packingData']);
    }
    public function postshipmentpackinglistviewprint($id = null)
    {
    	$packingData=$this->packinglistview($id,true);
    
    	$this->set('packingData', $packingData);
    	$this->set('_serialize', ['packingData']);
    }
}
