<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
/**
 * BoldNumberInventory Controller
 *
 * @property \App\Model\Table\BoldNumberInventoryTable $BoldNumberInventory
 *
 * @method \App\Model\Entity\BoldNumberInventory[] paginate($object = null, array $settings = [])
 */
class BoldNumberInventoryController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$ownercomp= $this->request->session()->read('OwnerCompany.id');

    	$condn= array(['AND' => [
    			'BoldNumberInventory.owner_company_id' => $ownercomp,
    			'BoldNumberInventory.delete_status' => "0"
    	]]);
        $this->paginate = [
        	'conditions'=>$condn,
            'contain' => ['BoldNumberRequest', 'OwnerCompanies']
        ];
        $boldNumberInventory = $this->paginate($this->BoldNumberInventory);

        $this->set(compact('boldNumberInventory'));
        $this->set('_serialize', ['boldNumberInventory']);
    }

    /**
     * View method
     *
     * @param string|null $id Bold Number Inventory id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $boldNumberInventory = $this->BoldNumberInventory->get($id, [
            'contain' => ['BoldNumberRequest', 'OwnerCompanies', 'BoldNoInventoryTran','BoldNoInventoryTran.ProductsMaster','BoldNoInventoryTran.Order','BoldNoInventoryTran.OrderAcceptance']
        ]);

        $this->set('boldNumberInventory', $boldNumberInventory);
        $this->set('_serialize', ['boldNumberInventory']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $boldNumberInventory = $this->BoldNumberInventory->newEntity();
        if ($this->request->is('post')) {
            $boldNumberInventory = $this->BoldNumberInventory->patchEntity($boldNumberInventory, $this->request->data);
            if ($this->BoldNumberInventory->save($boldNumberInventory)) {
                $this->Flash->success(__('The {0} has been saved.', 'Bold Number Inventory'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bold Number Inventory'));
            }
        }
        $boldNumberRequests = $this->BoldNumberInventory->BoldNumberRequests->find('list', ['limit' => 200]);
        $ownerCompanies = $this->BoldNumberInventory->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('boldNumberInventory', 'boldNumberRequests', 'ownerCompanies'));
        $this->set('_serialize', ['boldNumberInventory']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Bold Number Inventory id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $boldNumberInventory = $this->BoldNumberInventory->get($id, [
            'contain' => ['BoldNumberRequest','BoldNoInventoryTran','BoldNoInventoryTran.ProductsMaster','BoldNoInventoryTran.Order','BoldNoInventoryTran.OrderAcceptance']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
        	$ownercomp=$this->request->data['owner_company_id'];
        	if($ownercomp==1){
        		$week=Configure::read('UniqueNoSeries.1');
        		
        	}elseif($ownercomp==5){
        		$week=Configure::read('UniqueNoSeries.2');        		
        	}
        	$condn= array("BoldNumberRequest.owner_company_id"=>$ownercomp);
        	
        	$TransLatest=0;
        	foreach ($this->request->data['bold_no_inventory_tran'] as $currentData){
        	
        		$TransLatest += $currentData['to']-$currentData['from'] +1;
        	
        	}
        	$this->loadModel('BoldNumberRequest');
        	$getReqdata=$this->BoldNumberRequest->find('all',array('conditions'=>$condn))->toArray();
        	$totalReq=0;
        	$trans=0;
        	$tranOnly=0;
        	foreach ($getReqdata as $olddata) {
        		$totalReq +=$olddata['bold_number_to']-$olddata['bold_number_from']-$olddata['quantity_reject']+1;
        	}
        	
        	$this->loadModel('BoldNoInventoryTran');
        	$getTransdata=$this->BoldNoInventoryTran->find('all')->toArray();
        	foreach ($getTransdata as $oldTransdata) {
        		$trans +=$oldTransdata['BoldNoInventoryTran']['to']-$oldTransdata['BoldNoInventoryTran']['from']+1;
        	
        		$tranOnly =$oldTransdata['BoldNoInventoryTran']['to']-$oldTransdata['BoldNoInventoryTran']['from']+1;
        	}
        	$totalTrans=$trans+$TransLatest;
        		
        		
        	$diff=$totalReq-$totalTrans;
        	$BoldNumReq = $this->request->data['to']-$this->request->data['from']-$this->request->data['quantity_rejected'] +1;
        	
        	
        	$this->request->data['remain_quantity']=$BoldNumReq-$TransLatest;
        	
        	
        	
            $boldNumberInventory = $this->BoldNumberInventory->patchEntity($boldNumberInventory, $this->request->data);
            //debug($this->request->data);exit;
            if ($TransLatest <= $BoldNumReq) {
            $this->BoldNumberInventory->save($boldNumberInventory);
            if($diff <= Configure::read('boldNoLimit.limit')){
            	$getdata = $this->BoldNumberRequest->find('list', ['keyFields'=>'id','valueField'=>'unique_series','limit' => 200,'conditions'=>$condn])->toArray();
            	$lastdata = end($getdata);
            	//debug($lastdata);exit;
            	if($lastdata !=null){
            		$lastdata2 = \DateTime::createFromFormat('dmy', $lastdata)->format('Y-m-d');
            		$nextSaturday = new \DateTime("$lastdata2 next $week");
            		$firstSat=$nextSaturday->format("m/d/y");
            	}else{
            		$firstSat= date("m/d/y", strtotime("first $week of last month"));
            	}
            	
            	$start = new \DateTime($firstSat);// date format should be m/d/y
            	$end = new \DateTime($firstSat);
            	$end = $end->add(new \DateInterval('P35D'));
            	 
            	$satPeriod = new \DatePeriod ($start,\DateInterval::createFromDateString("next $week"),$end);
            	foreach ($satPeriod as $key=>$saturday) {
            		$satdatenew=$saturday->format("Y-m-d");
            		$today = date('Y-m-d');
            		if(strtotime($satdatenew) < strtotime($today)){
            			$Request[$key]['bold_number_from']= $this->request->data['from'];
            			$Request[$key]['bold_number_to']= $this->request->data['to'];
            			$Request[$key]['unique_series']= $saturday->format("dmy");
            			$Request[$key]['owner_company_id']= $this->request->data['owner_company_id'];
            			$Request[$key]['del_status']= "0";
            			$Request[$key]['created_by']= $this->Auth->User('id');
            		}
            	}
            	//debug($Request);exit;
            	if(isset($Request)){
            		$entities = $this->BoldNumberRequest->newEntities($Request);
            		$this->BoldNumberRequest->saveMany($entities);
            	}
            	
            }
            
            
                $this->Flash->success(__('The {0} has been saved.', 'Bold Number Inventory'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bold Number Inventory'));
            }
        }
        $boldNumberRequests = $this->BoldNumberInventory->BoldNumberRequest->find('list', ['limit' => 200]);
        $ownerCompanies = $this->BoldNumberInventory->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('boldNumberInventory', 'boldNumberRequests', 'ownerCompanies'));
        $this->set('_serialize', ['boldNumberInventory']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Bold Number Inventory id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $boldNumberInventory = $this->BoldNumberInventory->get($id);
        $data = array('id' => $id , 'delete_status' => "1");
        $boldNumberInventory = $this->BoldNumberInventory->patchEntity($boldNumberInventory, $data);
        if ($this->BoldNumberInventory->save($boldNumberInventory)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Bold Number Inventory'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Bold Number Inventory'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
