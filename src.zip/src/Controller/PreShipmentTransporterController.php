<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PreShipmentTransporter Controller
 *
 * @property \App\Model\Table\PreShipmentTransporterTable $PreShipmentTransporter
 *
 * @method \App\Model\Entity\PreShipmentTransporter[] paginate($object = null, array $settings = [])
 */
class PreShipmentTransporterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Oas', 'Transports', 'Invoices']
        ];
        $preShipmentTransporter = $this->paginate($this->PreShipmentTransporter);

        $this->set(compact('preShipmentTransporter'));
        $this->set('_serialize', ['preShipmentTransporter']);
    }

    /**
     * View method
     *
     * @param string|null $id Pre Shipment Transporter id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $preShipmentTransporter = $this->PreShipmentTransporter->get($id, [
            'contain' => ['Oas', 'Transports', 'Invoices']
        ]);

        $this->set('preShipmentTransporter', $preShipmentTransporter);
        $this->set('_serialize', ['preShipmentTransporter']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $preShipmentTransporter = $this->PreShipmentTransporter->newEntity();
        if ($this->request->is('post')) {
            $preShipmentTransporter = $this->PreShipmentTransporter->patchEntity($preShipmentTransporter, $this->request->data);
            if ($this->PreShipmentTransporter->save($preShipmentTransporter)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Transporter'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Transporter'));
            }
        }
        $oas = $this->PreShipmentTransporter->Oas->find('list', ['limit' => 200]);
        $transports = $this->PreShipmentTransporter->Transports->find('list', ['limit' => 200]);
        $invoices = $this->PreShipmentTransporter->Invoices->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentTransporter', 'oas', 'transports', 'invoices'));
        $this->set('_serialize', ['preShipmentTransporter']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Pre Shipment Transporter id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $preShipmentTransporter = $this->PreShipmentTransporter->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $preShipmentTransporter = $this->PreShipmentTransporter->patchEntity($preShipmentTransporter, $this->request->data);
            if ($this->PreShipmentTransporter->save($preShipmentTransporter)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Transporter'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Transporter'));
            }
        }
        $oas = $this->PreShipmentTransporter->Oas->find('list', ['limit' => 200]);
        $transports = $this->PreShipmentTransporter->Transports->find('list', ['limit' => 200]);
        $invoices = $this->PreShipmentTransporter->Invoices->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentTransporter', 'oas', 'transports', 'invoices'));
        $this->set('_serialize', ['preShipmentTransporter']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Pre Shipment Transporter id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $preShipmentTransporter = $this->PreShipmentTransporter->get($id);
        if ($this->PreShipmentTransporter->delete($preShipmentTransporter)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Pre Shipment Transporter'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Pre Shipment Transporter'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
