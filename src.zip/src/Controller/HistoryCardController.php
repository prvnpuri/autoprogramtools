<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * HistoryCard Controller
 *
 * @property \App\Model\Table\HistoryCardTable $HistoryCard
 *
 * @method \App\Model\Entity\HistoryCard[] paginate($object = null, array $settings = [])
 */
class HistoryCardController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['EquipmentCalibrationMasters']
        ];
        $historyCard = $this->paginate($this->HistoryCard);

        $this->set(compact('historyCard'));
        $this->set('_serialize', ['historyCard']);
    }

    /**
     * View method
     *
     * @param string|null $id History Card id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $historyCard = $this->HistoryCard->get($id, [
            'contain' => ['EquipmentCalibrationMasters']
        ]);

        $this->set('historyCard', $historyCard);
        $this->set('_serialize', ['historyCard']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $historyCard = $this->HistoryCard->newEntity();
        if ($this->request->is('post')) {
            $historyCard = $this->HistoryCard->patchEntity($historyCard, $this->request->data);
            if ($this->HistoryCard->save($historyCard)) {
                $this->Flash->success(__('The {0} has been saved.', 'History Card'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'History Card'));
            }
        }
        $equipmentCalibrationMasters = $this->HistoryCard->EquipmentCalibrationMasters->find('list', ['limit' => 200]);
        $this->set(compact('historyCard', 'equipmentCalibrationMasters'));
        $this->set('_serialize', ['historyCard']);
    }

    /**
     * Edit method
     *
     * @param string|null $id History Card id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $historyCard = $this->HistoryCard->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $historyCard = $this->HistoryCard->patchEntity($historyCard, $this->request->data);
            if ($this->HistoryCard->save($historyCard)) {
                $this->Flash->success(__('The {0} has been saved.', 'History Card'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'History Card'));
            }
        }
        $equipmentCalibrationMasters = $this->HistoryCard->EquipmentCalibrationMasters->find('list', ['limit' => 200]);
        $this->set(compact('historyCard', 'equipmentCalibrationMasters'));
        $this->set('_serialize', ['historyCard']);
    }

    /**
     * Delete method
     *
     * @param string|null $id History Card id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $historyCard = $this->HistoryCard->get($id);
        if ($this->HistoryCard->delete($historyCard)) {
            $this->Flash->success(__('The {0} has been deleted.', 'History Card'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'History Card'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
