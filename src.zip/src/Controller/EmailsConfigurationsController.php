<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * EmailsConfigurations Controller
 *
 * @property \App\Model\Table\EmailsConfigurationsTable $EmailsConfigurations
 *
 * @method \App\Model\Entity\EmailsConfiguration[] paginate($object = null, array $settings = [])
 */
class EmailsConfigurationsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $emailsConfigurations = $this->paginate($this->EmailsConfigurations);

        $this->set(compact('emailsConfigurations'));
        $this->set('_serialize', ['emailsConfigurations']);
    }

    /**
     * View method
     *
     * @param string|null $id Emails Configuration id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $emailsConfiguration = $this->EmailsConfigurations->get($id, [
            'contain' => []
        ]);

        $this->set('emailsConfiguration', $emailsConfiguration);
        $this->set('_serialize', ['emailsConfiguration']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $emailsConfiguration = $this->EmailsConfigurations->newEntity();
        if ($this->request->is('post')) {
            $emailsConfiguration = $this->EmailsConfigurations->patchEntity($emailsConfiguration, $this->request->data);
            if ($this->EmailsConfigurations->save($emailsConfiguration)) {
                $this->Flash->success(__('The {0} has been saved.', 'Emails Configuration'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Emails Configuration'));
            }
        }
        $this->set(compact('emailsConfiguration'));
        $this->set('_serialize', ['emailsConfiguration']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Emails Configuration id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $emailsConfiguration = $this->EmailsConfigurations->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $emailsConfiguration = $this->EmailsConfigurations->patchEntity($emailsConfiguration, $this->request->data);
            if ($this->EmailsConfigurations->save($emailsConfiguration)) {
                $this->Flash->success(__('The {0} has been saved.', 'Emails Configuration'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Emails Configuration'));
            }
        }
        $this->set(compact('emailsConfiguration'));
        $this->set('_serialize', ['emailsConfiguration']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Emails Configuration id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $emailsConfiguration = $this->EmailsConfigurations->get($id);
        if ($this->EmailsConfigurations->delete($emailsConfiguration)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Emails Configuration'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Emails Configuration'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
