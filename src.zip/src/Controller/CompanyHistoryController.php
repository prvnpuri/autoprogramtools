<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanyHistory Controller
 *
 * @property \App\Model\Table\CompanyHistoryTable $CompanyHistory
 *
 * @method \App\Model\Entity\CompanyHistory[] paginate($object = null, array $settings = [])
 */
class CompanyHistoryController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Companies', 'Products']
        ];
        $companyHistory = $this->paginate($this->CompanyHistory);

        $this->set(compact('companyHistory'));
        $this->set('_serialize', ['companyHistory']);
    }

    /**
     * View method
     *
     * @param string|null $id Company History id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companyHistory = $this->CompanyHistory->get($id, [
            'contain' => ['Companies', 'Products']
        ]);

        $this->set('companyHistory', $companyHistory);
        $this->set('_serialize', ['companyHistory']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companyHistory = $this->CompanyHistory->newEntity();
        if ($this->request->is('post')) {
            $companyHistory = $this->CompanyHistory->patchEntity($companyHistory, $this->request->data);
            if ($this->CompanyHistory->save($companyHistory)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company History'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company History'));
            }
        }
        $companies = $this->CompanyHistory->Companies->find('list', ['limit' => 200]);
        $products = $this->CompanyHistory->Products->find('list', ['limit' => 200]);
        $this->set(compact('companyHistory', 'companies', 'products'));
        $this->set('_serialize', ['companyHistory']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company History id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companyHistory = $this->CompanyHistory->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companyHistory = $this->CompanyHistory->patchEntity($companyHistory, $this->request->data);
            if ($this->CompanyHistory->save($companyHistory)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company History'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company History'));
            }
        }
        $companies = $this->CompanyHistory->Companies->find('list', ['limit' => 200]);
        $products = $this->CompanyHistory->Products->find('list', ['limit' => 200]);
        $this->set(compact('companyHistory', 'companies', 'products'));
        $this->set('_serialize', ['companyHistory']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company History id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyHistory = $this->CompanyHistory->get($id);
        if ($this->CompanyHistory->delete($companyHistory)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company History'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company History'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
