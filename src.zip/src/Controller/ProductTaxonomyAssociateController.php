<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductTaxonomyAssociate Controller
 *
 * @property \App\Model\Table\ProductTaxonomyAssociateTable $ProductTaxonomyAssociate
 *
 * @method \App\Model\Entity\ProductTaxonomyAssociate[] paginate($object = null, array $settings = [])
 */
class ProductTaxonomyAssociateController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ProductTaxonomies']
        ];
        $productTaxonomyAssociate = $this->paginate($this->ProductTaxonomyAssociate);

        $this->set(compact('productTaxonomyAssociate'));
        $this->set('_serialize', ['productTaxonomyAssociate']);
    }

    /**
     * View method
     *
     * @param string|null $id Product Taxonomy Associate id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productTaxonomyAssociate = $this->ProductTaxonomyAssociate->get($id, [
            'contain' => ['ProductTaxonomies']
        ]);

        $this->set('productTaxonomyAssociate', $productTaxonomyAssociate);
        $this->set('_serialize', ['productTaxonomyAssociate']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productTaxonomyAssociate = $this->ProductTaxonomyAssociate->newEntity();
        if ($this->request->is('post')) {
            $productTaxonomyAssociate = $this->ProductTaxonomyAssociate->patchEntity($productTaxonomyAssociate, $this->request->data);
            if ($this->ProductTaxonomyAssociate->save($productTaxonomyAssociate)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Taxonomy Associate'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Taxonomy Associate'));
            }
        }
        $productTaxonomies = $this->ProductTaxonomyAssociate->ProductTaxonomies->find('list', ['limit' => 200]);
        $this->set(compact('productTaxonomyAssociate', 'productTaxonomies'));
        $this->set('_serialize', ['productTaxonomyAssociate']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product Taxonomy Associate id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productTaxonomyAssociate = $this->ProductTaxonomyAssociate->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productTaxonomyAssociate = $this->ProductTaxonomyAssociate->patchEntity($productTaxonomyAssociate, $this->request->data);
            if ($this->ProductTaxonomyAssociate->save($productTaxonomyAssociate)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Taxonomy Associate'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Taxonomy Associate'));
            }
        }
        $productTaxonomies = $this->ProductTaxonomyAssociate->ProductTaxonomies->find('list', ['limit' => 200]);
        $this->set(compact('productTaxonomyAssociate', 'productTaxonomies'));
        $this->set('_serialize', ['productTaxonomyAssociate']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product Taxonomy Associate id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productTaxonomyAssociate = $this->ProductTaxonomyAssociate->get($id);
        if ($this->ProductTaxonomyAssociate->delete($productTaxonomyAssociate)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product Taxonomy Associate'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product Taxonomy Associate'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
