<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;
/**
 * ProductsMaster Controller
 *
 * @property \App\Model\Table\ProductsMasterTable $ProductsMaster
 * @property \App\Model\Table\TaxMasterTable $TaxMaster
 * @method \App\Model\Entity\ProductsMaster[] paginate($object = null, array $settings = [])
 */
class ProductsMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
		
    	$this->loadModel('OwnerCompanies');
    	
    	$query=$this->request->getQuery("search");
    	$conditions=array(['AND' => [
    	    'ProductsMaster.del_status' => "0"
    	]]);
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="ProductsMaster.product_name like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['ProductMsds','ProductIndustryApplications','ProductIndustryApplications.ProductApplications','ProductIndustryApplications.IndustryTypeMaster'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","product_name","State.state_name","product_information","grade_name","well_known_grade_name","acronym","cas_no"]
    	];
    	
    	
    	$productsMaster= $this->paginate($this->ProductsMaster);
//     	debug($productsMaster); exit;
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('productsMaster'));
    	$this->set( '_serialize', ['productsMaster','paging']);
    	$ownerCompanies= $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
    	$this->set('ownerCompanies',$ownerCompanies);
    
    }

    /**
     * View method
     *
     * @param string|null $id Products Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
    	 $productsMaster = $this->ProductsMaster->get($id, [
        		'contain' => ['ProductDataTests', 'ProductIndustryApplications','ProductIndustryApplications.ProductApplications','ProductIndustryApplications.IndustryTypeMaster',
        		'ProductSolubilityTests','ProductStandards'=>array('PackingType','PackingSubtype','Uom','Currency')]
        ]);
        $proddet = json_decode( $productsMaster['product_details']);
//        	$productsMaster->synonym= $proddet->synonym;
        $productsMaster->Application= $proddet->Application;
//         $productsMaster->Benefit= $proddet->Benefit;
//         $productsMaster->Registration= $proddet->Registration;
//         $productsMaster->PolymerDetails= $proddet->PolymerDetails;
       
        $this->loadModel('IndustryTypeMaster');
        $this->loadModel('ProductApplications');
        $this->set('productsMaster', $productsMaster);   
        $groups= $this->IndustryTypeMaster->find('list', ['keyField' => 'id','valueField' => 'industry_type','order'=>'industry_type']);
        
        $subgroups= $this->ProductApplications->find('list', ['keyField' => 'id','valueField' => 'application_name','order'=>'application_name']);
        
        $this->loadModel('PackingType');
        $this->loadModel('PackingSubtype');
        $this->loadModel('Uom');
        $this->loadModel('Currency');
        $packing_type = $this->PackingType->find('list', ['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type']);
        $subpacking_type = $this->PackingSubtype->find('list', ['keyField' => 'id','valueField' => 'sub_type','order'=>'sub_type']);
        $uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_name','conditions'=>['unit_type'=>'weight'],'order'=>'unit_name']);
        $currency = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'name','order'=>'name']);
        $this->set(compact('groups','subgroups','taxname','packing_type','subpacking_type','uom','currency'));
        
        $this->set('_serialize', ['productsMaster']);

        
    }
	
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
      
    	$productsMaster = $this->ProductsMaster->newEntity();
        if ($this->request->is('post')) {
        	$this->loadModel('ProductStandards');
        	
        	//$this->request->data['product_data_tests']=array();
            if( $this->request->getData('product_data_tests')!=null ){
                foreach ($this->request->data['product_data_tests'] as $key => &$productDataCheck){
            		
            		$this->request->data['product_data_tests'][$key]["purpose"]= implode(",",$productDataCheck["purpose"]);
            	} 
            }
            
//             if( $this->request->getData('product_industry_applications')!=null ){
                
//             	foreach($this->request->data['product_industry_applications'] as $industry){
            		
//             		foreach($industry['Product_applications_id'] as $appId){
            			        			
//             			$industryInfo['industry_type_master_id'] = $industry['industry_type_master_id'];
//             			$industryInfo['Product_applications_id'] = $appId;
            			
//             			$industryData[] = $industryInfo;        			        			
//             		}
//             	}
//             }
//         	$this->request->data['product_industry_applications'] = $industryData;        	
     
            $productsMaster= $this->ProductsMaster->patchEntity($productsMaster, $this->request->data,
            		[
            				'associated' => ['ProductIndustryApplications','ProductSolubilityTests','ProductDataTests','ProductTaxes'/*,'ProductStandards'*/]
            		]
            );
            
            //debug($productsMaster);exit;
            if(isset($this->request->data["msds_attachment"]) &&  $this->request->data["msds_attachment"]["error"]==0){
            	$filename=$this->request->data["msds_attachment"]["name"];
            	$productsMaster["msds_attachment"]=$filename;
            }else{
            	
            }
            
            
            if(isset($this->request->data["coa_attachment"]) &&  $this->request->data["coa_attachment"]["error"]==0){
            	$filename=$this->request->data["coa_attachment"]["name"];
            	$productsMaster["coa_attachment"]=$filename;
            }else{
            	
            }
            
            
            if(isset($this->request->data["tds_attachment"]) &&  $this->request->data["tds_attachment"]["error"]==0){
            	$filename=$this->request->data["tds_attachment"]["name"];
            	$productsMaster["tds_attachment"]=$filename;
            }else{
            	
            }
            
            $productsMaster['created_by'] = $this->Auth->User('id');
//             $synonym=$this->request->data['synonym'];
            $product_application=$this->request->data['product_application'];
//             $product_benefit=$this->request->data['product_benefit'];
//             $polymer_details=$this->request->data['polymer_details'];
//             $suggested_dosage=$this->request->data['suggested_dosage'];
//             $srno=$this->request->data['srno'];
//             $title=$this->request->data['title'];
//             $chapter=$this->request->data['chapter'];
//             $subchapter=$this->request->data['subchapter'];
//             $part=$this->request->data['part'];
//             $subpart=$this->request->data['subpart'];
//             $section=$this->request->data['section'];
            
//             $registration=array();
//             foreach ($srno as $k => $data ){
//             	$registration[]=[
//             			"Sno"=>$srno[$k],
//             			"Title"=>$title[$k],
//             			'Chapter'=>$chapter[$k],
//             			'SubChapter'=>$subchapter[$k],
//             			'Part'=>$part[$k],
//             			'SubPart'=>$subpart[$k],
//             			'Section'=>$section[$k]
            			
//             	];
//             }
            
         
            
//             $PolymerDetails=array();
//             foreach ($polymer_details as $k => $data ){
//             	$PolymerDetails[]=[
//             			"PolymerDetail"=>$polymer_details[$k],
//             			'SuggestedDosage'=>$suggested_dosage[$k],
            			
            			
//             	];
//             }
            $extrainfo = array(
//             		"synonym"=>$synonym,
            		'Application'=>$product_application,
//             		'Benefit'=>$product_benefit,
//             		'Registration'=>$registration,
//             		'PolymerDetails'=>$PolymerDetails,
            		//'ProductStandard'=>$pStandards
            );
            
            
            $info= json_encode($extrainfo);

            $productsMaster['product_details'] = $info;
            
            //debug($productsMaster);exit;
            if ($this->ProductsMaster->save($productsMaster)) {
            	
            	
            	if(isset($this->request->data["msds_attachment"]) &&  $this->request->data["msds_attachment"]["error"]==0){
            		$id= $productsMaster["id"];
            		$filename=$id."_".$this->request->data["msds_attachment"]["name"];
            		$url = Router::url('/',true).'upload/product-msds-pdf/'.$filename;
            		$uploadpath = 'upload/product-msds-pdf/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["msds_attachment"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["msds_attachment"]);
            	}
            	
            	
            	
//             	if(isset($this->request->data["coa_attachment"]) &&  $this->request->data["coa_attachment"]["error"]==0){
//             		$id= $productsMaster["id"];
//             		$filename=$id."_".$this->request->data["coa_attachment"]["name"];
//             		$url = Router::url('/',true).'upload/product-coa-pdf/'.$filename;
//             		$uploadpath = 'upload/product-coa-pdf/';
//             		$uploadfile = $uploadpath.$filename;
//             		move_uploaded_file($this->request->data["coa_attachment"]['tmp_name'], $uploadfile);
            		
//             	}else{
//             		unset($this->request->data["coa_attachment"]);
//             	}
            	
            	
            	
//             	if(isset($this->request->data["tds_attachment"]) &&  $this->request->data["tds_attachment"]["error"]==0){
//             		$id= $productsMaster["id"];
//             		$filename=$id."_".$this->request->data["tds_attachment"]["name"];
//             		$url = Router::url('/',true).'upload/product-tds-pdf/'.$filename;
//             		$uploadpath = 'upload/product-tds-pdf/';
//             		$uploadfile = $uploadpath.$filename;
//             		move_uploaded_file($this->request->data["tds_attachment"]['tmp_name'], $uploadfile);
            		
//             	}else{
//             		unset($this->request->data["tds_attachment"]);
//             	}
            	
            	
            	
                $this->Flash->success(__('The {0} has been saved.', 'Products Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Products Master'));
            }
        }
        
        
        $this->set(compact('productsMaster'));
        $this->loadModel('ProductIndustryApplication');
        $this->loadModel('IndustryTypeMaster');
        $this->loadModel('ProductApplications');
        $this->loadModel('TaxMaster');
        $this->loadModel('OwnerCompanies');
        $ownerCompanies=$this->OwnerCompanies->find("all");
        $groups= $this->IndustryTypeMaster->find('list', ['keyField' => 'id','valueField' => 'industry_type','order'=>'industry_type']);
       	$subgroups= $this->ProductApplications->find('list', ['keyField' => 'id','valueField' => 'application_name','order'=>'application_name'
        ]);
        $taxname = $this->TaxMaster->find('list', [
            'keyField' => 'id',
            'valueField' => 'modified_tax_name',
            'order' => 'modified_tax_name'
        ]);
            
        $taxname->select(["id",
           "modified_tax_name"=> $taxname->func()->concat([ 
               'tax_name'=>'identifier'," - ", 
               " CASE applicability WHEN 1 then '".__('Local')."' when 2 then '".__('Inter state')."' else '".__('Export')."'  END" =>'literal' 
           ]) 
        ]);
        $this->loadModel('PackingType');
        $this->loadModel('PackingSubtype');
        $this->loadModel('Uom');
        $this->loadModel('Currency');
        $packing_type = $this->PackingType->find('list', ['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type']);
        $subpacking_type = $this->PackingSubtype->find('list', ['keyField' => 'id','valueField' => 'sub_type','order'=>'sub_type']);
        $uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_name','conditions'=>['unit_type'=>'weight'],'order'=>'unit_name']);
    	$currency = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'name','order'=>'name']);
       	$this->set(compact('ownerCompanies','groups','subgroups','taxname','packing_type','subpacking_type','uom','currency'));
                
        $this->set('_serialize', ['productsMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Products Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productsMaster = $this->ProductsMaster->get($id, [
            'contain' => [
                'ProductIndustryApplications','ProductSolubilityTests','ProductDataTests','ProductTaxes','ProductStandards'
            ]
        ]);
        $proddet = json_decode( $productsMaster['product_details']);
        if(isset($proddet)){
//             if(array_key_exists('synonym', $proddet )) $productsMaster->synonym= $proddet->synonym;
            if(array_key_exists('Application', $proddet )) $productsMaster->Application= $proddet->Application;
//             if(array_key_exists('Benefit', $proddet )) $productsMaster->Benefit= $proddet->Benefit;
//             if(array_key_exists('Registration', $proddet )) $productsMaster->Registration= $proddet->Registration;
//             if(array_key_exists('PolymerDetails', $proddet )) $productsMaster->PolymerDetails= $proddet->PolymerDetails;
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
          	        
        	if(empty($this->request->data['msds_attachment']['name'])){
        		unset($this->request->data['msds_attachment']);
        	}
        	
//         	if(!empty($this->request->data['product_industry_applications_added'])){
        	
//         		$dataAdded = $this->request->data['product_industry_applications_added'];
        		
//         		foreach($dataAdded as $industry){
        			
//         			foreach($industry['Product_applications_id'] as $appId){
        				
//         				$industryInfo['industry_type_master_id'] = $industry['industry_type_master_id'];
//         				$industryInfo['Product_applications_id'] = $appId;
        				
//         				$industryData[] = $industryInfo;
//         			}
//         		}
        		
//         		$industrynewData = $this->request->data['product_industry_applications'];
//         		$indnew = array_merge($industrynewData,$industryData);
        		
//         		$this->request->data['product_industry_applications'] = $indnew;
//         		unset($this->request->data['product_industry_applications_added']);        		
//         	}
        	
        	
//         	if(!empty($this->request->data['product_solubility_tests_added']))
//         	{
//         		$productsolubilitytestsnew = array_merge($this->request->data['product_solubility_tests'], $this->request->data['product_solubility_tests_added']);
        		
//         		$this->request->data['product_solubility_tests'] = $productsolubilitytestsnew;
//         		unset($this->request->data['product_solubility_tests_added']);
//         	}
        	//$this->request->data['product_data_tests_added']=array();
        	if(!empty($this->request->data['product_data_tests_added'])){
        	
        		foreach ($this->request->data['product_data_tests_added'] as $key => &$productDataCheck){
        			
        			if(!empty($productDataCheck["purpose"])){
        				$this->request->data['product_data_tests_added'][$key]["purpose"]= implode(", ",$productDataCheck["purpose"]);
        			}
        		}
        		$product_data_tests=[];
        		$product_data_tests_added=[];
        		if( isset( $this->request->data['product_data_tests'] )  ){
        		    $product_data_tests=$this->request->data['product_data_tests'] ;
        		}
        		
        		if( isset( $this->request->data['product_data_tests_added'] )  ){
        		    $product_data_tests_added=$this->request->data['product_data_tests_added'] ;
        		}
        		if(isset($this->request->data['product_data_tests'])){
        		    $productdatatestsnew = array_merge($this->request->data['product_data_tests'], $this->request->data['product_data_tests_added']);
        		}else{
        		    $productdatatestsnew = $this->request->data['product_data_tests_added'];
        		}
        		$this->request->data['product_data_tests'] = $productdatatestsnew;
        		unset($this->request->data['product_data_tests_added']);        		
        	}
        	if(!empty($this->request->data['product_standards_added'])){
        	    
        	    //debug($this->request->data['product_standards_added']);die;
        	    foreach ($this->request->data['product_standards_added'] as $k=>$v){
        	        
        	        if($v['standard_packing_type']==""){
        	            unset($this->request->data['product_standards_added'][$k]);
        	        }
        	    }
        	    
        	    
        	    
        	    
        	    if(isset($this->request->data['product_standards'])){
        	        $productstdnew = array_merge($this->request->data['product_standards'], $this->request->data['product_standards_added']);
        	    }
        	    
        	    $productstdnew = $this->request->data['product_standards_added'];
        	    //}
        	    //debug($productstdnew);exit;
        		$this->request->data['product_standards'] = $productstdnew;
        		unset($this->request->data['product_standards_added']);
        	}
        	 
        	//debug($this->request->data['product_standards']);exit;
        	
        	     
        	$productsMaster= $this->ProductsMaster->patchEntity($productsMaster, $this->request->getData(),
            	[
            		'associated' => ['ProductIndustryApplications','ProductSolubilityTests','ProductDataTests','ProductTaxes'/*,'ProductStandards'*/]
            	]
        	);
            
        	if(isset($this->request->data["msds_attachment"]) &&  $this->request->data["msds_attachment"]["error"]==0){
        		$filename=$this->request->data["msds_attachment"]["name"];
        		$productsMaster["msds_attachment"]=$filename;
        	}else{
        		unset($this->request->data["msds_attachment"]);
        	}
        	
        	
        	
//         	if(isset($this->request->data["coa_attachment"]) &&  $this->request->data["coa_attachment"]["error"]==0){
//         		$filename=$this->request->data["coa_attachment"]["name"];
//         		$productsMaster["coa_attachment"]=$filename;
//         	}else{
//         		unset($this->request->data["coa_attachment"]);
//         	}
            
            
            
            
//         	if(isset($this->request->data["tds_attachment"]) &&  $this->request->data["tds_attachment"]["error"]==0){
//         		$filename=$this->request->data["tds_attachment"]["name"];
//         		$productsMaster["tds_attachment"]=$filename;
//         	}else{
//         		unset($this->request->data["tds_attachment"]);
//         	}
         
        	$productsMaster['modified_by'] = $this->Auth->User('id');
//         	$synonym= $this->request->getData('synonym');
        	$product_application=$this->request->getData('product_application');
//         	$product_benefit=$this->request->getData('product_benefit');
//         	$polymer_details=$this->request->getData('polymer_details');
//         	$suggested_dosage=$this->request->getData('suggested_dosage');
//         	$srno=$this->request->getData('srno');
//         	$title=$this->request->getData('title');
//         	$chapter=$this->request->getData('chapter');
//         	$subchapter=$this->request->getData('subchapter');
//         	$part=$this->request->getData('part');
//         	$subpart=$this->request->getData('subpart');
//         	$section=$this->request->getData('section');
        	
        	
        	
//         	$registration=array();
//         	if(isset($srno)){
//             	foreach ($srno as $k => $data ){
//             		$registration[]=[
//             				"Sno"=>$srno[$k],
//             				"Title"=>$title[$k],
//             				'Chapter'=>$chapter[$k],
//             				'SubChapter'=>$subchapter[$k],
//             				'Part'=>$part[$k],
//             				'SubPart'=>$subpart[$k],
//             				'Section'=>$section[$k]
            				
//             		];
//             	}
//         	}
        	
        	
        	
//         	$PolymerDetails=array();
//         	if(isset($polymer_details)){
//             	foreach ($polymer_details as $k => $data ){
//             		$PolymerDetails[]=[
//             				"PolymerDetail"=>$polymer_details[$k],
//             				'SuggestedDosage'=>$suggested_dosage[$k],
            				
            				
//             		];
//             	}
//         	}
        	
        	
        	$extrainfo = array(
//         			"synonym"=>$synonym,
        			'Application'=>$product_application,
//         			'Benefit'=>$product_benefit,
//         			'Registration'=>$registration,
//         			'PolymerDetails'=>$PolymerDetails
        			
        	);
        	
        	
        	$info= json_encode($extrainfo);
        	
        	
        	
        	
        	$productsMaster['product_details'] = $info;
        	
//         	debug($productsMaster);exit;
            if ($this->ProductsMaster->save($productsMaster)) {       	
            	if(isset($this->request->data["msds_attachment"]) &&  $this->request->data["msds_attachment"]["error"]==0){
            		$id= $productsMaster["id"];
            		$filename=$id."_".$this->request->data["msds_attachment"]["name"];
            		$url = Router::url('/',true).'upload/product-msds-pdf/'.$filename;
            		$uploadpath = 'upload/product-msds-pdf/';
            		$uploadfile = $uploadpath.$filename;
            		move_uploaded_file($this->request->data["msds_attachment"]['tmp_name'], $uploadfile);
            		 
            	}else{
            		unset($this->request->data["msds_attachment"]);
            	}
               
            	
            	
//             	if(isset($this->request->data["coa_attachment"]) &&  $this->request->data["coa_attachment"]["error"]==0){
//             		$id= $productsMaster["id"];
//             		$filename=$id."_".$this->request->data["coa_attachment"]["name"];
//             		$url = Router::url('/',true).'upload/product-coa-pdf/'.$filename;
//             		$uploadpath = 'upload/product-coa-pdf/';
//             		$uploadfile = $uploadpath.$filename;
//             		move_uploaded_file($this->request->data["coa_attachment"]['tmp_name'], $uploadfile);
            		
//             	}else{
//             		unset($this->request->data["coa_attachment"]);
//             	}
            	
            	
            	
            	
//             	if(isset($this->request->data["tds_attachment"]) &&  $this->request->data["tds_attachment"]["error"]==0){
//             		$id= $productsMaster["id"];
//             		$filename=$id."_".$this->request->data["tds_attachment"]["name"];
//             		$url = Router::url('/',true).'upload/product-tds-pdf/'.$filename;
//             		$uploadpath = 'upload/product-tds-pdf/';
//             		$uploadfile = $uploadpath.$filename;
//             		move_uploaded_file($this->request->data["tds_attachment"]['tmp_name'], $uploadfile);
            		
//             	}else{
//             		unset($this->request->data["tds_attachment"]);
//             	}
            	
            	
            	
            	
            	
            	$this->Flash->success(__('The {0} has been saved.', 'Products Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Products Master'));
            }
        }
        $this->set(compact('productsMaster'));
      
        $this->loadModel('IndustryTypeMaster');
        $this->loadModel('ProductApplications');
        $this->loadModel('TaxMaster');
        $this->loadModel('PackingType');
        $this->loadModel('PackingSubtype');
        $this->loadModel('Uom');
        $this->loadModel('Currency');
        $this->loadModel('OwnerCompanies');
        $ownerCompanies=$this->OwnerCompanies->find("all");
        $groups= $this->IndustryTypeMaster->find('list', ['keyField' => 'id','valueField' => 'industry_type','order'=>'industry_type']);
        
        $subgroups= $this->ProductApplications->find('list', ['keyField' => 'id','valueField' => 'application_name','order'=>'application_name']);
        $taxname= $this->TaxMaster->find('list', ['keyField' => 'id','valueField' => 'modified_tax_name','order'=>'modified_tax_name']);
        $taxname->select(["id",
            "modified_tax_name"=> $taxname->func()->concat([
                'tax_name'=>'identifier'," - ",
                " CASE applicability WHEN 1 then '".__('Local')."' when 2 then '".__('Inter state')."' else '".__('Export')."'  END" =>'literal'
            ])
        ]);
        
       	$packing_type = $this->PackingType->find('list', ['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type']);
        $subpacking_type = $this->PackingSubtype->find('list', ['keyField' => 'id','valueField' => 'sub_type','order'=>'sub_type']);
        $uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_name','conditions'=>['unit_type'=>'weight'],'order'=>'unit_name']);
        $currency = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'name','order'=>'name']);
        $this->set(compact('ownerCompanies','groups','subgroups','taxname','packing_type','subpacking_type','uom','currency'));
        
        $this->set('_serialize', ['productsMaster']);
       
        
    }

    /**
     * Delete method
     *
     * @param string|null $id Products Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productsMaster = $this->ProductsMaster->get($id);
      //  debug($productsMaster);exit;
        $data = array('id' => $id , 'del_status' => "1");
        $productsMaster = $this->ProductsMaster->patchEntity($productsMaster, $data);
        //debug($productsMaster);exit;
        
        if ( $this->ProductsMaster->save($productsMaster)) {
            //  debug($city);exit();
            $this->Flash->success(__('The {0} has been deleted.', 'Product'));
        } else {
            //  debug("Hiiii");exit();
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    
    public function changestatus($id = null) {
   
    	
    	$productsMaster = $this->ProductsMaster->get($id);
   
    	if ($productsMaster->id) {
    		if($productsMaster->status=='1'){
    			
    			$data = array('id' => $id , 'status' => "2");
    			$productsMaster= $this->ProductsMaster->patchEntity($productsMaster, $data);
    			$this->ProductsMaster->save($productsMaster);
    			$this->Flash->success(__('The {0} has been deactivated.', 'Product'));
    			
    		}else if($productsMaster->status=='2'){
    			
    			$data = array('id' => $id , 'status' => "1");
    			$productsMaster= $this->ProductsMaster->patchEntity($productsMaster, $data);
    			$this->ProductsMaster->save($productsMaster);
    			$this->Flash->success(__('The {0} has been activated.', 'Product'));
    			
    		}
    	}
    	return $this->redirect(array('action' => 'index'));
    	
    }
    
    
    public function techDsPdf($id=null,$isRedirect=true){
    	
    	
    	
    	$product= $this->ProductsMaster->get($id, [
    			'contain' => ['ProductDataTests', 'ProductIndustryApplications','ProductIndustryApplications.ProductApplications','ProductIndustryApplications.IndustryTypeMaster','ProductSolubilityTests']
    	]);
    	
    	
    	
    	$this->set("product", $product);
    	
    	$this->set('product_id', $id);
    	
    	
    	
    	$proddet = json_decode($product['product_details']);
    	$product->synonym= $proddet->synonym;
    	$product->Application= $proddet->Application;
    	$product->Benefit= $proddet->Benefit;
    	$product->Registration= $proddet->Registration;
    	$product->PolymerDetails= $proddet->PolymerDetails;
    	
    	
    	
    	$this->loadModel('OwnerCompanies');
    	$this->loadModel('ProductIndustryApplication');
    	$this->loadModel('IndustryTypeMaster');
    	$this->loadModel('ProductApplications');
    	
    	$groups= $this->IndustryTypeMaster->find('list', ['keyField' => 'id','valueField' => 'industry_type','order'=>'industry_type']);
    	$subgroups= $this->ProductApplications->find('list', ['keyField' => 'id','valueField' => 'application_name','order'=>'application_name']);
    	
    	$this->set(compact('groups','subgroups'));
  
    
    	$pro = $this->ProductsMaster->get($id);
    	
    	
    	
    	
    	$ownercompanies=$this->OwnerCompanies->find("all");
    	
    	
    	foreach($ownercompanies as $ownercompany){
    		$this->set("ownercompanies",$ownercompany);
    		
    	
    		$CakePdf = new \CakePdf\Pdf\CakePdf();
    		$CakePdf->template('product_tech_ds', 'default');
    		$CakePdf->viewVars($this->viewVars);
    		
    		$pdf = $CakePdf->output();
    		
    		
    		$pdf = $CakePdf->write(WWW_ROOT.DS.'upload'. DS.'product-techds'.DS.$pro->cas_no.'_'.$ownercompany->id.'.pdf');
    		
    	}
    	
    	//$this->viewBuilder()->setLayout("../Pdf/default");
    	//$this->render('/Pdf/product_tech_ds');
    	
    	$data = array('id' => $id , 'has_techds_pdf' => 1);
    	$pro= $this->ProductsMaster->patchEntity($pro, $data);
    	
    	if($this->ProductsMaster->save($pro)){
    		$this->Flash->success(__('Tech Datasheet Pdf has been generated.'));
    		
    	}else{
    		$this->Flash->error(__('Tech Datasheet Pdf has failed to generated.'));
    		
    	}
    	
    	    	if($isRedirect){
    	    		return  $this->redirect(array("action"=>"index"));
    	    	}
    	
    	
    	
    	
    }
    
    
}