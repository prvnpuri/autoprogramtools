<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * DailyWork Controller
 *
 * @property \App\Model\Table\DailyWorkTable $DailyWork
 *
 * @method \App\Model\Entity\DailyWork[] paginate($object = null, array $settings = [])
 */
class DailyWorkController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Employees']
        ];
        $dailyWork = $this->paginate($this->DailyWork);

        $this->set(compact('dailyWork'));
        $this->set('_serialize', ['dailyWork']);
    }

    /**
     * View method
     *
     * @param string|null $id Daily Work id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $dailyWork = $this->DailyWork->get($id, [
            'contain' => ['Employees', 'DailyWorkDetails']
        ]);

        $this->set('dailyWork', $dailyWork);
        $this->set('_serialize', ['dailyWork']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $dailyWork = $this->DailyWork->newEntity();
        if ($this->request->is('post')) {
            $dailyWork = $this->DailyWork->patchEntity($dailyWork, $this->request->data);
            if ($this->DailyWork->save($dailyWork)) {
                $this->Flash->success(__('The {0} has been saved.', 'Daily Work'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Daily Work'));
            }
        }
        $employees = $this->DailyWork->Employees->find('list', ['limit' => 200]);
        $this->set(compact('dailyWork', 'employees'));
        $this->set('_serialize', ['dailyWork']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Daily Work id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $dailyWork = $this->DailyWork->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $dailyWork = $this->DailyWork->patchEntity($dailyWork, $this->request->data);
            if ($this->DailyWork->save($dailyWork)) {
                $this->Flash->success(__('The {0} has been saved.', 'Daily Work'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Daily Work'));
            }
        }
        $employees = $this->DailyWork->Employees->find('list', ['limit' => 200]);
        $this->set(compact('dailyWork', 'employees'));
        $this->set('_serialize', ['dailyWork']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Daily Work id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $dailyWork = $this->DailyWork->get($id);
        if ($this->DailyWork->delete($dailyWork)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Daily Work'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Daily Work'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
