<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * GoodsReceiveNote Controller
 *
 * @property \App\Model\Table\GoodsReceiveNoteTable $GoodsReceiveNote
 *
 * @method \App\Model\Entity\GoodsReceiveNote[] paginate($object = null, array $settings = [])
 */
class GoodsReceiveNoteController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['WarehouseMasters', 'Pos', 'SupplierInvoices', 'Uoms', 'TransporterCompanies']
        ];
        $goodsReceiveNote = $this->paginate($this->GoodsReceiveNote);

        $this->set(compact('goodsReceiveNote'));
        $this->set('_serialize', ['goodsReceiveNote']);
    }

    /**
     * View method
     *
     * @param string|null $id Goods Receive Note id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $goodsReceiveNote = $this->GoodsReceiveNote->get($id, [
            'contain' => ['WarehouseMasters', 'Pos', 'SupplierInvoices', 'Uoms', 'TransporterCompanies']
        ]);

        $this->set('goodsReceiveNote', $goodsReceiveNote);
        $this->set('_serialize', ['goodsReceiveNote']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $goodsReceiveNote = $this->GoodsReceiveNote->newEntity();
        if ($this->request->is('post')) {
            $goodsReceiveNote = $this->GoodsReceiveNote->patchEntity($goodsReceiveNote, $this->request->data);
            if ($this->GoodsReceiveNote->save($goodsReceiveNote)) {
                $this->Flash->success(__('The {0} has been saved.', 'Goods Receive Note'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Goods Receive Note'));
            }
        }
        $warehouseMasters = $this->GoodsReceiveNote->WarehouseMasters->find('list', ['limit' => 200]);
        $pos = $this->GoodsReceiveNote->Pos->find('list', ['limit' => 200]);
        $supplierInvoices = $this->GoodsReceiveNote->SupplierInvoices->find('list', ['limit' => 200]);
        $uoms = $this->GoodsReceiveNote->Uoms->find('list', ['limit' => 200]);
        $transporterCompanies = $this->GoodsReceiveNote->TransporterCompanies->find('list', ['limit' => 200]);
        $this->set(compact('goodsReceiveNote', 'warehouseMasters', 'pos', 'supplierInvoices', 'uoms', 'transporterCompanies'));
        $this->set('_serialize', ['goodsReceiveNote']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Goods Receive Note id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $goodsReceiveNote = $this->GoodsReceiveNote->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $goodsReceiveNote = $this->GoodsReceiveNote->patchEntity($goodsReceiveNote, $this->request->data);
            if ($this->GoodsReceiveNote->save($goodsReceiveNote)) {
                $this->Flash->success(__('The {0} has been saved.', 'Goods Receive Note'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Goods Receive Note'));
            }
        }
        $warehouseMasters = $this->GoodsReceiveNote->WarehouseMasters->find('list', ['limit' => 200]);
        $pos = $this->GoodsReceiveNote->Pos->find('list', ['limit' => 200]);
        $supplierInvoices = $this->GoodsReceiveNote->SupplierInvoices->find('list', ['limit' => 200]);
        $uoms = $this->GoodsReceiveNote->Uoms->find('list', ['limit' => 200]);
        $transporterCompanies = $this->GoodsReceiveNote->TransporterCompanies->find('list', ['limit' => 200]);
        $this->set(compact('goodsReceiveNote', 'warehouseMasters', 'pos', 'supplierInvoices', 'uoms', 'transporterCompanies'));
        $this->set('_serialize', ['goodsReceiveNote']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Goods Receive Note id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $goodsReceiveNote = $this->GoodsReceiveNote->get($id);
        if ($this->GoodsReceiveNote->delete($goodsReceiveNote)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Goods Receive Note'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Goods Receive Note'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
