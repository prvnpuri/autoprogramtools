<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ConsumableStoreMaster Controller
 *
 * @property \App\Model\Table\ConsumableStoreMasterTable $ConsumableStoreMaster
 *
 * @method \App\Model\Entity\ConsumableStoreMaster[] paginate($object = null, array $settings = [])
 */
class ConsumableStoreMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $query=$this->request->getQuery("search");
        $conditions=array();
        if($query!=null && trim($query," ")!=""){
        	$conditions[]="ConsumableStoreMaster.name like '%$query%'";
        }
        $this->paginate = [
        		'contain' => ['OwnerCompanies','City','State','Countries'],
        		"conditions" => $conditions,
        		"sortWhitelist"=>["name","store_location","address","postal_code","OwnerCompanies.Company_name","Countries.country_name","State.state_name","City.city_name"]
        ];
        $consumablesStoreMaster = $this->paginate($this->ConsumableStoreMaster);
        $this->set("paging",$this->request->getParam("paging"));
		$this->set(compact('consumablesStoreMaster'));
        $this->set( '_serialize', ['consumablesStoreMaster','paging']);
        
        
    }

    /**
     * View method
     *
     * @param string|null $id Consumable Store Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $consumableStoreMaster = $this->ConsumableStoreMaster->get($id, [
            'contain' => ['OwnerCompanies','City','State','Countries']
        ]);

        $this->set('consumableStoreMaster', $consumableStoreMaster);
        $this->set('_serialize', ['consumableStoreMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $consumableStoreMaster = $this->ConsumableStoreMaster->newEntity();
        if ($this->request->is('post')) {
            $consumableStoreMaster = $this->ConsumableStoreMaster->patchEntity($consumableStoreMaster, $this->request->data);
            $consumableStoreMaster['created_by'] = $this->Auth->User('id');
            if ($this->ConsumableStoreMaster->save($consumableStoreMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Consumable Store Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Consumable Store Master'));
            }
        }
        $ownerCompanies = $this->ConsumableStoreMaster->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
        $city = $this->ConsumableStoreMaster->City->find('list',['keyField' => 'id','valueField' => 'city_name','order'=>'city_name']);
        $state = $this->ConsumableStoreMaster->State->find('list',['keyField' => 'id','valueField' => 'state_name','order'=>'state_name']);
        $countries = $this->ConsumableStoreMaster->Countries->find('list',['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        
        
        //$city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name']);
       // $state = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name']);
       // $countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        $this->set(compact('consumableStoreMaster', 'ownerCompanies','city','state','countries'));
        $this->set('_serialize', ['consumableStoreMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Consumable Store Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $consumableStoreMaster = $this->ConsumableStoreMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $consumableStoreMaster = $this->ConsumableStoreMaster->patchEntity($consumableStoreMaster, $this->request->data);
            if ($this->ConsumableStoreMaster->save($consumableStoreMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Consumable Store Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Consumable Store Master'));
            }
        }
        //debug($consumableStoreMaster['state_id']);exit();
        $this->loadModel('Countries');
        $this->loadModel('City');
        $this->loadModel('State');
        $ownerCompanies = $this->ConsumableStoreMaster->OwnerCompanies->find('list', ['limit' => 200]);
        $countries = $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
        $state = $this->State->find('list', ['keyField' => 'id','valueField' => 'state_name','order'=>'state_name','conditions'=>['State.country_id'=>$consumableStoreMaster['countries_id']]]);
       // $state = $state->toArray();
        
        $city = $this->City->find('list', ['keyField' => 'id','valueField' => 'city_name','order'=>'city_name' ,'conditions'=>['City.state_id'=>$consumableStoreMaster['state_id']]]);
        
        $this->set(compact('consumableStoreMaster', 'ownerCompanies','countries','state','city'));
        $this->set('_serialize', ['consumableStoreMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Consumable Store Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $consumableStoreMaster = $this->ConsumableStoreMaster->get($id);
        if ($this->ConsumableStoreMaster->delete($consumableStoreMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Consumable Store Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Consumable Store Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
