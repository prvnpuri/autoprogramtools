<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanyIndustryTypes Controller
 *
 * @property \App\Model\Table\CompanyIndustryTypesTable $CompanyIndustryTypes
 *
 * @method \App\Model\Entity\CompanyIndustryType[] paginate($object = null, array $settings = [])
 */
class CompanyIndustryTypesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['CompanyMaster', 'IndustryTypeMaster']
        ];
        $companyIndustryTypes = $this->paginate($this->CompanyIndustryTypes);

        $this->set(compact('companyIndustryTypes'));
        $this->set('_serialize', ['companyIndustryTypes']);
    }

    /**
     * View method
     *
     * @param string|null $id Company Industry Type id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companyIndustryType = $this->CompanyIndustryTypes->get($id, [
            'contain' => ['CompanyMaster', 'IndustryTypeMaster']
        ]);

        $this->set('companyIndustryType', $companyIndustryType);
        $this->set('_serialize', ['companyIndustryType']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companyIndustryType = $this->CompanyIndustryTypes->newEntity();
        if ($this->request->is('post')) {
            $companyIndustryType = $this->CompanyIndustryTypes->patchEntity($companyIndustryType, $this->request->data);
            if ($this->CompanyIndustryTypes->save($companyIndustryType)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Industry Type'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Industry Type'));
            }
        }
        $companyMaster = $this->CompanyIndustryTypes->CompanyMaster->find('list', ['limit' => 200]);
        $industryTypeMaster = $this->CompanyIndustryTypes->IndustryTypeMaster->find('list', ['limit' => 200]);
        $this->set(compact('companyIndustryType', 'companyMaster', 'industryTypeMaster'));
        $this->set('_serialize', ['companyIndustryType']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Industry Type id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companyIndustryType = $this->CompanyIndustryTypes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companyIndustryType = $this->CompanyIndustryTypes->patchEntity($companyIndustryType, $this->request->data);
            if ($this->CompanyIndustryTypes->save($companyIndustryType)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Industry Type'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Industry Type'));
            }
        }
        $companyMaster = $this->CompanyIndustryTypes->CompanyMaster->find('list', ['limit' => 200]);
        $industryTypeMaster = $this->CompanyIndustryTypes->IndustryTypeMaster->find('list', ['limit' => 200]);
        $this->set(compact('companyIndustryType', 'companyMaster', 'industryTypeMaster'));
        $this->set('_serialize', ['companyIndustryType']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Industry Type id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyIndustryType = $this->CompanyIndustryTypes->get($id);
        if ($this->CompanyIndustryTypes->delete($companyIndustryType)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Industry Type'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Industry Type'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
