<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TestPhotos Controller
 *
 * @property \App\Model\Table\TestPhotosTable $TestPhotos
 *
 * @method \App\Model\Entity\TestPhoto[] paginate($object = null, array $settings = [])
 */
class TestPhotosController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['TestingMasters']
        ];
        $testPhotos = $this->paginate($this->TestPhotos);

        $this->set(compact('testPhotos'));
        $this->set('_serialize', ['testPhotos']);
    }

    /**
     * View method
     *
     * @param string|null $id Test Photo id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $testPhoto = $this->TestPhotos->get($id, [
            'contain' => ['TestingMasters']
        ]);

        $this->set('testPhoto', $testPhoto);
        $this->set('_serialize', ['testPhoto']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $testPhoto = $this->TestPhotos->newEntity();
        if ($this->request->is('post')) {
            $testPhoto = $this->TestPhotos->patchEntity($testPhoto, $this->request->data);
            if ($this->TestPhotos->save($testPhoto)) {
                $this->Flash->success(__('The {0} has been saved.', 'Test Photo'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Photo'));
            }
        }
        $testingMasters = $this->TestPhotos->TestingMasters->find('list', ['limit' => 200]);
        $this->set(compact('testPhoto', 'testingMasters'));
        $this->set('_serialize', ['testPhoto']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Test Photo id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $testPhoto = $this->TestPhotos->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $testPhoto = $this->TestPhotos->patchEntity($testPhoto, $this->request->data);
            if ($this->TestPhotos->save($testPhoto)) {
                $this->Flash->success(__('The {0} has been saved.', 'Test Photo'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Test Photo'));
            }
        }
        $testingMasters = $this->TestPhotos->TestingMasters->find('list', ['limit' => 200]);
        $this->set(compact('testPhoto', 'testingMasters'));
        $this->set('_serialize', ['testPhoto']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Test Photo id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $testPhoto = $this->TestPhotos->get($id);
        if ($this->TestPhotos->delete($testPhoto)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Test Photo'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Test Photo'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
