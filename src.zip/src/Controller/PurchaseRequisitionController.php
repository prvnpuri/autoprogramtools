<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Network\Session\DatabaseSession;
use Cake\Cache\Cache;
use Cake\ORM\toArray;
use Cake\Mailer\Email;
use PhpParser\Node\Stmt\Foreach_;


/**
 * PurchaseRequisition Controller
 *
 * @property \App\Model\Table\PurchaseRequisitionTable $PurchaseRequisition
 *
 * @method \App\Model\Entity\PurchaseRequisition[] paginate($object = null, array $settings = [])
 */



class PurchaseRequisitionController extends AppController
{

	
	public function initialize()
	{
		parent::initialize();
		$this->loadComponent('RequestHandler');
		$this->loadComponent('Paginator');
		Configure::write('Session', ['defaults' => 'php']);
		
		
	}
	
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index(){

    	//echo "This is the index functionality";
    }
    
    public function sendtoapprove($id){
    	
    	$this->loadModel('PurchaseRequisition');
    	$purchaseRequisition = $this->PurchaseRequisition->get($id, [
    			//'contain' => ['Approveds']
    	]);
    	
    	$data = array('id' => $id , 'send_to_approve' => "Y");
    	
    	if($this->PurchaseRequisition->patchEntity($purchaseRequisition,$data)){
    		
    		$this->PurchaseRequisition->save($purchaseRequisition);
    		$this->Flash->success(__('MR  has been sent to Approval.', 'Purchase Requisition Request'));    		
    		return $this->redirect(['action' => 'summary']);    		
    	}else{
    		$this->Flash->success(__('Invoice has not 	been sent to Payment.', 'Invoice'));    		
    	}
    }
    
    public function summary(){
    	
    	$this->paginate = [
    			'contain' => ['PurchaseRequisitionProducts'],
				'order'=>['PurchaseRequisitionProducts.id' => 'DESC']
    	];
		
    	$purchaseRequisition = $this->paginate($this->PurchaseRequisition);
    	
    	$this->set(compact('purchaseRequisition'));
    	$this->set('_serialize', ['purchaseRequisition']);
    }

    /**
     * View method
     *
     * @param string|null $id Purchase Requisition id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null){
    
        $purchaseRequisition = $this->PurchaseRequisition->get($id, [	
			'contain' => ['PurchaseRequisitionProducts','PurchaseRequisitionProducts.ConsumablesMaster','PurchaseRequisitionProducts.Uom']
        ]);

        $this->set('purchaseRequisition', $purchaseRequisition);
        $this->set('_serialize', ['purchaseRequisition']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add(){
        	    	
        $purchaseRequisition = $this->PurchaseRequisition->newEntity();
        if ($this->request->is('post')) {
			
			// echo "RequestedData<pre>";
			// print_r($this->request->data);
			
			// die();
			
        	       	
        	$ownerCompaniesId = $this->request->session()->read('Auth.User.owner_company_id');
        	
        	$this->request->data['owner_company_id'] = $ownerCompaniesId; 
        	
        	$userId = $this->request->session()->read('Auth.User.id');
        	$this->request->data['created_by'] = $userId;
        	
        	$next_ref = $this->ReferenceNumber->get_next_ref_number($this->request->session()->read('Auth.User.owner_company_id'),'requisition');        	
        	$this->request->data['pr_reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
        	
        	//	echo '<pre>',print_r($this->request->data);
        	//	die;
        	
        	if(!isset($next_ref['full_next_ref_no'])){
        		$this->Flash->error(__('The {0} could not be saved.Reference number not generated. Please contact administrator.', 'Supplier Inquiry'));
        		//return $this->redirect(['action' => 'index']);
        	}
        	else{	        		
        		$purchaseRequisition = $this->PurchaseRequisition->patchEntity($purchaseRequisition, $this->request->data);
        		$purchaseRequisition['pr_reference_no']=$this->request->data['pr_reference_number'];
				$purchaseRequisition['owner_company_id']=$ownerCompaniesId;
        		
        		// debug($this->request->data);
        		// debug($purchaseRequisition);
        		// die();	
        		
        		foreach($this->request->data['purchase_requisition_products'] as $key=>$data){
        			// $purchaseRequisition['purchase_requisition_products'][$key]['purchase_requisition_id']=$data['purchase_requisition_id'];
        			// $purchaseRequisition['purchase_requisition_products'][$key]['product_id']=$data['purchase_requisition_id'];
        			$purchaseRequisition['purchase_requisition_products'][$key]['product_name']=$data['prodsearch'];
        		}
        		
        		if ($this->PurchaseRequisition->save($purchaseRequisition)) {        			
        			$this->Flash->success(__('The {0} has been saved.', 'Purchase Requisition'));
	                return $this->redirect(['action' => 'summary']);
	            } else {
	                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Requisition'));
	            }
        	}
        }
        
        //$approveds = $this->PurchaseRequisition->Approveds->find('list', ['limit' => 200]);
        $this->set(compact('purchaseRequisition', 'approveds'));

        $this->loadModel('SupplierInquiry');
        $ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name','conditions'=>array('id'=>$this->request->session()->read('Auth.User.owner_company_id'))], ['limit' => 200]);
        $uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
        $packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);

        $currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
        $this->set(compact('supplierInquiry','ownerCompanies', 'uom', 'currency','packingMaster'));

        $this->set('_serialize', ['purchaseRequisition']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Purchase Requisition id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null){
    
      	$purchaseRequisition = $this->PurchaseRequisition->get($id, [
        		'contain' => ['PurchaseRequisitionProducts','PurchaseRequisitionProducts.ConsumablesMaster']
        ]);

        $date_info = (array)($purchaseRequisition['pr_date']);

        $purchaseRequisition['pr_date'] = $date_info['date'];

        if ($this->request->is(['patch', 'post', 'put'])) {
        	
        	// debug($this->request->data);//exit;
            // debug($this->request->data['data']['DelMaterialAsso']);
            
        	$ownerCompaniesId = $this->request->session()->read('Auth.User.owner_company_id');        	
        	$this->request->data['owner_company_id'] = $ownerCompaniesId;

        	$purchaseRequisition = $this->PurchaseRequisition->patchEntity($purchaseRequisition, $this->request->data);

        	if(!empty($this->request->data['data']['DelMaterialAsso'])){
        		$delInfo = array_replace($this->request->data['data']['DelMaterialAsso']);
        		$this->loadModel('PurchaseRequisitionProducts');
        		$this->PurchaseRequisitionProducts->deleteAll(['PurchaseRequisitionProducts.id IN' => $delInfo]);
        	}

        	foreach($this->request->data['purchase_requisition_products'] as $key=>$data){
            	$purchaseRequisition['purchase_requisition_products'][$key]['purchase_requisition_id']=$this->request->data['purchase_requisition_id'];
            }
            
            if ($this->PurchaseRequisition->save($purchaseRequisition)) {
                $this->Flash->success(__('The {0} has been saved.', 'Purchase Requisition'));
                return $this->redirect(['action' => 'summary']);
            } else {
            	$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Requisition'));
            }
        }

        //$approveds = $this->PurchaseRequisition->Approveds->find('list', ['limit' => 200]);
        $this->set(compact('purchaseRequisition', 'approveds'));
        
        $this->loadModel('SupplierInquiry');
        $ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name','conditions'=>array('id'=>$this->request->session()->read('Auth.User.owner_company_id'))], ['limit' => 200]);
        $uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
        $packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
        
        $currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
        $this->set(compact('supplierInquiry','ownerCompanies', 'uom', 'currency','packingMaster'));
        
        $this->set('_serialize', ['purchaseRequisition']);        
    }

    /**
     * Delete method
     *
     * @param string|null $id Purchase Requisition id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null){
    
        $this->request->allowMethod(['post', 'delete']);
        $purchaseRequisition = $this->PurchaseRequisition->get($id);
        if ($this->PurchaseRequisition->delete($purchaseRequisition)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Purchase Requisition'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Purchase Requisition'));
        }
        return $this->redirect(['action' => 'summary']);
    }    
    
        
    public function indexConsumableProduct()
    {       	    	
    	$this->request->session()->delete('supplierId');
    	
    	$this->loadModel('Company_master');
    	$companies= $this->Company_master->find('list', [
    			'keyField' => 'id',
    			'valueField' => 'Company_name'
    	]);
    	
    	$this->set(compact('companies'));
    	
    	$this->loadModel('PurchaseRequisitionProducts');
    	$pr_product = $this->PurchaseRequisitionProducts->find('all',
			[
    					'contain'=>['PurchaseRequisition','ConsumablesMaster','Uom'],
    					'order'=>['PurchaseRequisitionProducts.id' => 'DESC'],
						'conditions'=>['PurchaseRequisition.is_approve'=>'Y']
    		]);
    	
    	$pr_product = $this->paginate($pr_product);
    	$pr_product=$pr_product->toArray();
    	
    	$this->set(compact('pr_product'));
    	$this->set('_serialize', ['pr_product']);
    }
    
    public function indexAsset() {
		
		$this->paginate = [
            'contain' => ['PurchaseRequisitionProducts']
        ];
        $purchaseRequisition = $this->paginate($this->PurchaseRequisition);

        $this->set(compact('purchaseRequisition'));
        $this->set('_serialize', ['purchaseRequisition']);
		
		
		
		
    	/*
		$this->loadModel('SupplierInquiry');
    	$supplierinquires = $this->SupplierInquiry->find()
    	->where(['inquiry_type'=>'Consumable'])
    	->contain(['OwnerCompanies', 'Uom', 'Currency', 'AssetsMaster'])
    	->order(['SupplierInquiry.id' => 'DESC']);
    	$supplierInquiry = $this->paginate($supplierinquires);
    	$company_ids=array();
    	$arrsupplierInquiry=$supplierInquiry->toArray();
    	//echo '<pre>',print_r($arrsupplierInquiry);
    	foreach ($arrsupplierInquiry as $keys => $inq){
    		$coms=$inq['company_ids'];
    		//echo '@@'.$coms=explode(",",$inq->company_ids);
    		$pos = strpos(",", $coms);
    		if($pos){
    			foreach($coms as $comid){
    				$company_ids[]=$comid;
    			}
    		}else{
    			$company_ids[]=$coms;
    		}
    	}
    	
    	//	echo print_r($company_ids);
    	
    	$companyMaster =  $this->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $company_ids]);
    	$this->set('companyMaster', $companyMaster);
    	
    	$this->set(compact('supplierInquiry'));
    	$this->set('_serialize', ['supplierInquiry']);
    	
		*/
		
    }
    
    
    
    public function addasset()
    {
        $purchaseRequisition = $this->PurchaseRequisition->newEntity();
        
        if ($this->request->is('post')) {
            $purchaseRequisition = $this->PurchaseRequisition->patchEntity($purchaseRequisition, $this->request->data);
            if ($this->PurchaseRequisition->save($purchaseRequisition)) {
                $this->Flash->success(__('The {0} has been saved.', 'Purchase Requisition'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Requisition'));
            }
        }
        //$approveds = $this->PurchaseRequisition->Approveds->find('list', ['limit' => 200]);
        $this->set(compact('purchaseRequisition', 'approveds'));
        $this->set('_serialize', ['purchaseRequisition']);
    	
    }
    
    
    public function editasset($id = null)
    {
        $purchaseRequisition = $this->PurchaseRequisition->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $purchaseRequisition = $this->PurchaseRequisition->patchEntity($purchaseRequisition, $this->request->data);
            if ($this->PurchaseRequisition->save($purchaseRequisition)) {
                $this->Flash->success(__('The {0} has been saved.', 'Purchase Requisition'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Requisition'));
            }
        }
        $approveds = $this->PurchaseRequisition->Approveds->find('list', ['limit' => 200]);
        $this->set(compact('purchaseRequisition', 'approveds'));
        $this->set('_serialize', ['purchaseRequisition']);

    }
    
    
    public function requestApproval($id,$approvalId,$owner){
    	
    	$data = ['id' => $id , 'is_approved' => $approvalId];
    	$boldNumberRequest = $this->BoldNumberRequest->get($id, [
    			'contain' => []
    	]);
    	$boldNumberRequest = $this->BoldNumberRequest->patchEntity($boldNumberRequest, $data);
    	
    	$this->BoldNumberRequest->save($boldNumberRequest);
    	if($approvalId==1){
    		$this->sendEmail($boldNumberRequest,3);
    	}
    	
    	return $this->redirect(['action' => 'index',$owner]);
    }
    
        
    public function enquiry(){
    
    	$this->loadModel('Company_master');
    	$companiesInfo = $this->Company_master->find('all',[
    			'conditions'=>['id'=>$_REQUEST['supplier']],
    	]);
    	
    	//$companyInfoData=$companiesInfo->toArray();
    	$compData = $companiesInfo->first();
    	
    	$_REQUEST['supplier_name'] = $compData['Company_name'];
    	    	
    	if($_REQUEST['supplier'] == ''){
    		
    		echo "no_supplier";
    		die();
    	}
    	else{
    		
    		//$this->request->session()->delete('supplierId');
    		if($_REQUEST['check'] == 1){
    			
    			if($this->request->session()->check('supplierId')){
    				$data2 = $this->request->session()->read("supplierId");
    				$supplierId[$_REQUEST['id']] = $_REQUEST;
    				$result = $supplierId + $data2;
    				
    				$this->request->session()->write('supplierId', $result);
    			}
    			else{
    				$supplierId[$_REQUEST['id']] = $_REQUEST;
    				
    				$this->request->session()->write('supplierId', $supplierId);
    			}
    		}
    		else{
    			
    			$datadelete = $this->request->session()->read("supplierId");
    			
    			$infodelete1= array();
    			foreach($datadelete as $keydelete=>$infodelete){
    				
    				if($keydelete != $_REQUEST['id']){
    					$infodelete1[$keydelete] = $infodelete;
    				}
    			}
    			
    			$this->request->session()->write('supplierId', $infodelete1);
    		}    		
    	}
    	
    	$data1 = $this->request->session()->read("supplierId");    	
    	
    	$grouped_types = array();


    	foreach($data1 as $prod1){
    		$data[$prod1['supplier_name']][$prod1['product_id']][$prod1['uom']][] = $prod1;
    		//$data[$prod1['supplier']]['supplier_name'] = $prod1['supplier_name'];
    	}
		
		/* echo "Data<pre>";
		print_r($data);
		
		die(); */
		
    	$this->set(compact('data'));
    }

    
	public function sendInquiry(){
    	    	
		if($this->request->session()->check('supplierId')){
	    	$data1 = $this->request->session()->read("supplierId");
	    	
	    	$grouped_types = array();
	    	
	    	foreach($data1 as $prod1){
	    		$data[$prod1['supplier']][$prod1['uom']][] = $prod1;
	    	}
	    	
	    	foreach($data as $key=>$supplierinquiery){
	    		
	    		if($supplierinquiery>0){
	    			
	    			$keyone = key($supplierinquiery);
	    			
	    			$this->request->data['owner_companies_id'] = $this->request->session()->read('Auth.User.owner_company_id');
	    			$this->request->data['company_ids'] = $key;
	    			//$this->request->data['products_master_id'] = $sup['product_id'];	
	    			//$this->request->data['qty_required'] = $quantity;
	
	    			$this->loadModel('SupplierInquiry');
	    			$supplierInquiry= $this->SupplierInquiry->newEntity();
	    			$supplierInquiry= $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->data);
	    			
	    			if ($saverecords = $this->SupplierInquiry->save($supplierInquiry)) {
	
	    				$lastsupid = $saverecords->id;
	    				
	    				foreach($supplierinquiery as $key_sup_data=>$sup_data){
	    					
	    					if(count($sup_data)>0){
	    						
	    						foreach($sup_data as $sup_info){
	    							
	    							$supplierinquieryData['supplier_inquiry_id'] = $lastsupid;
	    							$supplierinquieryData['product_id'] = $sup_info['product_id'];
	    							$supplierinquieryData['qty_required'] = $sup_info['quantity'];
	    							$supplierinquieryData['uom_id'] = $sup_info['uom'];
	    							
	    							$this->loadModel('SupplierInquiryProducts');
	    							$supplierInquiryProducts= $this->SupplierInquiryProducts->newEntity();
	    							$supplierInquiryprod= $this->SupplierInquiry->patchEntity($supplierInquiryProducts, $supplierinquieryData);
	    							
	    							$saverecords = $this->SupplierInquiryProducts->save($supplierInquiryprod);
	    							
	    							//purchase_requision_inquiry
	    							$purchaseSupInquieryData['supplier_inquiry_id'] = $lastsupid;
	    							$purchaseSupInquieryData['purchase_requisition_products_id'] = $sup_info['product_id'];
	    							
	    							$this->loadModel('PurchaseRequisionInquiry');
	    							$purchaseInquieryData= $this->PurchaseRequisionInquiry->newEntity();
	    							
	    							$purchaseSupInquieryData['purchase_requisition_id'] = $sup_info['purchase_requisition_id'];
	    								
	    							$purchaseInquieryData1= $this->PurchaseRequisionInquiry->patchEntity($purchaseInquieryData, $purchaseSupInquieryData);
	    								
	    							$saverecords1 = $this->PurchaseRequisionInquiry->save($purchaseInquieryData1);    							
	    						}
	    					
	    					}
	    				
	    				}
	
	    			}
	    			else{
		    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Inquiry'));
		    		}			
	    		}
	    	}
	    	
	    	if(isset($data1)){
	    		
	    		foreach($data1 as $purchaseprod){
	    			
	    			$purchase['id'] = $purchaseprod['id'];
	    			$purchase['status'] = 0;
	    			$purchase['qty'] = $purchaseprod['quantity'];
	    			
	    			$this->loadModel('PurchaseRequisitionProducts');
	    			$purchaseRequisitionProd= $this->PurchaseRequisitionProducts->get($purchaseprod['id']);
	    			$purchaseRequisitionProd= $this->PurchaseRequisitionProducts->patchEntity($purchaseRequisitionProd, $purchase);
	    			
	    			$saverecords = $this->PurchaseRequisitionProducts->save($purchaseRequisitionProd);
	    		}
	    		
	    		$this->Flash->success(__('The {0} has been saved.', 'Send Inquiry'));
	    		return $this->redirect(['action' => 'index_consumable_product']);
	    	}
    	}
    }
    
    
    public function pendingapprovalprrequest(){
    
    	$this->loadModel('PurchaseRequisition');
    	$prrequest = $this->PurchaseRequisition->find('all',[
    			'conditions'=>['send_to_approve'=>'Y'],
    	]);
    	
    	$prRequest = $this->paginate($prrequest);
    	
    	$this->set(compact('prRequest'));
    	$this->set('_serialize', ['prRequest']);
    }
    
    public function approvemr($id){
    
    	$prRequest = $this->PurchaseRequisition->get($id, [
    			'contain' => []
    	]);
		
		$prRequest['approved_id'] = $this->request->session()->read('Auth.User.id');
		
    	$data = array('id' => $id , 'is_approve' => "Y");
    	if($this->PurchaseRequisition->patchEntity($prRequest,$data)){
    		$this->PurchaseRequisition->save($prRequest);
    		return $this->redirect(['action' => 'pendingapprovalprrequest']);
    	}
    }
    
    public function rejectmr($id){
    
    	$prRequest = $this->PurchaseRequisition->get($id, [
    			'contain' => []
    	]);
    	
    	$data = array('id' => $id , 'send_to_approve' => "N");
    	if($this->PurchaseRequisition->patchEntity($prRequest,$data)){
    		$this->PurchaseRequisition->save($prRequest);
    		return $this->redirect(['action' => 'pendingapprovalprrequest']);
    	}
    }
    
    public function pendingprrequest(){
    	
    	$this->loadModel('PurchaseRequisition');
    	$prrequest = $this->PurchaseRequisition->find('all',[
    			'conditions'=>['is_approve'=>'Y'],
    	]);
    	
    	$prRequest = $this->paginate($prrequest);
    	
    	$this->set(compact('prRequest'));
    	$this->set('_serialize', ['prRequest']);
    }
		
	public function editstockupdate($id = null)
    {
    	$purchaseRequisition = $this->PurchaseRequisition->get($id, [
    			'contain' => ['PurchaseRequisitionProducts','PurchaseRequisitionProducts.ConsumablesMaster']
    	]);
    	
    	$date_info = (array)($purchaseRequisition['pr_date']);
    	
    	$purchaseRequisition['pr_date'] = $date_info['date'];
    	
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		
    		// debug($this->request->data);//exit;
    		// debug($this->request->data['data']['DelMaterialAsso']);

    		$this->request->data['owner_companies_id'] = $this->request->session()->read('Auth.User.owner_company_id');
    		
    		$purchaseRequisition = $this->PurchaseRequisition->patchEntity($purchaseRequisition, $this->request->data);
    		
    		if(!empty($this->request->data['data']['DelMaterialAsso'])){
    			$delInfo = array_replace($this->request->data['data']['DelMaterialAsso']);
    			$this->loadModel('PurchaseRequisitionProducts');
    			$this->PurchaseRequisitionProducts->deleteAll(['PurchaseRequisitionProducts.id IN' => $delInfo]);
    		}
    		
    		foreach($this->request->data['purchase_requisition_products'] as $key=>$data){
    			$purchaseRequisition['purchase_requisition_products'][$key]['purchase_requisition_id']=$this->request->data['purchase_requisition_id'];
    		}
    		
    		if ($this->PurchaseRequisition->save($purchaseRequisition)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Purchase Requisition'));
    			return $this->redirect(['action' => 'summary']);
    		} else {    			
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Purchase Requisition'));
    		}
    	}
    	
    	//$approveds = $this->PurchaseRequisition->Approveds->find('list', ['limit' => 200]);
    	$this->set(compact('purchaseRequisition', 'approveds'));
    	
    	$this->loadModel('SupplierInquiry');
    	$ownerCompanies = $this->SupplierInquiry->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name','conditions'=>array('id'=>$this->request->session()->read('Auth.User.owner_company_id'))], ['limit' => 200]);
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    	
    	$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    	$this->set(compact('supplierInquiry','ownerCompanies', 'uom', 'currency','packingMaster'));
    	
    	$this->set('_serialize', ['purchaseRequisition']);    	
    }
    
    public function mrview($id = null){
    	
    	$purchaseRequisition = $this->PurchaseRequisition->get($id, [
    			//'contain' => ['Approveds']
    	]);
    	
    	$this->set('purchaseRequisition', $purchaseRequisition);
    	$this->set('_serialize', ['purchaseRequisition']);
    }
    
    public function storemrview($id = null){
    	
    	$purchaseRequisition = $this->PurchaseRequisition->get($id, [
    			//'contain' => ['Approveds']
    	]);
    	
    	$this->set('purchaseRequisition', $purchaseRequisition);
    	$this->set('_serialize', ['purchaseRequisition']);
    }
    
	public function sendmailConsumable($module=null, $supplierInquiryid = null, $compId=null, $isView=null, $datakey=null){
    			
		$datakey_replace = str_replace(" ","_",$datakey);		
		$datakey_undo = str_replace("_"," ",$datakey_replace);
		
    	if($isView==="1"){
			
			$this->loadModel('SupplierInquiry');
			$this->loadModel('PurchaseRequisition');
			
			$data1 = $this->request->session()->read("supplierId");

			$grouped_types = array();

			foreach($data1 as $prod1){
				$finaldata[$prod1['supplier_name']][$prod1['product_id']][$prod1['uom']][] = $prod1;
			}
			
			foreach($finaldata as $eachkey=>$each){
				if($eachkey == $datakey){
					$data[$eachkey] = $each;
				}
			}
			
			$this->set(compact('data'));
			
			$purchaseRequisitionData = $this->PurchaseRequisition->get($supplierInquiryid, [
        		'contain' => ['PurchaseRequisitionProducts','PurchaseRequisitionProducts.ConsumablesMaster']
			]);
			
			$ownerCompanyId = $this->request->session()->read('Auth.User.owner_company_id');
			
			$this->loadModel('OwnerCompanies');
			$OwnerCompany = $this->OwnerCompanies->get($ownerCompanyId);
			$supplierinquires['owner_company'] = $OwnerCompany;
			
			$html="supplierenquiryconsumable_pr";
			$SupplierInquiry = $purchaseRequisitionData;
    		//$Uom = $supplierinquires['uom'];
    		//$PackingMaster = $supplierinquires['packing_master'];
    		//$PackingType = $PackingMaster['packing_type'];
    		//$PackingSubtype = $PackingMaster['packing_subtype'];
    		//$OwnerCompany=$supplierinquires['owner_company'];			
			
    		/* 
			$supplierinquires = $this->SupplierInquiry->get($supplierInquiryid, [
    				'contain' => ['SupplierInquiryProducts','SupplierInquiryProducts.ConsumablesMaster','SupplierInquiryProducts.Uom','SupplierInquiryProducts.PackingMaster','SupplierInquiryProducts.PackingMaster.PackingType','OwnerCompanies','OwnerCompanies.OwnerContactPersons','OwnerCompanies.OwnerContactPersons.Users', 'ProductsMaster']
    		]);
    		
			$html="supplierenquiryconsumable_pr";
    		$SupplierInquiry = $supplierinquires;
    		$Uom = $supplierinquires['uom'];
    		$PackingMaster = $supplierinquires['packing_master'];
    		$PackingType = $PackingMaster['packing_type'];
    		$PackingSubtype = $PackingMaster['packing_subtype'];
    		$OwnerCompany=$supplierinquires['owner_company']; 
			*/
    		
    		// debug($OwnerCompany);die();
    		$this->loadModel('CompanyMaster');
    		$this->loadModel('CompanyContactPersons');
    		$companyOne =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $compId])->contain(['CompanyContactPersons']);
    		$CompanyMaster = $companyOne->first();

    		$suppliercontact = "";
    		$supplieremail = array();
    		$vpercount=0;
    		foreach ($CompanyMaster["company_contact_persons"] as $contact["CompanyContactPerson"]){
    			$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
      			ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
      			ucfirst($contact["CompanyContactPerson"]["last_name"]);
      			if(trim($personname," ")!=""){
      				$suppliercontact.=$vpercount>0?",":"";
      				$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
      				$vpercount++;
      			}
      			
      			$contactemail=$contact["CompanyContactPerson"]["email_id"];
      			
      			if(trim($contactemail," ")!=""){
      				array_push($supplieremail, $contactemail);
      			}else{
      				//$this->Flash->error(__("Please check email_id for contact_name is not valid email."));		
      				$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
      				//return $this->redirect(['action' => 'index']);
      			}
    		}
    		
    		//debug($CompanyMaster);exit;
    		$CompanyMaster["contact_persons"]=$suppliercontact;
    		
    		$this->set(compact('CompanyContactPersons','CompanyMaster','OwnerCompany','SupplierInquiry','Uom','supplierinquires','PackingMaster','PackingType','PackingSubtype'));
    		$Subject = 'Supplier Inquiry from '.$OwnerCompany->Company_name;
    		
    		$cc[]=$SupplierInquiry["cc_email"];
    		$to = array();
    		$cc = array();
    		$bcc= array();
			
			if(Configure::read("productionMode")){
    			/*******Production Mode*******************/
    			$to=$contactemail;
    			$cc=array($SupplierInquiry['cc_email']);
    			//$bcc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    		}else{
    			/*******Dev Mode*******************/
    			$to=$contactemail;
    			$cc=array($SupplierInquiry['cc_email']);
    			$bcc=array("dkvastrakar18@gmail.com");
    			/**************************/
    		}
			
    		if($isView==="1"){
    			/*******Email Preview Mode*******************/
    			
    			/*******For local*******************/
    			
    			$this->set("isView",$isView);
    			$this->set("mails",array(
    					"from"=>$supplierinquires['owner_company']['company_email'],						
    					"to" =>$to,
    					"cc" => $cc,
    					"bcc"=> $bcc,
    					"subject"=>$Subject
    			));
    			
    			/**************************/

    			$this->set("title_for_layout","Suppiler Inquiry");
				
				$this->set(	"mailSendAction",array(
						"send"=>array("action"=>"sendmail_consumable",$module, $supplierInquiryid, $compId, 0, $datakey_replace)
    			));

				//"cancel"=>array("action"=>"index-consumable")
    			//$this->layout = 'emailpreview';

    			$this->viewBuilder()->setLayout("/Email/html/emailpreviewpr");
    			$this->render('/Email/html/'.$html);
    			/**************************/
    		}
    	}
    	else{
						
			$this->loadModel('OwnerCompanies');
			$this->loadModel('SupplierInquiry');
			$this->loadModel('PurchaseRequisition');
			
			$ownerCompanyId = $this->request->session()->read('Auth.User.owner_company_id');
			$OwnerCompany = $this->OwnerCompanies->get($ownerCompanyId);
			
			$next_ref = $this->ReferenceNumber->get_next_ref_number($ownerCompanyId,'requisition');        	
        	$reference_number = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';			
			
			$purchaseRequisitionData = $this->PurchaseRequisition->get($supplierInquiryid, [
        		'contain' => ['PurchaseRequisitionProducts','PurchaseRequisitionProducts.ConsumablesMaster']
			])->toArray();
    		
    		$supplierInquiry=$purchaseRequisitionData;
    		
			//$supplierinc['owner_company'] = $OwnerCompany;
			
			$supplierinc[0]['OwnerCompany']=$OwnerCompany;
			$supplierinc[0]['SupplierInquiry']=$supplierInquiry;			
			
			$this->loadModel('CompanyMaster');
    		$this->loadModel('CompanyContactPersons');
    		$companyOne =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $compId])->contain(['CompanyContactPersons']);
    		$CompanyMaster = $companyOne->first();

    		$suppliercontact = "";
    		$supplieremail = array();
    		$vpercount=0;
    		foreach ($CompanyMaster["company_contact_persons"] as $contact["CompanyContactPerson"]){
    			$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
      			ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
      			ucfirst($contact["CompanyContactPerson"]["last_name"]);
      			if(trim($personname," ")!=""){
      				$suppliercontact.=$vpercount>0?",":"";
      				$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
      				$vpercount++;
      			}
      			
      			$contactemail=$contact["CompanyContactPerson"]["email_id"];
      			
      			if(trim($contactemail," ")!=""){
      				array_push($supplieremail, $contactemail);
      			}else{
      				//$this->Flash->error(__("Please check email_id for contact_name is not valid email."));		
      				$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
      				//return $this->redirect(['action' => 'index']);
      			}
    		}
    		
    		//debug($CompanyMaster);exit;
    		$CompanyMaster["contact_persons"]=$suppliercontact;			
    		$supplierinc[0]["CompanyMaster"]=$CompanyMaster;

    		//debug($productTestData);exit;
    		$this->set(compact('ProductDataTest','isView','supplierinquires','comapnyName','productDataTest','productTestData','companyMaster', 'ownerCompanies', 'productsMasters'));
    		//echo "<pre>",print_r($comapnyName);exit;
    		
    		$emailvar=$supplierinc[0];
    		
			$ret=false;
    		$companyname = $supplierinc[0]['OwnerCompany']['Company_name'];
			    		
			if($this->doSendMail_Consumable($emailvar,$isView)){
			
				if($this->request->session()->check('supplierId')){
					$data1 = $this->request->session()->read("supplierId");
					
					$grouped_types = array();
					
					foreach($data1 as $prod1){
						$finaldata[$prod1['supplier_name']][$prod1['supplier']][$prod1['uom']][] = $prod1;
					}

					foreach($finaldata as $eachkey=>$each){
						if($eachkey == $datakey_undo){
							$data[$eachkey] = $each;
						}
					}
					
					foreach($data as $key=>$supplierinquiery){
						
						$supplierkey = key($supplierinquiery);
						
						if($supplierinquiery>0){
							
							$keyone = key($supplierinquiery);
							
							$this->request->data['owner_companies_id'] = $this->request->session()->read('Auth.User.owner_company_id');
							$this->request->data['company_ids'] = $supplierkey;
							$this->request->data['reference_number'] = $reference_number;
							$this->request->data['raised_on'] = date('y-m-d');
							$this->request->data['status'] = 1;
							$this->request->data['created_by'] = $this->request->session()->read('Auth.User.id');
							$this->request->data['inquiry_type'] = $module;
							//$this->request->data['products_master_id'] = $sup['product_id'];	
							//$this->request->data['qty_required'] = $quantity;
			
							$this->loadModel('SupplierInquiry');
							$supplierInquiry= $this->SupplierInquiry->newEntity();
							$supplierInquiry= $this->SupplierInquiry->patchEntity($supplierInquiry, $this->request->data);
							
							// debug($supplierInquiry);
							// die();
							
							if ($saverecords = $this->SupplierInquiry->save($supplierInquiry)) {

								$lastsupid = $saverecords->id;

								foreach($supplierinquiery as $sup_data){
															
									foreach($sup_data as $supl){
										
										foreach($supl as $suplsave){
											
											$supplierinquieryData['supplier_inquiry_id'] = $lastsupid;
											$supplierinquieryData['product_id'] = $suplsave['product_id'];
											$supplierinquieryData['qty_required'] = $suplsave['quantity'];
											$supplierinquieryData['uom'] = $suplsave['uom'];
											$supplierinquieryData['uom_id'] = $suplsave['uom_id'];

											$this->loadModel('SupplierInquiryProducts');
											$supplierInquiryProducts= $this->SupplierInquiryProducts->newEntity();
											$supplierInquiryprod= $this->SupplierInquiry->patchEntity($supplierInquiryProducts, $supplierinquieryData);
											
											$saverecords = $this->SupplierInquiryProducts->save($supplierInquiryprod);
											
											//purchase_requision_inquiry
											$purchaseSupInquieryData['supplier_inquiry_id'] = $lastsupid;
											$purchaseSupInquieryData['purchase_requisition_products_id'] = $suplsave['product_id'];
											
											$this->loadModel('PurchaseRequisionInquiry');
											$purchaseInquieryData= $this->PurchaseRequisionInquiry->newEntity();
											
											$purchaseSupInquieryData['purchase_requisition_id'] = $suplsave['purchase_requisition_id'];
											
											$purchaseInquieryData1= $this->PurchaseRequisionInquiry->patchEntity($purchaseInquieryData, $purchaseSupInquieryData);
											$saverecords1 = $this->PurchaseRequisionInquiry->save($purchaseInquieryData1);
																																	
											$purchase['id'] = $suplsave['id'];
											$purchase['status'] = 0;
											$purchase['qty'] = $suplsave['quantity'];
											$purchase['uom_id'] = $suplsave['uom_id'];
											
											$this->loadModel('PurchaseRequisitionProducts');
											$purchaseRequisitionProd= $this->PurchaseRequisitionProducts->get($suplsave['id']);
											$purchaseRequisitionProd= $this->PurchaseRequisitionProducts->patchEntity($purchaseRequisitionProd, $purchase);
											
											$saverecords = $this->PurchaseRequisitionProducts->save($purchaseRequisitionProd);
										}
									}
								}
								
								$this->Flash->success(__('The {0} has been saved.', 'Send Inquiry'));
								return $this->redirect(['action' => 'index_consumable_product']);
							}
							else{
								$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Inquiry'));
							}			
						}
					}
				}		
    		}
			else {
    			$this->Flash->error(__('The {0} could not be sent successfully. Please, try again.', "Supplier Inquiry for  $companyname"));
    		}
			
    		exit;
    	}
    }
    
	
	private function doSendMail_Consumable($supplierinc,$isView=null){
		
    	try{
						
    		$settings=$supplierinc["OwnerCompany"]["email_setting"];
    		$companyname=$supplierinc["OwnerCompany"]["Company_name"];
    		$fromid=$supplierinc["OwnerCompany"]["company_email"];
    		$Subject = 'Supplier Inquiry from '.$companyname;
			
			if(isset($supplierinc["SupplierInquiry"]["cc_email"])){
				if(trim($supplierinc["SupplierInquiry"]["cc_email"]," ")!=""){
					$cc[]=$supplierinc["SupplierInquiry"]["cc_email"];    			
				}
			}
    					
    		$suppliercompanies=$supplierinc["CompanyMaster"];
    		
    		foreach($suppliercompanies as $company){
    			
    			$supplierinc["CompanyMaster"]=$company;
    			$comapnyName=$company["Company_name"];
    			//debug($comapnyName);exit;
    			$suppliercontact = "";
    			$supplieremail = array();
    			$vpercount=0;
    			// for dynamic contacts//
    			foreach ($company["company_contact_persons"] as $contact["CompanyContactPerson"]){
    				$personname=ucfirst($contact["CompanyContactPerson"]["first_name"])." ".
      				ucfirst($contact["CompanyContactPerson"]["middle_name"])." ".
      				ucfirst($contact["CompanyContactPerson"]["last_name"]);
      				if(trim($personname," ")!=""){
      					$suppliercontact.=$vpercount>0?",":"";
      					$suppliercontact.= (isset($contact["CompanyContactPerson"]["prefix_name"])?$contact["CompanyContactPerson"]["prefix_name"]:"" )." ".$personname;
      					$vpercount++;
      				}
      				
      				$contactemail=$contact["CompanyContactPerson"]["email_id"];
      				
      				if(trim($contactemail," ")!=""){
      					array_push($supplieremail, $contactemail);
      				}else{
      					$this->Flash->error("Please check email_id '$contactemail' for contact_name '$personname' is not valid email.");
      					return false;
      				}
    			}
    			
    			$supplierinc["CompanyMaster"]["contact_persons"]=$suppliercontact;
    			$supplierinc["SupplierInquiry"]["mailto"]=$supplieremail;
    			
    			$supplierinc["isView"]=$isView;
    			
    			//$supplierinc["ProductDataTest"]=$ProductDataTest;
    			//debug($ProductDataTest);exit;
    			
    			$to = array();
    			$cc = array();
    			$bcc = array();
				
    			if(Configure::read("productionMode")){
    				/*******Production Mode*******************/
    				$to=$contactemail;
    				$cc=$cc;
    				$bcc=array("dkvastrakar18@gmail.com","dkvastrakar18@gmail.com");
    			}else{
    				/*******Dev Mode*******************/
    				$to=$contactemail;
    				$cc=$cc;
    				$bcc=array("dkvastrakar18@gmail.com");
    				/**************************/
    			}
    			
    			/***************tester end*******************/
				
				/* 
				echo "fromid:- ".$fromid;
				echo "<br />contactemail:- ".$contactemail;
				echo "<br />cc:- <pre>";
				print_r($cc);
				echo "<br />Subject:- ".$Subject;
				echo "<br />supplierinc<pre>";
				print_r($supplierinc); 
				*/
								
    			/*$email = new Email('default');
    			$email
    			//->setTransport($name)
    			->template("supplierenquiryconsumable_pr","supplierenquiryconsumable_pr")
    			->from($fromid)
    			->to($contactemail)
    			->cc($cc)
    			->subject($Subject)
    			->emailFormat('html')
    			->viewVars($supplierinc);
    			$email->send();*/
    		}    		
    		return true;
    	}catch(Exception $e){
    		echo $e->getMessage();
    		exit("Error : on send email in ");
    		return false;
    	}
    }
}