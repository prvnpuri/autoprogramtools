<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * IndustryTypeMaster Controller
 *
 * @property \App\Model\Table\IndustryTypeMasterTable $IndustryTypeMaster
 *
 * @method \App\Model\Entity\IndustryTypeMaster[] paginate($object = null, array $settings = [])
 */
class IndustryTypeMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="IndustryTypeMaster.industry_type like '%$query%'";
    	}
    	$this->paginate = [
    			
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","industry_type","industry_description"]
    	];
    	
    	$industryTypeMaster = $this->paginate($this->IndustryTypeMaster);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('industryTypeMaster'));
    	$this->set( '_serialize', ['industryTypeMaster','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Industry Type Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $industryTypeMaster = $this->IndustryTypeMaster->get($id, [
            'contain' => ['CompanyIndustryTypes', 'ProductIndustryApplications']
        ]);

        $this->set('industryTypeMaster', $industryTypeMaster);
        $this->set('_serialize', ['industryTypeMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $industryTypeMaster = $this->IndustryTypeMaster->newEntity();
        if ($this->request->is('post')) {
            $industryTypeMaster = $this->IndustryTypeMaster->patchEntity($industryTypeMaster, $this->request->data);
            if ($this->IndustryTypeMaster->save($industryTypeMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Industry Type Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Industry Type Master'));
            }
        }
        $this->set(compact('industryTypeMaster'));
        $this->set('_serialize', ['industryTypeMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Industry Type Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $industryTypeMaster = $this->IndustryTypeMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $industryTypeMaster = $this->IndustryTypeMaster->patchEntity($industryTypeMaster, $this->request->data);
            if ($this->IndustryTypeMaster->save($industryTypeMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Industry Type Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Industry Type Master'));
            }
        }
        $this->set(compact('industryTypeMaster'));
        $this->set('_serialize', ['industryTypeMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Industry Type Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $industryTypeMaster = $this->IndustryTypeMaster->get($id);
        if ($this->IndustryTypeMaster->delete($industryTypeMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Industry Type Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Industry Type Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
