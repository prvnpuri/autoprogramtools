<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * LeaveMaster Controller
 *
 * @property \App\Model\Table\LeaveMasterTable $LeaveMaster
 *
 * @method \App\Model\Entity\LeaveMaster[] paginate($object = null, array $settings = [])
 */
class LeaveMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $leaveMaster = $this->paginate($this->LeaveMaster);

        $this->set(compact('leaveMaster'));
        $this->set('_serialize', ['leaveMaster']);
    }

    /**
     * View method
     *
     * @param string|null $id Leave Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $leaveMaster = $this->LeaveMaster->get($id, [
            'contain' => []
        ]);

        $this->set('leaveMaster', $leaveMaster);
        $this->set('_serialize', ['leaveMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $leaveMaster = $this->LeaveMaster->newEntity();
        if ($this->request->is('post')) {
            $leaveMaster = $this->LeaveMaster->patchEntity($leaveMaster, $this->request->data);
            if ($this->LeaveMaster->save($leaveMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Leave Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Leave Master'));
            }
        }
        $this->set(compact('leaveMaster'));
        $this->set('_serialize', ['leaveMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Leave Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $leaveMaster = $this->LeaveMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $leaveMaster = $this->LeaveMaster->patchEntity($leaveMaster, $this->request->data);
            if ($this->LeaveMaster->save($leaveMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Leave Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Leave Master'));
            }
        }
        $this->set(compact('leaveMaster'));
        $this->set('_serialize', ['leaveMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Leave Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $leaveMaster = $this->LeaveMaster->get($id);
        if ($this->LeaveMaster->delete($leaveMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Leave Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Leave Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
