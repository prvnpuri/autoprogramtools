<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Network\Exception\NotFoundException;
use function Psy\debug;

/**
 * EmployeeSalaryMaster Controller
 *
 * @property \App\Model\Table\EmployeeSalaryMastersTable $EmployeeSalaryMaster
 * @property \App\Model\Table\EmployeeDetailsTable $EmployeeDetails
 *
 * @method \App\Model\Entity\EmployeeSalaryMaster[] paginate($object = null, array $settings = [])
 */
class EmployeeSalaryMasterController extends AppController
{

    public function initialize(){
        parent::initialize();
        $this->loadModel('EmployeeSalaryMasters');
        $this->loadModel('EmployeeDetails');
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        
        $this->paginate = [
            'contain' => ['EmployeeSalaryMaster','OwnerCompanies'],
            'fields'=>[
                'EmployeeSalaryMaster.id', 'EmployeeSalaryMaster.employee_details_id', 'EmployeeSalaryMaster.basic_sal', 'EmployeeSalaryMaster.hra', 'EmployeeSalaryMaster.conveyance_allowance', 'EmployeeSalaryMaster.medical_allowance', 'EmployeeSalaryMaster.professional_tax', 'EmployeeSalaryMaster.leave_travel_allowance', 'EmployeeSalaryMaster.special_allowance', 'EmployeeSalaryMaster.telephone_reimbursement', 'EmployeeSalaryMaster.chidlren_education_allowance', 'EmployeeSalaryMaster.city_compensation_allowance', 'EmployeeSalaryMaster.total_ctc', 'EmployeeSalaryMaster.employee_salarycol', 'EmployeeSalaryMaster.modified_by', 'EmployeeSalaryMaster.date_of_modification', 'EmployeeSalaryMaster.date_of_creation', 'EmployeeSalaryMaster.created_by', 
                'id','first_name','middle_name','last_name','pan_no',
                'OwnerCompanies.company_name',
                'full_name'=> $this->EmployeeDetails->query()->func()->concat(['first_name',' ','middle_name',' ','last_name']),
                'base_company'=>'OwnerCompanies.company_name',
            ],
            'sortWhitelist'=>['id','first_name','middle_name','last_name','full_name','OwnerCompanies.company_name','base_company'],
            
        ];
        $employeeDetails = $this->paginate($this->EmployeeDetails);

        $this->set(compact('employeeDetails'));
        $this->set('_serialize', ['employeeDetails']);
    }

    /**
     * View method
     *
     * @param string|null $id Employee Salary Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $employeeSalaryMaster = $this->EmployeeSalaryMaster->get($id, [
            'contain' => ['EmployeeDetails', 'EmployeeMonthlySalaries']
        ]);

        $this->set('employeeSalaryMaster', $employeeSalaryMaster);
        $this->set('_serialize', ['employeeSalaryMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($employee_id)
    {
        
        if(!$this->EmployeeDetails->exists($employee_id)){
            throw new NotFoundException( __( 'Invalid Employee details.' ) );
        }
            
        
        $employeeSalaryMaster = $this->EmployeeSalaryMaster->newEntity();
        if ($this->request->is('post')) {
            $employeeSalaryMaster = $this->EmployeeSalaryMaster->patchEntity($employeeSalaryMaster, $this->request->data);
            if ($this->EmployeeSalaryMaster->save($employeeSalaryMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Salary Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Salary Master'));
            }
        }
        $employeeDetail = $this->EmployeeDetails->find('all',[
            'fields'=>['id','first_name','last_name','middle_name','desi_id','Designations.designation','OwnerCompanies.Company_name']
        ])->contain(['Designations','OwnerCompanies'])->where(['EmployeeDetails.id'=>$employee_id])->first();
        $this->set(compact('employeeSalaryMaster', 'employeeDetail'));
        $this->set('_serialize', ['employeeSalaryMaster','employeeDetail']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Employee Salary Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $employeeSalaryMaster = $this->EmployeeSalaryMaster->get($id, [
            'contain' => ['EmployeeDetails']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $employeeSalaryMaster = $this->EmployeeSalaryMaster->patchEntity($employeeSalaryMaster, $this->request->data);
            if ($this->EmployeeSalaryMaster->save($employeeSalaryMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Salary Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Salary Master'));
            }
        }else{
            $this->request->getData($employeeSalaryMaster);
        }
        $employeeDetail = $this->EmployeeDetails->find('all',[
            'fields'=>['id','first_name','last_name','middle_name','desi_id','Designations.designation','OwnerCompanies.Company_name']
        ])->contain(['Designations','OwnerCompanies','EmployeeSalaryMaster'])->where(['EmployeeSalaryMaster.id'=>$id])->first();
        $this->set(compact('employeeSalaryMaster', 'employeeDetail'));
        $this->set('_serialize', ['employeeSalaryMaster','employeeDetail']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Employee Salary Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $employeeSalaryMaster = $this->EmployeeSalaryMaster->get($id);
        if ($this->EmployeeSalaryMaster->delete($employeeSalaryMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Employee Salary Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Employee Salary Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    
    public function getProfessinalTax(){
        $month=$this->request->getData("month");
        $amount=$this->request->getData("amount");
        $emplid=$this->request->getData("employee_id");
        $employeeGender=$this->EmployeeDetails->find("all",array(
            "fields"=>array("gender"),
            "conditions"=>array("EmployeeDetails.id"=>$emplid)
        ))->first();
        $gender="male";
        if( isset($employeeGender->gender) && $employeeGender->gender=="0" ){
            $gender="female";
        }
        $this->loadComponent('ProfessionalTax');
        $pt["amount"]=$this->ProfessionalTax->getProfessionalTax($gender,$amount,$month);
        $this->set("amount",$pt["amount"]);
        $this->set('_serialize', array("amount"));
    }
    
}
