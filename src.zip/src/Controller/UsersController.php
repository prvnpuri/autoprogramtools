<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Log\Log;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{

	//ssl
	//public $components = array('Security');
	
	public function beforeFilter(Event $event) {
		parent::beforeFilter($event);
		$this->Auth->allow('add','index','login','logout','admin_login','admin_logout','reset_password');
		//ssl -- $this->Security->blackHoleCallback = 'forceSSL';
		//ssl -- $this->Security->requireSecure();
	}
	
	//public function forceSSL() {
		//return $this->redirect('https://' . env('SERVER_NAME') . $this->here);
	//}
	
	/**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $users = $this->paginate($this->Users);

        $this->set(compact('users'));
        $this->set('_serialize', ['users']);
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);

        $this->set('user', $user);
        $this->set('_serialize', ['user']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        
    	$user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The {0} has been saved.', 'User'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'User'));
            }
        }
        $this->loadModel('Groups');
        $groups= $this->Groups->find('list', ['keyField' => 'id','valueField' => 'name','order'=>'name']);
        
        $this->loadModel('Roles');
        $roles= $this->Roles->find('list', ['keyField' => 'id','valueField' => 'name','order'=>'name']);
        
        $this->set(compact('user', 'groups','roles'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The {0} has been saved.', 'User'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'User'));
            }
        }
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The {0} has been deleted.', 'User'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'User'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    
    public function login()
    {
        if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            
            if ($user) {
                $ownerCompanId=$this->request->data['company'];
                $user['owner_company_id']=$ownerCompanId;
                $this->Auth->setUser($user);
                if ($this->Auth->user('active') == 1 ){
                    
                    $this->loadModel('UserOwnerCompany');
                    $userOwnerCompany = $this->UserOwnerCompany->find('all', [
                        'conditions'=>['user_id'=>$user['id']]
                    ])->toArray();
                    
                    $cnt=0;
                    foreach($userOwnerCompany as $userkey => $uservalue){
                        if(($uservalue['owner_companies_id']==$ownerCompanId)){
                            $cnt++;
                        }
                        
                    }
                    //echo '@@'.$cnt;die;
                    if($cnt=="0"){
                        $this->Flash->error(__('The user : {0} , is not associated with owner company.', $this->Auth->user('username')));
                        return $this->redirect($this->Auth->logout());
                    }
                    return $this->redirect($this->Auth->redirectUrl());
                } else {
                    $this->Flash->error(__('The user : {0} , is not active.', $this->Auth->user('username')));
                    return $this->redirect($this->Auth->logout());
                }
            }
            $this->Flash->error(__('Invalid User name or password.'));
            //$this->viewBuilder()->setLayout('AdminLTE.login');
        }else{
            $user = $this->Auth->identify();
            Log::debug('Loggin in User login');
        }
        $this->loadModel('OwnerCompanies');
        $ownerCompanies = $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
        
        
        $this->set(compact('user','ownerCompanies','userOwnerCompany'));
        $this->set('_serialize', ['user']);
    }
    
    
   
    
    public function logout()
    {
    	return $this->redirect($this->Auth->logout());
    }
}
