<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ImportExportData Controller
 *
 * @property \App\Model\Table\ImportExportDataTable $ImportExportData
 *
 * @method \App\Model\Entity\ImportExportData[] paginate($object = null, array $settings = [])
 */
class ImportExportDataController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => []
        ];
        $importExportData = $this->paginate($this->ImportExportData);

        $this->set(compact('importExportData'));
        $this->set('_serialize', ['importExportData']);
    }

    /**
     * View method
     *
     * @param string|null $id Import Export Data id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $importExportData = $this->ImportExportData->get($id, [
            'contain' => ['Items', 'Shippers', 'Consignees']
        ]);

        $this->set('importExportData', $importExportData);
        $this->set('_serialize', ['importExportData']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $importExportData = $this->ImportExportData->newEntity();
        if ($this->request->is('post')) {
            $importExportData = $this->ImportExportData->patchEntity($importExportData, $this->request->data);
            if ($this->ImportExportData->save($importExportData)) {
                $this->Flash->success(__('The {0} has been saved.', 'Import Export Data'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Import Export Data'));
            }
        }
        $items = $this->ImportExportData->Items->find('list', ['limit' => 200]);
        $shippers = $this->ImportExportData->Shippers->find('list', ['limit' => 200]);
        $consignees = $this->ImportExportData->Consignees->find('list', ['limit' => 200]);
        $this->set(compact('importExportData', 'items', 'shippers', 'consignees'));
        $this->set('_serialize', ['importExportData']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Import Export Data id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $importExportData = $this->ImportExportData->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $importExportData = $this->ImportExportData->patchEntity($importExportData, $this->request->data);
            if ($this->ImportExportData->save($importExportData)) {
                $this->Flash->success(__('The {0} has been saved.', 'Import Export Data'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Import Export Data'));
            }
        }
        $items = $this->ImportExportData->Items->find('list', ['limit' => 200]);
        $shippers = $this->ImportExportData->Shippers->find('list', ['limit' => 200]);
        $consignees = $this->ImportExportData->Consignees->find('list', ['limit' => 200]);
        $this->set(compact('importExportData', 'items', 'shippers', 'consignees'));
        $this->set('_serialize', ['importExportData']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Import Export Data id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $importExportData = $this->ImportExportData->get($id);
        if ($this->ImportExportData->delete($importExportData)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Import Export Data'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Import Export Data'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
