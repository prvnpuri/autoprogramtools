<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Cache\Cache;
use Cake\Core\Configure; 
use function Cake\ORM\toArray;

/**
 * SupplierOffer Controller
 *
 * @property \App\Model\Table\SupplierOfferTable $SupplierOffer
 *
 * @method \App\Model\Entity\SupplierOffer[] paginate($object = null, array $settings = [])
 */
class SupplierOfferController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
	public function index()
	{
		$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
		 
		$condn=array('SupplierInquiry.owner_companies_id'=>$ownercomp);
		$this->loadModel('SupplierInquiry');
		$supplierinquires = $this->SupplierInquiry->find('all',
				[
						//'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','ProductsMaster.product_name','id','status','company_ids'],
						'conditions'=>[['inquiry_type'=>'Chemical Product'],$condn],
						'contain'=>['SupplierOffer','SupplierOffer.SupplierOfferProducts','SupplierOffer.SupplierOfferProducts.ProductsMaster','SupplierOffer.SupplierOfferProducts.Uom','SupplierOffer.SupplierOfferProducts.PackingMaster','SupplierOffer.SupplierOfferProducts.PackingMaster.PackingType','SupplierOffer.SupplierOfferProducts.Currency', 'OwnerCompanies','Uom', 'SupplierOffer.Uom','SupplierOffer.CompanyMaster', 'SupplierOffer.Currency' ],
						'order'=>['SupplierInquiry.id' => 'DESC']
				]
				);
		$supplierOffer = $this->paginate($supplierinquires);
	
		$arrsupplierCompany=$supplierinquires->toArray();
		//echo '<pre>',print_r($arrsupplierCompany);die;
		foreach ($arrsupplierCompany as $ks=>$vals){
			 
			$companyIds=$vals['company_ids'];
			$companyMaster =  $this->SupplierInquiry->CompanyMaster->find('all',
					array('fields'=>array('id','company_name')	,
							'conditions'=>array('id IN '=> explode(",",$companyIds))
					))->toArray();
	
					$vals['CompanyMaster']=$companyMaster;
		}
		$supplierinquires=$supplierinquires->toArray();
	
		$this->set(compact('supplierOffer'));
		//  $this->set('_serialize', ['supplierOffer']);
	    
	}
    
    public function indexConsumable()
    {
    	$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
    	
    	$condn=array('SupplierInquiry.owner_companies_id'=>$ownercomp);
    	$this->loadModel('SupplierInquiry');
    	$supplierinquires = $this->SupplierInquiry->find('all',
    			[
    					//'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','ProductsMaster.product_name','id','status','company_ids'],
    					'conditions'=>[['inquiry_type'=>'Consumable'],$condn],
    					'contain'=>['SupplierOffer','SupplierOffer.SupplierOfferProducts','SupplierOffer.SupplierOfferProducts.ConsumablesMaster','SupplierOffer.SupplierOfferProducts.Uom','SupplierOffer.SupplierOfferProducts.PackingMaster','SupplierOffer.SupplierOfferProducts.PackingMaster.PackingType','SupplierOffer.SupplierOfferProducts.Currency', 'OwnerCompanies','Uom', 'SupplierOffer.Uom','SupplierOffer.CompanyMaster', 'SupplierOffer.Currency' ],
    					'order'=>['SupplierInquiry.id' => 'DESC']
    			]
    			);
    	$supplierOffer = $this->paginate($supplierinquires);
    	 
    	$arrsupplierCompany=$supplierinquires->toArray();
    	//echo '<pre>',print_r($arrsupplierCompany);die;
    	foreach ($arrsupplierCompany as $ks=>$vals){
    		 
    		$companyIds=$vals['company_ids'];
    		$companyMaster =  $this->SupplierInquiry->CompanyMaster->find('all',
    				array('fields'=>array('id','company_name')	,
    						'conditions'=>array('id IN '=> explode(",",$companyIds))
    				))->toArray();
    
    				$vals['CompanyMaster']=$companyMaster;
    	}
    	$supplierinquires=$supplierinquires->toArray();
    
    	$this->set(compact('supplierOffer'));
    	//  $this->set('_serialize', ['supplierOffer']);
       
    }
    public function indexPacking()
    {
    	$this->loadModel('SupplierInquiry');
    	$supplierinquires = $this->SupplierInquiry->find('all',
    			[
    					'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','id','status','company_ids',
    								'raised_on','PackingMaster.specification','PackingMaster.color','PackingType.packing_type','PackingSubtype.sub_type'
    							
    					],
    					'conditions'=>['inquiry_type'=>'Packing Product'],
    					'contain'=>['PackingMaster','Uom','PackingMaster.PackingType','PackingMaster.PackingSubtype','OwnerCompanies','Uom', 'SupplierOffer.Uom','SupplierOffer.CompanyMaster', 'SupplierOffer.Currency','SupplierOffer','SupplierOffer.PackingMaster','SupplierOffer.PackingMaster.PackingType'],
    					'order'=>['SupplierInquiry.id' => 'DESC']
    			]
    			);
    	$supplierOffer = $this->paginate($supplierinquires);
    	 
    	/* $arrsupplierCompany=$supplierinquires->toArray();
    	 //echo '<pre>',print_r($arrsupplierCompany);die;
    	 foreach ($arrsupplierCompany as $ks=>$vals){
    	  
    	 $companyIds=$vals['company_ids'];
    	 $companyMaster =  $this->SupplierInquiry->CompanyMaster->find('all',
    	 array('fields'=>array('id','company_name')	,
    	 'conditions'=>array('id IN '=> explode(",",$companyIds))
    	 ))->toArray();
    
    	 $vals['CompanyMaster']=$companyMaster;
    	 }
    	 $supplierinquires=$supplierinquires->toArray();  */
    
    	$this->set(compact('supplierOffer'));
    	//  $this->set('_serialize', ['supplierOffer']);
       
    }
    /**
     * View method
     *
     * @param string|null $id Supplier Offer id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
    	$supplierOffer = $this->SupplierOffer->get($id, [
    			/*  'fields'=>['OwnerCompanies.Company_name','reference_number','supplier_company_id','offer_date','SupplierInquiry.qty_required','Uom.unit_symbol','SupplierInquiry.validity_of_inquiry','ProductsMaster.product_name','id','status','SupplierInquiry.company_ids',
    			 'ProductsMaster.cas_no','ProductsMaster.grade_name','PaymentTerm.term','DeliveryTerm.term','offer_validity','IncoTerms.inco_term',
    					'supplier_company_id','SupplierInquiry.company_contact_persons','Currency.sign',
    					'qty_offered','offer_price','total_order_value','SupplierInquiry.reference_number','packing_offered',
    					'SupplierInquiry.inquiry_type','Uom.unit_symbol','SupplierInquiry.is_local','SupplierInquiry.packingMaster_id',
    
    
    			], */
    			'contain' => ['SupplierInquiry','SupplierInquiry.ProductsMaster','SupplierInquiry.CompanyMaster','SupplierInquiry.OwnerCompanies', 'SupplierInquiry.Uom', 'SupplierInquiry.Currency','SupplierInquiry.SupplierInquiryProducts','SupplierInquiry.SupplierInquiryProducts.ProductsMaster','SupplierInquiry.SupplierInquiryProducts.Uom','SupplierInquiry.SupplierInquiryProducts.PackingMaster','SupplierInquiry.SupplierInquiryProducts.PackingMaster.PackingType','IncoTerms','DeliveryTerm','PaymentTerm','SupplierOfferProducts','SupplierOfferProducts.ConsumablesMaster','SupplierOfferProducts.Uom','SupplierOfferProducts.PackingMaster','SupplierOfferProducts.PackingMaster.PackingType','SupplierOfferProducts.Currency']
    			 
    	]);
    	$companyidsval=isset($supplierOffer['supplier_company_id'])?$supplierOffer['supplier_company_id']['company_ids']:"";
    	//$companyids=explode(",",$companyidsval);
    
    
    	$companycontactIdval=isset($supplierOffer['supplier_inquiry']['company_contact_persons'])?$supplierOffer['supplier_inquiry']['company_contact_persons']:"";
    	$companycontactIds=explode(",",$companycontactIdval);
    
    	//echo '<pre>',print_r($companycontactIds);
    	$companyMaster =  $this->SupplierOffer->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $supplierOffer['supplier_company_id']])->
    	contain([
    			'CompanyContactPersons' => function ($q)use ($companycontactIds){
    			return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
    			},
    
    
    			]);
    	$this->set('companyMaster', $companyMaster);
    	 
    	$this->loadModel('PackingMaster');
    
    	//   echo '<pre>',print_r($supplierOffer);die;
    	$optioninquirys = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id' => $supplierOffer['supplier_inquiry']['packingMaster_id'],
    			),
    	);
    	$packingInquiryMaster = $this->PackingMaster->find('all', $optioninquirys)->toArray();
    	$this->set('packingInquiryMaster', $packingInquiryMaster);
    
    	// print_r($packingInquiryMaster);die;
    
    	$options = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id ' => $supplierOffer['packing_offered'],
    			),
    	);
    	$packingMaster = $this->SupplierOffer->PackingMaster->find('all', $options)->toArray();
    	$this->set('packingMaster', $packingMaster);
    
    
    	$this->set('supplierOffer', $supplierOffer);
    	$this->set('_serialize', ['supplierOffer']);
    }
    public function viewAsset($id = null)
    {
    	$supplierOffer = $this->SupplierOffer->get($id, [
    			'fields'=>['OwnerCompanies.Company_name','reference_number','supplier_company_id','offer_date','SupplierInquiry.qty_required','Uom.unit_symbol','SupplierInquiry.validity_of_inquiry','ProductsMaster.product_name','id','status','SupplierInquiry.company_ids',
    					'ProductsMaster.cas_no','ProductsMaster.grade_name','PaymentTerm.term','DeliveryTerm.term','offer_validity','IncoTerms.inco_term','PackingMaster.specification',
    					'supplier_company_id','SupplierInquiry.company_contact_persons',
    					'qty_offered','offer_price','total_order_value','SupplierInquiry.reference_number'
    
    
    			],
    			 
    			'contain' => ['SupplierInquiry','SupplierInquiry.ProductsMaster','SupplierInquiry.CompanyMaster','SupplierInquiry.OwnerCompanies', 'SupplierInquiry.Uom', 'SupplierInquiry.Currency', 'SupplierInquiry.PackingMaster','IncoTerms','DeliveryTerm','PaymentTerm']
    	]);
    	$companyidsval=isset($supplierOffer['supplier_company_id'])?$supplierOffer['supplier_company_id']['company_ids']:"";
    	//$companyids=explode(",",$companyidsval);
    	 
    	 
    	$companycontactIdval=isset($supplierOffer['supplier_inquiry']['company_contact_persons'])?$supplierOffer['supplier_inquiry']['company_contact_persons']:"";
    	$companycontactIds=explode(",",$companycontactIdval);
    	 
    	//echo '<pre>',print_r($companycontactIds);
    	$companyMaster =  $this->SupplierOffer->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $supplierOffer['supplier_company_id']])->
    	contain([
    			'CompanyContactPersons' => function ($q)use ($companycontactIds){
    			return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
    			},
    			 
    			 
    			]);
    	$this->set('companyMaster', $companyMaster);
    	 
    	//$producttestdataid=$supplierOffer['supplier_inquiry']['product_specifications'];
    	$this->loadModel('ProductDataTests');
    	 
    //	$productTestData =  $this->ProductDataTests->find()->where(['id IN' => explode(",",$producttestdataid)])->toArray();
    //	$this->set('productTestData', $productTestData);
    
    	$this->set('supplierOffer', $supplierOffer);
    	$this->set('_serialize', ['supplierOffer']);
    }
    public function viewPacking($id = null)
    {
    	$supplierOffer = $this->SupplierOffer->get($id, [
    			'fields'=>['supplier_inquiry_id','OwnerCompanies.Company_name','reference_number','supplier_company_id','offer_date','SupplierInquiry.qty_required','Uom.unit_symbol','SupplierInquiry.validity_of_inquiry','id','status','SupplierInquiry.company_ids',
    					'PaymentTerm.term','DeliveryTerm.term','offer_validity','IncoTerms.inco_term','PackingMaster.specification','PackingMaster.color','PackingType.packing_type','PackingSubtype.sub_type',
    					'supplier_company_id','SupplierInquiry.company_contact_persons',
    					'qty_offered','offer_price','total_order_value','SupplierInquiry.reference_number','Currency.sign',
    
    
    			],
    			 
    			'contain' => ['PackingMaster','PackingMaster.PackingType','PackingMaster.PackingSubtype','SupplierInquiry','SupplierInquiry.CompanyMaster','SupplierInquiry.OwnerCompanies', 'Uom','IncoTerms','DeliveryTerm','PaymentTerm','Currency']
    	]);
    	$companyidsval=isset($supplierOffer['supplier_company_id'])?$supplierOffer['supplier_company_id']['company_ids']:"";
    	//$companyids=explode(",",$companyidsval);
    	 
    	 
    	$companycontactIdval=isset($supplierOffer['supplier_inquiry']['company_contact_persons'])?$supplierOffer['supplier_inquiry']['company_contact_persons']:"";
    	$companycontactIds=explode(",",$companycontactIdval);
    	 
    	//echo '<pre>',print_r($companycontactIds);
    	$companyMaster =  $this->SupplierOffer->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $supplierOffer['supplier_company_id']])->
    	contain([
    			'CompanyContactPersons' => function ($q)use ($companycontactIds){
    			return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
    			},
    			 
    			 
    			]);
    	$this->set('companyMaster', $companyMaster);
    	 
    	
    
    	$this->set('supplierOffer', $supplierOffer);
    	$this->set('_serialize', ['supplierOffer']);
    	
    	
    	$this->loadModel('SupplierInquiry');
    	$supplierInquiry = $this->SupplierInquiry->get($supplierOffer ->supplier_inquiry_id, [
    			'fields'=>['id','packingMaster_id','PackingMaster.specification','PackingType.packing_type','PackingSubtype.sub_type',
    			],
    	
    			'contain' => ['PackingMaster','PackingMaster.PackingType','PackingMaster.PackingSubtype']
    	]);
    	
    	$this->set('PackingInquiry', $supplierInquiry);
    	
    }
    
    public function viewconsumable($id = null)
    {
    	$supplierOffer = $this->SupplierOffer->get($id, [
    			/*  'fields'=>['OwnerCompanies.Company_name','reference_number','supplier_company_id','offer_date','SupplierInquiry.qty_required','Uom.unit_symbol','SupplierInquiry.validity_of_inquiry','ProductsMaster.product_name','id','status','SupplierInquiry.company_ids',
    			 'ProductsMaster.cas_no','ProductsMaster.grade_name','PaymentTerm.term','DeliveryTerm.term','offer_validity','IncoTerms.inco_term',
    					'supplier_company_id','SupplierInquiry.company_contact_persons','Currency.sign',
    					'qty_offered','offer_price','total_order_value','SupplierInquiry.reference_number','packing_offered',
    					'SupplierInquiry.inquiry_type','Uom.unit_symbol','SupplierInquiry.is_local','SupplierInquiry.packingMaster_id',
    						
    
    			], */
    			'contain' => ['SupplierInquiry','SupplierInquiry.ProductsMaster','SupplierInquiry.CompanyMaster','SupplierInquiry.OwnerCompanies', 'SupplierInquiry.Uom', 'SupplierInquiry.Currency','SupplierInquiry.SupplierInquiryProducts','SupplierInquiry.SupplierInquiryProducts.ConsumablesMaster','SupplierInquiry.SupplierInquiryProducts.Uom','SupplierInquiry.SupplierInquiryProducts.PackingMaster','SupplierInquiry.SupplierInquiryProducts.PackingMaster.PackingType','IncoTerms','DeliveryTerm','PaymentTerm','SupplierOfferProducts','SupplierOfferProducts.ConsumablesMaster','SupplierOfferProducts.Uom','SupplierOfferProducts.PackingMaster','SupplierOfferProducts.PackingMaster.PackingType','SupplierOfferProducts.Currency']
    			
    	]);
    	$companyidsval=isset($supplierOffer['supplier_company_id'])?$supplierOffer['supplier_company_id']['company_ids']:"";
    	//$companyids=explode(",",$companyidsval);
    	 
    	 
    	$companycontactIdval=isset($supplierOffer['supplier_inquiry']['company_contact_persons'])?$supplierOffer['supplier_inquiry']['company_contact_persons']:"";
    	$companycontactIds=explode(",",$companycontactIdval);
    	 
    	//echo '<pre>',print_r($companycontactIds);
    	$companyMaster =  $this->SupplierOffer->SupplierInquiry->CompanyMaster->find()->where(['CompanyMaster.id IN' => $supplierOffer['supplier_company_id']])->
    	contain([
    			'CompanyContactPersons' => function ($q)use ($companycontactIds){
    			return $q->where(['CompanyContactPersons.id IN' => $companycontactIds]);
    			},
    			 
    			 
    			]);
    	$this->set('companyMaster', $companyMaster);
    	
    	$this->loadModel('PackingMaster');
    
    	//   echo '<pre>',print_r($supplierOffer);die;
    	$optioninquirys = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id' => $supplierOffer['supplier_inquiry']['packingMaster_id'],
    			),
    	);
    	$packingInquiryMaster = $this->PackingMaster->find('all', $optioninquirys)->toArray();
    	$this->set('packingInquiryMaster', $packingInquiryMaster);
    
    	// print_r($packingInquiryMaster);die;
    	 
    	$options = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id ' => $supplierOffer['packing_offered'],
    			),
    	);
    	$packingMaster = $this->SupplierOffer->PackingMaster->find('all', $options)->toArray();
    	$this->set('packingMaster', $packingMaster);
    
    	 
    	$this->set('supplierOffer', $supplierOffer);
    	$this->set('_serialize', ['supplierOffer']);
    }
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($id=null,$companyid=null)
    {
    	$supplierOffer = $this->SupplierOffer->newEntity();
    	$this->loadModel('SupplierInquiry');
    	$supplierInquiry = $this->SupplierInquiry->get($id, [
    			/* 'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','ProductsMaster.product_name','id','status','company_ids',
    					'ProductsMaster.cas_no','ProductsMaster.grade_name','packingMaster_id','PackingMaster.specification',
    					'company_contact_persons','date_of_creation','owner_companies_id','uom_id'
    					,'is_local','owner_companies_id'
  
  
    			], */
    
    			'contain' => ['OwnerCompanies', 'Uom', 'Currency', 'PackingMaster', 'SupplierOffer','SelectedProductSpecs','SupplierInquiryProducts','SupplierInquiryProducts.ProductsMaster','SupplierInquiryProducts.Uom','SupplierInquiryProducts.PackingMaster','SupplierInquiryProducts.PackingMaster.PackingType']
    	]);
    
    
    	if ($this->request->is('post')) {
    		$this->loadModel('ReferenceNumberCounter');
    		$this->loadComponent('ReferenceNumber');
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'sup_offer');
    		$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    		if(!isset($next_ref['full_next_ref_no'])){
    			//echo 'sdfsg';die;
    			$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Offer'));
    			//return $this->redirect(['action' => 'index']);
    		}else{
    			 
    			 
    			$supplierOffer = $this->SupplierOffer->patchEntity($supplierOffer, $this->request->data);
    			//debug($supplierOffer);exit;
    			if ($this->SupplierOffer->save($supplierOffer)) {
    				$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    
    				//Update send to offer YES in supplier inquiry
    
    				$data = array('id' => $id , 'send_to_offer' => 'YES');
    				//echo '<pre>',print_r($data);die;
    				/* $SupplierInquiry = $this->SupplierInquiry->get($id, [
    				 'fields'=>['id'
    
    
    				 ],
    
    				 //	'contain' => ['ProductsMaster','OwnerCompanies', 'Uom', 'Currency', 'PackingMaster', 'SupplierOffer']
    				 ]);
    				$this->SupplierInquiry->patchEntity($SupplierInquiry,$data);
    				$this->SupplierInquiry->save($SupplierInquiry); */
    				//  die;
    				$this->Flash->success(__('The {0} has been saved.', 'Supplier Offer'));
    				return $this->redirect(['controller'=>'supplier-inquiry','action' => 'index']);
    			} else {
    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Offer'));
    			}
    		}
    	}
    
    	/*  $companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    	 $companyids=explode(",",$companyidsval); */
    
    
    	// echo $currencyId;exit;
    
    	$this->loadModel('CompanyMaster');
    	$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id' => $companyid])->contain(['CompanyContactPersons'])->toArray();
    	//Get currency from cache
    
    	$options='';
    	if($supplierInquiry->is_local==1){
    		$CurrencyKey=$supplierInquiry->owner_companies_id.'_'.'currency';
    		$currencyId = Cache::read($CurrencyKey, $config = 'default');
    		 
    		$options=array('iso_code'=>$currencyId);
    	}
    	//die;
    	$currencies = $this->SupplierOffer->Currency->find('list', ['keyField' => 'id','valueField' => 'name','conditions'=>$options,'limit' => 200]);
    	$incoterms = $this->SupplierOffer->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    	$deliveryterms = $this->SupplierOffer->DeliveryTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$paymentterms = $this->SupplierOffer->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$this->loadModel('ProductDataTests');
    	foreach($supplierInquiry['selected_product_specs'] as $pk=>$pv){
    		$arrdetails[]=$pv['product_data_tests_id'];
    
    	}
    
    	$options = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id ' => $supplierInquiry->packingMaster_id,
    			),
    	);
    
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('all', $options)->toArray();
    
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$this->set(compact('uom','packingMaster','supplierOffer', 'supplierInquiry','productTestData','companyMaster','currencies','incoterms','deliveryterms','paymentterms'));
    	$this->set('_serialize', ['supplierOffer']);
    }
    public function addPacking($id=null,$companyid=null)
    {
    	$supplierOffer = $this->SupplierOffer->newEntity();
    	if ($this->request->is('post')) {
    		$this->loadModel('ReferenceNumberCounter');
    		$this->loadComponent('ReferenceNumber');
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'sup_offer');
    		$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    		if(!isset($next_ref['full_next_ref_no'])){
    			//echo 'sdfsg';die;
    			$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Offer'));
    			//return $this->redirect(['action' => 'index']);
    		}else{
    			$supplierOffer = $this->SupplierOffer->patchEntity($supplierOffer, $this->request->data);
    			if ($this->SupplierOffer->save($supplierOffer)) {
    				$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    				 
    				$this->Flash->success(__('The {0} has been saved.', 'Supplier Offer'));
    				return $this->redirect(['action' => 'index_packing']);
    			} else {
    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Offer'));
    			}
    		}
    	}
    	$this->loadModel('SupplierInquiry');
    	$supplierInquiry = $this->SupplierInquiry->get($id, [
    			'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','id','status','company_ids','is_local',
     	 				'PackingMaster.paking_type_id','PackingMaster.packing_subtype_id','PackingMaster.specification','packingMaster_id','PackingMaster.description','PackingMaster.color',
     	 				'company_contact_persons','date_of_creation','owner_companies_id','uom_id'
     
     
    			],
    
    			'contain' => ['OwnerCompanies', 'Uom', 'Currency', 'PackingMaster', 'SupplierOffer']
    	]);
    	$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    	$companyids=explode(",",$companyidsval);
    	 
    
    	// echo $currencyId;exit;
    	 
    	$this->loadModel('CompanyMaster');
    	$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons'])->toArray();
    	//Get currency from cache
    
    	$options='';
    	if($supplierInquiry->is_local==1){
    		$CurrencyKey=$supplierInquiry->owner_companies_id.'_'.'currency';
    		$currencyId = Cache::read($CurrencyKey, $config = 'default');
    		 
    		$options=array('iso_code'=>$currencyId);
    	}
    	$currencies = $this->SupplierOffer->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','conditions'=>$options,'limit' => 200]);
    	$incoterms = $this->SupplierOffer->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    	$deliveryterms = $this->SupplierOffer->DeliveryTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$paymentterms = $this->SupplierOffer->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$this->loadModel('PackingType');
    	$this->loadModel('PackingSubtype');
    	 
    	$packingtype = $this->PackingType->find('list',['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type'], ['limit' => 200]);
    	$packingsubtype = $this->PackingSubtype->find('list',['keyField' => 'id','valueField' => 'sub_type'], ['limit' => 200]);
    	$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    	 
    	 
    
    	$this->set(compact('packingtype','packingMaster','packingsubtype','supplierOffer', 'supplierInquiry','companyMaster','currencies','incoterms','deliveryterms','paymentterms'));
    	$this->set('_serialize', ['supplierOffer']);
    }
    
    public function addconsumable($id=null,$companyid=null)
    {
    	$supplierOffer = $this->SupplierOffer->newEntity();
    	$this->loadModel('SupplierInquiry');
    	$supplierInquiry = $this->SupplierInquiry->get($id, [
    			'fields'=>['OwnerCompanies.Company_name','reference_number','qty_required','Uom.unit_symbol','validity_of_inquiry','ProductsMaster.product_name','id','status','company_ids',
    					'ProductsMaster.cas_no','ProductsMaster.grade_name','packingMaster_id','PackingMaster.specification',
    					'company_contact_persons','date_of_creation','owner_companies_id','uom_id'
    					,'is_local','owner_companies_id'
   
   
    			],
    
    			'contain' => ['ProductsMaster','OwnerCompanies', 'Uom', 'Currency', 'PackingMaster', 'SupplierOffer','SelectedProductSpecs','SupplierInquiryProducts','SupplierInquiryProducts.ConsumablesMaster','SupplierInquiryProducts.Uom','SupplierInquiryProducts.PackingMaster','SupplierInquiryProducts.PackingMaster.PackingType']
    	]);
    
    
    	if ($this->request->is('post')) {
    		$this->loadModel('ReferenceNumberCounter');
    		$this->loadComponent('ReferenceNumber');
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'sup_offer');
    		$this->request->data['reference_number'] = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    		if(!isset($next_ref['full_next_ref_no'])){
    			//echo 'sdfsg';die;
    			$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Offer'));
    			//return $this->redirect(['action' => 'index']);
    		}else{
    			
    			
    			$supplierOffer = $this->SupplierOffer->patchEntity($supplierOffer, $this->request->data);
    			//debug($supplierOffer);exit;
    			if ($this->SupplierOffer->save($supplierOffer)) {
    				$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    
    				//Update send to offer YES in supplier inquiry
    
    				$data = array('id' => $id , 'send_to_offer' => 'YES');
    				//echo '<pre>',print_r($data);die;
    				/* $SupplierInquiry = $this->SupplierInquiry->get($id, [
    				 'fields'=>['id'
    				  
    				  
    				 ],
    
    				 //	'contain' => ['ProductsMaster','OwnerCompanies', 'Uom', 'Currency', 'PackingMaster', 'SupplierOffer']
    				 ]);
    				$this->SupplierInquiry->patchEntity($SupplierInquiry,$data);
    				$this->SupplierInquiry->save($SupplierInquiry); */
    				//  die;
    				$this->Flash->success(__('The {0} has been saved.', 'Supplier Offer'));
    				return $this->redirect(['controller'=>'supplier-inquiry','action' => 'index-consumable']);
    			} else {
    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Offer'));
    			}
    		}
    	}
    
    	/*  $companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    	 $companyids=explode(",",$companyidsval); */
    	 
    
    	// echo $currencyId;exit;
    	 
    	$this->loadModel('CompanyMaster');
    	$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id' => $companyid])->contain(['CompanyContactPersons'])->toArray();
    	//Get currency from cache
    
    	$options='';
    	if($supplierInquiry->is_local==1){
    		$CurrencyKey=$supplierInquiry->owner_companies_id.'_'.'currency';
    		$currencyId = Cache::read($CurrencyKey, $config = 'default');
    		 
    		$options=array('iso_code'=>$currencyId);
    	}
    	//die;
    	$currencies = $this->SupplierOffer->Currency->find('list', ['keyField' => 'id','valueField' => 'name','conditions'=>$options,'limit' => 200]);
    	$incoterms = $this->SupplierOffer->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    	$deliveryterms = $this->SupplierOffer->DeliveryTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$paymentterms = $this->SupplierOffer->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$this->loadModel('ProductDataTests');
    	foreach($supplierInquiry['selected_product_specs'] as $pk=>$pv){
    		$arrdetails[]=$pv['product_data_tests_id'];
    
    	}
    
    	$options = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id ' => $supplierInquiry->packingMaster_id,
    			),
    	);
    
    	$packingMaster = $this->SupplierInquiry->PackingMaster->find('all', $options)->toArray();
    	 
    	$uom = $this->SupplierInquiry->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$this->set(compact('uom','packingMaster','supplierOffer', 'supplierInquiry','productTestData','companyMaster','currencies','incoterms','deliveryterms','paymentterms'));
    	$this->set('_serialize', ['supplierOffer']);
    }
    public function addAsset($id=null,$companyid=null)
    {
    	$supplierOffer = $this->SupplierOffer->newEntity();
    	if ($this->request->is('post')) {
    		$this->loadModel('ReferenceNumberCounter');
    		 
    		$next_ref =
    		$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'sup_inq');
    		$this->request->data['reference_number'] = $next_ref['full_next_ref_no'];
    
    		$supplierOffer = $this->SupplierOffer->patchEntity($supplierOffer, $this->request->data);
    		if ($this->SupplierOffer->save($supplierOffer)) {
    			$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    
    			$this->Flash->success(__('The {0} has been saved.', 'Supplier Offer'));
    			return $this->redirect(['action' => 'index']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Offer'));
    		}
    	}
    	$this->loadModel('SupplierInquiry');
    	$supplierInquiry = $this->SupplierInquiry->get($id, [
    			
    			'contain' => ['FactoryQcequipment', 'OwnerCompanies', 'Uom', 'Currency', 'SupplierOffer']
    			
    	]);
    	$companyidsval=isset($supplierInquiry['company_ids'])?$supplierInquiry['company_ids']:"";
    	$companyids=explode(",",$companyidsval);
    	 
    	 
    	$this->loadModel('CompanyMaster');
    	$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons'])->toArray();
    	$currencies = $this->SupplierOffer->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','limit' => 200]);
    	$incoterms = $this->SupplierOffer->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    	$deliveryterms = $this->SupplierOffer->DeliveryTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$paymentterms = $this->SupplierOffer->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$this->set(compact('supplierOffer', 'supplierInquiry','companyMaster','currencies','incoterms','deliveryterms','paymentterms'));
    	$this->set('_serialize', ['supplierOffer']);
    }

    public function acceptOffer($id=null,$inquiryType=null){

    	if($inquiryType=="ChemicalProduct")
    	{
    		$supplierOffer = $this->SupplierOffer->get($id, [
    				'contain' => ['SupplierInquiry','SupplierOfferProducts']
    		]);
    		
    		foreach($supplierOffer->supplier_offer_products as $offerProduct){
    			$orderdataproduct[]=array(
    					"product_id"=>$offerProduct->product_id,
    					"qty"=>$offerProduct->qty_offered,
    					"uom_id"=>$offerProduct["uom_id"],
    					"packingMaster_id"=>$offerProduct["packingMaster_id"],
    					"price"=>$offerProduct["offer_price"],
    					"currency_id"=>$offerProduct["currency_id"],
    					"total_order_value"=>$offerProduct["total_order_value"],
    			);
    		}
    		
    	}else if($inquiryType=="PackingProduct"){
    		
    		$supplierOffer = $this->SupplierOffer->get($id, [
    				'fields'=>['reference_number','supplier_company_id','packing_offered','offer_date','SupplierInquiry.uom_id','id','status','owner_companies_id',
    						'payment_terms','offer_validity','IncoTerms.inco_term','PackingMaster.specification',
    						'supplier_company_id',
    						'qty_offered','offer_price','total_order_value','SupplierInquiry.company_ids',
    						'inco_terms','delivery_terms','payment_terms','currency_id',
    						'SupplierInquiry.packingMaster_id',
    							
    						 
    				],
    		
    				'contain' => ['SupplierInquiry', 'SupplierInquiry.PackingMaster','IncoTerms','DeliveryTerm','PaymentTerm']
    		]);
    		
    		
    	}else if($inquiryType=="Consumable")
    	{
    		$supplierOffer = $this->SupplierOffer->get($id, [
    				'contain' => ['SupplierInquiry','SupplierOfferProducts']
    		]);
    		
    		foreach($supplierOffer->supplier_offer_products as $offerProduct){
    			$orderdataproduct[]=array(
    							"product_id"=>$offerProduct->product_id,
    							"qty"=>$offerProduct->qty_offered,
    							"uom_id"=>$offerProduct["uom_id"],
    							"packingMaster_id"=>$offerProduct["packingMaster_id"],
    							"price"=>$offerProduct["offer_price"],
    							"currency_id"=>$offerProduct["currency_id"],
    							"total_order_value"=>$offerProduct["total_order_value"],
    			);
    		}
    	}
    	//debug($supplierOffer);
    	//debug($orderdataproduct);
    	/** Code to generate reference number start **/
    	$this->loadModel('ReferenceNumberCounter');
    	$this->loadComponent('ReferenceNumber');
    	$next_ref =
    	$this->ReferenceNumber->get_next_ref_number($supplierOffer['owner_companies_id'],'po');
    	$reference_number = isset($next_ref['full_next_ref_no'])?$next_ref['full_next_ref_no']:'';
    	if(!isset($next_ref['full_next_ref_no'])){
    		//echo 'sdfsg';die;
    		$this->Flash->error(__('The Purchase Order could not be saved.Reference number not generated .Please contact administrator.', 'Supplier Inquiry'));
			if($inquiryType=="ChemicalProduct")
    			$action="index";
    		else if($inquiryType=="PackingProduct")
    			$action="index_packing";
    		else if($inquiryType=="Asset")
    			$action="index_asset";
    		else if($inquiryType=="Consumable")
    			$action="index_consumable";
    		return $this->redirect(['action' => $action]);    	}else{
    		
    		$po_number = $next_ref['full_next_ref_no'];
    	//	echo '<pre>',print_R($supplierOffer["supplier_inquiry"]);
    		$orderdata=array(
    				"PurchaseOrder"=>array(
    					"po_date"=>date("Y-m-d"),
    					"po_number"=>$reference_number,
    					"owner_companies_id"=>$supplierOffer["owner_companies_id"],
    					"status"=>0,
    					"product_id"=>isset($supplierOffer["supplier_inquiry"]['products_master_id'])?$supplierOffer["supplier_inquiry"]['products_master_id']:'',
    					"packingMaster_id"=>isset($supplierOffer["packing_offered"])?$supplierOffer["packing_offered"]:'',
    					"grade"=>isset($supplierOffer["supplier_inquiry"]['products_master']["grade_name"])?$supplierOffer["supplier_inquiry"]['products_master']["grade_name"]:'',
    					"quantity_ordered"=>$supplierOffer["qty_offered"],
    					"balance_qty"=>$supplierOffer["qty_offered"],
    						
    					"uom_id"=>$supplierOffer["supplier_inquiry"]["uom_id"],
    					"rate"=>$supplierOffer["offer_price"],
    					"currency_id"=>$supplierOffer["currency_id"],
    					"inco_terms_id"=>$supplierOffer["inco_terms"],
    					"supplier_id"=>$supplierOffer["supplier_company_id"],
    					"total_order_price"=>$supplierOffer["total_order_value"],
    					"supplier_offer_id"=>$supplierOffer["id"],
    					"payment_terms"=>	$supplierOffer["payment_terms"],
    					'is_local'=>$supplierOffer["supplier_inquiry"]['is_local'],
    					'purchase_type'=>$supplierOffer["offer_type"],
    					'created_by'=>$this->request->session()->read('Auth.User.id'),
    					'purchase_order_products'=>$orderdataproduct,
    				    
    					)
    				);
    		$this->loadModel('PurchaseOrder');
    		
    		$order = $this->PurchaseOrder->newEntity();
    		$purchaseOrder = $this->PurchaseOrder->patchEntity($order, $orderdata);
            //debug($purchaseOrder);exit;
    		if ($this->PurchaseOrder->save($purchaseOrder)) {
    			
    		//	echo 'ppp';die;
    			$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
    			 
    			//staus update
    			$data = array('id' => $id , 'status' => 1);
    			 
    			$this->SupplierOffer->patchEntity($supplierOffer,$data);
    			$this->SupplierOffer->save($supplierOffer);
    			 
    		//	echo 'sdfdfs';die;
    			$this->Flash->success(__('The {0} has been saved.', 'Supplier Offer'));
    			if($inquiryType=="ChemicalProduct")
    				$action="index";
    			else if($inquiryType=="PackingProduct")
    				$action="index_packing";
    			else if($inquiryType=="Asset")
    				$action="index_asset";
    			else if($inquiryType=="Consumable")
    				$action="index_consumable";
    			return $this->redirect(['controller'=>'purchase-order','action' => $action]);
    							
    			//return $this->redirect(['action' => 'index']);
    		} else {
    			
    			echo 'else';die;
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Offer'));
    		}
    	}
    	
    	
    	
    

    }
    public function rejectOffer($id=null,$inquiryType=null){
    	
    	$supplierOffer = $this->SupplierOffer->get($id, [
    			'fields'=>['id','status'],
    			'contain' => []
    	]);
    	 
    	$data = array('id' => $id , 'status' => 2);
    	 
    	if($this->SupplierOffer->patchEntity($supplierOffer,$data)){
    		$this->SupplierOffer->save($supplierOffer);
	         $this->Flash->success(__('The {0} has been Rejected.', 'Supplier Offer'));
	         if($inquiryType=="ChemicalProduct")
	         		$action="index";
	         else if($inquiryType=="PackingProduct")
	         		$action="index_packing";
	         else if($inquiryType=="Asset")
	         		$action="index_asset";
	         else if($inquiryType=="Consumable")
	         			$action="index_consumable";
    		return $this->redirect(['action' => $action]);
    	}else{
    		$this->Flash->error(__('Unable to reject offer . Please try again', 'Supplier Offer'));
    		
    	}
    }

    /**
     * Edit method
     *
     * @param string|null $id Supplier Offer id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
    	
    	
    	$supplierOffer = $this->SupplierOffer->get($id, [
    			/* 'fields'=>['OwnerCompanies.Company_name','reference_number','supplier_company_id','offer_date','SupplierInquiry.qty_required','Uom.unit_symbol','SupplierInquiry.validity_of_inquiry','ProductsMaster.product_name','id','status','SupplierInquiry.company_ids',
    					'ProductsMaster.cas_no','ProductsMaster.grade_name','PaymentTerm.term','DeliveryTerm.term','offer_validity','IncoTerms.inco_term',
    					'supplier_company_id','SupplierInquiry.company_contact_persons',
    					'qty_offered','offer_price','total_order_value','SupplierInquiry.company_ids','SupplierInquiry.date_of_creation',
    					'packing_offered','inco_terms','delivery_terms','payment_terms','currency_id',
    					'SupplierInquiry.is_local','SupplierInquiry.owner_companies_id','SupplierInquiry.packingMaster_id','SelectedProductSpecs.product_data_tests_id'
    	
    			], */
    			 
    			'contain' => ['SupplierInquiry','SupplierInquiry.ProductsMaster','SupplierInquiry.CompanyMaster','SupplierInquiry.OwnerCompanies', 'SupplierInquiry.Uom', 'SupplierInquiry.Currency','SupplierInquiry.SupplierInquiryProducts','SupplierInquiry.SupplierInquiryProducts.ProductsMaster','SupplierInquiry.SupplierInquiryProducts.Uom','SupplierInquiry.SupplierInquiryProducts.PackingMaster','SupplierInquiry.SupplierInquiryProducts.PackingMaster.PackingType','IncoTerms','DeliveryTerm','PaymentTerm','SupplierOfferProducts','SupplierOfferProducts.ProductsMaster','SupplierOfferProducts.Uom','SupplierOfferProducts.PackingMaster','SupplierOfferProducts.PackingMaster.PackingType']
    	]);
  
       
        if ($this->request->is(['patch', 'post', 'put'])) {
            $supplierOffer = $this->SupplierOffer->patchEntity($supplierOffer, $this->request->data);
            if ($this->SupplierOffer->save($supplierOffer)) {
                $this->Flash->success(__('The {0} has been saved.', 'Supplier Offer'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Offer'));
            }
        }
        $companyidsval=isset($supplierOffer['supplier_inquiry']['company_ids'])?$supplierOffer['supplier_inquiry']['company_ids']:"";
        $companyids=explode(",",$companyidsval);        
         
        $this->loadModel('CompanyMaster');
        $companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons'])->toArray();
        
        $incoterms = $this->SupplierOffer->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
        $deliveryterms = $this->SupplierOffer->DeliveryTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
        $paymentterms = $this->SupplierOffer->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
      
        $this->loadModel('PackingMaster');
       
     //   echo '<pre>',print_r($supplierOffer);die;
        $optioninquirys = array(
        		'contain' => ['PackingType'],
        		'fields' => array('id','color','PackingType.packing_type','specification'),
        		'conditions' => array(
        				'PackingMaster.id' => $supplierOffer['supplier_inquiry']['packingMaster_id'],
        		),
        );
        $packingInquiryMaster = $this->PackingMaster->find('all', $optioninquirys)->toArray();
        
       // print_r($packingInquiryMaster);die;
        
        $options = array(
        		'contain' => ['PackingType'],
        		'fields' => array('id','color','PackingType.packing_type','specification'),
        		'conditions' => array(
        				'PackingMaster.id ' => $supplierOffer['packing_offered'],
        		),
        );
        $packingMaster = $this->SupplierOffer->PackingMaster->find('all', $options)->toArray();
        
       // echo '<pre>',print_r($packingMaster);die;
        
		//Get currency from cache

        $options='';
        if($supplierOffer['supplier_inquiry']->is_local==1){
        	
       		$CurrencyKey=$supplierOffer['supplier_inquiry']->owner_companies_id.'_'.'currency';
        	$currencyId = Cache::read($CurrencyKey, $config = 'default');
        	$options=array('iso_code'=>$currencyId);
        }
        $currencies = $this->SupplierOffer->Currency->find('list', ['keyField' => 'id','valueField' => 'name','conditions'=>$options,'limit' => 200]);
               
        $this->set(compact('supplierOffer','currencies','packingInquiryMaster','paymentterms','deliveryterms','incoterms','packingMaster', 'supplierInquiry','productTestData','companyMaster'));
        $this->set('_serialize', ['supplierOffer']);
    }
    
    public function editconsumable($id = null)
    {
    	 
    	 
    	$supplierOffer = $this->SupplierOffer->get($id, [
    			/* 'fields'=>['OwnerCompanies.Company_name','reference_number','supplier_company_id','offer_date','SupplierInquiry.qty_required','Uom.unit_symbol','SupplierInquiry.validity_of_inquiry','ProductsMaster.product_name','id','status','SupplierInquiry.company_ids',
    			 'ProductsMaster.cas_no','ProductsMaster.grade_name','PaymentTerm.term','DeliveryTerm.term','offer_validity','IncoTerms.inco_term',
    					'supplier_company_id','SupplierInquiry.company_contact_persons',
    					'qty_offered','offer_price','total_order_value','SupplierInquiry.company_ids','SupplierInquiry.date_of_creation',
    					'packing_offered','inco_terms','delivery_terms','payment_terms','currency_id',
    					'SupplierInquiry.is_local','SupplierInquiry.owner_companies_id','SupplierInquiry.packingMaster_id','SelectedProductSpecs.product_data_tests_id'
    					 
    			], */
    
    			'contain' => ['SupplierInquiry','SupplierInquiry.ProductsMaster','SupplierInquiry.CompanyMaster','SupplierInquiry.OwnerCompanies', 'SupplierInquiry.Uom', 'SupplierInquiry.Currency','SupplierInquiry.SupplierInquiryProducts','SupplierInquiry.SupplierInquiryProducts.ConsumablesMaster','SupplierInquiry.SupplierInquiryProducts.Uom','SupplierInquiry.SupplierInquiryProducts.PackingMaster','SupplierInquiry.SupplierInquiryProducts.PackingMaster.PackingType','IncoTerms','DeliveryTerm','PaymentTerm','SupplierOfferProducts','SupplierOfferProducts.ConsumablesMaster','SupplierOfferProducts.Uom','SupplierOfferProducts.PackingMaster','SupplierOfferProducts.PackingMaster.PackingType']
    	]);
    
    	 
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		$supplierOffer = $this->SupplierOffer->patchEntity($supplierOffer, $this->request->data);
    		//debug($supplierOffer);exit;
    		if ($this->SupplierOffer->save($supplierOffer)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Supplier Offer'));
    			return $this->redirect(['action' => 'index-consumable']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Offer'));
    		}
    	}
    	//  $producttestdataid=$supplierOffer['supplier_inquiry']['product_specifications'];
    	$this->loadModel('ProductDataTests');
    	
    
    	// $productTestData =  $this->ProductDataTests->find()->where(['id IN' => explode(",",$producttestdataid)])->toArray();
    	$companyidsval=isset($supplierOffer['supplier_inquiry']['company_ids'])?$supplierOffer['supplier_inquiry']['company_ids']:"";
    	$companyids=explode(",",$companyidsval);
    	 
    	$this->loadModel('CompanyMaster');
    	$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons'])->toArray();
    
    	$incoterms = $this->SupplierOffer->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    	$deliveryterms = $this->SupplierOffer->DeliveryTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$paymentterms = $this->SupplierOffer->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    
    	$this->loadModel('PackingMaster');
    	 
    	//   echo '<pre>',print_r($supplierOffer);die;
    	$optioninquirys = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id' => $supplierOffer['supplier_inquiry']['packingMaster_id'],
    			),
    	);
    	$packingInquiryMaster = $this->PackingMaster->find('all', $optioninquirys)->toArray();
    
    	// print_r($packingInquiryMaster);die;
    
    	$options = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id ' => $supplierOffer['packing_offered'],
    			),
    	);
    	$packingMaster = $this->SupplierOffer->PackingMaster->find('all', $options)->toArray();
    
    	// echo '<pre>',print_r($packingMaster);die;
    
    	//Get currency from cache
    
    	$options='';
    	if($supplierOffer['supplier_inquiry']->is_local==1){
    		 
    		$CurrencyKey=$supplierOffer['supplier_inquiry']->owner_companies_id.'_'.'currency';
    		$currencyId = Cache::read($CurrencyKey, $config = 'default');
    		$options=array('iso_code'=>$currencyId);
    	}
    	$currencies = $this->SupplierOffer->Currency->find('list', ['keyField' => 'id','valueField' => 'name','conditions'=>$options,'limit' => 200]);
    	$uom = $this->SupplierOffer->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	$this->set(compact('supplierOffer','uom','currencies','packingInquiryMaster','paymentterms','deliveryterms','incoterms','packingMaster', 'supplierInquiry','productTestData','companyMaster'));
    	$this->set('_serialize', ['supplierOffer']);
    }
    public function editAsset($id = null)
    {
    	 
    	 
    	$supplierOffer = $this->SupplierOffer->get($id, [
    			'fields'=>['OwnerCompanies.Company_name','reference_number','supplier_company_id','offer_date','SupplierInquiry.qty_required','Uom.unit_symbol','SupplierInquiry.validity_of_inquiry','ProductsMaster.product_name','id','status','SupplierInquiry.company_ids',
    					'ProductsMaster.cas_no','ProductsMaster.grade_name','PaymentTerm.term','DeliveryTerm.term','offer_validity','IncoTerms.inco_term','PackingMaster.specification',
    					'supplier_company_id','SupplierInquiry.company_contact_persons',
    					'qty_offered','offer_price','total_order_value','SupplierInquiry.company_ids','SupplierInquiry.date_of_creation',
    					'SupplierInquiry.packingMaster_id','inco_terms','delivery_terms','payment_terms','currency_id'
   
   
    			],
    
    			'contain' => ['SupplierInquiry','SupplierInquiry.ProductsMaster','SupplierInquiry.CompanyMaster','SupplierInquiry.OwnerCompanies', 'SupplierInquiry.Uom', 'SupplierInquiry.Currency', 'SupplierInquiry.PackingMaster','IncoTerms','DeliveryTerm','PaymentTerm']
    	]);
    
    	 
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		$supplierOffer = $this->SupplierOffer->patchEntity($supplierOffer, $this->request->data);
    		if ($this->SupplierOffer->save($supplierOffer)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Supplier Offer'));
    			return $this->redirect(['action' => 'index']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Offer'));
    		}
    	}
    		$companyidsval=isset($supplierOffer['supplier_inquiry']['company_ids'])?$supplierOffer['supplier_inquiry']['company_ids']:"";
    	$companyids=explode(",",$companyidsval);
    	 
    	$this->loadModel('CompanyMaster');
    	$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons'])->toArray();
    
    	$incoterms = $this->SupplierOffer->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    	$deliveryterms = $this->SupplierOffer->DeliveryTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$paymentterms = $this->SupplierOffer->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    
    	$options = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id ' => $supplierOffer['supplier_inquiry']['packingMaster_id'],
    			),
    	);
    	$packingMaster = $this->SupplierOffer->SupplierInquiry->PackingMaster->find('all', $options)->toArray();
    	 
    
    	//Get currency from cache
    
    	$options='';
    	if($supplierOffer['supplier_inquiry']->is_local==1){
    		 
    		$CurrencyKey=$supplierOffer['supplier_inquiry']->owner_companies_id.'_'.'currency';
    		$currencyId = Cache::read($CurrencyKey, $config = 'default');
    		$options=array('id'=>$currencyId);
    	}
    	$currencies = $this->SupplierOffer->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','conditions'=>$options,'limit' => 200]);
    	 
    	$this->set(compact('supplierOffer','currencies','paymentterms','deliveryterms','incoterms','packingMaster', 'supplierInquiry','productTestData','companyMaster'));
    	$this->set('_serialize', ['supplierOffer']);
    }
    public function editPacking($id = null)
    {
    	 
    	 
    	$supplierOffer = $this->SupplierOffer->get($id, [
    			'fields'=>['OwnerCompanies.Company_name','reference_number','supplier_company_id','offer_date','SupplierInquiry.qty_required','Uom.unit_symbol','SupplierInquiry.validity_of_inquiry','id','status','SupplierInquiry.company_ids',
    					  'PaymentTerm.term','DeliveryTerm.term','offer_validity','IncoTerms.inco_term','PackingMaster.specification','PackingType.packing_type','PackingSubtype.sub_type',
    					'supplier_company_id','SupplierInquiry.company_contact_persons','SupplierInquiry.is_local',
    					'qty_offered','offer_price','total_order_value','SupplierInquiry.company_ids','SupplierInquiry.date_of_creation',
    					'inco_terms','delivery_terms','payment_terms','currency_id','SupplierInquiry.owner_companies_id',
     	 				'PackingMaster.paking_type_id','PackingMaster.packing_subtype_id','PackingMaster.specification','SupplierInquiry.packingMaster_id','PackingMaster.description','PackingMaster.color',
    					
   
    			],
    
    			'contain' => ['SupplierInquiry','SupplierInquiry.CompanyMaster','SupplierInquiry.OwnerCompanies', 'SupplierInquiry.Uom', 'SupplierInquiry.Currency', 'SupplierInquiry.PackingMaster','IncoTerms','DeliveryTerm','PaymentTerm','PackingMaster','PackingMaster.PackingType','PackingMaster.PackingSubtype']
    	]);
    
    	 //debug($this->request->data);exit;
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		$supplierOffer = $this->SupplierOffer->patchEntity($supplierOffer, $this->request->data);
    		if ($this->SupplierOffer->save($supplierOffer)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Supplier Offer'));
    			return $this->redirect(['action' => 'index_packing']);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Supplier Offer'));
    		}
    	}
    	$companyidsval=isset($supplierOffer['supplier_inquiry']['company_ids'])?$supplierOffer['supplier_inquiry']['company_ids']:"";
    	$companyids=explode(",",$companyidsval);
    	 
    	$this->loadModel('CompanyMaster');
    	$companyMaster =  $this->CompanyMaster->find()->where(['CompanyMaster.id IN' => $companyids])->contain(['CompanyContactPersons'])->toArray();
    	$this->loadModel('PackingType');
    	$this->loadModel('PackingSubtype');
    	//$this->loadModel('PackingMaster');
    	 
    	
    	$packingtype = $this->PackingType->find('list',['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type'], ['limit' => 200]);
    	$packingsubtype = $this->PackingSubtype->find('list',['keyField' => 'id','valueField' => 'sub_type'], ['limit' => 200]);
    //	$currency = $this->SupplierInquiry->Currency->find('list', ['limit' => 200]);
    //	$packingMaster = $this->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    	//	
    	$incoterms = $this->SupplierOffer->IncoTerms->find('list', ['keyField' => 'id','valueField' => 'inco_term','limit' => 200]);
    	$deliveryterms = $this->SupplierOffer->DeliveryTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    	$paymentterms = $this->SupplierOffer->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','limit' => 200]);
    
    	$options = array(
    			'contain' => ['PackingType'],
    			'fields' => array('id','color','PackingType.packing_type','specification'),
    			'conditions' => array(
    					'PackingMaster.id ' => $supplierOffer['supplier_inquiry']['packingMaster_id'],
    			),
    	);
    	//$packingMaster = $this->SupplierOffer->SupplierInquiry->PackingMaster->find('all', $options)->toArray();
    	$packingMaster = $this->SupplierOffer->SupplierInquiry->PackingMaster->find('list', ['keyField' => 'id','valueField' => 'specification','order'=>'specification'], ['limit' => 200]);
    	   
    
    	//Get currency from cache
    
    	$options='';
    	if($supplierOffer['supplier_inquiry']->is_local==1){
    		 
    	    $CurrencyKey=$supplierOffer['supplier_inquiry']->owner_companies_id.'_'.'currency';
    		$currencyId = Cache::read($CurrencyKey, $config = 'default');
    		$options=array('iso_code'=>$currencyId);
    	}
    	$currencies = $this->SupplierOffer->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','conditions'=>$options,'limit' => 200]);
    	 
    	$this->set(compact('supplierOffer','currencies','packingtype','packingsubtype','paymentterms','deliveryterms','incoterms','packingMaster', 'supplierInquiry','productTestData','companyMaster'));
    	$this->set('_serialize', ['supplierOffer']);
    }
    /**
     * Delete method
     *
     * @param string|null $id Supplier Offer id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $supplierOffer = $this->SupplierOffer->get($id);
        if ($this->SupplierOffer->delete($supplierOffer)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Supplier Offer'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Supplier Offer'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
