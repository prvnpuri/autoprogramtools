<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PostshipmentTransporter Controller
 *
 * @property \App\Model\Table\PostshipmentTransporterTable $PostshipmentTransporter
 *
 * @method \App\Model\Entity\PostshipmentTransporter[] paginate($object = null, array $settings = [])
 */
class PostshipmentTransporterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Oas', 'Companies', 'Currencies', 'InOutWards', 'Purchases', 'Inwards', 'Products', 'Uoms']
        ];
        $postshipmentTransporter = $this->paginate($this->PostshipmentTransporter);

        $this->set(compact('postshipmentTransporter'));
        $this->set('_serialize', ['postshipmentTransporter']);
    }

    /**
     * View method
     *
     * @param string|null $id Postshipment Transporter id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $postshipmentTransporter = $this->PostshipmentTransporter->get($id, [
            'contain' => ['Oas', 'Companies', 'Currencies', 'InOutWards', 'Purchases', 'Inwards', 'Products', 'Uoms']
        ]);

        $this->set('postshipmentTransporter', $postshipmentTransporter);
        $this->set('_serialize', ['postshipmentTransporter']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $postshipmentTransporter = $this->PostshipmentTransporter->newEntity();
        if ($this->request->is('post')) {
            $postshipmentTransporter = $this->PostshipmentTransporter->patchEntity($postshipmentTransporter, $this->request->data);
            if ($this->PostshipmentTransporter->save($postshipmentTransporter)) {
                $this->Flash->success(__('The {0} has been saved.', 'Postshipment Transporter'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Postshipment Transporter'));
            }
        }
        $oas = $this->PostshipmentTransporter->Oas->find('list', ['limit' => 200]);
        $companies = $this->PostshipmentTransporter->Companies->find('list', ['limit' => 200]);
        $currencies = $this->PostshipmentTransporter->Currencies->find('list', ['limit' => 200]);
        $inOutWards = $this->PostshipmentTransporter->InOutWards->find('list', ['limit' => 200]);
        $purchases = $this->PostshipmentTransporter->Purchases->find('list', ['limit' => 200]);
        $inwards = $this->PostshipmentTransporter->Inwards->find('list', ['limit' => 200]);
        $products = $this->PostshipmentTransporter->Products->find('list', ['limit' => 200]);
        $uoms = $this->PostshipmentTransporter->Uoms->find('list', ['limit' => 200]);
        $this->set(compact('postshipmentTransporter', 'oas', 'companies', 'currencies', 'inOutWards', 'purchases', 'inwards', 'products', 'uoms'));
        $this->set('_serialize', ['postshipmentTransporter']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Postshipment Transporter id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $postshipmentTransporter = $this->PostshipmentTransporter->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $postshipmentTransporter = $this->PostshipmentTransporter->patchEntity($postshipmentTransporter, $this->request->data);
            if ($this->PostshipmentTransporter->save($postshipmentTransporter)) {
                $this->Flash->success(__('The {0} has been saved.', 'Postshipment Transporter'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Postshipment Transporter'));
            }
        }
        $oas = $this->PostshipmentTransporter->Oas->find('list', ['limit' => 200]);
        $companies = $this->PostshipmentTransporter->Companies->find('list', ['limit' => 200]);
        $currencies = $this->PostshipmentTransporter->Currencies->find('list', ['limit' => 200]);
        $inOutWards = $this->PostshipmentTransporter->InOutWards->find('list', ['limit' => 200]);
        $purchases = $this->PostshipmentTransporter->Purchases->find('list', ['limit' => 200]);
        $inwards = $this->PostshipmentTransporter->Inwards->find('list', ['limit' => 200]);
        $products = $this->PostshipmentTransporter->Products->find('list', ['limit' => 200]);
        $uoms = $this->PostshipmentTransporter->Uoms->find('list', ['limit' => 200]);
        $this->set(compact('postshipmentTransporter', 'oas', 'companies', 'currencies', 'inOutWards', 'purchases', 'inwards', 'products', 'uoms'));
        $this->set('_serialize', ['postshipmentTransporter']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Postshipment Transporter id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $postshipmentTransporter = $this->PostshipmentTransporter->get($id);
        if ($this->PostshipmentTransporter->delete($postshipmentTransporter)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Postshipment Transporter'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Postshipment Transporter'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
