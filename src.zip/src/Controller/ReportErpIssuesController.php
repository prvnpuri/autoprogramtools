<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ReportErpIssues Controller
 *
 * @property \App\Model\Table\ReportErpIssuesTable $ReportErpIssues
 *
 * @method \App\Model\Entity\ReportErpIssue[] paginate($object = null, array $settings = [])
 */
class ReportErpIssuesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $reportErpIssues = $this->paginate($this->ReportErpIssues);

        $this->set(compact('reportErpIssues'));
        $this->set('_serialize', ['reportErpIssues']);
    }

    /**
     * View method
     *
     * @param string|null $id Report Erp Issue id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $reportErpIssue = $this->ReportErpIssues->get($id, [
            'contain' => []
        ]);

        $this->set('reportErpIssue', $reportErpIssue);
        $this->set('_serialize', ['reportErpIssue']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $reportErpIssue = $this->ReportErpIssues->newEntity();
        if ($this->request->is('post')) {
            $reportErpIssue = $this->ReportErpIssues->patchEntity($reportErpIssue, $this->request->data);
            if ($this->ReportErpIssues->save($reportErpIssue)) {
                $this->Flash->success(__('The {0} has been saved.', 'Report Erp Issue'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Report Erp Issue'));
            }
        }
        $this->set(compact('reportErpIssue'));
        $this->set('_serialize', ['reportErpIssue']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Report Erp Issue id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $reportErpIssue = $this->ReportErpIssues->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $reportErpIssue = $this->ReportErpIssues->patchEntity($reportErpIssue, $this->request->data);
            if ($this->ReportErpIssues->save($reportErpIssue)) {
                $this->Flash->success(__('The {0} has been saved.', 'Report Erp Issue'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Report Erp Issue'));
            }
        }
        $this->set(compact('reportErpIssue'));
        $this->set('_serialize', ['reportErpIssue']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Report Erp Issue id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $reportErpIssue = $this->ReportErpIssues->get($id);
        if ($this->ReportErpIssues->delete($reportErpIssue)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Report Erp Issue'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Report Erp Issue'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
