<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * VisitCustomerRepresentatives Controller
 *
 * @property \App\Model\Table\VisitCustomerRepresentativesTable $VisitCustomerRepresentatives
 *
 * @method \App\Model\Entity\VisitCustomerRepresentative[] paginate($object = null, array $settings = [])
 */
class VisitCustomerRepresentativesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['SubsequentVisits']
        ];
        $visitCustomerRepresentatives = $this->paginate($this->VisitCustomerRepresentatives);

        $this->set(compact('visitCustomerRepresentatives'));
        $this->set('_serialize', ['visitCustomerRepresentatives']);
    }

    /**
     * View method
     *
     * @param string|null $id Visit Customer Representative id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $visitCustomerRepresentative = $this->VisitCustomerRepresentatives->get($id, [
            'contain' => ['SubsequentVisits']
        ]);

        $this->set('visitCustomerRepresentative', $visitCustomerRepresentative);
        $this->set('_serialize', ['visitCustomerRepresentative']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $visitCustomerRepresentative = $this->VisitCustomerRepresentatives->newEntity();
        if ($this->request->is('post')) {
            $visitCustomerRepresentative = $this->VisitCustomerRepresentatives->patchEntity($visitCustomerRepresentative, $this->request->data);
            if ($this->VisitCustomerRepresentatives->save($visitCustomerRepresentative)) {
                $this->Flash->success(__('The {0} has been saved.', 'Visit Customer Representative'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Visit Customer Representative'));
            }
        }
        $subsequentVisits = $this->VisitCustomerRepresentatives->SubsequentVisits->find('list', ['limit' => 200]);
        $this->set(compact('visitCustomerRepresentative', 'subsequentVisits'));
        $this->set('_serialize', ['visitCustomerRepresentative']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Visit Customer Representative id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $visitCustomerRepresentative = $this->VisitCustomerRepresentatives->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $visitCustomerRepresentative = $this->VisitCustomerRepresentatives->patchEntity($visitCustomerRepresentative, $this->request->data);
            if ($this->VisitCustomerRepresentatives->save($visitCustomerRepresentative)) {
                $this->Flash->success(__('The {0} has been saved.', 'Visit Customer Representative'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Visit Customer Representative'));
            }
        }
        $subsequentVisits = $this->VisitCustomerRepresentatives->SubsequentVisits->find('list', ['limit' => 200]);
        $this->set(compact('visitCustomerRepresentative', 'subsequentVisits'));
        $this->set('_serialize', ['visitCustomerRepresentative']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Visit Customer Representative id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $visitCustomerRepresentative = $this->VisitCustomerRepresentatives->get($id);
        if ($this->VisitCustomerRepresentatives->delete($visitCustomerRepresentative)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Visit Customer Representative'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Visit Customer Representative'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
