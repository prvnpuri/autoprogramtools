<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * DeliveryTerm Controller
 *
 * @property \App\Model\Table\DeliveryTermTable $DeliveryTerm
 *
 * @method \App\Model\Entity\DeliveryTerm[] paginate($object = null, array $settings = [])
 */
class DeliveryTermController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="DeliveryTerm.term like '%$query%'";
    	}
    	$this->paginate = [
    			
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","term"]
    	];
    	
    	$deliveryTerm = $this->paginate($this->DeliveryTerm);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('deliveryTerm'));
    	$this->set( '_serialize', ['deliveryTerm','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Delivery Term id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $deliveryTerm = $this->DeliveryTerm->get($id, [
            'contain' => []
        ]);

        $this->set('deliveryTerm', $deliveryTerm);
        $this->set('_serialize', ['deliveryTerm']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $deliveryTerm = $this->DeliveryTerm->newEntity();
        if ($this->request->is('post')) {
            $deliveryTerm = $this->DeliveryTerm->patchEntity($deliveryTerm, $this->request->data);
            if ($this->DeliveryTerm->save($deliveryTerm)) {
                $this->Flash->success(__('The {0} has been saved.', 'Delivery Term'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Delivery Term'));
            }
        }
        $this->set(compact('deliveryTerm'));
        $this->set('_serialize', ['deliveryTerm']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Delivery Term id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $deliveryTerm = $this->DeliveryTerm->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $deliveryTerm = $this->DeliveryTerm->patchEntity($deliveryTerm, $this->request->data);
            if ($this->DeliveryTerm->save($deliveryTerm)) {
                $this->Flash->success(__('The {0} has been saved.', 'Delivery Term'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Delivery Term'));
            }
        }
        $this->set(compact('deliveryTerm'));
        $this->set('_serialize', ['deliveryTerm']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Delivery Term id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $deliveryTerm = $this->DeliveryTerm->get($id);
        if ($this->DeliveryTerm->delete($deliveryTerm)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Delivery Term'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Delivery Term'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
