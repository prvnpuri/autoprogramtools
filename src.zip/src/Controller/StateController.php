<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * State Controller
 *
 * @property \App\Model\Table\StateTable $State
 *
 * @method \App\Model\Entity\State[] paginate($object = null, array $settings = [])
 */
class StateController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="State.state_name like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['Countries'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","state_name","Countries.country_name","state_code","state_initial"]
    	];
    	
    	$state = $this->paginate($this->State);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('state'));
    	$this->set( '_serialize', ['state','paging']);
    	
    }

    /**
     * View method
     *
     * @param string|null $id State id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $state = $this->State->get($id, [
            'contain' => ['Countries', 'City', 'CommercialStateInfo', 'ProformaInvoice']
        ]);

        $this->set('state', $state);
        $this->set('_serialize', ['state']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $state = $this->State->newEntity();
        if ($this->request->is('post')) {
            $state = $this->State->patchEntity($state, $this->request->data);
            if ($this->State->save($state)) {
                $this->Flash->success(__('The {0} has been saved.', 'State'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'State'));
            }
        }
        $countries = $this->State->Countries->find('list',['keyField' => 'id','valueField' => 'country_name','order'=>'country_name'], ['limit' => 200]);
        $this->set(compact('state', 'countries'));
        $this->set('_serialize', ['state']);
    }

    /**
     * Edit method
     *
     * @param string|null $id State id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $state = $this->State->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $state = $this->State->patchEntity($state, $this->request->data);
            if ($this->State->save($state)) {
                $this->Flash->success(__('The {0} has been saved.', 'State'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'State'));
            }
        }
        $countries = $this->State->Countries->find('list',['keyField' => 'id','valueField' => 'country_name','order'=>'country_name'], ['limit' => 200]);
        $this->set(compact('state', 'countries'));
        $this->set('_serialize', ['state']);
    }

    /**
     * Delete method
     *
     * @param string|null $id State id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $state = $this->State->get($id);
        if ($this->State->delete($state)) {
            $this->Flash->success(__('The {0} has been deleted.', 'State'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'State'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
