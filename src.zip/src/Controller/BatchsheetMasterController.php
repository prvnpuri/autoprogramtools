<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * BatchsheetMaster Controller
 *
 * @property \App\Model\Table\BatchsheetMasterTable $BatchsheetMaster
 *
 * @method \App\Model\Entity\BatchsheetMaster[] paginate($object = null, array $settings = [])
 */
class BatchsheetMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
        		'contain' => ['ProductsMaster'],
        ];
        $batchsheetMaster = $this->paginate($this->BatchsheetMaster);

        $this->set(compact('batchsheetMaster'));
        $this->set('_serialize', ['batchsheetMaster']);
    }

    /**
     * View method
     *
     * @param string|null $id Batchsheet Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $batchsheetMaster = $this->BatchsheetMaster->get($id, [
            'contain' => ['ProductsMaster', 'BatchsheetStepsMaster', 'BatchsheetTran']
        ]);

        $this->set('batchsheetMaster', $batchsheetMaster);
        $this->set('_serialize', ['batchsheetMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
    	$batchsheetMaster = $this->BatchsheetMaster->newEntity();
        if ($this->request->is('post')) {
        	$batchsheetMaster = $this->BatchsheetMaster->patchEntity($batchsheetMaster, $this->request->getData(),
            		[
            				'associated' => ['BatchsheetStepsMaster', 'ReferenceBom']
            		]);
        	//$this->log("BatchSheet Master : Add - patched data: ".print_r($batchsheetMaster,true),'debug');
        	
            if ($this->BatchsheetMaster->save($batchsheetMaster)) {
            	
            	$this->Flash->success(__('The {0} has been saved.', 'Batchsheet Master'));
                return $this->redirect(['action' => 'index']);
            } else {     	
            	//$this->log("BatchSheet Master : Add - patched data: ".print_r($batchsheetMaster,true),'debug');
            	$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Batchsheet Master'));
            }
        }
     
        $this->loadModel('ProductsMaster');
        $this->loadModel('Uom');
        $uomObj = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol',
        		'order'=>'unit_symbol', 'groupField' => 'unit_type']);
        $uom = $uomObj->toArray();
        $this->set(compact('batchsheetMaster', 'productsMaster','uom'));
        $this->set('_serialize', ['batchsheetMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Batchsheet Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $batchsheetMaster = $this->BatchsheetMaster->get($id, [
        		'contain' => ['ProductsMaster' => ['fields' => ['id','product_name','grade_name', 'cas_no']],
            		'BatchsheetStepsMaster','ReferenceBom',
        				'ReferenceBom.ProductsMaster' => ['fields' => ['id','product_name','grade_name', 'cas_no']]
        ]]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $batchsheetMaster = $this->BatchsheetMaster->patchEntity($batchsheetMaster, $this->request->getData(),
            		[
            				'associated' => ['BatchsheetStepsMaster', 'ReferenceBom']
            		]);
            $this->log("BatchSheet Master : Edit - patched data: ".print_r($batchsheetMaster,true),'debug');
            if ($this->BatchsheetMaster->save($batchsheetMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Batchsheet Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Batchsheet Master'));
            }
        }
        
        $this->loadModel('ProductsMaster');
        $this->loadModel('Uom');
        $uomObj = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol',
        		'order'=>'unit_symbol', 'groupField' => 'unit_type']);
        $uom = $uomObj->toArray();
        $this->set(compact('batchsheetMaster', 'productsMaster','uom'));
        $this->set('_serialize', ['batchsheetMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Batchsheet Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $batchsheetMaster = $this->BatchsheetMaster->get($id);
        if ($this->BatchsheetMaster->delete($batchsheetMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Batchsheet Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Batchsheet Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
