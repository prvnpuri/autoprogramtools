<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PostshipmentShippingBill Controller
 *
 * @property \App\Model\Table\PostshipmentShippingBillTable $PostshipmentShippingBill
 *
 * @method \App\Model\Entity\PostshipmentShippingBill[] paginate($object = null, array $settings = [])
 */
class PostshipmentShippingBillController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Oas']
        ];
        $postshipmentShippingBill = $this->paginate($this->PostshipmentShippingBill);

        $this->set(compact('postshipmentShippingBill'));
        $this->set('_serialize', ['postshipmentShippingBill']);
    }

    /**
     * View method
     *
     * @param string|null $id Postshipment Shipping Bill id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $postshipmentShippingBill = $this->PostshipmentShippingBill->get($id, [
            'contain' => ['Oas']
        ]);

        $this->set('postshipmentShippingBill', $postshipmentShippingBill);
        $this->set('_serialize', ['postshipmentShippingBill']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $postshipmentShippingBill = $this->PostshipmentShippingBill->newEntity();
        if ($this->request->is('post')) {
            $postshipmentShippingBill = $this->PostshipmentShippingBill->patchEntity($postshipmentShippingBill, $this->request->data);
            if ($this->PostshipmentShippingBill->save($postshipmentShippingBill)) {
                $this->Flash->success(__('The {0} has been saved.', 'Postshipment Shipping Bill'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Postshipment Shipping Bill'));
            }
        }
        $oas = $this->PostshipmentShippingBill->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postshipmentShippingBill', 'oas'));
        $this->set('_serialize', ['postshipmentShippingBill']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Postshipment Shipping Bill id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $postshipmentShippingBill = $this->PostshipmentShippingBill->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $postshipmentShippingBill = $this->PostshipmentShippingBill->patchEntity($postshipmentShippingBill, $this->request->data);
            if ($this->PostshipmentShippingBill->save($postshipmentShippingBill)) {
                $this->Flash->success(__('The {0} has been saved.', 'Postshipment Shipping Bill'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Postshipment Shipping Bill'));
            }
        }
        $oas = $this->PostshipmentShippingBill->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postshipmentShippingBill', 'oas'));
        $this->set('_serialize', ['postshipmentShippingBill']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Postshipment Shipping Bill id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $postshipmentShippingBill = $this->PostshipmentShippingBill->get($id);
        if ($this->PostshipmentShippingBill->delete($postshipmentShippingBill)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Postshipment Shipping Bill'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Postshipment Shipping Bill'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
