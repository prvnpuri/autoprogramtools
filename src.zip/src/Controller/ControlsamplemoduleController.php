<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Controlsamplemodule Controller
 *
 * @property \App\Model\Table\ControlsamplemoduleTable $Controlsamplemodule
 *
 * @method \App\Model\Entity\Controlsamplemodule[] paginate($object = null, array $settings = [])
 */
class ControlsamplemoduleController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ControlSamples']
        ];
        $controlsamplemodule = $this->paginate($this->Controlsamplemodule);

        $this->set(compact('controlsamplemodule'));
        $this->set('_serialize', ['controlsamplemodule']);
    }

    /**
     * View method
     *
     * @param string|null $id Controlsamplemodule id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $controlsamplemodule = $this->Controlsamplemodule->get($id, [
            'contain' => ['ControlSamples']
        ]);

        $this->set('controlsamplemodule', $controlsamplemodule);
        $this->set('_serialize', ['controlsamplemodule']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $controlsamplemodule = $this->Controlsamplemodule->newEntity();
        if ($this->request->is('post')) {
            $controlsamplemodule = $this->Controlsamplemodule->patchEntity($controlsamplemodule, $this->request->data);
            if ($this->Controlsamplemodule->save($controlsamplemodule)) {
                $this->Flash->success(__('The {0} has been saved.', 'Controlsamplemodule'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Controlsamplemodule'));
            }
        }
        $controlSamples = $this->Controlsamplemodule->ControlSamples->find('list', ['limit' => 200]);
        $this->set(compact('controlsamplemodule', 'controlSamples'));
        $this->set('_serialize', ['controlsamplemodule']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Controlsamplemodule id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $controlsamplemodule = $this->Controlsamplemodule->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $controlsamplemodule = $this->Controlsamplemodule->patchEntity($controlsamplemodule, $this->request->data);
            if ($this->Controlsamplemodule->save($controlsamplemodule)) {
                $this->Flash->success(__('The {0} has been saved.', 'Controlsamplemodule'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Controlsamplemodule'));
            }
        }
        $controlSamples = $this->Controlsamplemodule->ControlSamples->find('list', ['limit' => 200]);
        $this->set(compact('controlsamplemodule', 'controlSamples'));
        $this->set('_serialize', ['controlsamplemodule']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Controlsamplemodule id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $controlsamplemodule = $this->Controlsamplemodule->get($id);
        if ($this->Controlsamplemodule->delete($controlsamplemodule)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Controlsamplemodule'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Controlsamplemodule'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
