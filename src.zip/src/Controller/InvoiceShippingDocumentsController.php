<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Network\Exception\NotFoundException;
use Cake\Log\Log;
use Cake\Cache\Cache;
use Aura\Intl\Exception;


/**
 * InvoiceShippingDocuments Controller
 *
 * @property \App\Model\Table\InvoiceShippingDocumentsTable $InvoiceShippingDocuments
 *
 * @method \App\Model\Entity\InvoiceShippingDocument[] paginate($object = null, array $settings = [])
 */
class InvoiceShippingDocumentsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'CompanyMaster', 'InternationalTransporterCompanies']
        ];
        $invoiceShippingDocuments = $this->paginate($this->InvoiceShippingDocuments);

        $this->set(compact('invoiceShippingDocuments'));
        $this->set('_serialize', ['invoiceShippingDocuments']);
    }

    /**
     * View method
     *
     * @param string|null $id Invoice Shipping Document id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function billofladingview($id = null)
    {
    	$this->loadModel('PostsipmentDocuments');
    	 
       
        $postsipmentDocument=$this->PostsipmentDocuments->find('all')
        ->select([
        		'id','is_local','bill_of_landing_no','bill_of_lading_date','bill_of_lading_ocean_vessel','bill_of_lading_port_of_loading'
        		,'bill_of_lading_voyage_number','invoice_id','bill_of_lading_port_of_discharge','bill_of_lading_container_no','bill_of_lading_seal_no',
        		'bill_of_lading_quantity'
        ])
        ->contain([
        		'Invoices'=> function ($q) {
        		return $q
        		->select([
        				'Invoices.id','Invoices.invoice_no'
        		]);
        		 
        		},
        		'OwnerCompanies'=> function ($q) {
	        		return $q
	        		->select([
	        				'OwnerCompanies.id','OwnerCompanies.Company_name'
	        		]);
        		}
        		 
        		])
        		->where(['PostsipmentDocuments.id'=>$id])
        		->first();	
        	
        		
        $this->set('postsipmentDocument', $postsipmentDocument);
        $this->set('_serialize', ['postsipmentDocument']);
    } 
    public function bankremitanceview($id = null)
    {
    	$this->loadModel('PostsipmentDocuments');
    
    	 
    	$postsipmentDocument=$this->PostsipmentDocuments->find('all')
    	->select([
    			'id','is_local','remitance_sr_no','remitance_date','remitance_inward_ref_no','remitance_credit_to_account_no'
    			,'remitance_remark','invoice_id','remitance_remitter','remitance_branch','remitance_bank_id',
    			'remitance_ref_no','remitance_amount','remitance_favouring_company','remitance_exchange_rate'
    	])
    	->contain([
    			'Invoices'=> function ($q) {
    			return $q
    			->select([
    					'Invoices.id','Invoices.invoice_no'
    			]);
    			 
    			},
    			'OwnerCompanies'=> function ($q) {
    			return $q
    			->select([
    					'OwnerCompanies.id','OwnerCompanies.Company_name'
    			]);
    			}
    			 
    			])
    			->where(['PostsipmentDocuments.id'=>$id])
    			->first();
    			 
    
    			$this->set('postsipmentDocument', $postsipmentDocument);
    			$this->set('_serialize', ['postsipmentDocument']);
    }
    public function shippingbillview($id = null)
    {
    	$this->loadModel('PostsipmentDocuments');
    
    
    	$postsipmentDocument=$this->PostsipmentDocuments->find('all')
    	->select([
    			'id','is_local','shipping_bill_leo_no','shipping_bill_sb_no','shipping_bill_brc_realisation_date','shipping_bill_cha'
    			,'shipping_bill_port_of_ldg_code','invoice_id','shipping_bill_amount_qty','shipping_bill_duty_drawback_amount','shipping_bill_total',
    	])
    	->contain([
    			'Invoices'=> function ($q) {
    			return $q
    			->select([
    					'Invoices.id','Invoices.invoice_no'
    			]);
    
    			},
    			'OwnerCompanies'=> function ($q) {
    			return $q
    			->select([
    					'OwnerCompanies.id','OwnerCompanies.Company_name'
    			]);
    			}
    
    			])
    			->where(['PostsipmentDocuments.id'=>$id])
    			->first();
    
    
    			$this->set('postsipmentDocument', $postsipmentDocument);
    			$this->set('_serialize', ['postsipmentDocument']);
    }
    
    public function bankrealisationview($id = null)
    {
    	$this->loadModel('PostsipmentDocuments');
    
    
    	$postsipmentDocument=$this->PostsipmentDocuments->find('all')
    	->select([
    			'id','is_local','bank_realisation_firm_id','bank_realisation_iec','bank_realisation_shipping_bill_no','bank_realisation_shipping_bill_date'
    			,'bank_realisation_bank_id','invoice_id','bank_realisation_bank_file_no','bank_realisation_bill_id_no','bank_realisation_certificate_no',
    			'date_of_realisation_of_money_by_bank','realised_value_in_foreign_currency','currency_of_realisation'
    	])
    	->contain([
    			'Invoices'=> function ($q) {
    			return $q
    			->select([
    					'Invoices.id','Invoices.invoice_no'
    			]);
    
    			},
    			'OwnerCompanies'=> function ($q) {
    			return $q
    			->select([
    					'OwnerCompanies.id','OwnerCompanies.Company_name'
    			]);
    			}
    
    			])
    			->where(['PostsipmentDocuments.id'=>$id])
    			->first();
    
    
    			$this->set('postsipmentDocument', $postsipmentDocument);
    			$this->set('_serialize', ['postsipmentDocument']);
    }
    public function insurancepolicyview($id = null)
    {
    	$this->loadModel('PostsipmentDocuments');
    
    
    	$postsipmentDocument=$this->PostsipmentDocuments->find('all')
    	->select([
    			'id','is_local','insurance_policy_policy_no','insurance_policy_code','insurance_policy_collection_no','insurance_policy_collection_date'
    			,'insurance_policy_voyage','invoice_id','insurance_policy_mode_of_transport','insurance_policy_date','insurance_policy_commodity','insurance_policy_sum_insured',
    			'insurance_policy_rate','insurance_policy_marine_premium','insurance_policy_place','insurance_policy_total_amount'
    	])
    	->contain([
    			'Invoices'=> function ($q) {
    			return $q
    			->select([
    					'Invoices.id','Invoices.invoice_no'
    			]);
    
    			},
    			'OwnerCompanies'=> function ($q) {
    			return $q
    			->select([
    					'OwnerCompanies.id','OwnerCompanies.Company_name'
    			]);
    			}
    
    			])
    			->where(['PostsipmentDocuments.id'=>$id])
    			->first();
    
    
    			$this->set('postsipmentDocument', $postsipmentDocument);
    			$this->set('_serialize', ['postsipmentDocument']);
    }
    public function internationaltransporterview($id = null)
    {
    	$this->loadModel('PostsipmentDocuments');
    
    	 
    	$postsipmentDocument=$this->PostsipmentDocuments->find('all')
    	->select([
    			'id','is_local','international_transporter_company_id','international_transporter_product_id','international_transporter_quantity','international_transporter_from_locaton'
    			,'international_transporter_to_location','invoice_id','international_transporter_bill_no','international_transporter_bill_date','international_transporter_frieght_amt',
    			'international_transporter_thc_amt','international_transporter_total_amt'
    	])
    	->contain([
    			'Invoices'=> function ($q) {
    			return $q
    			->select([
    					'Invoices.id','Invoices.invoice_no'
    			]);
    			 
    			},
    			'OwnerCompanies'=> function ($q) {
    			return $q
    			->select([
    					'OwnerCompanies.id','OwnerCompanies.Company_name'
    			]);
    			}
    			 
    			])
    			->where(['PostsipmentDocuments.id'=>$id])
    			->first();
    			 
    
    			$this->set('postsipmentDocument', $postsipmentDocument);
    			$this->set('_serialize', ['postsipmentDocument']);
    }
    
    
    public function nonhazview($id = null,$requiredReturn=null) {
    
        /* $invoiceShippingDocument = $this->InvoiceShippingDocuments->get($id, [
            'contain' => ['Invoices', 'CompanyMaster']
        ]); */
        
        $invoiceShippingDocument=$this->InvoiceShippingDocuments->find('all')
        ->select([
        		'id','is_local','non_haz_awb_no','non_haz_date','invoice_id'
        ])
        ->contain([
        		'Invoices' => function($q) {
	        		return $q
	        		->select([
	        				'id','is_local','invoice_no','invoice_date'
	        		])
	        		->contain([
	        				'InvoiceProducts' => function($q) {
	        				return $q
	        				->select([
	        						'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.product_id','InvoiceProducts.order_id','InvoiceProducts.kind_of_pkg','marks_nos'
	        				])
	        				->contain([
	        						'ProductsMaster' => function($q) {
	        						return $q
	        						->select([
	        								'ProductsMaster.id', 'ProductsMaster.product_name','ProductsMaster.cas_no','ProductsMaster.hs_code'
	        						]);
	        						},
	        						'Order' => function($q) {
	        						return $q
	        						->select([
	        								'Order.id', 'Order.order_no','Order.order_date'
	        						]);
	        						}
	        						 
	        						]);
	        				 
	        				},
	        				
        			]);
        		},        		
        		
        		'OwnerCompanies'=> function ($q) {
        		return $q
        		->select([
        				'OwnerCompanies.id','OwnerCompanies.Company_name'
        		])
        		->contain([
    						'OwnerCompanyOffices' => function($q) {
    						return $q
    						->select([
    								'OwnerCompanyOffices.id','OwnerCompanyOffices.phone_no','OwnerCompanyOffices.postal_code','OwnerCompanyOffices.name', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
    						])
    						->contain([
    								'City' => function($q) {
    								return $q
    								->select([
    										'City.city_name'
    								]);
    								}
    								])
    								->contain([
    										'Countries' => function($q) {
    										return $q
    										->select([
    												'Countries.country_name'
    										]);
    										}
    										])
    										->contain([
    												'State' => function($q) {
    												return $q
    												->select([
    														'State.state_name'
    												]);
    												}
    												]);
    						}
    						]);
        		 
        		},
        		'CompanyMaster'=> function ($q) {
        		return $q
        		->select([
        				'CompanyMaster.id','CompanyMaster.Company_name'
        		]);
        		 
        		},
        		 
        		])
        		->where(['Invoices.id'=>$id])
        		->toArray();
        
        		
        		
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
        if($requiredReturn===true){
        	return $invoiceShippingDocument;
        }
    }
    public function nonhazviewprint($id = null)
    {
    	$invoiceShippingDocument=$this->nonhazview($id,true);
              
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
    }
    public function tscaview($id = null,$requiredReturn=null) {
    
        
    	$invoiceShippingDocument=$this->InvoiceShippingDocuments->find('all')
        ->select([
        		'id','is_local','tsca_date','tsca_title','tsca_auth_sign','non_haz_awb_no','invoice_id'
        ])
        ->contain([
        		'Invoices' => function($q) {
	        		return $q
	        		->select([
	        				'id','is_local','invoice_no','invoice_date'
	        		])
	        		->contain([
	        				'InvoiceProducts' => function($q) {
	        				return $q
	        				->select([
	        						'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.product_id','InvoiceProducts.order_id','InvoiceProducts.kind_of_pkg','marks_nos'
	        				])
	        				->contain([
	        						'ProductsMaster' => function($q) {
	        						return $q
	        						->select([
	        								'ProductsMaster.id', 'ProductsMaster.product_name','ProductsMaster.cas_no','ProductsMaster.hs_code'
	        						]);
	        						},
	        						
	        						 
	        						]);
	        				 
	        				},
	        				
        			]);
        		},        		
        		
        		'OwnerCompanies'=> function ($q) {
        		return $q
        		->select([
        				'OwnerCompanies.id','OwnerCompanies.Company_name'
        		])
        		->contain([
    						'OwnerCompanyOffices' => function($q) {
    						return $q
    						->select([
    								'OwnerCompanyOffices.id','OwnerCompanyOffices.phone_no','OwnerCompanyOffices.postal_code','OwnerCompanyOffices.name', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
    						])
    						->contain([
    								'City' => function($q) {
    								return $q
    								->select([
    										'City.city_name'
    								]);
    								}
    								])
    								->contain([
    										'Countries' => function($q) {
    										return $q
    										->select([
    												'Countries.country_name'
    										]);
    										}
    										])
    										->contain([
    												'State' => function($q) {
    												return $q
    												->select([
    														'State.state_name'
    												]);
    												}
    												]);
    						}
    						]);
        		 
        		},
        		'CompanyMaster'=> function ($q) {
        		return $q
        		->select([
        				'CompanyMaster.id','CompanyMaster.Company_name'
        		]);
        		 
        		},
        		 
        		])
        		->where(['InvoiceShippingDocuments.id'=>$id])
        		->toArray();
        
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
        if($requiredReturn===true){
        	return $invoiceShippingDocument;
        }
    }
    public function sdfview($id = null,$requiredReturn=null) {
        
        
        $invoiceShippingDocument=$this->InvoiceShippingDocuments->find('all')
        ->select([
            'id','is_local','sdf_shipping_bill_no','invoice_id'
        ])
        ->contain([
            'Invoices' => function($q) {
            return $q
            ->select([
                'id','is_local','invoice_no','invoice_date'
            ]);
         
            },
            
            'OwnerCompanies'=> function ($q) {
            return $q
            ->select([
                'OwnerCompanies.id','OwnerCompanies.Company_name'
            ])
            ->contain([
                'OwnerCompanyOffices' => function($q) {
                return $q
                ->select([
                    'OwnerCompanyOffices.id','OwnerCompanyOffices.phone_no','OwnerCompanyOffices.postal_code','OwnerCompanyOffices.name', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
                ])
                ->contain([
                    'City' => function($q) {
                    return $q
                    ->select([
                        'City.city_name'
                    ]);
                    }
                    ])
                    ->contain([
                        'Countries' => function($q) {
                        return $q
                        ->select([
                            'Countries.country_name'
                        ]);
                        }
                        ])
                        ->contain([
                            'State' => function($q) {
                            return $q
                            ->select([
                                'State.state_name'
                            ]);
                            }
                            ]);
                }
                ]);
            
            },
            'CompanyMaster'=> function ($q) {
            return $q
            ->select([
                'CompanyMaster.id','CompanyMaster.Company_name'
            ]);
            
            },
            
            ])
            ->where(['InvoiceShippingDocuments.id'=>$id])
            ->toArray();
            
            $this->set('invoiceShippingDocument', $invoiceShippingDocument);
            $this->set('_serialize', ['invoiceShippingDocument']);
            if($requiredReturn===true){
                return $invoiceShippingDocument;
            }
    }
    
    
    public function sdfviewprint($id = null)
    {
        $invoiceShippingDocument=$this->nonhazview($id,true);
        
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
    }
    
    public function tscaviewprint($id = null)
    {
        $invoiceShippingDocument=$this->tscaview($id,true);
        
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
    }
    
    
    public function valuedeclarationview($id = null,$requiredReturn=null) {
        
        
        $invoiceShippingDocument=$this->InvoiceShippingDocuments->find('all')
        ->select([
            'id','is_local','val_decl_shipping_bill_no','val_decl_previous_export_bill_date','val_decl_sale','val_decl_sample','val_decl_sale_on_consignment','val_decl_gift','val_decl_other','invoice_id',
        		'val_decl_rule_3','val_decl_rule_4','val_decl_rule_5','val_decl_rule_6','val_decl_wether_yes_no','val_decl_price_yes_no','val_decl_previous_export_bill_no','val_decl_other_reivent_info','val_decl_information',
        		'val_decl_place','val_decl_date'
        ])
        ->contain([
            'Invoices' => function($q) {
            return $q
            ->select([
                'id','is_local','invoice_no','invoice_date'
            ])
            ->contain([
            		
            		'PaymentTerm'=> function ($q) {
            		return $q
            		->select([
            				'PaymentTerm.id','PaymentTerm.term'
            		]);
            		
            		},
            		'DeliveryTerm'=> function ($q) {
            		return $q
            		->select([
            				'DeliveryTerm.id','DeliveryTerm.term'
            		]);
            		
            		},
            		
            		
            ]);
            },
           
            'OwnerCompanies'=> function ($q) {
            return $q
            ->select([
                'OwnerCompanies.id','OwnerCompanies.Company_name'
            ])
            ->contain([
                'OwnerCompanyOffices' => function($q) {
                return $q
                ->select([
                    'OwnerCompanyOffices.id','OwnerCompanyOffices.phone_no','OwnerCompanyOffices.postal_code','OwnerCompanyOffices.name', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
                ])
                ->contain([
                    'City' => function($q) {
                    return $q
                    ->select([
                        'City.city_name'
                    ]);
                    }
                    ])
                    ->contain([
                        'Countries' => function($q) {
                        return $q
                        ->select([
                            'Countries.country_name'
                        ]);
                        }
                        ])
                        ->contain([
                            'State' => function($q) {
                            return $q
                            ->select([
                                'State.state_name'
                            ]);
                            }
                            ]);
                }
                ]);
            
            },
            'CompanyMaster'=> function ($q) {
            return $q
            ->select([
                'CompanyMaster.id','CompanyMaster.Company_name'
            ]);
            
            },
            
            ])
            ->where(['InvoiceShippingDocuments.id'=>$id])
            ->toArray();
            
            $this->set('invoiceShippingDocument', $invoiceShippingDocument);
            $this->set('_serialize', ['invoiceShippingDocument']);
            if($requiredReturn===true){
                return $invoiceShippingDocument;
            }
    }
    
    public function insurancerequestletterview($id = null,$requiredReturn=null) {
        
        
        $invoiceShippingDocument=$this->InvoiceShippingDocuments->find('all')
        ->select([
            'id','is_local','insurance_policy_no','insurance_current_date','insurance_company_id','insurance_code','insurance_date','insurance_time','insurance_pro_desc','insurance_transpoter_address','insurance_sum_of_insured','insurance_total_sum_insured'
        		,'insurance_exchange_amount','insurance_total_amount','insurance_business_period','insurance_currency_id','insurance_decision','insurance_dept','invoice_id'
        ])
        ->contain([
            'Invoices' => function($q) {
            return $q
            ->select([
                'id','is_local','invoice_no','invoice_date'
            ])
            ->contain([
            		'InvoiceProducts' => function($q) {
            		return $q
            		->select([
            				'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.uom_id'
            		]);
            		 
            		},
            		 
            		 
            		])->contain([
                'InvoiceProducts' => function($q) {
                return $q
                ->select([
                    'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.product_id','InvoiceProducts.order_id','InvoiceProducts.kind_of_pkg','marks_nos'
                ])
                ->contain([
                    'ProductsMaster' => function($q) {
                    return $q
                    ->select([
                        'ProductsMaster.id', 'ProductsMaster.product_name','ProductsMaster.cas_no','ProductsMaster.hs_code'
                    ]);
                    },
                    
                    
                    ]);
                
                },
                
                ]);
            },
            
            'OwnerCompanies'=> function ($q) {
            return $q
            ->select([
                'OwnerCompanies.id','OwnerCompanies.Company_name','OwnerCompanies.cd_acc_no'
            ])
            ->contain([
                'OwnerCompanyOffices' => function($q) {
                return $q
                ->select([
                    'OwnerCompanyOffices.id','OwnerCompanyOffices.phone_no','OwnerCompanyOffices.postal_code','OwnerCompanyOffices.name', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
                ])
                ->contain([
                    'City' => function($q) {
                    return $q
                    ->select([
                        'City.city_name'
                    ]);
                    }
                    ])
                    ->contain([
                        'Countries' => function($q) {
                        return $q
                        ->select([
                            'Countries.country_name'
                        ]);
                        }
                        ])
                        ->contain([
                            'State' => function($q) {
                            return $q
                            ->select([
                                'State.state_name'
                            ]);
                            }
                            ]);
                }
                ]);
            
            },
            'InsuranceCompany'=> function ($q) {
            return $q
            ->select([
            		'InsuranceCompany.id','InsuranceCompany.Company_name'
            ])->contain([
                'CompanySublocation' => function($q) {
                return $q
                ->select([
                    'CompanySublocation.id','CompanySublocation.sublocation_name','CompanySublocation.postal_code','CompanySublocation.address','CompanySublocation.company_master_id'
                ])
                ->contain([
                    'City' => function($q) {
                    return $q
                    ->select([
                        'City.city_name'
                    ]);
                    }
                    ])
                    ->contain([
                        'Countries' => function($q) {
                        return $q
                        ->select([
                            'Countries.country_name'
                        ]);
                        }
                        ])
                        ->contain([
                            'State' => function($q) {
                            return $q
                            ->select([
                                'State.state_name'
                            ]);
                            }
                            ]);
                }
                ]);
            
            },
            
            ])
            ->where(['InvoiceShippingDocuments.id'=>$id])
            ->toArray();
            
            $this->set('invoiceShippingDocument', $invoiceShippingDocument);
            $this->set('_serialize', ['invoiceShippingDocument']);
            if($requiredReturn===true){
                return $invoiceShippingDocument;
            }
    }
    
    public function insurancerequestletterviewprint($id = null)
    {
        $invoiceShippingDocument=$this->insurancerequestletterview($id,true);
        
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
    }
    public function insurancerequestletterlocalviewprint($id = null)
    {
        $invoiceShippingDocument=$this->insurancerequestletterview($id,true);
        
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
    }
    public function insurancerequestletterlocalview($id = null)
    {
        $invoiceShippingDocument=$this->insurancerequestletterview($id,true);
        
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
    }
    public function valuedeclarationviewprint($id = null)
    {
        $invoiceShippingDocument=$this->valuedeclarationview($id,true);
        
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
    }
    
    public function fedfxletterofinstructionview($id = null,$requiredReturn=null) {
        
        
        $invoiceShippingDocument=$this->InvoiceShippingDocuments->find('all')
        ->select([
            'id','is_local','tsca_date','tsca_title','tsca_auth_sign','tsca_airway_bill','invoice_id'
        ])
        ->contain([
            'Invoices' => function($q) {
            return $q
            ->select([
                'id','is_local','invoice_no','invoice_date'
            ])
            ->contain([
                'InvoiceProducts' => function($q) {
                return $q
                ->select([
                    'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.product_id','InvoiceProducts.order_id','InvoiceProducts.kind_of_pkg','marks_nos'
                ])
                ->contain([
                    'ProductsMaster' => function($q) {
                    return $q
                    ->select([
                        'ProductsMaster.id', 'ProductsMaster.product_name','ProductsMaster.cas_no','ProductsMaster.hs_code'
                    ]);
                    },
                    
                    
                    ]);
                
                },
                
                ]);
            },
            
            'OwnerCompanies'=> function ($q) {
            return $q
            ->select([
                'OwnerCompanies.id','OwnerCompanies.Company_name'
            ])
            ->contain([
                'OwnerCompanyOffices' => function($q) {
                return $q
                ->select([
                    'OwnerCompanyOffices.id','OwnerCompanyOffices.phone_no','OwnerCompanyOffices.postal_code','OwnerCompanyOffices.name', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
                ])
                ->contain([
                    'City' => function($q) {
                    return $q
                    ->select([
                        'City.city_name'
                    ]);
                    }
                    ])
                    ->contain([
                        'Countries' => function($q) {
                        return $q
                        ->select([
                            'Countries.country_name'
                        ]);
                        }
                        ])
                        ->contain([
                            'State' => function($q) {
                            return $q
                            ->select([
                                'State.state_name'
                            ]);
                            }
                            ]);
                }
                ]);
            
            },
            'CompanyMaster'=> function ($q) {
            return $q
            ->select([
                'CompanyMaster.id','CompanyMaster.Company_name'
            ]) 
            ->contain([
                'CompanySublocation' => function($q) {
                return $q
                ->select([
                    'CompanySublocation.id','CompanySublocation.phone_no','CompanySublocation.postal_code','CompanySublocation.name', 'CompanySublocation.address','CompanySublocation.company_id'
                ])
                ->contain([
                    'City' => function($q) {
                    return $q
                    ->select([
                        'City.city_name'
                    ]);
                    }
                    ])
                    ->contain([
                        'Countries' => function($q) {
                        return $q
                        ->select([
                            'Countries.country_name'
                        ]);
                        }
                        ])
                        ->contain([
                            'State' => function($q) {
                            return $q
                            ->select([
                                'State.state_name'
                            ]);
                            }
                            ]);
                }
                ]);
            
            },
            
            ])
            ->where(['Invoices.id'=>$id])
            ->toArray();
            
            $this->set('invoiceShippingDocument', $invoiceShippingDocument);
            $this->set('_serialize', ['invoiceShippingDocument']);
            if($requiredReturn===true){
                return $invoiceShippingDocument;
            }
    }
    
    public function fedfxletterofinstructionviewprint($id = null)
    {
        $invoiceShippingDocument=$this->tscaview($id,true);
        
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
    }

    public function certificateoforiginview($id = null)
    {
 		$invoiceShippingDocument=$this->InvoiceShippingDocuments->find('all')
        ->select([
            'id','is_local','certificateoforigin_transport_route','certificateoforigin_origin_criteria','certificateoforigin_place','certificateoforigin_yes_no','certificateoforigin_date','invoice_id'
        ])
        ->contain([
            'Invoices' => function($q) {
            return $q
            ->select([
                'id','is_local','invoice_no','invoice_date'
            ]);
         
            },
            
            'OwnerCompanies'=> function ($q) {
            return $q
            ->select([
                'OwnerCompanies.id','OwnerCompanies.Company_name'
            ])
            ->contain([
                'OwnerCompanyOffices' => function($q) {
                return $q
                ->select([
                    'OwnerCompanyOffices.id','OwnerCompanyOffices.phone_no','OwnerCompanyOffices.postal_code','OwnerCompanyOffices.name', 'OwnerCompanyOffices.address','OwnerCompanyOffices.owner_company_id'
                ])
                ->contain([
                    'City' => function($q) {
                    return $q
                    ->select([
                        'City.city_name'
                    ]);
                    }
                    ])
                    ->contain([
                        'Countries' => function($q) {
                        return $q
                        ->select([
                            'Countries.country_name'
                        ]);
                        }
                        ])
                        ->contain([
                            'State' => function($q) {
                            return $q
                            ->select([
                                'State.state_name'
                            ]);
                            }
                            ]);
                }
                ]);
            
            },
            'CompanyMaster'=> function ($q) {
            return $q
            ->select([
                'CompanyMaster.id','CompanyMaster.Company_name'
            ]);
            
            },
            
            ])
            ->where(['InvoiceShippingDocuments.id'=>$id])
            ->toArray();
        
            
            
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
    }
    public function certificateoforiginviewprint($id = null)
    {
        $invoiceShippingDocument=$this->tscaview($id,true);
        
        $this->set('invoiceShippingDocument', $invoiceShippingDocument);
        $this->set('_serialize', ['invoiceShippingDocument']);
    }
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function addPoShipping($invoiceId)
    {
        $invoiceShippingDocument = $this->InvoiceShippingDocuments->newEntity();
        if ($this->request->is('post')) {

        	
            $invoiceShippingDocument = $this->InvoiceShippingDocuments->patchEntity($invoiceShippingDocument, $this->request->data);
           
         
            if ($this->InvoiceShippingDocuments->save($invoiceShippingDocument)) {
                $this->Flash->success(__('The {0} has been saved.', 'Invoice Shipping Document'));
                return $this->redirect(['controller'=>'invoices','action' => 'po_document',$invoiceId]);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice Shipping Document'));
            }
        }
        $this->loadModel('Uom');
        $uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
        
        $this->loadModel('Currency');
        $currencyList = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'id'], ['limit' => 200]);
        
        
        
        $this->loadModel('Invoices');
        $invoiceData=$this->Invoices->find('all')
        ->select([
        		'id','currency_id'
        ])
        ->contain([
        		'InvoiceProducts' => function($q) {
        		return $q
        		->select([
        				'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.uom_id'
        		]);
        		 
        		},
        		 
        		 
        		])
        		->where(['Invoices.id'=>$invoiceId])
        		->toArray();
        
        		//End Get currency and uom
        		$currency=$invoiceData[0]['currency_id'];
        		// debug($invoiceData);
        
        		$this->set(compact('invoiceShippingDocument', 'invoices','uom','invoiceData','currency','currencyList'));
        
        		
        //$invoices = $this->InvoiceShippingDocuments->Invoices->find('list', ['limit' => 200]);
       // $lrTransporters = $this->InvoiceShippingDocuments->LrTransporters->find('list', ['limit' => 200]);
       // $internationalTransporterCompanies = $this->InvoiceShippingDocuments->InternationalTransporterCompanies->find('list', ['limit' => 200]);
        //$this->set(compact('invoiceShippingDocument', 'invoiceId'));
        $this->set('_serialize', ['invoiceShippingDocument']);
    }

    public function addCoaSaleShipping($invoiceId,$invoiceProductId)
    {
    	$this->loadModel('CoaResults');
    	$CoaResults = $this->CoaResults->newEntity();
    	if ($this->request->is('post')) {
    	
    		//echo '<pre>',print_r($this->request->data['coa_results']);
    		//die;
    		
    		 foreach ($this->request->data['coa_results'] as $ck=>$cv){
    			//echo '<pre>',print_r($cv);die;
    			$CoaResults = $this->CoaResults->newEntities($cv);
    			try{
    				$this->CoaResults->saveMany($CoaResults);
    				
    				
    			}
    			catch(Exception $e){
    				
    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'COA Document'));
    				
    				
    			}
    		}	 
    			//save batch data in invoice batch
    			$this->loadModel('InvoiceProductBatches');    			
    			/* $invoicebatchData = $this->InvoiceProductBatches->get($invoiceId, [
    					//	'contain' => ['CompanyMaster','Currency','OwnerCompanies','OwnerCompanies.OwnerCompanyOffices','InvoiceProducts','InvoiceProducts.InvoiceProductBatches','InvoiceProducts.Order','InvoiceProducts.Order.BoldNoInventoryTran','InvoiceProducts.Order.BoldNoInventoryTran.BoldNumberInventory','InvoiceProducts.Uom','InvoiceProducts.Currency','InvoiceProducts.ProductsMaster','PaymentTerm'],
    			]); */
    			//debug($this->request->data['invoice_product_batches']);die;
    			foreach ($this->request->data['invoice_product_batches'] as $pk=>$pvbatch){
    			
    				$arrbatchproduct[]=$pvbatch['id'];
    				 
    			}

    			$invoicebatchData = $this->InvoiceProductBatches->find('all',[
    					//'fields'=>'id',
    					'conditions'=>["InvoiceProductBatches.id  IN ( " . implode(",", $arrbatchproduct ) ." )" ]
    						
    			]);
    			
    			$invoicebatchData = $this->InvoiceProductBatches->patchEntities($invoicebatchData,$this->request->data['invoice_product_batches']);
    			/* debug($invoicebatchData);
    			die; */
    			
    			if($this->InvoiceProductBatches->saveMany($invoicebatchData)){
    				$this->Flash->success(__('The {0} has been saved.', 'COA Document'));
    				return $this->redirect(['controller'=>'invoices','action' => 'sales_document',$invoiceId]);
    				 
    			}else{
    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'COA Document'));
    				
    				
    			}
    		
    		
    	}
    		

    		$this->loadModel('InvoiceProducts');
    		
    		/* $invoiceData = $this->Invoices->get($invoiceId, [
    				
    				'contain' => ['InvoiceProducts','InvoiceProducts.ProductsMaster','InvoiceProducts.InvoiceProductBatches']
    		])->toArray();
    		 */
    		
    		/* $invoiceData=$this->InvoiceProductBatches->find('all')
	    		->select([
    								'InvoiceProductBatches.id','InvoiceProductBatches.batch_number','InvoiceProductBatches.invoice_products_id'
	    				])
	    		->contain([
	    				'InvoiceProducts' => function($q) {
	    				return $q
	    				->select([
    							'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.uom_id'
	    						])
	    				->contain([
	    						'ProductsMaster' => function($q) {
	    						return $q
	    						->select([
	    								'ProductsMaster.product_name','ProductsMaster.id'
	    						])
	    						->contain([
	    								'ProductDataTests' => function($q) {
	    								return $q
	    								->select([
	    										'ProductDataTests.id','ProductDataTests.test','ProductDataTests.products_master_id','ProductDataTests.specification','ProductDataTests.methods'
	    								])
	    								->where(['purpose like'=>'%Purchase%']);
	    								}
	    								]);
	    		
	    						},
	    						'InvoiceProductBatches' => function($q) {
	    						return $q
	    						->select([
	    								'InvoiceProductBatches.id','InvoiceProductBatches.batch_number','InvoiceProductBatches.invoice_products_id'
	    						]);
	    						}			
    						]);
	    				}
	    						
	    				])
	    				->where(['InvoiceProductBatches.invoice_products_id'=>$invoiceProductId,'InvoiceProducts.invoice_id'=>$invoiceId])->toArray();
	    				  */
    		
    		$invoiceData=$this->InvoiceProducts->find('all')
    		->select([
    					'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.uom_id'
    				])
    		->contain([
    						'ProductsMaster' => function($q) {
    						return $q
    						->select([
    								'ProductsMaster.product_name','ProductsMaster.id'
    						])
    						->contain([
    								'ProductDataTests' => function($q) {
    								return $q
    								->select([
    										'ProductDataTests.id','ProductDataTests.test','ProductDataTests.products_master_id','ProductDataTests.specification','ProductDataTests.methods'
    								])
    								->where(['purpose like'=>'%Purchase%']);
    								}
    								]);
    		
    						},
    						'InvoiceProductBatches' => function($q) {
    						return $q
    						->select([
    								'InvoiceProductBatches.id','InvoiceProductBatches.batch_number','InvoiceProductBatches.invoice_products_id'
    						]);
    						}			
    				])
    				->where(['InvoiceProducts.id'=>$invoiceProductId,'InvoiceProducts.invoice_id'=>$invoiceId])->toArray();
    				
    				
    		//	debug($invoiceData);	
    				
    				
    				
    				
    				
    				
    			
    		
    				//debug($invoiceData);die;
    				
    		
    		$this->loadModel('Uom');
    		$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    	/* 	
    		$options = array(
    				'fields' => array('id','products_master_id', 'test', 'specification', 'methods'),
    				'conditions' => array('products_master_id' => $prodid ,'purpose LIKE'=> "%COA"));
    		$lm = $this->ProductDataTests->find('all', $options);
    		 */
    		
    		$this->set(compact('invoiceData','CoaResults','uom'));
    				
    		
    		
    	
    	
    	$this->set('_serialize', ['CoaResults']);
    	 
    	
    }
    public function editCoaSaleShipping($Id)
    {
    	$this->loadModel('CoaResults');
    	$CoaResults = $this->CoaResults->newEntity();
    	if ($this->request->is('post')) {
    		 
    			//echo '<pre>',print_r($this->request->data);die;
    
    
    		foreach ($this->request->data['coa_results'] as $ck=>$cv){
    			//echo '<pre>',print_r($cv);die;
    			$CoaResults = $this->CoaResults->patchEntities($cv,$this->request->data['coa_results']);
    			try{
    				$this->CoaResults->saveMany($CoaResults);
    
    
    			}
    			catch(Exception $e){
    
    				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'COA Document'));
    
    
    			}
    		}
    		//save batch data in invoice batch
    		$this->loadModel('InvoiceProductBatches');
    	
    		foreach ($this->request->data['invoice_product_batches'] as $pk=>$pvbatch){
    			 
    			$arrbatchproduct[]=$pvbatch['id'];
    				
    		}
    		//echo $arrbatchproduct;
    		//die;
    		$invoicebatchData = $this->InvoiceProductBatches->find('all',[
    				//'fields'=>'id',
    				'conditions'=>["InvoiceProductBatches.id  IN ( " . implode(",", $arrbatchproduct ) ." )" ]
    
    		]);
    
    		$invoicebatchData = $this->InvoiceProductBatches->patchEntities($invoicebatchData,$this->request->data['invoice_product_batches']);
    		 
    		 
    		if($this->InvoiceProductBatches->saveMany($invoicebatchData)){
    			$this->Flash->success(__('The {0} has been saved.', 'COA Document'));
    			return $this->redirect(['controller'=>'invoices','action' => 'sales_document',$Id]);
    				
    		}else{
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'COA Document'));
    
    
    		}
    
    
    	}
    
    
    	$this->loadModel('Invoices');
       	$invoiceData=$this->Invoices->find('all')
    	->select([
    			'id','currency_id'
    	])
    	->contain([
    			'InvoiceProducts' => function($q) {
    			return $q
    			->select([
    					'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.uom_id'
    			])
    			->contain([
    					'ProductsMaster' => function($q) {
    					return $q
    					->select([
    							'ProductsMaster.product_name','ProductsMaster.id'
    					])
    					->contain([
    							'ProductDataTests' => function($q) {
    							return $q
    							->select([
    									'ProductDataTests.id','ProductDataTests.test','ProductDataTests.products_master_id','ProductDataTests.specification','ProductDataTests.methods'
    							])
    							->where(['purpose like'=>'%Purchase%']);
    							}
    							]);
    
    					},
    					'InvoiceProductBatches' => function($q) {
    					return $q
    					->select([
    							'InvoiceProductBatches.id','InvoiceProductBatches.batch_number','InvoiceProductBatches.invoice_products_id',"batch_size","batch_size_uom","no_of_bags","sample_bag_nos","expiry_date","manufacturing_date","InvoiceProductBatches.invoice_id"
    					])->contain([
    							'CoaResults' => function($q) {
    							return $q
    							->select([
    									'CoaResults.id','CoaResults.invoice_product_batches_id','product_data_tests_id','result'
    							]);
    							//->where(['purpose like'=>'%COA%']);
    							}
    							]);
    					}
    
    					]);
    
    				
    			},
    				
    				
    			])
    			->where(['Invoices.id'=>$Id])->toArray();
    
    			//debug($invoiceData);die;
    
    
    			$this->loadModel('Uom');
    			$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    			/*
    			 $options = array(
    			 'fields' => array('id','products_master_id', 'test', 'specification', 'methods'),
    			 'conditions' => array('products_master_id' => $prodid ,'purpose LIKE'=> "%COA"));
    			 $lm = $this->ProductDataTests->find('all', $options);
    			 */
    
    			$this->set(compact('invoiceData','CoaResults','uom'));
    
    
    
    			 
    			 
    			$this->set('_serialize', ['CoaResults']);
    
    			 
    }
    
// ------------------- Ragini -----------------
	public function viewCoaSaleShipping($invoiceId, $invoiceProductId) {
		//echo $invoiceId.'......................'.$invoiceProductId;
		$this->loadModel ( 'InvoiceProducts' );
		
		$invoiceData = $this->InvoiceProducts->find ( 'all' )->select ( [ 
				'InvoiceProducts.id',
				'InvoiceProducts.invoice_id',
				'InvoiceProducts.uom_id',
				'InvoiceProducts.product_id' 
		] )->contain ( [ 
				'ProductsMaster' => function ($q) {
					return $q->select ( [ 
							'ProductsMaster.product_name',
							'ProductsMaster.id' 
					] )->contain ( [ 
							'ProductDataTests' => function ($q) {
								return $q->select ( [ 
										'ProductDataTests.id',
										'ProductDataTests.test',
										'ProductDataTests.products_master_id',
										'ProductDataTests.specification',
										'ProductDataTests.methods' 
								] )->where ( [ 
										'purpose like' => '%Purchase%' 
								] );
							} 
					] );
				},
				'Invoices' => function ($q) {
					return $q->select ( [ 
							'Invoices.id',
							'Invoices.currency_id',
							'Invoices.created' 
					] )->contain ( [ 
							'OwnerCompanies' => function ($q) {
								return $q->select ( [ 
										'OwnerCompanies.id',
										'OwnerCompanies.Company_name',
										'OwnerCompanies.logo_image',
										'OwnerCompanies.header_image',
										'OwnerCompanies.logo_image' 
								] );
							} 
					] );
				},
				'InvoiceProductBatches' => function ($q) {
					return $q->select ( [ 
							'InvoiceProductBatches.id',
							'InvoiceProductBatches.batch_number',
							'InvoiceProductBatches.invoice_products_id',
							"batch_size",
							"batch_size_uom",
							"no_of_bags",
							"sample_bag_nos",
							"expiry_date",
							"manufacturing_date",
							"InvoiceProductBatches.invoice_id" 
					] )->contain ( [ 
							'CoaResults' => function ($q) {
								return $q->select ( [ 
										'CoaResults.id',
										'CoaResults.invoice_product_batches_id',
										'product_data_tests_id',
										'result' 
								] )->contain ( [ 
										'ProductDataTests' => function ($q) {
											return $q->select ( [ 
													'ProductDataTests.id',
													'ProductDataTests.test',
													'ProductDataTests.products_master_id',
													'ProductDataTests.specification',
													'ProductDataTests.methods' 
											] );
										} 
								] );
							} 
					] );
				} 
		] )->where ( [ 
				'InvoiceProducts.id' => $invoiceProductId,
				'InvoiceProducts.invoice_id' => $invoiceId 
		] )->toArray ();
		
		//echo '<pre>';
		//print_r ( $invoiceData );
		//die ();
		
		$this->loadModel ( 'Uom' );
		$uom = $this->Uom->find ( 'list', [ 
				'keyField' => 'id',
				'valueField' => 'unit_symbol',
				'order' => 'unit_symbol',
				'conditions' => [ 
						'unit_type' => 'weight' 
				] 
		], [ 
				'limit' => 200 
		] );
		
		$this->loadModel ( 'ProductDataTests' );
		
		$tests = $this->ProductDataTests->find ( 'all', [ 
				'conditions' => [ 
						'ProductDataTests.products_master_id' => $invoiceData ['0']['products_master']['id']] 
		] );
		$tests = $tests->toarray ();
		
		$this->set ( compact ( 'invoiceData', 'CoaResults', 'uom', 'tests' ) );
		$this->set ( '_serialize', [ 
				'CoaResults' 
		] );
	}
	public function printCoaSaleShipping($invoiceId, $invoiceProductId) {
		$coasalesshipping = $this->viewCoaSaleShipping ( $invoiceId, $invoiceProductId, true );
		
		$this->set ( 'coasalesshipping', $coasalesshipping );
		$this->set ( '_serialize', [ 
				'coasalesshipping' 
		] );
	}
    public function addSaleShipping($invoiceId)
    {
    	$invoiceShippingDocument = $this->InvoiceShippingDocuments->newEntity();
    	if ($this->request->is('post')) {
    
    		$this->request->data['InvoiceShippingDocuments']['owner_company_id']= $this->Auth->User('owner_company_id');
    		$invoiceShippingDocument = $this->InvoiceShippingDocuments->patchEntity($invoiceShippingDocument, $this->request->data);
    		 
    		 
    		if ($this->InvoiceShippingDocuments->save($invoiceShippingDocument)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Invoice Shipping Document'));
    			return $this->redirect(['controller'=>'invoices','action' => 'sales_document',$invoiceId]);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice Shipping Document'));
    		}
    	}
    	$this->loadModel('Uom');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    
    	$this->loadModel('Currency');
    	$currencyList = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'id'], ['limit' => 200]);
    
    
    
    	$this->loadModel('Invoices');
    	$invoiceData=$this->Invoices->find('all')
    	->select([
    			'id','currency_id','is_local','grand_total_amount'
    	])
    	->contain([
    			'InvoiceProducts' => function($q) {
    			return $q
    			->select([
    					'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.uom_id'
    			]);
    			 
    			},
    			 
    			 
    			])
    			->where(['Invoices.id'=>$invoiceId])
    			->toArray();
    			$currency=$invoiceData[0]['currency_id'];
    			$this->set(compact('invoiceShippingDocument', 'invoices','uom','invoiceData','currency','currencyList'));
    
    			$this->set('_serialize', ['invoiceShippingDocument']);
    }
    public function addPostshipmentShipping($invoiceId)
    {
    	
    	$this->loadModel('PostsipmentDocuments');
    	 
    	$postsipmentDocuments = $this->PostsipmentDocuments->newEntity();
    	if ($this->request->is('post')) {
    
    		$this->request->data['PostsipmentDocuments']['owner_company_id']= $this->Auth->User('owner_company_id');
    		$postsipmentDocuments = $this->PostsipmentDocuments->patchEntity($postsipmentDocuments, $this->request->data);
    		 
    		 //debug($postsipmentDocuments);die;
    		if ($this->PostsipmentDocuments->save($postsipmentDocuments)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Post-Shipping Document'));
    			return $this->redirect(['controller'=>'invoices','action' => 'postshipment-document-view',$invoiceId]);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Post-Shipping Document'));
    		}
    	}
    	
    
    
    	$this->loadModel('Invoices');
    	$invoiceData=$this->Invoices->find('all')
		    	->select([
		    			'id','currency_id','is_local','owner_company_id','grand_total_amount','invoice_no'
		    	])
    
    			->where(['Invoices.id'=>$invoiceId])
    			->toArray();
    	
    			//Get Owner company name
    			$ownercomp= $this->request->session()->read('Auth.User.owner_company_id');
    			$this->loadModel('OwnerCompanies');
    			$ownercompanyData=$this->OwnerCompanies->find('all')
    			->select([
    					'id','Company_name','iec_no'
    			])
    			->where(['id'=>$ownercomp])
    			->toArray();
    			
    			$this->loadModel('OwnerBankMaster');    			 
    			$ownerbankData=$this->OwnerBankMaster->find('list')
    			->select([    					
    					'id','name','bank_name','account_no','owner_companies_id'
    					])
    			->where(['id'=>$ownercomp])
    			->toArray();
    						
    			
    			$this->loadModel('Currency');
    			$currencyData=$this->Currency->find('list')
    			->select([
    					'id','sign'
    			])
    			->where(['active'=>1])
    			->toArray();
    			
    			//debug($ownercompanyData);die;
    			$frimName=$ownercompanyData[0]['Company_name'];
    			$frimid=$ownercompanyData[0]['id'];
    			 
    			$iec_no=$ownercompanyData[0]['iec_no'];
    			//stop Owner Company name
    			
    			$currency=$invoiceData[0]['currency_id'];
    			$this->set(compact('postsipmentDocuments','frimName','frimid','iec_no','ownerbankData','currencyData' ,'invoiceData','currency'));
    
    			$this->set('_serialize', ['postsipmentDocuments']);
    }
    
    public function editPostshipmentShipping($id)
    {
    	//$invoiceShippingDocument = $this->InvoiceShippingDocuments->newEntity();
    	$this->loadModel('PostsipmentDocuments');
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		$postsipmentDocuments = $this->PostsipmentDocuments->get($id, [
    				'contain' => []
    		]);
    		$postsipmentDocuments = $this->PostsipmentDocuments->patchEntity($postsipmentDocuments, $this->request->data);
    		//debug($postsipmentDocuments);die;
    		
    		if ($this->PostsipmentDocuments->save($postsipmentDocuments)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Invoice Shipping Document'));
    			return $this->redirect(['controller'=>'invoices','action' => 'postshipment-document-view',$postsipmentDocuments['invoice_id']]);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice Shipping Document'));
    		}
    	}
    	$this->loadModel('Uom');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    
    	$this->loadModel('Currency');
    	$currencyList = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'id'], ['limit' => 200]);
    	
    	$this->loadModel('Invoices');
    	
    	$postsipmentDocuments = $this->PostsipmentDocuments->get($id, [
    		//	'contain' => ['invoices']
    	]);
    	 
    	if($postsipmentDocuments['is_local']=="0"){
    		$shippingArray=array(
    				
    				"21"=>array( //Bill Of Landing
    						'bill_of_landing_no','bill_of_lading_date'
    				),
    				"43"=>array( //International Transporter
    						'international_transporter_from_locaton','international_transporter_to_location'
    				),
    				
    				"22"=>array( //Shipment Advice
    						'shipment_advice_date_port_of_loading','shipment_advice_date_port_of_discharge'
    				),
    				
    				"25"=>array( //Shipping Bill
    						'shipping_bill_leo_no','shipping_bill_brc_realisation_date'
    				),
    				"26"=>array( //Bank Realisation Certificate
    						'bank_realisation_shipping_bill_no','bank_realisation_shipping_bill_date','bank_realisation_certificate_no'
    				),
    				"27"=>array( //Bank  Inward Remittance Advice
    						'remitance_sr_no','remitance_date','remitance_inward_ref_no'
    				),
    				"24"=>array( //Insurance Policy
    						'insurance_policy_policy_no','insurance_policy_code'
    				),
    				"28"=>array( //Covering letter for for bank Regularisation
    					//	'remitance_sr_no','remitance_date','remitance_inward_ref_no'
    				),
    
    					
    		);
    	}else{
    
    		$shippingArray=array(
    				"47"=>array(		//Shipment Advice
    						'shipment_advice_date_port_of_loading','shipment_advice_date_port_of_discharge'
    						),
    				"48"=>array( //Insurance Policy
    						'insurance_policy_policy_no','insurance_policy_code'
    				),
    		);
    
    	}
    
    
    		 
    	//Get name of transporter Company
    	$this->loadModel('CompanyMaster');
    	$insuranceCompany=$this->CompanyMaster->find('all')
    	->select([
    			'Company_name'
    	])
    	->where(['id'=>$postsipmentDocuments['insurance_company_id']])->toArray();
    	$invoiceData=$this->Invoices->find('all')
    	->select([
    			'id','currency_id','is_local','owner_company_id','grand_total_amount','invoice_no'
    	])
    	
    	->where(['Invoices.id'=>$postsipmentDocuments['invoice_id']])
    	->toArray();
    	 
    	//Get Owner company name
    	$ownercomp= $postsipmentDocuments['owner_company_id'];
    	$this->loadModel('OwnerCompanies');
    	$ownercompanyData=$this->OwnerCompanies->find('all')
    	->select([
    			'id','Company_name','iec_no'
    	])
    	->where(['id'=>$ownercomp])
    	->toArray();
    	 
    	$this->loadModel('OwnerBankMaster');
    	$ownerbankData=$this->OwnerBankMaster->find('list')
    	->select([
    			'id','name','bank_name','account_no','owner_companies_id'
    	])
    	->where(['id'=>$ownercomp])
    	->toArray();
    	
    	 
    	$this->loadModel('Currency');
    	$currencyData=$this->Currency->find('list')
    	->select([
    			'id','sign'
    	])
    	->where(['active'=>1])
    	->toArray();
    	 
    	//debug($ownercompanyData);die;
    	$frimName=$ownercompanyData[0]['Company_name'];
    	$iec_no=$ownercompanyData[0]['iec_no'];
    	//stop Owner Company name
    	 
    	//$currency=$invoiceData[0]['currency_id'];
    	 
    	$this->set(compact('postsipmentDocuments','shippingArray','frimName','ownerbankData','iec_no','insuranceCompany','sh-ippingArray', 'invoices','invoiceData','currencyData'));
    
    	$this->set('_serialize', ['invoiceShippingDocument']);
    }
    
    public function editSaleShipping($id)
    {
    	//$invoiceShippingDocument = $this->InvoiceShippingDocuments->newEntity();
    	if ($this->request->is(['patch', 'post', 'put'])) {
    		$invoiceShippingDocument = $this->InvoiceShippingDocuments->get($id, [
    				'contain' => []
    		]);
    		$invoiceShippingDocument = $this->InvoiceShippingDocuments->patchEntity($invoiceShippingDocument, $this->request->data);
    		if ($this->InvoiceShippingDocuments->save($invoiceShippingDocument)) {
    			$this->Flash->success(__('The {0} has been saved.', 'Invoice Shipping Document'));
    			return $this->redirect(['controller'=>'invoices','action' => 'sales_document',$invoiceShippingDocument['invoice_id']]);
    		} else {
    			$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice Shipping Document'));
    		}
    	}
    	$this->loadModel('Uom');
    	$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
    
    	$this->loadModel('Currency');
    	$currencyList = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'id'], ['limit' => 200]);
    	$invoiceShippingDocument = $this->InvoiceShippingDocuments->get($id, [
    			'contain' => []
    	]);
    	
    	if($invoiceShippingDocument['is_local']=="0"){
    		$shippingArray=array(
    				"30"=>array( //Non Haz
  					'non_haz_awb_no','non_haz_date'
		  			),
		  			"31"=>array( //TSCA
		  					'tsca_date','tsca_auth_sign','tsca_title'
		  			),
		  			"32"=>array( //SDF
		  					'sdf_shipping_bill_no'
		  			),
		  			"33"=>array( //Value Declaration
		  					'val_decl_shipping_bill_no','val_decl_sale','val_decl_sale_on_consignment'
		  			),
		  			"34"=>array( //FedFx Letter Of Instruction
		  			
		  					'val_decl_shipping_bill_no','val_decl_sale','val_decl_sale_on_consignment'
		  			),
		  			"35"=>array( //Insurance Request Letter	
		  					'insurance_company_id','insurance_pro_desc','insurance_business_period','insurance_date'
		  			),
		  			"36"=>array( //Certificate Of origin
		  					'certificateoforigin_transport_route','certificateoforigin_origin_criteria','certificateoforigin_place'
		  			),
    				
  					
    		);
    	}else{
    		
    		$shippingArray=array(
    				"37"=>array(		//Insurance Request Letter	
        					'insurance_company_id','insurance_pro_desc','insurance_business_period','insurance_date'
        			)
    		);
    		
    	}


    	//Get name of insurance Company
    	$this->loadModel('CompanyMaster');
    	$insuranceCompany=$this->CompanyMaster->find('all')
    	->select([
    			'Company_name'
    	])
    	->where(['id'=>$invoiceShippingDocument['insurance_company_id']])->toArray();
    	
    	//Get name of transporter Company
    	$this->loadModel('CompanyMaster');
    	$insuranceCompany=$this->CompanyMaster->find('all')
    	->select([
    			'Company_name'
    	])
    	->where(['id'=>$invoiceShippingDocument['insurance_company_id']])->toArray();
    	 
    	
    			$this->set(compact('invoiceShippingDocument','insuranceCompany','shippingArray', 'invoices','uom','invoiceData','currency','currencyList'));
    
    			$this->set('_serialize', ['invoiceShippingDocument']);
    }
    /**
     * Edit method
     *
     * @param string|null $id Invoice Shipping Document id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function editPoShipping($id = null)
    {
        $invoiceShippingDocument = $this->InvoiceShippingDocuments->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $invoiceShippingDocument = $this->InvoiceShippingDocuments->patchEntity($invoiceShippingDocument, $this->request->data);
            if ($this->InvoiceShippingDocuments->save($invoiceShippingDocument)) {
                $this->Flash->success(__('The {0} has been saved.', 'Invoice Shipping Document'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Invoice Shipping Document'));
            }
        }
        //$invoices = $this->InvoiceShippingDocuments->Invoices->find('list', ['limit' => 200]);
        //$lrTransporters = $this->InvoiceShippingDocuments->LrTransporters->find('list', ['limit' => 200]);
        //$internationalTransporterCompanies = $this->InvoiceShippingDocuments->InternationalTransporterCompanies->find('list', ['limit' => 200]);
        $this->loadModel('Uom');
        $uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
        
        $this->loadModel('Currency');
        $currencyList = $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'id'], ['limit' => 200]);
        
        
        
        $this->loadModel('Invoices');
        $invoiceData=$this->Invoices->find('all')
    	->select([
    			'id','currency_id'
    	])
    	->contain([
    			'InvoiceProducts' => function($q) {
    			return $q
    			->select([
    					'InvoiceProducts.id','InvoiceProducts.invoice_id','InvoiceProducts.uom_id'
    			]);
    	
    			},
    			
    			
    			])
    			->where(['Invoices.id'=>$invoiceShippingDocument['invoice_id']])
    			->toArray();
        
        //End Get currency and uom
    			$currency=$invoiceData[0]['currency_id'];
       // debug($invoiceData);
        
        $this->set(compact('invoiceShippingDocument', 'invoices','uom','invoiceData','currency','currencyList'));
        $this->set('_serialize', ['invoiceShippingDocument']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Invoice Shipping Document id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $invoiceShippingDocument = $this->InvoiceShippingDocuments->get($id);
        if ($this->InvoiceShippingDocuments->delete($invoiceShippingDocument)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Invoice Shipping Document'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Invoice Shipping Document'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
