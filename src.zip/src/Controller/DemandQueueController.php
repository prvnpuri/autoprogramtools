<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

/**
 * DemandQueue Controller
 *
 * @property \App\Model\Table\DemandQueueTable $DemandQueue
 *
 * @method \App\Model\Entity\DemandQueue[] paginate($object = null, array $settings = [])
 */
class DemandQueueController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
        		'contain' => ['Order' => [ 'fields' => ['id', 'reference_number', 'order_date', 'quantity_ordered'] ], 
        				'Order.OwnerCompanies'=> ['fields' => ['company_name']], 
        				'Order.CompanyMaster'=> ['fields' => ['id', 'Company_name']],
        				'Order.uom' => ['fields' => ['unit_symbol']]
        		],
        		'conditions' => ['DemandQueue.status !=' => 1]
        ];
        $demandQueue = $this->paginate($this->DemandQueue);

        $this->set(compact('demandQueue'));
        $this->set('_serialize', ['demandQueue']);
    }

    /**
     * View method
     *
     * @param string|null $id Demand Queue id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $demandQueue = $this->DemandQueue->get($id, [
            'contain' => ['Order', 'ProcurementRequests', 'ProductionRequests']
        ]);

        $this->set('demandQueue', $demandQueue);
        $this->set('_serialize', ['demandQueue']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $demandQueue = $this->DemandQueue->newEntity();
        if ($this->request->is('post')) {
            $demandQueue = $this->DemandQueue->patchEntity($demandQueue, $this->request->data);
            if ($this->DemandQueue->save($demandQueue)) {
                $this->Flash->success(__('The {0} has been saved.', 'Demand Queue'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Demand Queue'));
            }
        }
        $order = $this->DemandQueue->Order->find('list', ['limit' => 200]);
        $this->set(compact('demandQueue', 'order'));
        $this->set('_serialize', ['demandQueue']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Demand Queue id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $blockerror = 0;
        $totalQtyForProcess = 0;
        if ($this->request->is(['patch', 'post', 'put'])) {
        	
        	$this->log("DemandQueue : edit - request data: ".print_r($this->request->getData(),true),'debug');
        	$warehouseInventoryTable = TableRegistry::get('WarehouseInventory');
        	$demandQueueTable = TableRegistry::get('DemandQueue');
        	
        	$WhData = $this->request->getdata('warehouse_inventory');
        	$demandData = $this->request->getdata('demand_queue');
        	
        	$overallbalance = 0;
        	$overallblocked = 0;
        	if ($WhData != null) {
        	//check if blocked qty > inventory batch wise qty (wh inventory details table)
        	foreach ($WhData['warehouse_inventory_details'] as $key => $value) {
        		if ($value['blocked_qty'] > $value['balance_qty']) {
        			$blockerror = 1;
        			break;
        		}
        	//update the total, blocked and balance qtys of wh inventory details table
        		$WhData['warehouse_inventory_details'][$key]['balance_qty'] = $value['balance_qty'] - $value['blocked_qty']; 
        		$WhData['warehouse_inventory_details'][$key]['blocked_qty'] = $WhData['warehouse_inventory_details'][$key]['total_qty'] - $WhData['warehouse_inventory_details'][$key]['balance_qty'];
        		$overallbalance = $overallbalance + $WhData['warehouse_inventory_details'][$key]['balance_qty'];
        		$overallblocked = $overallblocked + $value['blocked_qty'];
        		$WhData['balance_uom'] = $value['uom'];
        		$WhData['blocked_uom'] = $value['blocked_uom'];       		
        	}
        	//update the total, blocked and balance qtys of wh inventory table
        	$WhData['balance_qty'] = $overallbalance;
        	$WhData['blocked_qty'] = $overallblocked + $WhData['blocked_qty'];
        	}
        	/*
        	 * check if the total qty being processed (blocked+ procured + production) is same as and not greater than ordered qty 
        	 * Also check that the individual qtys (blocked+ procured + production) are not greater than ordered qty
        	 */
        	$totalQtyForProcess = $overallblocked + $demandData['production_requests']['0']['qty'] + $demandData['supplier_inquiry']['0']['qty_required'];
        	if($blockerror || 
        			$overallblocked > $overallbalance || 
        			$overallblocked > $demandData['order']['quantity_ordered'] ||
        			$totalQtyForProcess > $demandData['order']['quantity_ordered'] ||
        			$demandData['production_requests']['0']['qty'] > $demandData['order']['quantity_ordered'] ||
        			$demandData['supplier_inquiry']['0']['qty_required'] > $demandData['order']['quantity_ordered']){
        		$blockerror = 0;
        		$this->Flash->error(__('You cannot block qty more than available / order qty. Please reduce and try again.'));
        	} else if($totalQtyForProcess != $demandData['order']['quantity_ordered']) {
        		$this->Flash->error(__('Please block qty equal to order qty. Please change and try again.'));
        	}else {
        	
        	// indicates that the demand is processed and will not appear in the list
        	$demandData['status'] = 1;
        	$warehouseInventoryEntity = $warehouseInventoryTable->newEntity($WhData, [
        			'associated' => ['WarehouseInventoryDetails']
        	]);
        	
        	$demandQueueEntity = $demandQueueTable->newEntity($demandData, [
        			'associated' => ['ProductionRequests'=> ['validate' => false] , 'SupplierInquiry'=> ['validate' => false]]
        	]);
        	
        	
        	//$this->log("DemandQueue : edit - warehouseInventoryEntity: ".print_r($demandQueueEntity,true),'debug');
        	
        	if ($warehouseInventoryTable->getConnection()->transactional(function() use($warehouseInventoryTable,$demandQueueTable,
        			$warehouseInventoryEntity,$demandQueueEntity) {
        		$warehouseInventoryTable->save($warehouseInventoryEntity, ['atomic' => false]);
        		$demandQueueTable->save($demandQueueEntity, ['atomic' => false]);       	
        	}) == 0 ) {   
        	$this->Flash->success(__('The {0} has been processed.', 'Demand Queue'));
        	return $this->redirect(['action' => 'index']);
        	} else {
        	$this->Flash->error(__('The {0} could not be processed. Please, try again.', 'Demand Queue'));
        	} 
        	}
        }
        $demandQueue = $this->DemandQueue->get($id, [
        		'contain' => [
        				'Order' => ['fields' => ['id','products_master_id','reference_number', 'order_date', 'quantity_ordered', 'expected_delivery_dt'] ],
        				'Order.OwnerCompanies'=> ['fields' => ['id','company_name']],
        				'Order.CustomerMaster'=> ['fields' => ['id', 'Company_name']],
        				'Order.CompanyMaster'=> ['fields' => ['id', 'Company_name']],
        				'Order.uom' => ['fields' => ['id', 'unit_symbol']],
        				'Order.ProductsMaster' => ['fields' => ['product_name']]
        		]
        ]);
        //$this->log("DemandQueue : edit - got data: ".print_r($demandQueue,true),'debug');
        
        $this->loadModel('WarehouseInventory');
        $inventory = $this->WarehouseInventory->find('all')
        ->where(['WarehouseInventory.product_id' => $demandQueue->order->products_master_id,
        		'WarehouseInventory.owner_company_id' => $demandQueue->order->owner_company->id
        ])
        ->contain(['WarehouseMaster','WarehouseInventoryDetails']);
        $this->loadModel('Uom');
        $uomObj = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol',
        		'order'=>'unit_symbol', 'groupField' => 'unit_type']);
        $uom = $uomObj->toArray();
        $this->set('uomarray',$uomObj);
        $this->set(compact('demandQueue','uom','inventory'));
        $this->set('_serialize', ['demandQueue','uom','inventory']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Demand Queue id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null){
        $this->request->allowMethod(['post', 'delete']);
        $demandQueue = $this->DemandQueue->get($id);
        if ($this->DemandQueue->delete($demandQueue)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Demand Queue'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Demand Queue'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
