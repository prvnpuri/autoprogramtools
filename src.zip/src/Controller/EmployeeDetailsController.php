<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * EmployeeDetails Controller
 *
 * @property \App\Model\Table\EmployeeDetailsTable $EmployeeDetails
 *
 * @method \App\Model\Entity\EmployeeDetail[] paginate($object = null, array $settings = [])
 */
class EmployeeDetailsController extends AppController
{
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users', 'Managers', 'Designations', 'Departments','OwnerCompanies'],
            'sortWhitelist'=>['id','first_name','middle_name','last_name','gender','Managers.username','Designations.designation','OwnerCompanies.company_name'],
            'fields'=>[
                'id','first_name','middle_name','last_name','gender','Managers.username','Designations.designation','OwnerCompanies.company_name',
                'full_name'=> $this->EmployeeDetails->query()->func()->concat(['first_name','last_name'])
            ]
        ];
        
        $employeeDetails = $this->paginate($this->EmployeeDetails);
        
        $this->set(compact('employeeDetails'));
        $this->set('_serialize', ['employeeDetails']);
    }
    
    /**
     * View method
     *
     * @param string|null $id Employee Detail id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $employeeDetail = $this->EmployeeDetails->get($id, [
            'contain' => ['Users', 'Managers', 'Designations', 'Departments']
        ]);
        
        $this->set('employeeDetail', $employeeDetail);
        $this->set('_serialize', ['employeeDetail']);
    }
    
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $employeeDetail = $this->EmployeeDetails->newEntity();
        if ($this->request->is('post')) {
            $employeeDetail = $this->EmployeeDetails->patchEntity($employeeDetail, $this->request->data);
            if ($this->EmployeeDetails->save($employeeDetail)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Detail'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Detail'));
            }
        }
        $managers = $this->EmployeeDetails->Managers->find('list', ['limit' => 200]);
        $desis = $this->EmployeeDetails->Designations->find('list', ['limit' => 200]);
        $depts = $this->EmployeeDetails->Departments->find('list', ['limit' => 200]);
        $ownercompanies=$this->EmployeeDetails->OwnerCompanies->find('list');
        $this->set(compact('employeeDetail', 'users', 'managers', 'desis', 'depts','ownercompanies'));
        $this->set('_serialize', ['employeeDetail', 'users', 'managers', 'desis', 'depts','ownercompanies']);
    }
    
    /**
     * Edit method
     *
     * @param string|null $id Employee Detail id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $employeeDetail = $this->EmployeeDetails->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $employeeDetail = $this->EmployeeDetails->patchEntity($employeeDetail, $this->request->data);
            if ($this->EmployeeDetails->save($employeeDetail)) {
                $this->Flash->success(__('The {0} has been saved.', 'Employee Detail'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Employee Detail'));
            }
        }
        $users = $this->EmployeeDetails->Users->find('list', ['limit' => 200]);
        $managers = $this->EmployeeDetails->Managers->find('list', ['limit' => 200]);
        $desis = $this->EmployeeDetails->Designations->find('list', ['limit' => 200]);
        $depts = $this->EmployeeDetails->Departments->find('list', ['limit' => 200]);
        $ownercompanies=$this->EmployeeDetails->OwnerCompanies->find('list');
        $this->set(compact('employeeDetail', 'users', 'managers', 'desis', 'depts','ownercompanies'));
        $this->set('_serialize', ['employeeDetail','ownercompanies']);
    }
    
    /**
     * Delete method
     *
     * @param string|null $id Employee Detail id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $employeeDetail = $this->EmployeeDetails->get($id);
        if ($this->EmployeeDetails->delete($employeeDetail)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Employee Detail'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Employee Detail'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
