<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;
use Cake\Filesystem\File;

/**
 * GovernmentAgenciesDocuments Controller
 *
 * @property \App\Model\Table\GovernmentAgenciesDocumentsTable $GovernmentAgenciesDocuments
 *
 * @method \App\Model\Entity\GovernmentAgenciesDocument[] paginate($object = null, array $settings = [])
 */
class GovernmentAgenciesDocumentsController extends AppController {
	
	/**
	 * Index method
	 *
	 * @return \Cake\Http\Response|void
	 */
	public function index($doc_type = null) {
		
		$conditions=array();
		$owner_company_id =  $this->Auth->User('owner_company_id' );
		
		$conditions = array('GovernmentAgenciesDocuments.government_documents_type_acronym'=>$doc_type,
				       'GovernmentAgenciesDocuments.owner_companies_id'=>$owner_company_id);
		//debug($conditions);exit;
		$this->paginate = [ 
				'contain' => [ 'OwnerCompanies'] ,
				"conditions" => $conditions,
		];
		
		$governmentAgenciesDocuments = $this->paginate ( $this->GovernmentAgenciesDocuments );
		
		$this->set ( compact ( 'governmentAgenciesDocuments' ) );
		$this->set ( '_serialize', [ 
				'governmentAgenciesDocuments' 
		] );
	}
	
	/**
	 * View method
	 *
	 * @param string|null $id
	 *        	Government Agencies Document id.
	 * @return \Cake\Http\Response|void
	 * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
	 */
	public function view($doc_type=null,$id = null) {
		$governmentAgenciesDocument = $this->GovernmentAgenciesDocuments->get ( $id, [ 
				'contain' => [ 
						'OwnerCompanies' 
				] 
		] );
		
		$this->set ( 'governmentAgenciesDocument', $governmentAgenciesDocument );
		$this->set ( '_serialize', [ 
				'governmentAgenciesDocument' 
		] );
	}
	
	/**
	 * Add method
	 *
	 * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
	 */
	public function add($doc_type = null) {
		$governmentAgenciesDocument = $this->GovernmentAgenciesDocuments->newEntity ();
		
		if ($this->request->is ( 'post' )) {
			// debug($this->request->data);exit;
			// debug($this->request->data['attachment']);exit;
			if (! empty ( $this->request->data ['attachment'] )) {
				
				foreach ( $this->request->data ['attachment'] as $attach ) {
					// debug($attach);exit;
					if (isset ( $attach ) && $attach ["error"] == 0) {
						// upload file code
						$filename = $doc_type.'_'.$this->Auth->User ( 'owner_company_id' ) . '_' . $attach ["name"];
						$url = Router::url ( '/', true ) . 'upload/goverment_agencies/' . $filename;
						$uploadpath = 'upload/goverment_agencies/';
						$uploadfile = $uploadpath . $filename;
						//move_uploaded_file ( $attach ['tmp_name'], $uploadfile );
						// end
						
						// save data code
						if (move_uploaded_file ( $attach ['tmp_name'], $uploadfile )) {
							$governmentAgenciesDocument = $this->GovernmentAgenciesDocuments->newEntity ();
							$governmentAgenciesDocument->owner_companies_id = $this->Auth->User ( 'owner_company_id' );
							$governmentAgenciesDocument->government_documents_type_acronym = $doc_type;
							$governmentAgenciesDocument->attachment = $attach ["name"];
							$governmentAgenciesDocument->date_of_creation = date ( 'Y-m-d' );
							$governmentAgenciesDocument->created_by = $this->Auth->User ( 'id' );
							
							if ($this->GovernmentAgenciesDocuments->save ( $governmentAgenciesDocument )) {
								
							} else {
								$this->Flash->error ( __ ( 'The {0} could not be saved. Please, try again.', 'Government Agencies Document' ) );
							}
							
						} else {
							$this->Flash->error ( __ ( 'Unable to upload image, please try again.' ) );
						}
					} else {
						$this->Flash->error ( __ ( 'Please choose an image to upload.' ) );
					}
				} //end foreach
				
				$this->Flash->success ( __ ( 'The {0} has been saved.', 'Government Agencies Document' ) );
				return $this->redirect ( [ 'action' => 'index',"$doc_type"] );
			} else { // checking ! empty ( $this->request->data ['attachment'] )
				$this->Flash->error ( __ ( 'Please choose an image to upload.' ) );
			}
		}
		
		$this->set ( compact ( 'governmentAgenciesDocument') );
		$this->set ( '_serialize', [ 
				'governmentAgenciesDocument' 
		] );
	}
	
	/**
	 * Edit method
	 *
	 * @param string|null $id
	 *        	Government Agencies Document id.
	 * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
	 * @throws \Cake\Network\Exception\NotFoundException When record not found.
	 */
	public function edit($doc_type,$id = null) {
		$governmentAgenciesDocument = $this->GovernmentAgenciesDocuments->get ( $id, [ 
				'contain' => [ ] 
		] );
		if ($this->request->is ( [ 'patch','post','put' ] )) {
			
			if (! empty ( $this->request->data ['attachment'][0]['name'])) {
				
				foreach ( $this->request->data ['attachment'] as $attach ) {
					// debug($attach);exit;
					if (isset ( $attach ) && $attach ["error"] == 0) {
						// upload file code
						$filename = $doc_type.'_'.$this->Auth->User ( 'owner_company_id' ) . '_' . $attach ["name"];
						$url = Router::url ( '/', true ) . 'upload/goverment_agencies/' . $filename;
						$uploadpath = 'upload/goverment_agencies/';
						$uploadfile = $uploadpath . $filename;
						//move_uploaded_file ( $attach ['tmp_name'], $uploadfile );
						// end
						
						// save data code
						if (move_uploaded_file ( $attach ['tmp_name'], $uploadfile )) {
							$governmentAgenciesDocument = $this->GovernmentAgenciesDocuments->newEntity ();
							$governmentAgenciesDocument->owner_companies_id = $this->Auth->User ( 'owner_company_id' );
							$governmentAgenciesDocument->government_documents_type_acronym = $doc_type;
							$governmentAgenciesDocument->attachment = $attach ["name"];
							$governmentAgenciesDocument->date_of_creation = date ( 'Y-m-d' );
							$governmentAgenciesDocument->created_by = $this->Auth->User ( 'id' );
							
							if ($this->GovernmentAgenciesDocuments->save ( $governmentAgenciesDocument )) {
								
							} else {
								$this->Flash->error ( __ ( 'The {0} could not be saved. Please, try again.', 'Government Agencies Document' ) );
							}
							
						} else {
							$this->Flash->error ( __ ( 'Unable to upload image, please try again.' ) );
						}
					} else {
						$this->Flash->error ( __ ( 'Please choose an image to upload.' ) );
					}
				} //end foreach
				
				$this->Flash->success ( __ ( 'The {0} has been saved.', 'Government Agencies Document' ) );
				return $this->redirect ( [ 'action' => 'index',"$doc_type"] );
			} else { // checking ! empty ( $this->request->data ['attachment'] )
				return $this->redirect ( [ 'action' => 'index',"$doc_type"] );
			}
			
			
		}
			
			/*$governmentAgenciesDocument = $this->GovernmentAgenciesDocuments->patchEntity ( $governmentAgenciesDocument, $this->request->data );
			if ($this->GovernmentAgenciesDocuments->save ( $governmentAgenciesDocument )) {
				$this->Flash->success ( __ ( 'The {0} has been saved.', 'Government Agencies Document' ) );
				return $this->redirect ( [ 
						'action' => 'index' 
				] );
			} else {
				$this->Flash->error ( __ ( 'The {0} could not be saved. Please, try again.', 'Government Agencies Document' ) );
			}
		}*/
		$ownerCompanies = $this->GovernmentAgenciesDocuments->OwnerCompanies->find ( 'list', [ 
				'limit' => 200 
		] );
		$this->set ( compact ( 'governmentAgenciesDocument', 'ownerCompanies' ) );
		$this->set ( '_serialize', [ 
				'governmentAgenciesDocument' 
		] );
	
	}
	/**
	 * Delete method
	 *
	 * @param string|null $id
	 *        	Government Agencies Document id.
	 * @return \Cake\Network\Response|null Redirects to index.
	 * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
	 */
	public function delete($doc_type =null,$id = null) {
		
		$this->request->allowMethod ( [ 
				'post',
				'delete' 
		] );
		$governmentAgenciesDocument = $this->GovernmentAgenciesDocuments->get ( $id );
		$file = new File(WWW_ROOT . 'upload/goverment_agencies/'.$doc_type.'_'.$governmentAgenciesDocument->owner_companies_id.'_'.$governmentAgenciesDocument->attachment, false, 0777);
		$file->delete();
		
		
		if ($this->GovernmentAgenciesDocuments->delete ( $governmentAgenciesDocument )) {
			$this->Flash->success ( __ ( 'The {0} has been deleted.', 'Government Agencies Document' ) );
		} else {
			$this->Flash->error ( __ ( 'The {0} could not be deleted. Please, try again.', 'Government Agencies Document' ) );
		}
		return $this->redirect ( [ 'action' => 'index',"$doc_type"] );
	}
}
