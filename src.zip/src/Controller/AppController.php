<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link      https://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   https://opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\I18n\FrozenDate;

use Cake\Cache\Cache;
use Cake\Controller\Component\RequestHandlerComponent;

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 * @property RequestHandlerComponent $RequestHandler
 * @property \App\Model\Table\NotificationsTable $Notifications
 * @property \App\Model\Table\NotificationMasterTable $NotificationMaster
 * @link https://book.cakephp.org/3.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller
{
	public $components = [
			'Acl' => [
					'className' => 'Acl.Acl'
			]
	];
	
	public static $AclActionsExclude = [
			'isAuthorized'
	];
	/**
	 * Initialization hook method.
	 *
	 * Use this method to add common initialization code like loading components.
	 *
	 * e.g. `$this->loadComponent('Security');`
	 *
	 * @return void
	 */
	public function initialize(){
		
		parent::initialize();
		$this->loadComponent('Security', ['blackHoleCallback' => 'forceSSL']);
		
		
		// Remove a key
		//Cache::delete('systemsettingData');
		//Cache::delete('companysettingData');
		
		if ((Cache::read('systemsettingData')) === false) {
			
			$this->loadModel('SystemSettings');
			$systemsetting = $this->SystemSettings->find('list', ['keyField' => 'id','valueField' => array('key', 'value')]); //,'order'=>'id'
			
			// echo "systemsetting<pre>";
			// print_r($systemsetting);
			// die();
			
			if(isset($systemsetting)){
				
				$systemsettingData = $systemsetting->toArray();
				
				foreach($systemsettingData as $system){
					
					$systemData = explode(";", $system);
					$systemInfo[$systemData[0]] = $systemData[1];
				}
				
				if(isset($systemInfo)){
					Cache::writeMany($systemInfo, $config = 'default');
				}
			}
			Cache::write('systemsettingData', $systemsettingData);
		}
		
		if ((Cache::read('companysettingData')) === false) {
			
			$this->loadModel('CompanySettings');
			$companysetting = $this->CompanySettings->find('list', ['keyField' => 'id','valueField' => array('owner_companies_id', 'category', 'key', 'value', 'active')]); //,'order'=>'id'
			$companysettingData = $companysetting->toArray();
			
			foreach($companysettingData as $company){
				
				$companyData = explode(";", $company);
				
				$companyInfo[$companyData[0].'_'.$companyData[2]] = $companyData[3];
			}
			
			if(isset($companyInfo)){
				Cache::writeMany($companyInfo, $config = 'default');
			}
			Cache::write('companysettingData', $companysettingData);
		}
		
		//Cache::write('systemsettingData', $systemsettingData);
		//Cache::write('companysettingData', $companysettingData);
		$this->loadComponent('ReferenceNumber');
		
		$this->loadComponent('RequestHandler');
		$this->loadComponent('Flash');
		$this->loadComponent('Auth', [
				'authorize' => [
						'Acl.Actions' => ['actionPath' => 'controllers/']
				],
				'loginAction' => [
						'plugin' => false,
						'controller' => 'Users',
						'action' => 'login',
				        'prefix'=>false
				],
				'loginRedirect' => [
						'plugin' => false,
				        'prefix'=>false,
						'controller' => 'Pages',
				        'action' => 'display','home'
				],
				'logoutRedirect' => [
				        'prefix'=>false,
						'plugin' => false,
						'controller' => 'Users',
						'action' => 'login'
				],
				'unauthorizedRedirect' => [

						'controller' => 'Users',
						'action' => 'login',
						'prefix' => false
				],
				'authError' => 'You are not authorized to access that location.',
				'flash' => [
						'element' => 'error'
				]
		]);
		
		// Only for ACL setup
// 		$this->Auth->allow();
		
		
	}
	
	public function beforeFilter(Event $event){
		if($this->RequestHandler->accepts("json")||$this->request->getParam("_ext")=="json"){
			
		} else {
		}
		$this->Security->requireSecure();
		
		$this->Auth->allow(['login', 'logout']);
		
	}
	
	/**
	 * Before render callback.
	 *
	 * @param \Cake\Event\Event $event The beforeRender event.
	 * @return \Cake\Http\Response|null|void
	 */
	public function beforeRender(Event $event){
		
		// Note: These defaults are just to get started quickly with development
		// and should not be used in production. You should instead set "_serialize"
		// in each action as required.
		if (!array_key_exists('_serialize', $this->viewVars) &&
				in_array($this->response->type(), ['application/json', 'application/xml'])
				) {
					$this->set('_serialize', true);
				}
				//$tt = $this->Auth->user();
				//var_dump($tt);
				// if (isset($tt))
				//$this->set('user', $tt);
				//Bootstrp Theme Call
				$this->set('Auth', $this->Auth);
				if($this->Auth !=null ){
					$userid= $this->Auth->user('id');
					$group_id= $this->Auth->user('group_id');
					$this->loadModel('Notifications');
					$cond["Notifications.status"]="1";
					$cond["NotificationMaster.group_id"]=$group_id;
					
					if($group_id!="1"){
					    $cond["Notifications.user_id"]=$group_id;
					}
					
					/** 
					 * find out the count of all types of notifications for that user/group
					 * Admin will be able to see all noitifications
					 */
					 
					$notificationCountByActivites=$this->Notifications->find('all')
					   ->join([
					       "table"=>"notification_master",
					       "alias"=>"NotificationMaster",
					       "type"=>"INNER",
					       "conditions"=>"Notifications.notification_master_id=NotificationMaster.id"
					   ]);
					$notificationCountByActivites=$notificationCountByActivites->select([
					    "notification_count"=>'COUNT(notification_by)',
					    "notification_by"
					])->group(["notification_by"])
					->where($cond);
					
					
					
					$this->set("notificationCountByActivites",$notificationCountByActivites->toArray());
					//$this->set('inquirynotificationscount', $inquirynotificationscount);
					
					}
					 // end of code for noitification
					
					
					if($this->RequestHandler->accepts("json")||$this->request->getParam("_ext")=="json"){
					    FrozenDate::setJsonEncodeFormat('yyyy-MM-dd'); 
						$this->response->withType("application/json");
					}else {
						if($this->request->getParam("controller")!="Acl"){
							$this->viewBuilder()->theme('AdminLTE');
							$this->viewBuilder()->setLayout('adminlte');
							$this->viewBuilder()->setClassName('AdminLTE.AdminLTE');
						}
					}
					
				}
				
				/**
				 * isAuthorized.
				 *
				 * @param array $user user logged.
				 * @return void
				 */
				public function isAuthorized($user) {
					//return true;
					
					// Admin can access every action
					if (isset($user['group_id']) && $user['group_id'] === 1) {
						return true;
					}
					
					// Default deny
					return false;
				}
				
				public function forceSSL($type = '')
				{
					//return $this->redirect('https://' . env('SERVER_NAME') . $this->request->getRequestTarget());
					
					if ($type === 'secure') {
						return $this->redirect('https://' . env('SERVER_NAME') . $this->request->getRequestTarget());
					}
				}
	}
	