<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * WarehouseSubunit Controller
 *
 * @property \App\Model\Table\WarehouseSubunitTable $WarehouseSubunit
 *
 * @method \App\Model\Entity\WarehouseSubunit[] paginate($object = null, array $settings = [])
 */
class WarehouseSubunitController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="warehouseSubunit.name like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['WarehouseUnit'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","name","WarehouseUnit.name"]
    	];
    	
    	
    	$warehouseSubunit = $this->paginate($this->WarehouseSubunit);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('warehouseSubunit'));
    	$this->set( '_serialize', ['warehouseSubunit','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Warehouse Subunit id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $warehouseSubunit = $this->WarehouseSubunit->get($id, [
            'contain' => ['WarehouseUnit', 'TransactionProduct', 'WarehouseProductDetails']
        ]);

        $this->set('warehouseSubunit', $warehouseSubunit);
        $this->set('_serialize', ['warehouseSubunit']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $warehouseSubunit = $this->WarehouseSubunit->newEntity();
        if ($this->request->is('post')) {
            $warehouseSubunit = $this->WarehouseSubunit->patchEntity($warehouseSubunit, $this->request->data);
            if ($this->WarehouseSubunit->save($warehouseSubunit)) {
                $this->Flash->success(__('The {0} has been saved.', 'Warehouse Subunit'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Warehouse Subunit'));
            }
        }
        $warehouseUnit = $this->WarehouseSubunit->WarehouseUnit->find('list', ['keyField' => 'id','valueField' => 'name','order'=>'name'], ['limit' => 200]);
        $this->set(compact('warehouseSubunit', 'warehouseUnit'));
        $this->set('_serialize', ['warehouseSubunit']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Warehouse Subunit id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $warehouseSubunit = $this->WarehouseSubunit->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $warehouseSubunit = $this->WarehouseSubunit->patchEntity($warehouseSubunit, $this->request->data);
            if ($this->WarehouseSubunit->save($warehouseSubunit)) {
                $this->Flash->success(__('The {0} has been saved.', 'Warehouse Subunit'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Warehouse Subunit'));
            }
        }
        $warehouseUnit = $this->WarehouseSubunit->WarehouseUnit->find('list', ['limit' => 200]);
        $this->set(compact('warehouseSubunit', 'warehouseUnit'));
        $this->set('_serialize', ['warehouseSubunit']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Warehouse Subunit id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $warehouseSubunit = $this->WarehouseSubunit->get($id);
        if ($this->WarehouseSubunit->delete($warehouseSubunit)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Warehouse Subunit'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Warehouse Subunit'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
