<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PaymentsReceived Controller
 *
 * @property \App\Model\Table\PaymentsReceivedTable $PaymentsReceived
 *
 * @method \App\Model\Entity\PaymentsReceived[] paginate($object = null, array $settings = [])
 */
class PaymentsReceivedController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders', 'Currencies']
        ];
        $paymentsReceived = $this->paginate($this->PaymentsReceived);

        $this->set(compact('paymentsReceived'));
        $this->set('_serialize', ['paymentsReceived']);
    }

    /**
     * View method
     *
     * @param string|null $id Payments Received id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $paymentsReceived = $this->PaymentsReceived->get($id, [
            'contain' => ['Orders', 'Currencies']
        ]);

        $this->set('paymentsReceived', $paymentsReceived);
        $this->set('_serialize', ['paymentsReceived']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $paymentsReceived = $this->PaymentsReceived->newEntity();
        if ($this->request->is('post')) {
            $paymentsReceived = $this->PaymentsReceived->patchEntity($paymentsReceived, $this->request->data);
            if ($this->PaymentsReceived->save($paymentsReceived)) {
                $this->Flash->success(__('The {0} has been saved.', 'Payments Received'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Payments Received'));
            }
        }
        $orders = $this->PaymentsReceived->Orders->find('list', ['limit' => 200]);
        $currencies = $this->PaymentsReceived->Currencies->find('list', ['limit' => 200]);
        $this->set(compact('paymentsReceived', 'orders', 'currencies'));
        $this->set('_serialize', ['paymentsReceived']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Payments Received id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $paymentsReceived = $this->PaymentsReceived->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $paymentsReceived = $this->PaymentsReceived->patchEntity($paymentsReceived, $this->request->data);
            if ($this->PaymentsReceived->save($paymentsReceived)) {
                $this->Flash->success(__('The {0} has been saved.', 'Payments Received'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Payments Received'));
            }
        }
        $orders = $this->PaymentsReceived->Orders->find('list', ['limit' => 200]);
        $currencies = $this->PaymentsReceived->Currencies->find('list', ['limit' => 200]);
        $this->set(compact('paymentsReceived', 'orders', 'currencies'));
        $this->set('_serialize', ['paymentsReceived']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Payments Received id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $paymentsReceived = $this->PaymentsReceived->get($id);
        if ($this->PaymentsReceived->delete($paymentsReceived)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Payments Received'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Payments Received'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
