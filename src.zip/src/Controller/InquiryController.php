<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Cache\Cache;

/**
 * Inquiry Controller
 *
 * @property \App\Model\Table\InquiryTable $Inquiry
 *
 * @method \App\Model\Entity\Inquiry[] paginate($object = null, array $settings = [])
 */
class InquiryController extends AppController
{
	
	public function initialize()
	{
		parent::initialize();
		$this->loadComponent('RequestHandler');
	}
	
	/**
	 * Index method
	 *
	 * @return \Cake\Http\Response|void
	 */
	public function index()
	{
		
		 $ownercompanyid = $this->Auth->User('owner_company_id');
		$query= $this->Inquiry->find('all',
				[
						'fields'=>['OwnerCompanies.Company_name','CompanyMaster.Company_name','reference_number','qty_required','Uom.unit_symbol','ProductsMaster.product_name','id','received_on'],
						'conditions'=>['inquiry_archive' => 'N','send_to_offer' => 'NO','owner_companies_id'=>$ownercompanyid],
						'contain' => ['CompanyMaster', 'ProductsMaster', 'OwnerCompanies', 'Uom', 'Currency'],
						'order'=>['Inquiry.id' => 'DESC']
				]
				);
		
		
		
		$Inquiry = $this->paginate($query);
		
		
		$this->set('inquiry', $Inquiry);
		$this->set('_serialize', ['inquiry']);
	}
	
	/**
	 * View method
	 *
	 * @param string|null $id Inquiry id.
	 * @return \Cake\Http\Response|void
	 * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
	 */
	public function view($id = null)
	{
		$inquiry = $this->Inquiry->get($id, [
				'contain' => ['SelectedProductSpecs','SelectedProductSpecs.ProductDataTests','CompanyMaster', 'ProductsMaster','ProductsMaster.ProductDataTests','OwnerCompanies', 'Uom', 'Currency', 'FeasibilityMaster', 'Offer','PaymentTerm','PortOfDischarge','Countries','CountryOfOriginOfGood','CountryOfFinalDestination']
		]);
		$this->loadModel('CompanyContactPersons');
		$this->set('companycontactpersons',$this->CompanyContactPersons->find("all",array(
				"fields"=>array("id","prefix_name","first_name","middle_name","last_name","email_id"),
				"conditions"=>array("id IN"=>explode(",",$inquiry["company_contact_persons"])),
				
				"order"=>"concat(`first_name`,`middle_name`,`last_name`)"
		)));
		
		
		
		
		
		$this->set(compact('inquiry'));
		$this->set('_serialize', ['inquiry']);
	}
	
	/**
	 * Add method
	 *
	 * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
	 */
	public function add()
	{
		
		
		$inquiry= $this->Inquiry->newEntity();
		
		
		if ($this->request->is('post')) {
			$this->request->data['Inquiry']['send_to_offer'] ='NO';
			
			if(isset($this->request->data['data']['Inquiry']['company_contact_persons'])){
				$ptr=0;
				foreach ($this->request->data['data']['Inquiry']['company_contact_persons'] as $contact_id){
					
					
					$inquiry->company_contact_persons.=$ptr>0?",":"";
					$inquiry->company_contact_persons.=$contact_id;
					$ptr++;
				}
			}
			if(isset($this->request->data['selected_product_specs'])){
				foreach ($this->request->data['selected_product_specs'] as $key=>&$det){
					
						if($det['product_data_tests_id'] == '0'){
							unset($this->request->data['selected_product_specs'][$key]);
						}
						
					}
				}
			$this->loadModel('ReferenceNumberCounter');
			$this->loadComponent('ReferenceNumber');
			
			$next_ref =
			$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'buy_inq');
			$this->request->data['reference_number'] = $next_ref['full_next_ref_no'];
			if(!isset($next_ref['full_next_ref_no'])){
			
				$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Buyer Inquiry'));
				
			}else{
			
			
			$inquiry= $this->Inquiry->patchEntity($inquiry, $this->request->data(),[
					"associated"=>[
							"SelectedProductSpecs"
					]
			]);
			
			//echo "<pre>";
			//print_r($inquiry);exit;
			
			$inquiry['created_by'] = $this->Auth->User('id');
			if ($this->Inquiry->save($inquiry)) {
				$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
				
				$this->Flash->success(__('The {0} has been saved.', 'Inquiry'));
				return $this->redirect(['action' => 'index']);
			} else {
				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Inquiry'));
			}
			}
		}
		
		$this->loadModel('CompanyMaster');
		$this->loadModel('OwnerCompanies');
		$this->loadModel('Uom');
		$this->loadModel('Currency');
		//$this->loadModel('PackingTerm');
		$this->loadModel('PaymentTerm');
		$this->loadModel('Countries');
		$this->loadModel('PortOfDischarge');
		$companyMaster= $this->CompanyMaster->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
		$ownerCompanies= $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
		
		$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
		
		$currency= $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'sign']);
		$countryoforigineofgoods= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		//$packingterm= $this->PackingTerm->find('list', ['keyField' => 'id','valueField' => 'packing_term','order'=>'packing_term']);
		$paymentterm= $this->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
		$countries= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		$portofdischarge= $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge']);
		$this->set(compact('inquiry', 'companyMaster', 'productsMaster', 'ownerCompanies', 'uom', 'currency','countryoforigineofgoods','paymentterm','countries','portofdischarge'));
		$this->set('_serialize', ['inquiry']);
	}
	
	/**
	 * Edit method
	 *
	 * @param string|null $id Inquiry id.
	 * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
	 * @throws \Cake\Network\Exception\NotFoundException When record not found.
	 */
	public function edit($id = null)
	{
		$inquiry = $this->Inquiry->get($id, [
				'contain' => ['SelectedProductSpecs','CompanyMaster','CompanyMaster.CompanyContactPersons','ProductsMaster','ProductsMaster.ProductDataTests','OwnerCompanies', 'Uom', 'Currency']
		]);
		if ($this->request->is(['patch', 'post', 'put'])) {

			$this->request->data['company_contact_persons'] ='';
			if(isset($this->request->data['company_contact_person'])){
				$ptr=0;
				foreach ($this->request->data['company_contact_person'] as $contact_id){
					$this->request->data['company_contact_persons'].=$ptr>0?",":"";
					$this->request->data['company_contact_persons'].=$contact_id;
					$ptr++;
				}
				
			}
			
			if(isset($this->request->data['selected_product_specs'])){
				foreach ($this->request->data['selected_product_specs'] as $key=>&$det){
					if($det['product_data_tests_id'] == '0'){
						unset($this->request->data['selected_product_specs'][$key]);
					}
					
				}
			}
			
			$this->loadModel('SelectedProductSpecs');
			$this->SelectedProductSpecs->deleteAll(
					[
							'SelectedProductSpecs.transaction_id' => $id,
							'SelectedProductSpecs.type' => 'INQUIRY'
					]
					);
			
			$inquiry = $this->Inquiry->patchEntity($inquiry, $this->request->data);
			
			
			
			
			$inquiry['modified_by'] = $this->Auth->User('id');
			if ($this->Inquiry->save($inquiry)) {
				$this->Flash->success(__('The {0} has been saved.', 'Inquiry'));
				return $this->redirect(['action' => 'index']);
			} else {
				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Inquiry'));
			}
		}
		
		$this->loadModel('ProductDataTests');
		$this->set('prodatatest',$this->ProductDataTests->find("all",array(
				"fields"=>array("id","products_master_id","test","specification","methods","purpose"),
				"conditions"=>array('products_master_id'=>$inquiry->products_master_id,'purpose like'=>'%Sales%'),
				
		)));
		$this->loadModel('CompanyMaster');
		$this->loadModel('OwnerCompanies');
		$this->loadModel('Uom');
		$this->loadModel('Currency');
		//$this->loadModel('PackingTerm');
		$this->loadModel('PaymentTerm');
		$this->loadModel('Countries');
		$this->loadModel('PortOfDischarge');
		$this->loadModel('ProductDataTests');
		$this->loadModel('CompanyContactPersons');
		$companyMaster= $this->CompanyMaster->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
		$ownerCompanies= $this->OwnerCompanies->find('list', ['keyField' => 'id','valueField' => 'Company_name','order'=>'Company_name']);
		$uom = $this->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
		$currency= $this->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'sign']);
		$countryoforigineofgoods= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		//$packingterm= $this->PackingTerm->find('list', ['keyField' => 'id','valueField' => 'packing_term','order'=>'packing_term']);
		$paymentterm= $this->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
		$countries= $this->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		$portofdischarge= $this->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge']);
		$this->set(compact('inquiry', 'companyMaster', 'productsMaster', 'ownerCompanies', 'uom', 'currency','countryoforigineofgoods','paymentterm','countries','portofdischarge'));
		$this->set('_serialize', ['inquiry']);
	}
	
	/**
	 * Delete method
	 *
	 * @param string|null $id Inquiry id.
	 * @return \Cake\Network\Response|null Redirects to index.
	 * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
	 */
	public function delete($id = null)
	{
		$this->request->allowMethod(['post', 'delete']);
		$inquiry = $this->Inquiry->get($id);
		if ($this->Inquiry->delete($inquiry)) {
			$this->Flash->success(__('The {0} has been deleted.', 'Inquiry'));
		} else {
			$this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Inquiry'));
		}
		return $this->redirect(['action' => 'index']);
	}
	
	
	
	public function cannotoffer($id = null){
		$userid=$this->Auth->user('id');
		$data = array('id' => $id , 'isoffered' => false, 'inquiry_archive' => "Y");
		$inquiry = $this->Inquiry->get($id);
		$inquiry = $this->Inquiry->patchEntity($inquiry, $data);
		
		if($this->Inquiry->save($inquiry)){
		
		
		$this->loadModel('Notifications');
		
		$notifications= $this->Notifications->find()->where(['notification_by' => 'Inquiry','transaction_id'=>$id])->first();
		
		$data = array('transaction_id' => $id , 'status' => "2",'action_taken_by'=>$userid,'action_taken_on'=>date('Y-m-d'));
		$notifications= $this->Notifications->patchEntity($notifications, $data);
		$this->Notifications->save($notifications);
		
		
		}
		
		$this->Flash->success(__('The {0}  is not offered and set as inactive.', 'Inquiry'));
		
		return $this->redirect(['action' => 'index']);
	}
	
	
	public function sendToOffer($id= null){
		$inquiry = $this->Inquiry->get($id);
		$userid=$this->Auth->user('id');
		$companyInfo= $inquiry['owner_companies_id']."_iso";
		$companysettingData = Cache::read($companyInfo, $config = 'default');
		
		if ($companysettingData==1) {
			$data = array('id' => $id , 'send_to_offer' => "FES");
			$inquiry = $this->Inquiry->patchEntity($inquiry, $data);
			
		} else {
			$data = array('id' => $id , 'send_to_offer' => "YES");
			$inquiry = $this->Inquiry->patchEntity($inquiry, $data);
			
		}
		
		if($this->Inquiry->save($inquiry)){
			$this->loadModel('Notifications');
			
			$notifications= $this->Notifications->find()->where(['notification_by' => 'Inquiry','transaction_id'=>$id])->first();
			
			$data = array('transaction_id' => $id , 'status' => "2",'action_taken_by'=>$userid,'action_taken_on'=>date('Y-m-d'));
			$notifications= $this->Notifications->patchEntity($notifications, $data);
			$this->Notifications->save($notifications);
		}
		
		if ($companysettingData==1) {
		return $this->redirect(['action' => 'feasibilityindex']);
		}else{
			return $this->redirect(['controller'=>'offer','action' => 'index']);
		}
		
	}
	
	
	
	public function previewsrecordsuggestions() {
		$record = array();
		$record = $this->request->query;
		$this->autoRender = false;
		
		$options = array(
				'fields' => array('Inquiry.id',
						'Inquiry.company_master_id',
						'Inquiry.products_master_id',
						'Inquiry.qty_required',
						'Inquiry.uom_id',
						'Inquiry.rate',
						'Inquiry.currency_id',
						'Inquiry.local_offer',
						'Inquiry.packing',
						'Inquiry.expected_delivery_dt',
						'Inquiry.payment_terms',
						'Inquiry.validity_of_inquiry',
						'Inquiry.port_of_discharge_id',
						'Inquiry.country_of_origin_of_goods',
						'Inquiry.country_final_destination',
						'Inquiry.countries_id',
				),
				'conditions' => array(
						'AND'=>array('products_master_id' => $record['prodId']),
						array('company_master_id' => $record['compId'])
				)
		);
		$lmn = $this->Inquiry->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lmn));
		return null;
	}
	
	
	
	
	public function feasibilityindex()
	{
		$ownercompanyid = $this->Auth->User('owner_company_id');
		$query =$this->Inquiry->find('all',
				array('conditions'=>array('inquiry_archive' => 'N','send_to_offer' => 'FES','owner_companies_id'=>$ownercompanyid),'order'=>['Inquiry.id' => 'DESC']));
		
		
		$this->paginate = [
				'contain' => ['CompanyMaster', 'ProductsMaster', 'OwnerCompanies', 'Uom', 'Currency','FeasibilityMaster'],
				
		];
		
		
		$this->set('inquiry', $this->paginate($query));
		$this->set('_serialize', ['inquiry']);
	}
	
	
	
	
	public function sendToOfferafterfeasibility($id){
		
		$inquiry = $this->Inquiry->get($id);
		
		$data = array('id' => $id , 'send_to_offer' => "YES");
		$inquiry = $this->Inquiry->patchEntity($inquiry, $data);
		
		
		$this->Inquiry->save($inquiry);
		
		return $this->redirect(['action' => 'feasibilityindex']);
		
		
		
		
	}
	
	
	
}
