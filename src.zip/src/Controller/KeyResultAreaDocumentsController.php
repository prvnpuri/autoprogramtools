<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * KeyResultAreaDocuments Controller
 *
 * @property \App\Model\Table\KeyResultAreaDocumentsTable $KeyResultAreaDocuments
 *
 * @method \App\Model\Entity\KeyResultAreaDocument[] paginate($object = null, array $settings = [])
 */
class KeyResultAreaDocumentsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Employees']
        ];
        $keyResultAreaDocuments = $this->paginate($this->KeyResultAreaDocuments);

        $this->set(compact('keyResultAreaDocuments'));
        $this->set('_serialize', ['keyResultAreaDocuments']);
    }

    /**
     * View method
     *
     * @param string|null $id Key Result Area Document id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $keyResultAreaDocument = $this->KeyResultAreaDocuments->get($id, [
            'contain' => ['Employees']
        ]);

        $this->set('keyResultAreaDocument', $keyResultAreaDocument);
        $this->set('_serialize', ['keyResultAreaDocument']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $keyResultAreaDocument = $this->KeyResultAreaDocuments->newEntity();
        if ($this->request->is('post')) {
            $keyResultAreaDocument = $this->KeyResultAreaDocuments->patchEntity($keyResultAreaDocument, $this->request->data);
            if ($this->KeyResultAreaDocuments->save($keyResultAreaDocument)) {
                $this->Flash->success(__('The {0} has been saved.', 'Key Result Area Document'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Key Result Area Document'));
            }
        }
        $employees = $this->KeyResultAreaDocuments->Employees->find('list', ['limit' => 200]);
        $this->set(compact('keyResultAreaDocument', 'employees'));
        $this->set('_serialize', ['keyResultAreaDocument']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Key Result Area Document id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $keyResultAreaDocument = $this->KeyResultAreaDocuments->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $keyResultAreaDocument = $this->KeyResultAreaDocuments->patchEntity($keyResultAreaDocument, $this->request->data);
            if ($this->KeyResultAreaDocuments->save($keyResultAreaDocument)) {
                $this->Flash->success(__('The {0} has been saved.', 'Key Result Area Document'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Key Result Area Document'));
            }
        }
        $employees = $this->KeyResultAreaDocuments->Employees->find('list', ['limit' => 200]);
        $this->set(compact('keyResultAreaDocument', 'employees'));
        $this->set('_serialize', ['keyResultAreaDocument']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Key Result Area Document id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $keyResultAreaDocument = $this->KeyResultAreaDocuments->get($id);
        if ($this->KeyResultAreaDocuments->delete($keyResultAreaDocument)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Key Result Area Document'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Key Result Area Document'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
