<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;
/**
 * TestingMasters Controller
 *
 * @property \App\Model\Table\TestingMastersTable $TestingMasters
 *
 * @method \App\Model\Entity\TestingMaster[] paginate($object = null, array $settings = [])
 */
class TestingMastersController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="TestingMasters.test_name like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['TestMethods'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["test_name","type"]
    	];
    	
    	$testingMasters = $this->paginate($this->TestingMasters);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('testingMasters'));
    	$this->set( '_serialize', ['testingMasters','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Testing Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $testingMaster = $this->TestingMasters->get($id, [
            'contain' => ['TestPhotos']
        ]);
        
        $this->loadModel('Uom');
        $this->loadModel('TestPhotos');
        $uom = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_symbol'], ['limit' => 200]);
        $photos = $this->TestPhotos->find('all')->where(['TestPhotos.testing_masters_id'=>$id]);
        $this->set(compact('testingMaster','uom','photos'));
        $this->set('_serialize', ['testingMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
		public function add()
		{
			$testingMaster = $this->TestingMasters->newEntity();
			if ($this->request->is('post')) {
				
				$testingMaster = $this->TestingMasters->patchEntity($testingMaster, $this->request->data,
						[
							'associated' => ['TestPhotos']
						]);
				
				foreach ($this->request->data["test_photos"] as $key => $d ) {
					if(isset($d["image"]) &&  $d["image"]["error"]==0)
					{
						$filename=$d["image"]["name"];
						$testingMaster["test_photos"][$key]["photos"]=$filename;
					}else{
						unset($d["photos"]);
					}
				}
				$testingMaster['created_by'] = $this->Auth->User('id');
				if ($this->TestingMasters->save($testingMaster)) {
					$id = $testingMaster->id;
					foreach ($this->request->data["test_photos"] as $key => $d ) {
						if(isset($d["image"]) &&  $d["image"]["error"]==0)
						{
							$filename = $id."_".$d["image"]["name"];
							$url = Router::url('/',true).'upload/testing-masters/'.$filename;
							$uploadpath = 'upload/testing-masters/';
							$uploadfile = $uploadpath.$filename;
							move_uploaded_file($d["image"]['tmp_name'], $uploadfile);
								
						}else{
							unset($d["testing_masters"]);
						}
					}
					
					$this->Flash->success(__('The {0} has been saved.', 'Testing Master'));
					return $this->redirect(['action' => 'index']);
				} else {
					$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Testing Master'));
				}
			}
			$this->loadModel('Uom');
			$uom = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_symbol'], ['limit' => 200]);
			$this->set(compact('testingMaster','uom'));
			$this->set('_serialize', ['testingMaster']);
		}

	/**
     * Edit method
     *
     * @param string|null $id Testing Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $testingMaster = $this->TestingMasters->get($id, [
            'contain' => ['TestPhotos']
        ]);
        
     	if ($this->request->is(['patch', 'post', 'put'])) {
     		$testingMaster = $this->TestingMasters->patchEntity($testingMaster, $this->request->data(),
            		[
            				'associated'=>['TestPhotos']
            		]);
           if (isset($this->request->data["test_photos"])){
            foreach ($this->request->data["test_photos"] as $key => $d ) {
            	
				
            	if(isset($d["image"]) &&  $d["image"]["error"]==0)
            	{
            		$filename=$d["image"]["name"];
            		$testingMaster["test_photos"][$key]["photos"]=$filename;
            	}else{
            		unset($d["photos"]);
            	}
            }
           }

           if(isset($this->request->data['Delete'])){
           		foreach ( $this->request->data['Delete']['id'] as $key => $id ) {
           			$testPhoto = $this->TestingMasters->TestPhotos->get($id);
           	        $this->TestingMasters->TestPhotos->delete($testPhoto);
           	    }
           	}
           	
           	$testingMaster['modified_by'] = $this->Auth->User('id');
            if ($this->TestingMasters->save($testingMaster)) {
           		$id = $testingMaster->id;
            	
            	if (isset($this->request->data["test_photos"])){
            	foreach ($this->request->data['test_photos'] as $key => $d ) {
            	    if(isset($d["image"]) &&  $d["image"]["error"]==0){
            		     $filename = $id."_".$d["image"]["name"];
            		     $url = Router::url('/',true).'upload/testing-masters/'.$filename;
            		     $uploadpath = 'upload/testing-masters/';
            		     $uploadfile = $uploadpath.$filename;
            		     move_uploaded_file($d["image"]['tmp_name'], $uploadfile);
            	    }else{
            		     unset($d["testing_masters"]);
            		}
            	}
            	}
            	$this->Flash->success(__('The {0} has been saved.', 'Testing Master'));
            	return $this->redirect(['action' => 'index']);
            }
            else {
            	$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Testing Master'));
            }
        }
        $this->loadModel('Uom');
        $this->loadModel('TestPhotos');
        $uom = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_symbol'], ['limit' => 200]);
        $photos = $this->TestPhotos->find('all')->where(['TestPhotos.testing_masters_id'=>$id]);
        $this->set(compact('testingMaster','uom','photos'));
        $this->set('_serialize', ['testingMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Testing Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
    	$this->request->allowMethod(['post', 'delete']);
    	$testMaster = $this->TestingMasters->get($id);
    	if ($this->TestingMasters->delete($testMaster)) {
    		$this->Flash->success(__('The {0} has been deleted.', 'Test Method'));
    	} else {
    		$this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Test Method'));
    	}
    	return $this->redirect(['controller'=>'TestingMasters','action' => 'index']);
    }
}
