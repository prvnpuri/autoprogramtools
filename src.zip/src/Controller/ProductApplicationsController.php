<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Routing\Router;

/**
 * ProductApplications Controller
 *
 * @property \App\Model\Table\ProductApplicationsTable $ProductApplications
 *
 * @method \App\Model\Entity\ProductApplication[] paginate($object = null, array $settings = [])
 */
class ProductApplicationsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="ProductApplications.application_name like '%$query%'";
    	}
    	$this->paginate = [
    		
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","application_name"]
    	];
    	
        $productApplications = $this->paginate($this->ProductApplications);
        $this->set("paging",$this->request->getParam("paging"));
        $this->set(compact('productApplications'));
        $this->set( '_serialize', ['productApplications','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Product Application id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productApplication = $this->ProductApplications->get($id, [
            'contain' => []
        ]);

        $this->set('productApplication', $productApplication);
        $this->set('_serialize', ['productApplication']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productApplication = $this->ProductApplications->newEntity();
        if ($this->request->is('post')) {
            $productApplication = $this->ProductApplications->patchEntity($productApplication, $this->request->data);
            if ($this->ProductApplications->save($productApplication)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Application'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Application'));
            }
        }
        $this->set(compact('productApplication'));
        $this->set('_serialize', ['productApplication']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product Application id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productApplication = $this->ProductApplications->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productApplication = $this->ProductApplications->patchEntity($productApplication, $this->request->data);
            if ($this->ProductApplications->save($productApplication)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Application'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Application'));
            }
        }
        $this->set(compact('productApplication'));
        $this->set('_serialize', ['productApplication']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product Application id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productApplication = $this->ProductApplications->get($id);
        if ($this->ProductApplications->delete($productApplication)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product Application'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product Application'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
