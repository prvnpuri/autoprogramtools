<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * LocalPreShipmentAttachment Controller
 *
 * @property \App\Model\Table\LocalPreShipmentAttachmentTable $LocalPreShipmentAttachment
 *
 * @method \App\Model\Entity\LocalPreShipmentAttachment[] paginate($object = null, array $settings = [])
 */
class LocalPreShipmentAttachmentController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'Oas']
        ];
        $localPreShipmentAttachment = $this->paginate($this->LocalPreShipmentAttachment);

        $this->set(compact('localPreShipmentAttachment'));
        $this->set('_serialize', ['localPreShipmentAttachment']);
    }

    /**
     * View method
     *
     * @param string|null $id Local Pre Shipment Attachment id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $localPreShipmentAttachment = $this->LocalPreShipmentAttachment->get($id, [
            'contain' => ['Invoices', 'Oas']
        ]);

        $this->set('localPreShipmentAttachment', $localPreShipmentAttachment);
        $this->set('_serialize', ['localPreShipmentAttachment']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $localPreShipmentAttachment = $this->LocalPreShipmentAttachment->newEntity();
        if ($this->request->is('post')) {
            $localPreShipmentAttachment = $this->LocalPreShipmentAttachment->patchEntity($localPreShipmentAttachment, $this->request->data);
            if ($this->LocalPreShipmentAttachment->save($localPreShipmentAttachment)) {
                $this->Flash->success(__('The {0} has been saved.', 'Local Pre Shipment Attachment'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Local Pre Shipment Attachment'));
            }
        }
        $invoices = $this->LocalPreShipmentAttachment->Invoices->find('list', ['limit' => 200]);
        $oas = $this->LocalPreShipmentAttachment->Oas->find('list', ['limit' => 200]);
        $this->set(compact('localPreShipmentAttachment', 'invoices', 'oas'));
        $this->set('_serialize', ['localPreShipmentAttachment']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Local Pre Shipment Attachment id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $localPreShipmentAttachment = $this->LocalPreShipmentAttachment->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $localPreShipmentAttachment = $this->LocalPreShipmentAttachment->patchEntity($localPreShipmentAttachment, $this->request->data);
            if ($this->LocalPreShipmentAttachment->save($localPreShipmentAttachment)) {
                $this->Flash->success(__('The {0} has been saved.', 'Local Pre Shipment Attachment'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Local Pre Shipment Attachment'));
            }
        }
        $invoices = $this->LocalPreShipmentAttachment->Invoices->find('list', ['limit' => 200]);
        $oas = $this->LocalPreShipmentAttachment->Oas->find('list', ['limit' => 200]);
        $this->set(compact('localPreShipmentAttachment', 'invoices', 'oas'));
        $this->set('_serialize', ['localPreShipmentAttachment']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Local Pre Shipment Attachment id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $localPreShipmentAttachment = $this->LocalPreShipmentAttachment->get($id);
        if ($this->LocalPreShipmentAttachment->delete($localPreShipmentAttachment)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Local Pre Shipment Attachment'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Local Pre Shipment Attachment'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
