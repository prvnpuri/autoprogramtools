<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PreShipmentBase Controller
 *
 * @property \App\Model\Table\PreShipmentBaseTable $PreShipmentBase
 *
 * @method \App\Model\Entity\PreShipmentBase[] paginate($object = null, array $settings = [])
 */
class PreShipmentBaseController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Invoices', 'OwnerCompanies', 'OwnerCompanyOffices', 'Consignees', 'Notifies', 'Buyers', 'Products', 'Uoms', 'Currencies', 'Oas', 'Orders']
        ];
        $preShipmentBase = $this->paginate($this->PreShipmentBase);

        $this->set(compact('preShipmentBase'));
        $this->set('_serialize', ['preShipmentBase']);
    }

    /**
     * View method
     *
     * @param string|null $id Pre Shipment Base id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $preShipmentBase = $this->PreShipmentBase->get($id, [
            'contain' => ['Invoices', 'OwnerCompanies', 'OwnerCompanyOffices', 'Consignees', 'Notifies', 'Buyers', 'Products', 'Uoms', 'Currencies', 'Oas', 'Orders']
        ]);

        $this->set('preShipmentBase', $preShipmentBase);
        $this->set('_serialize', ['preShipmentBase']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $preShipmentBase = $this->PreShipmentBase->newEntity();
        if ($this->request->is('post')) {
            $preShipmentBase = $this->PreShipmentBase->patchEntity($preShipmentBase, $this->request->data);
            if ($this->PreShipmentBase->save($preShipmentBase)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Base'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Base'));
            }
        }
        $invoices = $this->PreShipmentBase->Invoices->find('list', ['limit' => 200]);
        $ownerCompanies = $this->PreShipmentBase->OwnerCompanies->find('list', ['limit' => 200]);
        $ownerCompanyOffices = $this->PreShipmentBase->OwnerCompanyOffices->find('list', ['limit' => 200]);
        $consignees = $this->PreShipmentBase->Consignees->find('list', ['limit' => 200]);
        $notifies = $this->PreShipmentBase->Notifies->find('list', ['limit' => 200]);
        $buyers = $this->PreShipmentBase->Buyers->find('list', ['limit' => 200]);
        $products = $this->PreShipmentBase->Products->find('list', ['limit' => 200]);
        $uoms = $this->PreShipmentBase->Uoms->find('list', ['limit' => 200]);
        $currencies = $this->PreShipmentBase->Currencies->find('list', ['limit' => 200]);
        $oas = $this->PreShipmentBase->Oas->find('list', ['limit' => 200]);
        $orders = $this->PreShipmentBase->Orders->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentBase', 'invoices', 'ownerCompanies', 'ownerCompanyOffices', 'consignees', 'notifies', 'buyers', 'products', 'uoms', 'currencies', 'oas', 'orders'));
        $this->set('_serialize', ['preShipmentBase']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Pre Shipment Base id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $preShipmentBase = $this->PreShipmentBase->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $preShipmentBase = $this->PreShipmentBase->patchEntity($preShipmentBase, $this->request->data);
            if ($this->PreShipmentBase->save($preShipmentBase)) {
                $this->Flash->success(__('The {0} has been saved.', 'Pre Shipment Base'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Pre Shipment Base'));
            }
        }
        $invoices = $this->PreShipmentBase->Invoices->find('list', ['limit' => 200]);
        $ownerCompanies = $this->PreShipmentBase->OwnerCompanies->find('list', ['limit' => 200]);
        $ownerCompanyOffices = $this->PreShipmentBase->OwnerCompanyOffices->find('list', ['limit' => 200]);
        $consignees = $this->PreShipmentBase->Consignees->find('list', ['limit' => 200]);
        $notifies = $this->PreShipmentBase->Notifies->find('list', ['limit' => 200]);
        $buyers = $this->PreShipmentBase->Buyers->find('list', ['limit' => 200]);
        $products = $this->PreShipmentBase->Products->find('list', ['limit' => 200]);
        $uoms = $this->PreShipmentBase->Uoms->find('list', ['limit' => 200]);
        $currencies = $this->PreShipmentBase->Currencies->find('list', ['limit' => 200]);
        $oas = $this->PreShipmentBase->Oas->find('list', ['limit' => 200]);
        $orders = $this->PreShipmentBase->Orders->find('list', ['limit' => 200]);
        $this->set(compact('preShipmentBase', 'invoices', 'ownerCompanies', 'ownerCompanyOffices', 'consignees', 'notifies', 'buyers', 'products', 'uoms', 'currencies', 'oas', 'orders'));
        $this->set('_serialize', ['preShipmentBase']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Pre Shipment Base id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $preShipmentBase = $this->PreShipmentBase->get($id);
        if ($this->PreShipmentBase->delete($preShipmentBase)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Pre Shipment Base'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Pre Shipment Base'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
