<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductIndustryApplications Controller
 *
 * @property \App\Model\Table\ProductIndustryApplicationsTable $ProductIndustryApplications
 *
 * @method \App\Model\Entity\ProductIndustryApplication[] paginate($object = null, array $settings = [])
 */
class ProductIndustryApplicationsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ProductsMaster', 'IndustryTypeMaster', 'ProductApplications']
        ];
        $productIndustryApplications = $this->paginate($this->ProductIndustryApplications);

        $this->set(compact('productIndustryApplications'));
        $this->set('_serialize', ['productIndustryApplications']);
    }

    /**
     * View method
     *
     * @param string|null $id Product Industry Application id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productIndustryApplication = $this->ProductIndustryApplications->get($id, [
            'contain' => ['ProductsMaster', 'IndustryTypeMaster', 'ProductApplications']
        ]);

        $this->set('productIndustryApplication', $productIndustryApplication);
        $this->set('_serialize', ['productIndustryApplication']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productIndustryApplication = $this->ProductIndustryApplications->newEntity();
        if ($this->request->is('post')) {
            $productIndustryApplication = $this->ProductIndustryApplications->patchEntity($productIndustryApplication, $this->request->data);
            if ($this->ProductIndustryApplications->save($productIndustryApplication)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Industry Application'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Industry Application'));
            }
        }
        $productsMaster = $this->ProductIndustryApplications->ProductsMaster->find('list', ['limit' => 200]);
        $industryTypeMaster = $this->ProductIndustryApplications->IndustryTypeMaster->find('list', ['limit' => 200]);
        $productApplications = $this->ProductIndustryApplications->ProductApplications->find('list', ['limit' => 200]);
        $this->set(compact('productIndustryApplication', 'productsMaster', 'industryTypeMaster', 'productApplications'));
        $this->set('_serialize', ['productIndustryApplication']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product Industry Application id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productIndustryApplication = $this->ProductIndustryApplications->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productIndustryApplication = $this->ProductIndustryApplications->patchEntity($productIndustryApplication, $this->request->data);
            if ($this->ProductIndustryApplications->save($productIndustryApplication)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Industry Application'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Industry Application'));
            }
        }
        $productsMaster = $this->ProductIndustryApplications->ProductsMaster->find('list', ['limit' => 200]);
        $industryTypeMaster = $this->ProductIndustryApplications->IndustryTypeMaster->find('list', ['limit' => 200]);
        $productApplications = $this->ProductIndustryApplications->ProductApplications->find('list', ['limit' => 200]);
        $this->set(compact('productIndustryApplication', 'productsMaster', 'industryTypeMaster', 'productApplications'));
        $this->set('_serialize', ['productIndustryApplication']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product Industry Application id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productIndustryApplication = $this->ProductIndustryApplications->get($id);
        if ($this->ProductIndustryApplications->delete($productIndustryApplication)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product Industry Application'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product Industry Application'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
