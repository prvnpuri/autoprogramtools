<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * MarksContainer Controller
 *
 * @property \App\Model\Table\MarksContainerTable $MarksContainer
 *
 * @method \App\Model\Entity\MarksContainer[] paginate($object = null, array $settings = [])
 */
class MarksContainerController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="MarksContainer.marks_container_name like '%$query%'";
    	}
    	$this->paginate = [
                'contain' => ['CompanyMaster','ProductsMaster'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["marks_container_name"]
    	];
    	$marksContainer= $this->paginate($this->MarksContainer);
    	
    	
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('marksContainer'));
        $this->set( '_serialize', ['marksContainer','paging']);
        
    }

    /**
     * View method
     *
     * @param string|null $id Marks Container id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $marksContainer = $this->MarksContainer->get($id, ['contain' => ['CompanyMaster','ProductsMaster']
           
    ]);

        $this->set('marksContainer', $marksContainer);
        $this->set('_serialize', ['marksContainer']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {    
        $marksContainer = $this->MarksContainer->newEntity();
        if ($this->request->is('post')) {
            $marksContainer = $this->MarksContainer->patchEntity($marksContainer, $this->request->data);
            $marksContainer['created_by'] = $this->Auth->User('company_id');
            if ($this->MarksContainer->save($marksContainer)) {
                $this->Flash->success(__('The {0} has been saved.', 'Marks Container'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Marks Container'));
            }
        }
       
        $this->set(compact('marksContainer'));
        $this->set('_serialize', ['marksContainer']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Marks Container id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $marksContainer = $this->MarksContainer->get($id, [
            'contain' => ['CompanyMaster','ProductsMaster']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $marksContainer = $this->MarksContainer->patchEntity($marksContainer, $this->request->data);
            if ($this->MarksContainer->save($marksContainer)) {
                $this->Flash->success(__('The {0} has been saved.', 'Marks Container'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Marks Container'));
            }
        }
        $this->set(compact('marksContainer'));
        $this->set('_serialize', ['marksContainer']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Marks Container id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $marksContainer = $this->MarksContainer->get($id);
        if ($this->MarksContainer->delete($marksContainer)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Marks Container'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Marks Container'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
