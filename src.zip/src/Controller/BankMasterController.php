<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * BankMaster Controller
 *
 * @property \App\Model\Table\BankMasterTable $BankMaster
 *
 * @method \App\Model\Entity\BankMaster[] paginate($object = null, array $settings = [])
 */
class BankMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $bankMaster = $this->paginate($this->BankMaster);

        $this->set(compact('bankMaster'));
        $this->set('_serialize', ['bankMaster']);
    }

    /**
     * View method
     *
     * @param string|null $id Bank Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $bankMaster = $this->BankMaster->get($id, [
            'contain' => []
        ]);

        $this->set('bankMaster', $bankMaster);
        $this->set('_serialize', ['bankMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $bankMaster = $this->BankMaster->newEntity();
        if ($this->request->is('post')) {
            $bankMaster = $this->BankMaster->patchEntity($bankMaster, $this->request->data);
            if ($this->BankMaster->save($bankMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Bank Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bank Master'));
            }
        }
        $this->set(compact('bankMaster'));
        $this->set('_serialize', ['bankMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Bank Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $bankMaster = $this->BankMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $bankMaster = $this->BankMaster->patchEntity($bankMaster, $this->request->data);
            if ($this->BankMaster->save($bankMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Bank Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bank Master'));
            }
        }
        $this->set(compact('bankMaster'));
        $this->set('_serialize', ['bankMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Bank Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $bankMaster = $this->BankMaster->get($id);
        if ($this->BankMaster->delete($bankMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Bank Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Bank Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
