<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * QualityDelPerformanceOfSupplier Controller
 *
 * @property \App\Model\Table\QualityDelPerformanceOfSupplierTable $QualityDelPerformanceOfSupplier
 *
 * @method \App\Model\Entity\QualityDelPerformanceOfSupplier[] paginate($object = null, array $settings = [])
 */
class QualityDelPerformanceOfSupplierController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['OwnerCompanies', 'Suppliers']
        ];
        $qualityDelPerformanceOfSupplier = $this->paginate($this->QualityDelPerformanceOfSupplier);

        $this->set(compact('qualityDelPerformanceOfSupplier'));
        $this->set('_serialize', ['qualityDelPerformanceOfSupplier']);
    }

    /**
     * View method
     *
     * @param string|null $id Quality Del Performance Of Supplier id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $qualityDelPerformanceOfSupplier = $this->QualityDelPerformanceOfSupplier->get($id, [
            'contain' => ['OwnerCompanies', 'Suppliers']
        ]);

        $this->set('qualityDelPerformanceOfSupplier', $qualityDelPerformanceOfSupplier);
        $this->set('_serialize', ['qualityDelPerformanceOfSupplier']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $qualityDelPerformanceOfSupplier = $this->QualityDelPerformanceOfSupplier->newEntity();
        if ($this->request->is('post')) {
            $qualityDelPerformanceOfSupplier = $this->QualityDelPerformanceOfSupplier->patchEntity($qualityDelPerformanceOfSupplier, $this->request->data);
            if ($this->QualityDelPerformanceOfSupplier->save($qualityDelPerformanceOfSupplier)) {
                $this->Flash->success(__('The {0} has been saved.', 'Quality Del Performance Of Supplier'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Quality Del Performance Of Supplier'));
            }
        }
        $ownerCompanies = $this->QualityDelPerformanceOfSupplier->OwnerCompanies->find('list', ['limit' => 200]);
        $suppliers = $this->QualityDelPerformanceOfSupplier->Suppliers->find('list', ['limit' => 200]);
        $this->set(compact('qualityDelPerformanceOfSupplier', 'ownerCompanies', 'suppliers'));
        $this->set('_serialize', ['qualityDelPerformanceOfSupplier']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Quality Del Performance Of Supplier id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $qualityDelPerformanceOfSupplier = $this->QualityDelPerformanceOfSupplier->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $qualityDelPerformanceOfSupplier = $this->QualityDelPerformanceOfSupplier->patchEntity($qualityDelPerformanceOfSupplier, $this->request->data);
            if ($this->QualityDelPerformanceOfSupplier->save($qualityDelPerformanceOfSupplier)) {
                $this->Flash->success(__('The {0} has been saved.', 'Quality Del Performance Of Supplier'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Quality Del Performance Of Supplier'));
            }
        }
        $ownerCompanies = $this->QualityDelPerformanceOfSupplier->OwnerCompanies->find('list', ['limit' => 200]);
        $suppliers = $this->QualityDelPerformanceOfSupplier->Suppliers->find('list', ['limit' => 200]);
        $this->set(compact('qualityDelPerformanceOfSupplier', 'ownerCompanies', 'suppliers'));
        $this->set('_serialize', ['qualityDelPerformanceOfSupplier']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Quality Del Performance Of Supplier id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $qualityDelPerformanceOfSupplier = $this->QualityDelPerformanceOfSupplier->get($id);
        if ($this->QualityDelPerformanceOfSupplier->delete($qualityDelPerformanceOfSupplier)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Quality Del Performance Of Supplier'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Quality Del Performance Of Supplier'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
