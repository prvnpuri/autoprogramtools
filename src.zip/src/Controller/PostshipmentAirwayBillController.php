<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PostshipmentAirwayBill Controller
 *
 * @property \App\Model\Table\PostshipmentAirwayBillTable $PostshipmentAirwayBill
 *
 * @method \App\Model\Entity\PostshipmentAirwayBill[] paginate($object = null, array $settings = [])
 */
class PostshipmentAirwayBillController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Oas']
        ];
        $postshipmentAirwayBill = $this->paginate($this->PostshipmentAirwayBill);

        $this->set(compact('postshipmentAirwayBill'));
        $this->set('_serialize', ['postshipmentAirwayBill']);
    }

    /**
     * View method
     *
     * @param string|null $id Postshipment Airway Bill id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $postshipmentAirwayBill = $this->PostshipmentAirwayBill->get($id, [
            'contain' => ['Oas']
        ]);

        $this->set('postshipmentAirwayBill', $postshipmentAirwayBill);
        $this->set('_serialize', ['postshipmentAirwayBill']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $postshipmentAirwayBill = $this->PostshipmentAirwayBill->newEntity();
        if ($this->request->is('post')) {
            $postshipmentAirwayBill = $this->PostshipmentAirwayBill->patchEntity($postshipmentAirwayBill, $this->request->data);
            if ($this->PostshipmentAirwayBill->save($postshipmentAirwayBill)) {
                $this->Flash->success(__('The {0} has been saved.', 'Postshipment Airway Bill'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Postshipment Airway Bill'));
            }
        }
        $oas = $this->PostshipmentAirwayBill->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postshipmentAirwayBill', 'oas'));
        $this->set('_serialize', ['postshipmentAirwayBill']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Postshipment Airway Bill id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $postshipmentAirwayBill = $this->PostshipmentAirwayBill->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $postshipmentAirwayBill = $this->PostshipmentAirwayBill->patchEntity($postshipmentAirwayBill, $this->request->data);
            if ($this->PostshipmentAirwayBill->save($postshipmentAirwayBill)) {
                $this->Flash->success(__('The {0} has been saved.', 'Postshipment Airway Bill'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Postshipment Airway Bill'));
            }
        }
        $oas = $this->PostshipmentAirwayBill->Oas->find('list', ['limit' => 200]);
        $this->set(compact('postshipmentAirwayBill', 'oas'));
        $this->set('_serialize', ['postshipmentAirwayBill']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Postshipment Airway Bill id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $postshipmentAirwayBill = $this->PostshipmentAirwayBill->get($id);
        if ($this->PostshipmentAirwayBill->delete($postshipmentAirwayBill)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Postshipment Airway Bill'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Postshipment Airway Bill'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
