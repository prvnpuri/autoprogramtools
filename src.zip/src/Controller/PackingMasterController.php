<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PackingMaster Controller
 *
 * @property \App\Model\Table\PackingMasterTable $PackingMaster
 *
 * @method \App\Model\Entity\PackingMaster[] paginate($object = null, array $settings = [])
 */
class PackingMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="PackingMaster.specification like '%$query%'";
    	}
    	$this->paginate = [
    			'contain' => ['PackingType','PackingSubtype'],
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","packingMaster","specification","description","color"]
    	];
    	
    	
    	$packingMaster = $this->paginate($this->PackingMaster);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->loadModel('PackingType');
    	$this->loadModel('PackingSubtype');
    	$this->loadModel('Uom');
    	$packingtype = $this->PackingType->find('list',['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type'], ['limit' => 200]);
    	$packingsubtype = $this->PackingSubtype->find('list',['keyField' => 'id','valueField' => 'sub_type'], ['limit' => 200]);
    	$uom = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_symbol'], ['limit' => 200]);
    	
    	$this->set(compact('packingMaster','packingtype','packingsubtype','uom'));
    	// $this->set('_serialize', ['city']);
    	$this->set( '_serialize', ['packingMaster','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Packing Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $packingMaster = $this->PackingMaster->get($id, [
            'contain' => ['PackingType','PackingSubtype','Uom']
        ]);
		$this->set(compact('packingMaster'));
        $this->set('_serialize', ['packingMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $packingMaster = $this->PackingMaster->newEntity();
        if ($this->request->is('post')) {
            $packingMaster = $this->PackingMaster->patchEntity($packingMaster, $this->request->data);
            $packingMaster['created_by'] = $this->Auth->User('id');
            if ($this->PackingMaster->save($packingMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Packing Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Packing Master'));
            }
        }
        $this->loadModel('PackingType');
        $this->loadModel('PackingSubtype');
        $this->loadModel('Uom');
        $packingtype = $this->PackingType->find('list',['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type'], ['limit' => 200]);
        $packingsubtype = $this->PackingSubtype->find('list',['keyField' => 'id','valueField' => 'sub_type'], ['limit' => 200]);
        $uom = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_symbol'], ['limit' => 200]);
        $this->set(compact('packingMaster','packingtype','packingsubtype','uom'));
        $this->set('_serialize', ['packingMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Packing Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $packingMaster = $this->PackingMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $packingMaster = $this->PackingMaster->patchEntity($packingMaster, $this->request->data);
            $packingMaster['edited_by'] = $this->Auth->User('id');
            if ($this->PackingMaster->save($packingMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Packing Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Packing Master'));
            }
        }
        $this->loadModel('PackingType');
        $this->loadModel('PackingSubtype');
        $this->loadModel('Uom');
        $packingtype = $this->PackingType->find('list',['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type'], ['limit' => 200]);
        $packingsubtype = $this->PackingSubtype->find('list',['keyField' => 'id','valueField' => 'sub_type'], ['limit' => 200]);
        $uom = $this->Uom->find('list',['keyField' => 'id','valueField' => 'unit_symbol'], ['limit' => 200]);
        $this->set(compact('packingMaster','packingtype','packingsubtype','uom'));
        $this->set('_serialize', ['packingMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Packing Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $packingMaster = $this->PackingMaster->get($id);
        if ($this->PackingMaster->delete($packingMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Packing Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Packing Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
