<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * MarketingCampaignProducts Controller
 *
 * @property \App\Model\Table\MarketingCampaignProductsTable $MarketingCampaignProducts
 *
 * @method \App\Model\Entity\MarketingCampaignProduct[] paginate($object = null, array $settings = [])
 */
class MarketingCampaignProductsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products', 'MarketingCampaigns']
        ];
        $marketingCampaignProducts = $this->paginate($this->MarketingCampaignProducts);

        $this->set(compact('marketingCampaignProducts'));
        $this->set('_serialize', ['marketingCampaignProducts']);
    }

    /**
     * View method
     *
     * @param string|null $id Marketing Campaign Product id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $marketingCampaignProduct = $this->MarketingCampaignProducts->get($id, [
            'contain' => ['Products', 'MarketingCampaigns']
        ]);

        $this->set('marketingCampaignProduct', $marketingCampaignProduct);
        $this->set('_serialize', ['marketingCampaignProduct']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $marketingCampaignProduct = $this->MarketingCampaignProducts->newEntity();
        if ($this->request->is('post')) {
            $marketingCampaignProduct = $this->MarketingCampaignProducts->patchEntity($marketingCampaignProduct, $this->request->data);
            if ($this->MarketingCampaignProducts->save($marketingCampaignProduct)) {
                $this->Flash->success(__('The {0} has been saved.', 'Marketing Campaign Product'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Marketing Campaign Product'));
            }
        }
        $products = $this->MarketingCampaignProducts->Products->find('list', ['limit' => 200]);
        $marketingCampaigns = $this->MarketingCampaignProducts->MarketingCampaigns->find('list', ['limit' => 200]);
        $this->set(compact('marketingCampaignProduct', 'products', 'marketingCampaigns'));
        $this->set('_serialize', ['marketingCampaignProduct']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Marketing Campaign Product id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $marketingCampaignProduct = $this->MarketingCampaignProducts->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $marketingCampaignProduct = $this->MarketingCampaignProducts->patchEntity($marketingCampaignProduct, $this->request->data);
            if ($this->MarketingCampaignProducts->save($marketingCampaignProduct)) {
                $this->Flash->success(__('The {0} has been saved.', 'Marketing Campaign Product'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Marketing Campaign Product'));
            }
        }
        $products = $this->MarketingCampaignProducts->Products->find('list', ['limit' => 200]);
        $marketingCampaigns = $this->MarketingCampaignProducts->MarketingCampaigns->find('list', ['limit' => 200]);
        $this->set(compact('marketingCampaignProduct', 'products', 'marketingCampaigns'));
        $this->set('_serialize', ['marketingCampaignProduct']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Marketing Campaign Product id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $marketingCampaignProduct = $this->MarketingCampaignProducts->get($id);
        if ($this->MarketingCampaignProducts->delete($marketingCampaignProduct)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Marketing Campaign Product'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Marketing Campaign Product'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
