<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductDataTests Controller
 *
 * @property \App\Model\Table\ProductDataTestsTable $ProductDataTests
 *
 * @method \App\Model\Entity\ProductDataTest[] paginate($object = null, array $settings = [])
 */
class ProductDataTestsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ProductsMaster']
        ];
        $productDataTests = $this->paginate($this->ProductDataTests);

        $this->set(compact('productDataTests'));
        $this->set('_serialize', ['productDataTests']);
    }

    /**
     * View method
     *
     * @param string|null $id Product Data Test id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productDataTest = $this->ProductDataTests->get($id, [
            'contain' => ['ProductsMaster']
        ]);

        $this->set('productDataTest', $productDataTest);
        $this->set('_serialize', ['productDataTest']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productDataTest = $this->ProductDataTests->newEntity();
        if ($this->request->is('post')) {
            $productDataTest = $this->ProductDataTests->patchEntity($productDataTest, $this->request->data);
            if ($this->ProductDataTests->save($productDataTest)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Data Test'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Data Test'));
            }
        }
        $productsMaster = $this->ProductDataTests->ProductsMaster->find('list', ['limit' => 200]);
        $this->set(compact('productDataTest', 'productsMaster'));
        $this->set('_serialize', ['productDataTest']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product Data Test id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productDataTest = $this->ProductDataTests->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productDataTest = $this->ProductDataTests->patchEntity($productDataTest, $this->request->data);
            if ($this->ProductDataTests->save($productDataTest)) {
                $this->Flash->success(__('The {0} has been saved.', 'Product Data Test'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Product Data Test'));
            }
        }
        $productsMaster = $this->ProductDataTests->ProductsMaster->find('list', ['limit' => 200]);
        $this->set(compact('productDataTest', 'productsMaster'));
        $this->set('_serialize', ['productDataTest']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product Data Test id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productDataTest = $this->ProductDataTests->get($id);
        if ($this->ProductDataTests->delete($productDataTest)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Product Data Test'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Product Data Test'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
