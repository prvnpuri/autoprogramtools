<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * VisitingCards Controller
 *
 * @property \App\Model\Table\VisitingCardsTable $VisitingCards
 *
 * @method \App\Model\Entity\VisitingCard[] paginate($object = null, array $settings = [])
 */
class VisitingCardsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Companies']
        ];
        $visitingCards = $this->paginate($this->VisitingCards);

        $this->set(compact('visitingCards'));
        $this->set('_serialize', ['visitingCards']);
    }

    /**
     * View method
     *
     * @param string|null $id Visiting Card id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $visitingCard = $this->VisitingCards->get($id, [
            'contain' => ['Companies']
        ]);

        $this->set('visitingCard', $visitingCard);
        $this->set('_serialize', ['visitingCard']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $visitingCard = $this->VisitingCards->newEntity();
        if ($this->request->is('post')) {
            $visitingCard = $this->VisitingCards->patchEntity($visitingCard, $this->request->data);
            if ($this->VisitingCards->save($visitingCard)) {
                $this->Flash->success(__('The {0} has been saved.', 'Visiting Card'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Visiting Card'));
            }
        }
        $companies = $this->VisitingCards->Companies->find('list', ['limit' => 200]);
        $this->set(compact('visitingCard', 'companies'));
        $this->set('_serialize', ['visitingCard']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Visiting Card id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $visitingCard = $this->VisitingCards->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $visitingCard = $this->VisitingCards->patchEntity($visitingCard, $this->request->data);
            if ($this->VisitingCards->save($visitingCard)) {
                $this->Flash->success(__('The {0} has been saved.', 'Visiting Card'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Visiting Card'));
            }
        }
        $companies = $this->VisitingCards->Companies->find('list', ['limit' => 200]);
        $this->set(compact('visitingCard', 'companies'));
        $this->set('_serialize', ['visitingCard']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Visiting Card id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $visitingCard = $this->VisitingCards->get($id);
        if ($this->VisitingCards->delete($visitingCard)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Visiting Card'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Visiting Card'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
