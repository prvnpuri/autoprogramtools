<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * CompanyTypesMaster Controller
 *
 * @property \App\Model\Table\CompanyTypesMasterTable $CompanyTypesMaster
 *
 * @method \App\Model\Entity\CompanyTypesMaster[] paginate($object = null, array $settings = [])
 */
class CompanyTypesMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="CompanyTypesMaster.type_short_name like '%$query%'";
    	}
    	$this->paginate = [
    			
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","type_short_name","type_description"]
    	];
    	
    	$companyTypesMaster = $this->paginate($this->CompanyTypesMaster);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('companyTypesMaster'));
    	$this->set( '_serialize', ['companyTypesMaster','paging']);
    	
    }

    /**
     * View method
     *
     * @param string|null $id Company Types Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $companyTypesMaster = $this->CompanyTypesMaster->get($id, [
            'contain' => []
        ]);

        $this->set('companyTypesMaster', $companyTypesMaster);
        $this->set('_serialize', ['companyTypesMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $companyTypesMaster = $this->CompanyTypesMaster->newEntity();
        if ($this->request->is('post')) {
            $companyTypesMaster = $this->CompanyTypesMaster->patchEntity($companyTypesMaster, $this->request->data);
            if ($this->CompanyTypesMaster->save($companyTypesMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Types Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Types Master'));
            }
        }
        $this->set(compact('companyTypesMaster'));
        $this->set('_serialize', ['companyTypesMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Company Types Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $companyTypesMaster = $this->CompanyTypesMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $companyTypesMaster = $this->CompanyTypesMaster->patchEntity($companyTypesMaster, $this->request->data);
            if ($this->CompanyTypesMaster->save($companyTypesMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Company Types Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Company Types Master'));
            }
        }
        $this->set(compact('companyTypesMaster'));
        $this->set('_serialize', ['companyTypesMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Company Types Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $companyTypesMaster = $this->CompanyTypesMaster->get($id);
        if ($this->CompanyTypesMaster->delete($companyTypesMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Company Types Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Company Types Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
