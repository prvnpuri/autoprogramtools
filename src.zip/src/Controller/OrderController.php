<?php
namespace App\Controller;
use App\Controller\AppController;
use Cake\Cache\Cache;
use Cake\Routing\Router;
use PhpParser\Node\Expr\Cast\Unset_;
use function Cake\ORM\toArray;

/**
 * Order Controller
 *
 * @property \App\Model\Table\OrderTable $Order
 *
 * @method \App\Model\Entity\Order[] paginate($object = null, array $settings = [])
 */
class OrderController extends AppController
{
	
	
	public function initialize()
	{
		parent::initialize();
		$this->loadComponent('RequestHandler');
	}
	
	
	
	/**
	 * Index method
	 *
	 * @return \Cake\Http\Response|void
	 */
	public function index()
	{
		$ownercompanyid = $this->Auth->User('owner_company_id');
		$query= $this->Order->find('all',
				[
						
						'conditions'=>['Order.order_type !=' => 1,"Order.owner_companies_id"=>$ownercompanyid],
						'contain' => ['CompanyMaster','CustomerMaster','ProductsMaster','Uom','Currency','OwnerCompanies'],
						'order'=>['Order.id' => 'DESC']
				]
				);
		
		
		$order= $this->paginate($query);
		
		$this->set('order', $order);
		$this->set('_serialize', ['order']);
		
		
		
		
	}
	
	/**
	 * View method
	 *
	 * @param string|null $id Order id.
	 * @return \Cake\Http\Response|void
	 * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
	 */
	public function view($id = null)
	{
		$order = $this->Order->get($id, [
				'contain' => ['AdditionalBuyerSpecification','CompanyMaster','CompanyMaster.CompanySublocation','CompanyMaster.CompanyContactPersons','CustomerMaster','CustomerMaster.CompanySublocation','CustomerMaster.CompanyContactPersons','ShippingCompany','ShippingCompany.CompanySublocation','ShippingCompany.CompanyContactPersons','NotifyCompany','NotifyCompany.CompanySublocation','NotifyCompany.CompanyContactPersons',
						'ProductsMaster','ProductsMaster.ProductDataTests','PackingTerm','PackingType','Uom','IncoTerms', 'Currency','OwnerCompanies',
						'CountryOfFinalDestination','CountryOfOriginOfGood','PortOfDischarge','Countries','PaymentTerm']
		]);
		
		$this->loadModel('CompanyContactPersons');
		
		$buyerCompContact = $this->CompanyContactPersons->find("all",array(
				"fields"=>array("id","prefix_name","first_name","middle_name","last_name","phone","email_id"),
				"conditions"=>array("id IN"=>explode(",",$order["company_contact_persons"])),
				"order"=>"concat(`first_name`,`middle_name`,`last_name`)"
		));
		$suppCompContact = $this->CompanyContactPersons->find("all",array(
				"fields"=>array("id","prefix_name","first_name","middle_name","last_name","phone","email_id"),
				"conditions"=>array("id IN"=>explode(",",$order["supplier_contact_persons"])),
				"order"=>"concat(`first_name`,`middle_name`,`last_name`)"
		));
		$notifyCompContact = $this->CompanyContactPersons->find("all",array(
				"fields"=>array("id","prefix_name","first_name","middle_name","last_name","phone","email_id"),
				"conditions"=>array("id IN"=>explode(",",$order["notify_contact_persons"])),
				"order"=>"concat(`first_name`,`middle_name`,`last_name`)"
		));
		$shipCompContact = $this->CompanyContactPersons->find("all",array(
				"fields"=>array("id","prefix_name","first_name","middle_name","last_name","phone","email_id"),
				"conditions"=>array("id IN"=>explode(",",$order["ship_contact_persons"])),
				"order"=>"concat(`first_name`,`middle_name`,`last_name`)"
		));
		
		
		$this->loadModel('ProductDataTests');
		$this->set('prodatatest',$this->ProductDataTests->find("all",array(
				"fields"=>array("id","products_master_id","test","specification","methods","purpose"),
				"conditions"=>array("id IN"=>explode(",",$order["product_specifications"])),
				
		)));
		
		
		
		$this->set('motherorderlist',$this->Order->MotherOrderCallofOrder->find("all",array(
				"fields"=>array('id','mother_order_id','call_off_id','qty','Order.id','Order.order_no','Order.quantity_ordered'),
				"conditions"=>array("call_off_id"=>$order["id"]),
				"contain"=>array('Order')
				
		)));
		
		
		
		
		$this->set(compact('order','buyerCompContact','suppCompContact','notifyCompContact','shipCompContact'));
		$this->set('_serialize', ['order']);
	}
	
	/**
	 * Add method
	 *
	 * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
	 */
	public function add()
	{
		$order = $this->Order->newEntity();
		if ($this->request->is('post')) {
			
	
			$this->loadModel('ReferenceNumberCounter');
			$this->loadComponent('ReferenceNumber');
			
			$next_ref =
			$this->ReferenceNumber->get_next_ref_number($this->request->data['owner_companies_id'],'order');
			$this->request->data['reference_number'] = $next_ref['full_next_ref_no'];
			
			if(isset($this->request->data['selected_product_specs'])){
			    foreach ($this->request->data['selected_product_specs'] as $key=>&$det){
			        
			        if($det['product_data_tests_id'] == '0'){
			            unset($this->request->data['selected_product_specs'][$key]);
			        }
			        
			    }
			}
			
			
			if(isset($details)){
				$testId=implode(", ", $details);
				$this->request->data['product_specifications'] = $testId;
			}else{
				unset($this->request->data['product_specifications']);
			}
			
			$order['created_by'] = $this->Auth->User('id');
			$order['balance_qty'] = $this->request->data['quantity_ordered'];
			$order['is_multiorder'] = 'Y';
			$order = $this->Order->patchEntity($order, $this->request->data,
					['associated' => ['AdditionalBuyerSpecification','MotherOrderCallofOrder']]
					);
			
			if(isset($this->request->data["file"]) &&  $this->request->data["file"]["error"]==0){
				$filename=$this->request->data["file"]["name"];
				$order["order_file"]=$filename;
			}else{
				unset($this->request->data["order_file"]);
			}
			
			
			if(isset($this->request->data['company_contact_persons'])){
				$ptr=0;
				foreach ($this->request->data['company_contact_persons'] as $contact_id){
					$order->company_contact_persons.=$ptr>0?",":"";
					$order->company_contact_persons.=$contact_id;
					$ptr++;
				}
			}
			if(isset($this->request->data['supplier_contact_persons'])){
				$ptr=0;
				foreach ($this->request->data['supplier_contact_persons'] as $contact_id){
					$order->supplier_contact_persons.=$ptr>0?",":"";
					$order->supplier_contact_persons.=$contact_id;
					$ptr++;
				}
			}
			if(isset($this->request->data['notify_contact_persons'])){
				$ptr=0;
				foreach ($this->request->data['notify_contact_persons'] as $contact_id){
					$order->notify_contact_persons.=$ptr>0?",":"";
					$order->notify_contact_persons.=$contact_id;
					$ptr++;
				}
			}
			if(isset($this->request->data['ship_contact_persons'])){
				$ptr=0;
				foreach ($this->request->data['ship_contact_persons'] as $contact_id){
					$order->ship_contact_persons.=$ptr>0?",":"";
					$order->ship_contact_persons.=$contact_id;
					$ptr++;
				}
			}
			
			
			
			if(!isset($next_ref['full_next_ref_no'])){
				
				$this->Flash->error(__('The {0} could not be saved.Reference number not generated .Please contact administrator.', 'Order'));
				
			}else {
				
				if ($this->Order->save($order)) {
					
					
					if(isset($this->request->data['mother_order_callof_order'])){
						
						foreach ($this->request->data['mother_order_callof_order'] as $orderkeys=>$ordervals){
							
							
							$motherorderid=$ordervals['mother_order_id'];

							$motherorder=  $this->Order->get($motherorderid);
							$quantity_despatch=$motherorder->quantity_despatch + $ordervals['qty'];
							
							$balance_qty=$motherorder->balance_qty - $ordervals['qty'];
							$data = array('id' => $motherorderid, 'quantity_despatch'=>$quantity_despatch,'balance_qty'=>$balance_qty);
							$motherorder= $this->Order->patchEntity($motherorder, $data);
							
							
							$this->Order->save($motherorder);
						
						
						
						
						
						}
						
						
					}
					
					$this->ReferenceNumber->save_next_ref_number($next_ref['ReferenceNumberCounter']);
					$id = $order['id'];
					if(isset($this->request->data["file"]) &&  $this->request->data["file"]["error"]==0){
						$filename=$this->request->data["file"]["name"];
						$url = Router::url('/',true).'upload/order-file/';
						$uploadpath = 'upload/order-file/';
						$uploadfile = $uploadpath.$id."_".$filename;
						move_uploaded_file($this->request->data["file"]['tmp_name'], $uploadfile);
						
					}else{
						unset($this->request->data["file"]);
					}
					$this->Flash->success(__('The {0} has been saved.', 'Order'));
					return $this->redirect(['action' => 'index']);
				} else {
					$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Order'));
				}
				
			}
			
			
			
		}
		
		$uom = $this->Order->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
		
		$currency= $this->Order->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'sign']);
		$packingterm= $this->Order->PackingTerm->find('list', ['keyField' => 'id','valueField' => 'packing_term','order'=>'packing_term']);
		$packingtype= $this->Order->PackingType->find('list', ['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type']);
		
		$incoTerms = $this->Order->IncoTerms->find('list', ['keyField'=>'id','valueField'=>'inco_term','limit' => 200]);
		$ownerComp = $this->Order->OwnerCompanies->find('list', ['keyField'=>'id','valueField'=>'Company_name']);
		$orderType = array('0'=>'Normal Order','1'=>'Mother Order','2'=>'Calloff Order');
		
		
		$countryoforigineofgoods= $this->Order->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		
		$countries= $this->Order->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		$portofdischarge= $this->Order->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge']);
		
		$paymentterm= $this->Order->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
		$deliveryterm= $this->Order->DeliveryTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
		
		$this->set(compact('order','uom', 'currency', 'incoTerms','ownerComp','orderType','packingterm','packingtype','countryoforigineofgoods','countries','portofdischarge','paymentterm','deliveryterm'));
		$this->set('_serialize', ['order']);
	}
	
	/**
	 * Edit method
	 *
	 * @param string|null $id Order id.
	 * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
	 * @throws \Cake\Network\Exception\NotFoundException When record not found.
	 */
	public function edit($id = null)
	{
		$order = $this->Order->get($id, [
				'contain' => ['MotherOrderCallofOrder','AdditionalBuyerSpecification','CompanyMaster','CompanyMaster.CompanyContactPersons','CustomerMaster','CustomerMaster.CompanyContactPersons','ShippingCompany','ShippingCompany.CompanyContactPersons','NotifyCompany','NotifyCompany.CompanyContactPersons','ProductsMaster','ProductsMaster.ProductDataTests','OwnerCompanies', 'Uom', 'Currency']
		]);
		if ($this->request->is(['patch', 'post', 'put'])) {
			

			
			foreach ($this->request->data['selected_specs'] as $key=> $det){
				
				if($det['product_data_tests'] !== '' && $det['product_data_tests'] !== 0){
					if($det['product_data_tests'] !== '0'){
						$details[] = $det['product_data_tests'];
					}
				}
				
				
				
			}
			unset($this->request->data['selected_specs']);
			
			
			
			if(isset($details)){
				$testId=implode(", ", $details);
				$this->request->data['product_specifications'] = $testId;
			}else{
				unset($this->request->data['product_specifications']);
			}
			
			
		
			
			$this->request->data['company_contact_persons'] ='';
			if(isset($this->request->data['company_contact_person'])){
				$ptr=0;
				foreach ($this->request->data['company_contact_person'] as $contact_id){
					$this->request->data['company_contact_persons'].=$ptr>0?",":"";
					$this->request->data['company_contact_persons'].=$contact_id;
					$ptr++;
				}
				
			}
			
			
			
			$this->request->data['supplier_contact_persons'] ='';
			if(isset($this->request->data['supplier_contact_person'])){
				$ptr=0;
				foreach ($this->request->data['supplier_contact_person'] as $contact_id){
					$this->request->data['supplier_contact_persons'].=$ptr>0?",":"";
					$this->request->data['supplier_contact_persons'].=$contact_id;
					$ptr++;
				}
				
			}
			
		
			$this->request->data['notify_contact_persons'] ='';
			if(isset($this->request->data['notify_contact_person'])){
				$ptr=0;
				foreach ($this->request->data['notify_contact_person'] as $contact_id){
					$this->request->data['notify_contact_persons'].=$ptr>0?",":"";
					$this->request->data['notify_contact_persons'].=$contact_id;
					$ptr++;
				}
				
			}
			
			
			$this->request->data['ship_contact_persons'] ='';
			if(isset($this->request->data['ship_contact_person'])){
				$ptr=0;
				foreach ($this->request->data['ship_contact_person'] as $contact_id){
					$this->request->data['ship_contact_persons'].=$ptr>0?",":"";
					$this->request->data['ship_contact_persons'].=$contact_id;
					$ptr++;
				}
				
			}
			
			
			
			$order = $this->Order->patchEntity($order, $this->request->getData(),
					['associated' => ['AdditionalBuyerSpecification']]
					);
			if(isset($this->request->data["file"]) &&  $this->request->data["file"]["error"]==0){
				$filename=$this->request->data["file"]["name"];
				$order["order_file"]=$filename;
			}else{
				unset($this->request->data["order_file"]);
			}
			
			
			$order['modified_by'] = $this->Auth->User('id');
			
			//echo "<pre>";print_r($order);exit;
			if ($this->Order->save($order)) {
				
				$id = $order['id'];
				if(isset($this->request->data["file"]) &&  $this->request->data["file"]["error"]==0){
					$filename=$this->request->data["file"]["name"];
					$url = Router::url('/',true).'upload/order-file/';
					$uploadpath = 'upload/order-file/';
					$uploadfile = $uploadpath.$id."_".$filename;
					move_uploaded_file($this->request->data["file"]['tmp_name'], $uploadfile);
					
				}else{
					unset($this->request->data["file"]);
				}
				$this->Flash->success(__('The {0} has been saved.', 'Order'));
				return $this->redirect(['action' => 'index']);
			} else {
				$this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Order'));
			}
		}
		
		$uom = $this->Order->Uom->find('list', ['keyField' => 'id','valueField' => 'unit_symbol','order'=>'unit_symbol','conditions'=>['unit_type'=>'weight']], ['limit' => 200]);
		
		$currency= $this->Order->Currency->find('list', ['keyField' => 'id','valueField' => 'sign','order'=>'sign']);
		
		$incoTerms = $this->Order->IncoTerms->find('list', ['keyField'=>'id','valueField'=>'inco_term','limit' => 200]);
		$ownerComp = $this->Order->OwnerCompanies->find('list', ['keyField'=>'id','valueField'=>'Company_name']);
		
		$packingterm= $this->Order->PackingTerm->find('list', ['keyField' => 'id','valueField' => 'packing_term','order'=>'packing_term']);
		$packingtype= $this->Order->PackingType->find('list', ['keyField' => 'id','valueField' => 'packing_type','order'=>'packing_type']);
		
		$deliveryterm= $this->Order->DeliveryTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
		
		
		$this->loadModel('ProductDataTests');
		$this->set('prodatatest',$this->ProductDataTests->find("all",array(
				"fields"=>array("id","products_master_id","test","specification","methods","purpose"),
				"conditions"=>array('products_master_id'=>$order->products_master_id,'purpose like'=>'%Offer%'),
				
		)));
		
		
		
		$this->loadModel('CompanySublocation');
		$buyerCompOffices = $this->CompanySublocation->find('list', ['keyField'=>'id','valueField'=>'sublocation_name','conditions'=>['CompanySublocation.company_master_id' => $order['buyer_company']],]);
		
		$suppCompOffices = $this->CompanySublocation->find('list', ['keyField'=>'id','valueField'=>'sublocation_name','conditions'=>['CompanySublocation.company_master_id' => $order['supplier_company']],]);
		
		$notifyCompOffices = $this->CompanySublocation->find('list', ['keyField'=>'id','valueField'=>'sublocation_name','conditions'=>['CompanySublocation.company_master_id' => $order['notify_to']],]);
		
		$shipCompOffices = $this->CompanySublocation->find('list', ['keyField'=>'id','valueField'=>'sublocation_name','conditions'=>['CompanySublocation.company_master_id' => $order['consignee']],]);
		$orderType = array('0'=>'Normal Order','1'=>'Mother Order','2'=>'Calloff Order');
		
		
		$countryoforigineofgoods= $this->Order->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		
		$countries= $this->Order->Countries->find('list', ['keyField' => 'id','valueField' => 'country_name','order'=>'country_name']);
		$portofdischarge= $this->Order->PortOfDischarge->find('list', ['keyField' => 'id','valueField' => 'port_of_discharge','order'=>'port_of_discharge']);
		
		$paymentterm= $this->Order->PaymentTerm->find('list', ['keyField' => 'id','valueField' => 'term','order'=>'term']);
		
		
		
		
		$this->set('motherorderlist',$this->Order->MotherOrderCallofOrder->find("all",array(
				"fields"=>array('id','mother_order_id','call_off_id','qty','Order.id','Order.order_no','Order.quantity_ordered'),
				"conditions"=>array("call_off_id"=>$order["id"]),
				"contain"=>array('Order')
				
		)));
		
		
		
		
		$this->set(compact('order','uom', 'currency', 'incoTerms','ownerComp','buyerCompOffices','suppCompOffices','notifyCompOffices','shipCompOffices','orderType','packingterm','packingtype','countryoforigineofgoods','countries','portofdischarge','paymentterm','deliveryterm'));
		$this->set('_serialize', ['order']);
	}
	
	/**
	 * Delete method
	 *
	 * @param string|null $id Order id.
	 * @return \Cake\Network\Response|null Redirects to index.
	 * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
	 */
	public function delete($id = null)
	{
		$this->request->allowMethod(['post', 'delete']);
		$order = $this->Order->get($id);
		if ($this->Order->delete($order)) {
			$this->Flash->success(__('The {0} has been deleted.', 'Order'));
		} else {
			$this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Order'));
		}
		return $this->redirect(['action' => 'index']);
	}
	
	public function sendToReview($id=null) {
		
		$order = $this->Order->get($id);
		$userid=$this->Auth->user('id');
		$data = array('id' => $id , 'review_status' => "SENT");
		$order= $this->Order->patchEntity($order, $data);
		
		
		if($this->Order->save($order)){
			$this->loadModel('Notifications');
			
			$notifications= $this->Notifications->find()->where(['notification_by' => 'Order','transaction_id'=>$id])->first();
			
			$data = array('transaction_id' => $id , 'status' => "2",'action_taken_by'=>$userid,'action_taken_on'=>date('Y-m-d'));
			$notifications= $this->Notifications->patchEntity($notifications, $data);
			$this->Notifications->save($notifications);
		$this->Flash->success(__('Order has been sent to review.'));
		}
		return $this->redirect(['action' => 'index']);
		
		
		
	}
	
	
	
	public function motherorderindex()
	{
		
		$query= $this->Order->find('all',
				[
						
						'conditions'=>['Order.order_type' => 1],
						'contain' => ['CompanyMaster','CustomerMaster','ProductsMaster','Uom','Currency','OwnerCompanies'],
						'order'=>['Order.id' => 'DESC']
				]
				);
		
		
		$order= $this->paginate($query);
		
		$this->set('order', $order);
		$this->set('_serialize', ['order']);
		
		
		
		
	}
	
	
	public function callofforderindex($id=null)
	{
		
		$query= $this->Order->MotherOrderCallofOrder->find('all',
				[
						
						'conditions'=>['MotherOrderCallofOrder.mother_order_id' => $id],
						'contain' => ['Order.CompanyMaster','Order.CustomerMaster','Order.ProductsMaster','Order.Uom','Order.Currency','Order.OwnerCompanies'],
						'order'=>['Order.id' => 'DESC']
				]
				);
		
				$order= $this->paginate($query);
				$this->set('order', $order);
				$this->set('_serialize', ['order']);
		
	}
	
	
	
	
}