<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Log\Log;

/**
 * LedgerAccounts Controller
 *
 * @property \App\Model\Table\LedgerAccountsTable $LedgerAccounts
 * @property \App\Model\Table\CompanyMasterTable $CompanyMaster
 * @method \App\Model\Entity\LedgerAccount[] paginate($object = null, array $settings = [])
 */
class LedgerAccountsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $fields=[
            "id","account_name","notes","opening_balance","opening_balance_side","model_reference_name",
            'CompanyMaster.Company_name',
            'BankMaster.bank_name','BankMaster.name','BankMaster.account_name',
            'TaxMaster.id','TaxMaster.tax_name',
            'OwnerCompanies.Company_name',
            "LedgerGroups.type",'ParentLedgerAccounts.account_name'
        ];
        $this->paginate = [
            'contain' => ['LedgerGroups', 'CompanyMaster','ParentLedgerAccounts','EmployeeDetails','BankMaster','OwnerCompanies','TaxMaster'],
            'sortWhitelist' => $fields,
            'fields'=>$fields,
            'order'=>["id"=>"DESC"]
        ];
        $ledgerAccounts = $this->paginate($this->LedgerAccounts);
        $this->set(compact('ledgerAccounts'));
        $this->set('_serialize', ['ledgerAccounts']);
    }

    /**
     * View method
     *
     * @param string|null $id Ledger Account id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ledgerAccount = $this->LedgerAccounts->get($id, [
            'contain' => ['LedgerGroups', 'CompanyMaster', 'ParentLedgerAccounts', ],
            "order"=>"LedgerAccounts.id desc"
        ]);

        $this->set('ledgerAccount', $ledgerAccount);
        $this->set('_serialize', ['ledgerAccount']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ledgerAccount = $this->LedgerAccounts->newEntity();
        if ($this->request->is('post')) {
            $ledgerAccount = $this->LedgerAccounts->patchEntity($ledgerAccount, $this->request->getData());
            if ($this->LedgerAccounts->save($ledgerAccount)) {
                $this->Flash->success(__('The {0} has been saved.', 'Ledger Account'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Ledger Account'));
            }
        }
        $ledgerGroups = $this->LedgerAccounts->LedgerGroups->find('list', [
            "keyField"=>"id",
            "valueField"=>"type",
            "order"=>"type asc",
            'limit' => 200]);
        
        $parentLedgerAccounts = $this->LedgerAccounts->ParentLedgerAccounts->find('list', [
            "keyField"=>"id",
            "valueField"=>"account_name",
            "order"=>"account_name asc",
            'limit' => 200]);
        $ownerCompanies=$this->LedgerAccounts->OwnerCompanies->find('list');
        $this->set(compact('ledgerAccount', 'ledgerGroups', 'CompanyMaster', 'parentLedgerAccounts','ownerCompanies'));
        $this->set('_serialize', ['ledgerAccount']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Ledger Account id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ledgerAccount = $this->LedgerAccounts->get($id, [
            'contain' => ['CompanyMaster']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ledgerAccount = $this->LedgerAccounts->patchEntity($ledgerAccount, $this->request->getData());
            if ($this->LedgerAccounts->save($ledgerAccount)) {
                $this->Flash->success(__('The {0} has been saved.', 'Ledger Account'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Ledger Account'));
            }
        }
        $ledgerGroups = $this->LedgerAccounts->LedgerGroups->find('list', [
            "keyField"=>"id",
            "valueField"=>"type",
            "order"=>"type asc",
            'limit' => 200]);
        $parentLedgerAccounts = $this->LedgerAccounts->ParentLedgerAccounts->find('list', [
            "keyField"=>"id",
            "valueField"=>"account_name",
            "order"=>"account_name asc",
            'limit' => 200]);
        $ownerCompanies=$this->LedgerAccounts->OwnerCompanies->find('list');
        $this->set(compact('ledgerAccount', 'ledgerGroups', 'CompanyMaster', 'parentLedgerAccounts','ownerCompanies'));
        $this->set('_serialize', ['ledgerAccount']);

    }

    /**
     * Delete method
     *
     * @param string|null $id Ledger Account id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ledgerAccount = $this->LedgerAccounts->get($id);
        if ($this->LedgerAccounts->delete($ledgerAccount)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Ledger Account'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Ledger Account'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    
    /**
     * 
     */
    public function searchaccountname(){
        $accountnamelist=[];
        $searchtext=$this->request->getQuery('search');
        
        if($searchtext!=null){
            $searchtext=str_replace(" ", "%", $searchtext);
            $this->loadModel('CompanyMaster');
            $companies=$this->CompanyMaster->find("all",["conditions"=>[
                "CONCAT(company_name) like '%$searchtext%'"
            ]]);
            $companies->select([
                "label"=>$companies->func()->concat(["Company_name" => "identifier"]),
                "model_reference_name"=>$companies->func()->concat(["CompanyMaster"]),
                "model_reference_id"=>"id",                
            ]);
            $this->loadModel('EmployeeDetails');
            $employees=$this->EmployeeDetails->find("all",["conditions"=>[
                "CONCAT(first_name,' ',middle_name,' ',last_name) like '%$searchtext%'"
            ]]);
            $employees->select([
                "label"=>$employees->func()->concat([
                    "first_name" => "identifier"," ",
                    "middle_name"=> "identifier"," ",
                    "last_name"=> "identifier"
                ]),
                "model_reference_name"=>$employees->func()->concat(["EmployeeDetails"]),
                "model_reference_id"=>"id",
            ]);
            $this->loadModel('BankMaster');
            $banks=$this->BankMaster->find("all",["conditions"=>[
                "CONCAT(bank_name,' ',name,' ',account_name)  like '%$searchtext%'"
            ]]);
            $banks->select([
                "label"=>$banks->func()->concat([
                    "bank_name" => "identifier"," ",
                    "name"=> "identifier"," ",
                    "account_name"=> "identifier"
                ]),
                "model_reference_name"=>$banks->func()->concat(["BankMaster"]),
                "model_reference_id"=>"id",
            ]);
            
            $this->loadModel('TaxMaster');
            $taxes=$this->TaxMaster->find("all",["conditions"=>[
                "tax_name  like '%$searchtext%'"
            ]]);
            $taxes->select([
                "label"=>$taxes->func()->concat([
                    "tax_name" => "identifier"," - ",
                    '_applicability'=>$this->TaxMaster->query()->func()->concat([ "CASE `applicability` WHEN 2 THEN  'INETER STATE' WHEN 1 THEN 'LOCAL' ELSE 'EXPORT' END "=>'literal'])
                ]),
                "model_reference_name"=>$banks->func()->concat(["TaxMaster"]),
                "model_reference_id"=>"id",
            ]);
            
        }
        $this->set(compact(['companies','employees','banks','taxes']));
        $this->set('_serialize', ['companies','employees','banks','taxes']);
        
    }
    
}
