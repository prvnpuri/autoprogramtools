<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * WarehouseInventoryDetails Controller
 *
 * @property \App\Model\Table\WarehouseInventoryDetailsTable $WarehouseInventoryDetails
 *
 * @method \App\Model\Entity\WarehouseInventoryDetail[] paginate($object = null, array $settings = [])
 */
class WarehouseInventoryDetailsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['WarehouseInventories', 'Inwards', 'WarehouseUnits', 'WarehouseSubunits']
        ];
        $warehouseInventoryDetails = $this->paginate($this->WarehouseInventoryDetails);

        $this->set(compact('warehouseInventoryDetails'));
        $this->set('_serialize', ['warehouseInventoryDetails']);
    }

    /**
     * View method
     *
     * @param string|null $id Warehouse Inventory Detail id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $warehouseInventoryDetail = $this->WarehouseInventoryDetails->get($id, [
            'contain' => ['WarehouseInventories', 'Inwards', 'WarehouseUnits', 'WarehouseSubunits']
        ]);

        $this->set('warehouseInventoryDetail', $warehouseInventoryDetail);
        $this->set('_serialize', ['warehouseInventoryDetail']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $warehouseInventoryDetail = $this->WarehouseInventoryDetails->newEntity();
        if ($this->request->is('post')) {
            $warehouseInventoryDetail = $this->WarehouseInventoryDetails->patchEntity($warehouseInventoryDetail, $this->request->data);
            if ($this->WarehouseInventoryDetails->save($warehouseInventoryDetail)) {
                $this->Flash->success(__('The {0} has been saved.', 'Warehouse Inventory Detail'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Warehouse Inventory Detail'));
            }
        }
        $warehouseInventories = $this->WarehouseInventoryDetails->WarehouseInventories->find('list', ['limit' => 200]);
        $inwards = $this->WarehouseInventoryDetails->Inwards->find('list', ['limit' => 200]);
        $warehouseUnits = $this->WarehouseInventoryDetails->WarehouseUnits->find('list', ['limit' => 200]);
        $warehouseSubunits = $this->WarehouseInventoryDetails->WarehouseSubunits->find('list', ['limit' => 200]);
        $this->set(compact('warehouseInventoryDetail', 'warehouseInventories', 'inwards', 'warehouseUnits', 'warehouseSubunits'));
        $this->set('_serialize', ['warehouseInventoryDetail']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Warehouse Inventory Detail id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $warehouseInventoryDetail = $this->WarehouseInventoryDetails->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $warehouseInventoryDetail = $this->WarehouseInventoryDetails->patchEntity($warehouseInventoryDetail, $this->request->data);
            if ($this->WarehouseInventoryDetails->save($warehouseInventoryDetail)) {
                $this->Flash->success(__('The {0} has been saved.', 'Warehouse Inventory Detail'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Warehouse Inventory Detail'));
            }
        }
        $warehouseInventories = $this->WarehouseInventoryDetails->WarehouseInventories->find('list', ['limit' => 200]);
        $inwards = $this->WarehouseInventoryDetails->Inwards->find('list', ['limit' => 200]);
        $warehouseUnits = $this->WarehouseInventoryDetails->WarehouseUnits->find('list', ['limit' => 200]);
        $warehouseSubunits = $this->WarehouseInventoryDetails->WarehouseSubunits->find('list', ['limit' => 200]);
        $this->set(compact('warehouseInventoryDetail', 'warehouseInventories', 'inwards', 'warehouseUnits', 'warehouseSubunits'));
        $this->set('_serialize', ['warehouseInventoryDetail']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Warehouse Inventory Detail id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $warehouseInventoryDetail = $this->WarehouseInventoryDetails->get($id);
        if ($this->WarehouseInventoryDetails->delete($warehouseInventoryDetail)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Warehouse Inventory Detail'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Warehouse Inventory Detail'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
