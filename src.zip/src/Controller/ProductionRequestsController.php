<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ProductionRequests Controller
 *
 * @property \App\Model\Table\ProductionRequestsTable $ProductionRequests
 *
 * @method \App\Model\Entity\ProductionRequest[] paginate($object = null, array $settings = [])
 */
class ProductionRequestsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
        		'contain' => ['ProductsMaster' => ['fields' => ['id', 'product_name','grade_name']]]
        ];
        $productionRequests = $this->paginate($this->ProductionRequests);

        $this->set(compact('productionRequests'));
        $this->set('_serialize', ['productionRequests']);
    }

    /**
     * View method
     *
     * @param string|null $id Production Request id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $productionRequest = $this->ProductionRequests->get($id, [
            'contain' => ['Orders', 'Products']
        ]);

        $this->set('productionRequest', $productionRequest);
        $this->set('_serialize', ['productionRequest']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $productionRequest = $this->ProductionRequests->newEntity();
        if ($this->request->is('post')) {
            $productionRequest = $this->ProductionRequests->patchEntity($productionRequest, $this->request->data);
            if ($this->ProductionRequests->save($productionRequest)) {
                $this->Flash->success(__('The {0} has been saved.', 'Production Request'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Production Request'));
            }
        }
        $orders = $this->ProductionRequests->Orders->find('list', ['limit' => 200]);
        $products = $this->ProductionRequests->Products->find('list', ['limit' => 200]);
        $this->set(compact('productionRequest', 'orders', 'products'));
        $this->set('_serialize', ['productionRequest']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Production Request id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $productionRequest = $this->ProductionRequests->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productionRequest = $this->ProductionRequests->patchEntity($productionRequest, $this->request->data);
            if ($this->ProductionRequests->save($productionRequest)) {
                $this->Flash->success(__('The {0} has been saved.', 'Production Request'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Production Request'));
            }
        }
        $orders = $this->ProductionRequests->Orders->find('list', ['limit' => 200]);
        $products = $this->ProductionRequests->Products->find('list', ['limit' => 200]);
        $this->set(compact('productionRequest', 'orders', 'products'));
        $this->set('_serialize', ['productionRequest']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Production Request id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $productionRequest = $this->ProductionRequests->get($id);
        if ($this->ProductionRequests->delete($productionRequest)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Production Request'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Production Request'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
