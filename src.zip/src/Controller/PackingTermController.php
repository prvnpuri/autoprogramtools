<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * PackingTerm Controller
 *
 * @property \App\Model\Table\PackingTermTable $PackingTerm
 *
 * @method \App\Model\Entity\PackingTerm[] paginate($object = null, array $settings = [])
 */
class PackingTermController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	
    	$query=$this->request->getQuery("search");
    	$conditions=array();
    	if($query!=null && trim($query," ")!=""){
    		$conditions[]="PackingTerm.packing_term like '%$query%'";
    	}
    	$this->paginate = [
    			"conditions" => $conditions,
    			"sortWhitelist"=>["id","packing_term"]
    	];
    	
    	
    	$packingTerm = $this->paginate($this->PackingTerm);
    	$this->set("paging",$this->request->getParam("paging"));
    	$this->set(compact('packingTerm'));
    	$this->set( '_serialize', ['packingTerm','paging']);
    }

    /**
     * View method
     *
     * @param string|null $id Packing Term id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $packingTerm = $this->PackingTerm->get($id, [
            'contain' => []
        ]);

        $this->set('packingTerm', $packingTerm);
        $this->set('_serialize', ['packingTerm']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $packingTerm = $this->PackingTerm->newEntity();
        if ($this->request->is('post')) {
            $packingTerm = $this->PackingTerm->patchEntity($packingTerm, $this->request->data);
            if ($this->PackingTerm->save($packingTerm)) {
                $this->Flash->success(__('The {0} has been saved.', 'Packing Term'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Packing Term'));
            }
        }
        $this->set(compact('packingTerm'));
        $this->set('_serialize', ['packingTerm']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Packing Term id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $packingTerm = $this->PackingTerm->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $packingTerm = $this->PackingTerm->patchEntity($packingTerm, $this->request->data);
            if ($this->PackingTerm->save($packingTerm)) {
                $this->Flash->success(__('The {0} has been saved.', 'Packing Term'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Packing Term'));
            }
        }
        $this->set(compact('packingTerm'));
        $this->set('_serialize', ['packingTerm']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Packing Term id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $packingTerm = $this->PackingTerm->get($id);
        if ($this->PackingTerm->delete($packingTerm)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Packing Term'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Packing Term'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
