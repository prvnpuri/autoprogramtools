<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * BuyerSpecification Controller
 *
 * @property \App\Model\Table\BuyerSpecificationTable $BuyerSpecification
 *
 * @method \App\Model\Entity\BuyerSpecification[] paginate($object = null, array $settings = [])
 */
class BuyerSpecificationController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Orders']
        ];
        $buyerSpecification = $this->paginate($this->BuyerSpecification);

        $this->set(compact('buyerSpecification'));
        $this->set('_serialize', ['buyerSpecification']);
    }

    /**
     * View method
     *
     * @param string|null $id Buyer Specification id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $buyerSpecification = $this->BuyerSpecification->get($id, [
            'contain' => ['Orders']
        ]);

        $this->set('buyerSpecification', $buyerSpecification);
        $this->set('_serialize', ['buyerSpecification']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $buyerSpecification = $this->BuyerSpecification->newEntity();
        if ($this->request->is('post')) {
            $buyerSpecification = $this->BuyerSpecification->patchEntity($buyerSpecification, $this->request->data);
            if ($this->BuyerSpecification->save($buyerSpecification)) {
                $this->Flash->success(__('The {0} has been saved.', 'Buyer Specification'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Buyer Specification'));
            }
        }
        $orders = $this->BuyerSpecification->Orders->find('list', ['limit' => 200]);
        $this->set(compact('buyerSpecification', 'orders'));
        $this->set('_serialize', ['buyerSpecification']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Buyer Specification id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $buyerSpecification = $this->BuyerSpecification->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $buyerSpecification = $this->BuyerSpecification->patchEntity($buyerSpecification, $this->request->data);
            if ($this->BuyerSpecification->save($buyerSpecification)) {
                $this->Flash->success(__('The {0} has been saved.', 'Buyer Specification'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Buyer Specification'));
            }
        }
        $orders = $this->BuyerSpecification->Orders->find('list', ['limit' => 200]);
        $this->set(compact('buyerSpecification', 'orders'));
        $this->set('_serialize', ['buyerSpecification']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Buyer Specification id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $buyerSpecification = $this->BuyerSpecification->get($id);
        if ($this->BuyerSpecification->delete($buyerSpecification)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Buyer Specification'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Buyer Specification'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
