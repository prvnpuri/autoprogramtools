<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ParticularMaster Controller
 *
 * @property \App\Model\Table\ParticularMasterTable $ParticularMaster
 *
 * @method \App\Model\Entity\ParticularMaster[] paginate($object = null, array $settings = [])
 */
class ParticularMasterController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $particularMaster = $this->paginate($this->ParticularMaster);

        $this->set(compact('particularMaster'));
        $this->set('_serialize', ['particularMaster']);
    }

    /**
     * View method
     *
     * @param string|null $id Particular Master id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $particularMaster = $this->ParticularMaster->get($id, [
            'contain' => ['FeasibilityParticular']
        ]);

        $this->set('particularMaster', $particularMaster);
        $this->set('_serialize', ['particularMaster']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $particularMaster = $this->ParticularMaster->newEntity();
        if ($this->request->is('post')) {
            $particularMaster = $this->ParticularMaster->patchEntity($particularMaster, $this->request->data);
            if ($this->ParticularMaster->save($particularMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Particular Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Particular Master'));
            }
        }
        $this->set(compact('particularMaster'));
        $this->set('_serialize', ['particularMaster']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Particular Master id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $particularMaster = $this->ParticularMaster->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $particularMaster = $this->ParticularMaster->patchEntity($particularMaster, $this->request->data);
            if ($this->ParticularMaster->save($particularMaster)) {
                $this->Flash->success(__('The {0} has been saved.', 'Particular Master'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Particular Master'));
            }
        }
        $this->set(compact('particularMaster'));
        $this->set('_serialize', ['particularMaster']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Particular Master id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $particularMaster = $this->ParticularMaster->get($id);
        if ($this->ParticularMaster->delete($particularMaster)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Particular Master'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Particular Master'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
