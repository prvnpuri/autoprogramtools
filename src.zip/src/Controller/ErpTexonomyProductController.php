<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * ErpTexonomyProduct Controller
 *
 * @property \App\Model\Table\ErpTexonomyProductTable $ErpTexonomyProduct
 *
 * @method \App\Model\Entity\ErpTexonomyProduct[] paginate($object = null, array $settings = [])
 */
class ErpTexonomyProductController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['ErpTexonomies', 'Products']
        ];
        $erpTexonomyProduct = $this->paginate($this->ErpTexonomyProduct);

        $this->set(compact('erpTexonomyProduct'));
        $this->set('_serialize', ['erpTexonomyProduct']);
    }

    /**
     * View method
     *
     * @param string|null $id Erp Texonomy Product id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $erpTexonomyProduct = $this->ErpTexonomyProduct->get($id, [
            'contain' => ['ErpTexonomies', 'Products']
        ]);

        $this->set('erpTexonomyProduct', $erpTexonomyProduct);
        $this->set('_serialize', ['erpTexonomyProduct']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $erpTexonomyProduct = $this->ErpTexonomyProduct->newEntity();
        if ($this->request->is('post')) {
            $erpTexonomyProduct = $this->ErpTexonomyProduct->patchEntity($erpTexonomyProduct, $this->request->data);
            if ($this->ErpTexonomyProduct->save($erpTexonomyProduct)) {
                $this->Flash->success(__('The {0} has been saved.', 'Erp Texonomy Product'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Erp Texonomy Product'));
            }
        }
        $erpTexonomies = $this->ErpTexonomyProduct->ErpTexonomies->find('list', ['limit' => 200]);
        $products = $this->ErpTexonomyProduct->Products->find('list', ['limit' => 200]);
        $this->set(compact('erpTexonomyProduct', 'erpTexonomies', 'products'));
        $this->set('_serialize', ['erpTexonomyProduct']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Erp Texonomy Product id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $erpTexonomyProduct = $this->ErpTexonomyProduct->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $erpTexonomyProduct = $this->ErpTexonomyProduct->patchEntity($erpTexonomyProduct, $this->request->data);
            if ($this->ErpTexonomyProduct->save($erpTexonomyProduct)) {
                $this->Flash->success(__('The {0} has been saved.', 'Erp Texonomy Product'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Erp Texonomy Product'));
            }
        }
        $erpTexonomies = $this->ErpTexonomyProduct->ErpTexonomies->find('list', ['limit' => 200]);
        $products = $this->ErpTexonomyProduct->Products->find('list', ['limit' => 200]);
        $this->set(compact('erpTexonomyProduct', 'erpTexonomies', 'products'));
        $this->set('_serialize', ['erpTexonomyProduct']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Erp Texonomy Product id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $erpTexonomyProduct = $this->ErpTexonomyProduct->get($id);
        if ($this->ErpTexonomyProduct->delete($erpTexonomyProduct)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Erp Texonomy Product'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Erp Texonomy Product'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
