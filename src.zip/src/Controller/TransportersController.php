<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Transporters Controller
 *
 * @property \App\Model\Table\TransportersTable $Transporters
 *
 * @method \App\Model\Entity\Transporter[] paginate($object = null, array $settings = [])
 */
class TransportersController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Companies', 'Currencies', 'InOutWards', 'Purchases', 'Inwards', 'Products', 'Uoms', 'PsTrans', 'Lrcopies']
        ];
        $transporters = $this->paginate($this->Transporters);

        $this->set(compact('transporters'));
        $this->set('_serialize', ['transporters']);
    }

    /**
     * View method
     *
     * @param string|null $id Transporter id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $transporter = $this->Transporters->get($id, [
            'contain' => ['Companies', 'Currencies', 'InOutWards', 'Purchases', 'Inwards', 'Products', 'Uoms', 'PsTrans', 'Lrcopies', 'Outward']
        ]);

        $this->set('transporter', $transporter);
        $this->set('_serialize', ['transporter']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $transporter = $this->Transporters->newEntity();
        if ($this->request->is('post')) {
            $transporter = $this->Transporters->patchEntity($transporter, $this->request->data);
            if ($this->Transporters->save($transporter)) {
                $this->Flash->success(__('The {0} has been saved.', 'Transporter'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Transporter'));
            }
        }
        $companies = $this->Transporters->Companies->find('list', ['limit' => 200]);
        $currencies = $this->Transporters->Currencies->find('list', ['limit' => 200]);
        $inOutWards = $this->Transporters->InOutWards->find('list', ['limit' => 200]);
        $purchases = $this->Transporters->Purchases->find('list', ['limit' => 200]);
        $inwards = $this->Transporters->Inwards->find('list', ['limit' => 200]);
        $products = $this->Transporters->Products->find('list', ['limit' => 200]);
        $uoms = $this->Transporters->Uoms->find('list', ['limit' => 200]);
        $psTrans = $this->Transporters->PsTrans->find('list', ['limit' => 200]);
        $lrcopies = $this->Transporters->Lrcopies->find('list', ['limit' => 200]);
        $this->set(compact('transporter', 'companies', 'currencies', 'inOutWards', 'purchases', 'inwards', 'products', 'uoms', 'psTrans', 'lrcopies'));
        $this->set('_serialize', ['transporter']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Transporter id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $transporter = $this->Transporters->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $transporter = $this->Transporters->patchEntity($transporter, $this->request->data);
            if ($this->Transporters->save($transporter)) {
                $this->Flash->success(__('The {0} has been saved.', 'Transporter'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Transporter'));
            }
        }
        $companies = $this->Transporters->Companies->find('list', ['limit' => 200]);
        $currencies = $this->Transporters->Currencies->find('list', ['limit' => 200]);
        $inOutWards = $this->Transporters->InOutWards->find('list', ['limit' => 200]);
        $purchases = $this->Transporters->Purchases->find('list', ['limit' => 200]);
        $inwards = $this->Transporters->Inwards->find('list', ['limit' => 200]);
        $products = $this->Transporters->Products->find('list', ['limit' => 200]);
        $uoms = $this->Transporters->Uoms->find('list', ['limit' => 200]);
        $psTrans = $this->Transporters->PsTrans->find('list', ['limit' => 200]);
        $lrcopies = $this->Transporters->Lrcopies->find('list', ['limit' => 200]);
        $this->set(compact('transporter', 'companies', 'currencies', 'inOutWards', 'purchases', 'inwards', 'products', 'uoms', 'psTrans', 'lrcopies'));
        $this->set('_serialize', ['transporter']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Transporter id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $transporter = $this->Transporters->get($id);
        if ($this->Transporters->delete($transporter)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Transporter'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Transporter'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
