<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * LocalPreshipmentTransportDetails Controller
 *
 * @property \App\Model\Table\LocalPreshipmentTransportDetailsTable $LocalPreshipmentTransportDetails
 *
 * @method \App\Model\Entity\LocalPreshipmentTransportDetail[] paginate($object = null, array $settings = [])
 */
class LocalPreshipmentTransportDetailsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Transports']
        ];
        $localPreshipmentTransportDetails = $this->paginate($this->LocalPreshipmentTransportDetails);

        $this->set(compact('localPreshipmentTransportDetails'));
        $this->set('_serialize', ['localPreshipmentTransportDetails']);
    }

    /**
     * View method
     *
     * @param string|null $id Local Preshipment Transport Detail id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $localPreshipmentTransportDetail = $this->LocalPreshipmentTransportDetails->get($id, [
            'contain' => ['Transports']
        ]);

        $this->set('localPreshipmentTransportDetail', $localPreshipmentTransportDetail);
        $this->set('_serialize', ['localPreshipmentTransportDetail']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $localPreshipmentTransportDetail = $this->LocalPreshipmentTransportDetails->newEntity();
        if ($this->request->is('post')) {
            $localPreshipmentTransportDetail = $this->LocalPreshipmentTransportDetails->patchEntity($localPreshipmentTransportDetail, $this->request->data);
            if ($this->LocalPreshipmentTransportDetails->save($localPreshipmentTransportDetail)) {
                $this->Flash->success(__('The {0} has been saved.', 'Local Preshipment Transport Detail'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Local Preshipment Transport Detail'));
            }
        }
        $transports = $this->LocalPreshipmentTransportDetails->Transports->find('list', ['limit' => 200]);
        $this->set(compact('localPreshipmentTransportDetail', 'transports'));
        $this->set('_serialize', ['localPreshipmentTransportDetail']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Local Preshipment Transport Detail id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $localPreshipmentTransportDetail = $this->LocalPreshipmentTransportDetails->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $localPreshipmentTransportDetail = $this->LocalPreshipmentTransportDetails->patchEntity($localPreshipmentTransportDetail, $this->request->data);
            if ($this->LocalPreshipmentTransportDetails->save($localPreshipmentTransportDetail)) {
                $this->Flash->success(__('The {0} has been saved.', 'Local Preshipment Transport Detail'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Local Preshipment Transport Detail'));
            }
        }
        $transports = $this->LocalPreshipmentTransportDetails->Transports->find('list', ['limit' => 200]);
        $this->set(compact('localPreshipmentTransportDetail', 'transports'));
        $this->set('_serialize', ['localPreshipmentTransportDetail']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Local Preshipment Transport Detail id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $localPreshipmentTransportDetail = $this->LocalPreshipmentTransportDetails->get($id);
        if ($this->LocalPreshipmentTransportDetails->delete($localPreshipmentTransportDetail)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Local Preshipment Transport Detail'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Local Preshipment Transport Detail'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
