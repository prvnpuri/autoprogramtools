<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * InvoiceTypes Controller
 *
 * @property \App\Model\Table\InvoiceTypesTable $InvoiceTypes
 *
 * @method \App\Model\Entity\InvoiceType[] paginate($object = null, array $settings = [])
 */
class InvoiceTypesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $invoiceTypes = $this->paginate($this->InvoiceTypes);

        $this->set(compact('invoiceTypes'));
        $this->set('_serialize', ['invoiceTypes']);
        $this->set("transactionTypes",$this->InvoiceTypes->transactionTypes);
    }

    /**
     * View method
     *
     * @param string|null $id Invoice Type id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $invoiceType = $this->InvoiceTypes->get($id, [
            'contain' => []
        ]);
        
    
        
        $this->set('invoiceType', $invoiceType);
        $this->set('_serialize', ['invoiceType']);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $invoiceType = $this->InvoiceTypes->newEntity();
        if ($this->request->is('post')) {
            $invoiceType = $this->InvoiceTypes->patchEntity($invoiceType, $this->request->getData());
            if ($this->InvoiceTypes->save($invoiceType)) {
                $this->Flash->success(__('The invoice type has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The invoice type could not be saved. Please, try again.'));
        }
        $this->set("transactionTypes",$this->InvoiceTypes->transactionTypes);
        $this->set(compact('invoiceType'));
        $this->set('_serialize', ['invoiceType']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Invoice Type id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $invoiceType = $this->InvoiceTypes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $invoiceType = $this->InvoiceTypes->patchEntity($invoiceType, $this->request->getData());
            if ($this->InvoiceTypes->save($invoiceType)) {
                $this->Flash->success(__('The invoice type has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The invoice type could not be saved. Please, try again.'));
        }
        $this->set("transactionTypes",$this->InvoiceTypes->transactionTypes);
        $this->set(compact('invoiceType'));
        $this->set('_serialize', ['invoiceType']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Invoice Type id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $invoiceType = $this->InvoiceTypes->get($id);
        if ($this->InvoiceTypes->delete($invoiceType)) {
            $this->Flash->success(__('The invoice type has been deleted.'));
        } else {
            $this->Flash->error(__('The invoice type could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
