<?php
namespace App\Controller;
use App\Controller\AppController;
use Cake\Cache\Cache;
use App\Lib\AmountInWords; 
use Cake\Log\Log;

/**
 * @property \App\Model\Table\ProductsMasterTable $ProductsMaster
 */
class PolyajaxController extends AppController {
	
	public function suggestedcompanies() {
		$this->loadModel('CompanyMaster');
		$this->autoRender = false;

		$options = array(
				'fields' => array('id','Company_name'),
				'conditions' => array('Company_name LIKE' => "%".$this->request->data['term']."%" ));
		//}
		$lm = $this->CompanyMaster->find('all', $options);
		//echo json_encode($lm);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}
	
	public function prodtestssuggestions() {
		$this->loadModel('ProductDataTests');
		$prodid = $this->request->query('prodid');
		$this->autoRender = false;
		$this->viewBuilder()->layout();
		$options = array(
				'fields' => array('id','products_master_id', 'test', 'specification', 'methods'),
				'conditions' => array('products_master_id' => $prodid));
		$lm = $this->ProductDataTests->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}
	
	
	public function prodtestssuggestionsforbuyeroffer() {
		$this->loadModel('ProductDataTests');
		$prodid = $this->request->query('prodid');
		$this->autoRender = false;
		$this->viewBuilder()->layout();
		$options = array(
				'fields' => array('id','products_master_id', 'test', 'specification', 'methods','purpose'),
				'conditions' => array('products_master_id' => $prodid,'purpose like'=>'%Sales%'));
		$lm = $this->ProductDataTests->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}
	
	
	public function getTaxdataByProductId($product_id=null){
	    $this->loadModel("ProductsMaster");
	    $products=$this->ProductsMaster->ProductTaxes->find("all")->select([
	        'id', 'products_master_id','tax_master_id','rate','tax_name'=>"CONCAT(TaxMaster.tax_name)"
	    ])->contain(['TaxMaster'])
	    ->where(["products_master_id"=>$product_id]);
	    $this->set("product_taxes",$products);
	    $this->set("_serialize",['product_taxes']);
	}
	
	public function prodtestssuggestionspurchase() {
		$this->loadModel('ProductDataTests');
		$prodid = $this->request->query('prodid');
		$this->autoRender = false;
		$this->viewBuilder()->layout();
		$options = array(
				'fields' => array('id','products_master_id', 'test', 'specification', 'methods'),
				'conditions' => array('products_master_id' => $prodid ,'purpose LIKE'=> "%Purchase"));
		$lm = $this->ProductDataTests->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}
	public function prodsuggestions() {
		$this->loadModel('ProductsMaster');
		$this->autoRender = false;
		$querydata="";
		if(isset($this->request->data['term'])){
			$querydata=preg_replace('/[\s]/','%',$this->request->data['term']);
		}
		//$this->viewBuilder()->layout();
		$options = array(
				'fields' => array('id','product_name', 'grade_name', 'cas_no',"has_msds_pdf","has_techds_pdf"),
				"order"=>"product_name",
				'conditions' => array(
						"or"=>array(
								'product_name LIKE' => "%".$querydata."%",
								'grade_name LIKE' => "%".$querydata."%",
								'cas_no' => $querydata
						)
				),
		);
		
		
		// need to remove orWhere it will deprecate in 3.5
		
		$lm = $this->ProductsMaster
				->find()
				->select(['id','product_name', 'grade_name', 'cas_no',"has_msds_pdf","has_techds_pdf"])
				->where(['product_name LIKE' => "%".$querydata."%"])
				->orWhere(['grade_name LIKE' => "%".$querydata."%"])
				->orWhere(['cas_no' => $querydata])
				->order(['product_name' => 'ASC'])
				->toArray();
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		//echo json_encode($lm);
		return null;
	}
	
	public function findportofdischarge() {
		
		$this->loadModel('PortOfDischarge');
		$this->autoRender = false;
		
		$options = array(
				'fields' => array('id','port_of_discharge'),
				'conditions' => array('countries_id' => $this->request->data['country_id']));
		$lm = $this->PortOfDischarge->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return null;
		
		
	}
	
	public function packingsubtypes() {
		$this->loadModel('PackingSubtype');
		$querydata="";
		if(isset($this->request->data['packingtype_id'])){
			$querydata=$this->request->data['packingtype_id'];
		}
		$this->autoRender = false;
		$options = array(
				'fields' => array('id','sub_type'),
				'conditions' => array(
						'packingtype_id'=>$querydata
				),
		);
		$lm = $this->PackingSubtype->find('all', $options);
		
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return null;
	}
	
	public function packingmastertypes() {
		$this->loadModel('PackingMaster');
		$querydata="";
		if(isset($this->request->data['groupids'])){
			$querydata=$this->request->data['groupids'];
		}
		$this->autoRender = false;
		$options = array(
				'fields' => array('id','packing_subtype_id','paking_type_id','specification'),
				'conditions' => array('PackingMaster.packing_subtype_id'=>$querydata),
		);
		$lm = $this->PackingMaster->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return null;
	}
	public function companysuggestions() {
		$this->loadModel('CompanyMaster');
		$this->autoRender = false;
		$querydata="";
		if(isset($this->request->data['term'])){
			$querydata=preg_replace('/[\s]/','%',$this->request->data['term']);
		}
		$this->viewBuilder()->layout();
		//$this->ProductsMaster->recursive = -1;
		$options = array(
				'fields' => array('id','Company_name'),
				"order"=>"Company_name",
		        'conditions' => ['Company_name LIKE' => "%".$querydata."%"]
		);
		$lm = $this->CompanyMaster->find('all', $options);
		Log::info($lm);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return null;
	}
	public function transportersuggest(){
		$this->loadModel('CompanyMaster');
		$this->autoRender = false;
		$querydata="";
		if(isset($this->request->data['term'])){
			$querydata=preg_replace('/[\s]/','%',$this->request->data['term']);
		}
		$this->viewBuilder()->layout();
		//$this->ProductsMaster->recursive = -1;
		$options = array(
				'fields' => array('id','Company_name'),
				"order"=>"Company_name",
				'conditions' => array(
						//"or"=>array(
						'company_types_master_id'=>'1',
								'Company_name LIKE' => "%".$querydata."%"
						//)
				),
		);
		$lm = $this->CompanyMaster->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return null;
		
		
	}
	
	public function insurancesuggest(){
		$this->loadModel('CompanyMaster');
		$this->autoRender = false;
		$querydata="";
		if(isset($this->request->data['term'])){
			$querydata=preg_replace('/[\s]/','%',$this->request->data['term']);
		}
		$this->viewBuilder()->layout();
		//$this->ProductsMaster->recursive = -1;
		$options = array(
				'fields' => array('id','Company_name'),
				"order"=>"Company_name",
				'conditions' => array(
						//"or"=>array(
						'company_types_master_id'=>'6',
						'Company_name LIKE' => "%".$querydata."%"
						//)
				),
		);
		$lm = $this->CompanyMaster->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return null;
	
	
	}
	public function getCompanyContactPersons(){
		$this->loadModel('CompanyContactPersons');
		$this->autoRender = false;
		
		$this->viewBuilder()->layout();
		$companyid=null;
		
		if(isset($this->request->query["companyid"])||isset($this->request->data["companyid"])){
			$companyid=isset($this->request->query["companyid"])?$this->request->query["companyid"]:(isset($this->request->data["companyid"])?$this->request->data["companyid"]:null);
		}
		
		if(isset($this->request->query["compid"])||isset($this->request->data["compid"])){
			$companyid=isset($this->request->query["compid"])?$this->request->query["compid"]:(isset($this->request->data["compid"])?$this->request->data["compid"]:null);
		}
		$persons=$this->CompanyContactPersons->find("all",
				array(
						"field"=>array(
								"CompanyContactPersons.id",
								"coalesce(CompanyContactPersons.prefix_name, '') as CompanyContactPersons.prefix_name",
								"CompanyContactPersons.first_name",
								"CompanyContactPersons.middle_name",
								"CompanyContactPersons.last_name",
								"CompanyContactPersons.phone",
								"CompanyContactPersons.email_id",
						),
						"conditions"=>array("CompanyContactPersons.company_master_id"=>$companyid),
						"order"=>"concat(`first_name`,`middle_name`,`last_name`)"
				)
				);
		//echo json_encode($persons);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($persons));
		return null;
		
	}
	
	public function getOffice() {
	
		$this->loadModel('CompanySublocation');
		$this->autoRender = false;
		$options = array(
				'fields' => array('id','sublocation_name'),
				'conditions' => array('company_master_id' => $this->request->data['company_id']));
		$lm = $this->CompanySublocation->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}
	
	public function getStateSuggestions() {
	
		$this->loadModel('State');
		$this->autoRender = false;
		$options = array(
				'fields' => array('id','state_name'),
				'order' => 'state_name',
				'conditions' => array('country_id' => $this->request->data['country_id']));
		$lm = $this->State->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}
	
	public function getCitySuggestions() {
	
		$this->loadModel('City');
		$this->autoRender = false;
		$options = array(
				'fields' => array('id','city_name'),
				'order' => 'city_name',
				'conditions' => array('state_id' => $this->request->data['state_id']));
		$lm = $this->City->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}
	
	public function getOfficeAddress() {
		$this->loadModel('CompanySublocation');
		$this->autoRender = false;
		$this->CompanySublocation->recursive = -1;
		$options = [
				'contain' => ['City','State','Countries'],
				'fields' => ['id','Address','postal_code','City.city_name','State.state_name','Countries.country_name'],
				'conditions' => ['CompanySublocation.id' => $this->request->data['office_id']],
		];
		$lm = $this->CompanySublocation->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}	
	public function getOwnerOfficeAddress() {
		$this->loadModel('OwnerCompanyOffices');
		$this->autoRender = false;
		$this->OwnerCompanyOffices->recursive = -1;
		$options = [
				'contain' => ['City','State','Countries'],
				'fields' => ['id','Address','postal_code','phone_no','City.city_name','State.state_name','Countries.country_name'],
				'conditions' => ['OwnerCompanyOffices.id' => $this->request->data['officeid']],
		];
		$lm = $this->OwnerCompanyOffices->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}
	public function equipmentsuggestions() {
		$this->loadModel('AssetsMaster');
		
		$this->autoRender = false;
		$querydata="";
		if(isset($this->request->data['term'])){
			$querydata=preg_replace('/[\s]/','%',$this->request->data['term']);
		}
		$this->AssetsMaster->recursive = -1;
		$options = array(
				'fields' => array('id','asset_name','qc_type'),
				"order"=>"asset_name",
				'conditions' => array(
	
	
						'asset_name LIKE' => "%".$querydata."%",
						'qc_type'=>'3'
	
	
				),
		);
		$lm = $this->AssetsMaster->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}
	
	public function assetsuggestions() {
		$this->loadModel('AssetsMaster');
		
		$this->autoRender = false;
		$querydata="";
		if(isset($this->request->data['term'])){
			$querydata=preg_replace('/[\s]/','%',$this->request->data['term']);
		}
	//	$this->layout = null ;
		$this->AssetsMaster->recursive = -1;
		$options = array(
				'fields' => array('id','asset_name','qc_type'),
				"order"=>"asset_name",
				'conditions' => array(
	
	
						'asset_name LIKE' => "%".$querydata."%",
						'qc_type'=>'2'
	
	
				),
		);
		$lm = $this->AssetsMaster->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return NULL;
	}
	
	
	public function currencysuggestions()
	{
		
		
		$ownercompanyId=$this->request->data['ownercompanyId'];
		$offertype=$this->request->data['offertype'];
		
		$CurrencyKey=$ownercompanyId.'_'.'currency';
		$currencyId = Cache::read($CurrencyKey, $config = 'default');
		
		$options=array('iso_code'=>$currencyId);
		
		
		$this->loadModel('Currency');
		
		$this->autoRender = false;
		
		if($offertype=='1'){
		$cond = array(
				'fields' => array('id','sign'),
				'conditions' => $options);
		$lm = $this->Currency->find('all', $cond);
		
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return null;
		}
		else if($offertype=='0') {
			$cond = array(
					'fields' => array('id','sign'));
			$lm = $this->Currency->find('all', $cond);
			
			$this->response = $this->response->withType('application/json')
			->withStringBody(json_encode($lm));
			return null;
			
		}
		
	}
	public function packingmasterlists() {
		$this->loadModel('PackingMaster');
		$querydata="";
		if(isset($this->request->data['term'])){
			$querydata=preg_replace('/[\s]/','%',$this->request->data['term']);
		}
		$this->autoRender = false;
		$options = array(
				'contain' => ['PackingType'],
				'fields' => array('id','color','PackingType.packing_type','specification'),
				'conditions' => array(
						'PackingType.packing_type LIKE' => "%".$querydata."%",
						
				
				
				),
		);
		$lm = $this->PackingMaster->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		return null;
	}
	
	
	
	public function getmotherorderajax() {
		$this->loadModel('Order');
		$this->autoRender = false;
		
		$options = array(
				'fields' => array('Order.id','Order.reference_number','Order.quantity_ordered','Order.balance_qty'),
				'conditions' => array('Order.order_type' => 1,
						'Order.buyer_company'=>$this->request->data['buyerid'],
						'Order.supplier_company'=>$this->request->data['supplierid'],
						'Order.products_master_id'=>$this->request->data['productid'],
						
				),
				
		);
		
		$ordernumber = $this->Order->find('all', $options);
		
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($ordernumber));
		return null;
	}
	public function numberInWords(){
		
		$this->loadModel('Currency');
		$this->autoRender = false;
	
		$grand_total = $this->request->query['grandTotal'];
		$currency = $this->request->query['currency'];
	
		$options = array(
				'fields' => array('id','name','mini_currency'),
				'conditions' => array("id"=>$currency
		
				)
		
		);
		$lm = $this->Currency->find('all', $options)->toArray();
		
		
		$total_amount=AmountInWords::convert_number($grand_total,$lm[0]['currency']['name'],$lm[0]['currency']['mini_currency'])." Only.";
	
		
		$amount=strtoupper($total_amount);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($amount));
		return null;
		
	}
	
	
	public function orderAcceptancesuggestions() {
		$this->loadModel('Order');
		$this->autoRender = false;
		$querydata="";
		if(isset($this->request->data['term'])){
			$querydata=preg_replace('/[\s]/','%',$this->request->data['term']);
		}
		$options = array(
				'fields' => array('id','order_no','OrderAcceptance.id','OrderAcceptance.number_and_kind_of_packages','products_master_id','ProductsMaster.id','ProductsMaster.product_name'),
				//"order"=>"order_no",
				'conditions' => array(
						'order_no LIKE' => "%".$querydata."%",
						'order_type !='=>'1'
	
				),
				'join'=>[
						
						'OrderAcceptance' => [
								'table' => 'order_acceptance',
								'type' => 'LEFT',
								'conditions' =>'Order.id = OrderAcceptance.order_id',
						]
				],
				
				'contain' => ['ProductsMaster'],
		);
		$lm = $this->Order->find('all', $options);
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		
		//echo json_encode($lm);
		
		return null;
	
	}
	
	public function assetsProdsuggestions () {
		$this->loadModel('AssetsMaster');
		$this->autoRender = false;
		$querydata="";
		if(isset($this->request->data['term'])){
			$querydata=preg_replace('/[\s]/','%',$this->request->data['term']);
		}
		//$this->viewBuilder()->layout();
		$options = array(
				'fields' => array('id','product'),
				"order"=>"product_name",
				'conditions' => array(
						"or"=>array(
								'product LIKE' => "%".$querydata."%",
						)
				),
		);
	
		$lm = $this->AssetsMaster
		->find()
		->select(['id','product'])
		->where(['product LIKE' => "%".$querydata."%"])
		->order(['product' => 'ASC'])
		->toArray();
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		//echo json_encode($lm);
		return null;
	}
	public function consumableProdsuggestions () {
		$this->loadModel('ConsumablesMaster');
		$this->autoRender = false;
		$querydata="";
		if(isset($this->request->data['term'])){
			$querydata=preg_replace('/[\s]/','%',$this->request->data['term']);
		}
		//$this->viewBuilder()->layout();
		/* $options = array(
				'fields' => array('id','consumable_name'),
				"order"=>"consumable_name",
				'conditions' => array(
						"or"=>array(
								'consumable_name LIKE' => "%".$querydata."%",
						)
				),
		); */
	
		$lm = $this->ConsumablesMaster
		->find()
		->select(['id','product_name'])
		->where(['product_name LIKE' => "%".$querydata."%"])
		->order(['product_name' => 'ASC'])
		->toArray();
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		//echo json_encode($lm);
		return null;
	}
	
	public function getproductStock(){
		
		$this->loadModel('WarehouseInventory');
		$this->autoRender = false;
		$querydata="";
		
		$lm = $this->WarehouseInventory
		->find()
		->select(['id','balance_qty'])
		->where(['product_id' => $this->request->data['term']])
		//->order(['product_name' => 'ASC'])
		->toArray();
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		//echo json_encode($lm);
		return null;
		
	}
	public function getconsumableStock(){
	
		$this->loadModel('ConsumableInventory');
		$this->autoRender = false;
		$querydata="";
		
		$lm = $this->ConsumableInventory
		->find()
		->select(['id','balance_qty'])
		->where(['product_id' => $this->request->data['term']])
		//->order(['product_name' => 'ASC'])
		->toArray();
		$this->response = $this->response->withType('application/json')
		->withStringBody(json_encode($lm));
		//echo json_encode($lm);
		return null;
	
	}
}
?>