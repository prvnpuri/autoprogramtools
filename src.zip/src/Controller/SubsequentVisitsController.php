<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * SubsequentVisits Controller
 *
 * @property \App\Model\Table\SubsequentVisitsTable $SubsequentVisits
 *
 * @method \App\Model\Entity\SubsequentVisit[] paginate($object = null, array $settings = [])
 */
class SubsequentVisitsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Attendees', 'OwnerCompanies']
        ];
        $subsequentVisits = $this->paginate($this->SubsequentVisits);

        $this->set(compact('subsequentVisits'));
        $this->set('_serialize', ['subsequentVisits']);
    }

    /**
     * View method
     *
     * @param string|null $id Subsequent Visit id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $subsequentVisit = $this->SubsequentVisits->get($id, [
            'contain' => ['Attendees', 'OwnerCompanies', 'ProductInterested', 'VisitCustomerRepresentatives', 'VisitStatusUpdates']
        ]);

        $this->set('subsequentVisit', $subsequentVisit);
        $this->set('_serialize', ['subsequentVisit']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $subsequentVisit = $this->SubsequentVisits->newEntity();
        if ($this->request->is('post')) {
            $subsequentVisit = $this->SubsequentVisits->patchEntity($subsequentVisit, $this->request->data);
            if ($this->SubsequentVisits->save($subsequentVisit)) {
                $this->Flash->success(__('The {0} has been saved.', 'Subsequent Visit'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Subsequent Visit'));
            }
        }
        $attendees = $this->SubsequentVisits->Attendees->find('list', ['limit' => 200]);
        $ownerCompanies = $this->SubsequentVisits->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('subsequentVisit', 'attendees', 'ownerCompanies'));
        $this->set('_serialize', ['subsequentVisit']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Subsequent Visit id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $subsequentVisit = $this->SubsequentVisits->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $subsequentVisit = $this->SubsequentVisits->patchEntity($subsequentVisit, $this->request->data);
            if ($this->SubsequentVisits->save($subsequentVisit)) {
                $this->Flash->success(__('The {0} has been saved.', 'Subsequent Visit'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Subsequent Visit'));
            }
        }
        $attendees = $this->SubsequentVisits->Attendees->find('list', ['limit' => 200]);
        $ownerCompanies = $this->SubsequentVisits->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('subsequentVisit', 'attendees', 'ownerCompanies'));
        $this->set('_serialize', ['subsequentVisit']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Subsequent Visit id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $subsequentVisit = $this->SubsequentVisits->get($id);
        if ($this->SubsequentVisits->delete($subsequentVisit)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Subsequent Visit'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Subsequent Visit'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
