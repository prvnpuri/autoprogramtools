<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TransactionProduct Controller
 *
 * @property \App\Model\Table\TransactionProductTable $TransactionProduct
 *
 * @method \App\Model\Entity\TransactionProduct[] paginate($object = null, array $settings = [])
 */
class TransactionProductController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['FromTos', 'Inwards', 'Outwards', 'Products', 'Uoms', 'WarehouseUnits', 'WarehouseSubunits', 'WarehouseMasters', 'OwnerCompanies']
        ];
        $transactionProduct = $this->paginate($this->TransactionProduct);

        $this->set(compact('transactionProduct'));
        $this->set('_serialize', ['transactionProduct']);
    }

    /**
     * View method
     *
     * @param string|null $id Transaction Product id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $transactionProduct = $this->TransactionProduct->get($id, [
            'contain' => ['FromTos', 'Inwards', 'Outwards', 'Products', 'Uoms', 'WarehouseUnits', 'WarehouseSubunits', 'WarehouseMasters', 'OwnerCompanies']
        ]);

        $this->set('transactionProduct', $transactionProduct);
        $this->set('_serialize', ['transactionProduct']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $transactionProduct = $this->TransactionProduct->newEntity();
        if ($this->request->is('post')) {
            $transactionProduct = $this->TransactionProduct->patchEntity($transactionProduct, $this->request->data);
            if ($this->TransactionProduct->save($transactionProduct)) {
                $this->Flash->success(__('The {0} has been saved.', 'Transaction Product'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Transaction Product'));
            }
        }
        $fromTos = $this->TransactionProduct->FromTos->find('list', ['limit' => 200]);
        $inwards = $this->TransactionProduct->Inwards->find('list', ['limit' => 200]);
        $outwards = $this->TransactionProduct->Outwards->find('list', ['limit' => 200]);
        $products = $this->TransactionProduct->Products->find('list', ['limit' => 200]);
        $uoms = $this->TransactionProduct->Uoms->find('list', ['limit' => 200]);
        $warehouseUnits = $this->TransactionProduct->WarehouseUnits->find('list', ['limit' => 200]);
        $warehouseSubunits = $this->TransactionProduct->WarehouseSubunits->find('list', ['limit' => 200]);
        $warehouseMasters = $this->TransactionProduct->WarehouseMasters->find('list', ['limit' => 200]);
        $ownerCompanies = $this->TransactionProduct->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('transactionProduct', 'fromTos', 'inwards', 'outwards', 'products', 'uoms', 'warehouseUnits', 'warehouseSubunits', 'warehouseMasters', 'ownerCompanies'));
        $this->set('_serialize', ['transactionProduct']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Transaction Product id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $transactionProduct = $this->TransactionProduct->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $transactionProduct = $this->TransactionProduct->patchEntity($transactionProduct, $this->request->data);
            if ($this->TransactionProduct->save($transactionProduct)) {
                $this->Flash->success(__('The {0} has been saved.', 'Transaction Product'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Transaction Product'));
            }
        }
        $fromTos = $this->TransactionProduct->FromTos->find('list', ['limit' => 200]);
        $inwards = $this->TransactionProduct->Inwards->find('list', ['limit' => 200]);
        $outwards = $this->TransactionProduct->Outwards->find('list', ['limit' => 200]);
        $products = $this->TransactionProduct->Products->find('list', ['limit' => 200]);
        $uoms = $this->TransactionProduct->Uoms->find('list', ['limit' => 200]);
        $warehouseUnits = $this->TransactionProduct->WarehouseUnits->find('list', ['limit' => 200]);
        $warehouseSubunits = $this->TransactionProduct->WarehouseSubunits->find('list', ['limit' => 200]);
        $warehouseMasters = $this->TransactionProduct->WarehouseMasters->find('list', ['limit' => 200]);
        $ownerCompanies = $this->TransactionProduct->OwnerCompanies->find('list', ['limit' => 200]);
        $this->set(compact('transactionProduct', 'fromTos', 'inwards', 'outwards', 'products', 'uoms', 'warehouseUnits', 'warehouseSubunits', 'warehouseMasters', 'ownerCompanies'));
        $this->set('_serialize', ['transactionProduct']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Transaction Product id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $transactionProduct = $this->TransactionProduct->get($id);
        if ($this->TransactionProduct->delete($transactionProduct)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Transaction Product'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Transaction Product'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
