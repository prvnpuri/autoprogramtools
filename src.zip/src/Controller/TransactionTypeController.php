<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TransactionType Controller
 *
 * @property \App\Model\Table\TransactionTypeTable $TransactionType
 *
 * @method \App\Model\Entity\TransactionType[] paginate($object = null, array $settings = [])
 */
class TransactionTypeController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate=[
            "contain"=>["ParentTransactionType"],
            "sortWhitelist"=>[
                "ParentTransactionType.type"
            ],
            "order"=>["TransactionType.id"=> "desc"]
        ];
        
        $transactionType = $this->paginate($this->TransactionType);

        $this->set(compact('transactionType'));
        $this->set('_serialize', ['transactionType']);
    }

    /**
     * View method
     *
     * @param string|null $id Transaction Type id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $transactionType = $this->TransactionType->get($id, [
            'contain' => ['ParentTransactionType']
        ]);
        
        $this->set(compact('transactionType','ParentTransactionType'));
        $this->set('_serialize', ['transactionType']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $transactionType = $this->TransactionType->newEntity();
        if ($this->request->is('post')) {
            $transactionType = $this->TransactionType->patchEntity($transactionType, $this->request->data);
            if ($this->TransactionType->save($transactionType)) {
                $this->Flash->success(__('The {0} has been saved.', 'Transaction Type'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Transaction Type'));
            }
        }
        $parentTransactionTypes = $this->TransactionType->ParentTransactionType->find("list",[
            "keyField"=>"id",
            "valueField"=>"type",
            "order"=>"type asc"
        ]);
        
        $this->set(compact('transactionType','parentTransactionTypes'));
        $this->set('_serialize', ['transactionType']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Transaction Type id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $transactionType = $this->TransactionType->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $transactionType = $this->TransactionType->patchEntity($transactionType, $this->request->data);
            if ($this->TransactionType->save($transactionType)) {
                $this->Flash->success(__('The {0} has been saved.', 'Transaction Type'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Transaction Type'));
            }
        }
        $parentTransactionTypes = $this->TransactionType->ParentTransactionType->find("list",[
            "keyField"=>"id",
            "valueField"=>"type",
            "order"=>"type asc"
        ]);
        
        $this->set(compact('transactionType','parentTransactionTypes'));
        
        $this->set('_serialize', ['transactionType']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Transaction Type id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $transactionType = $this->TransactionType->get($id);
        if ($this->TransactionType->delete($transactionType)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Transaction Type'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Transaction Type'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
