<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * BoldNoInventoryTran Controller
 *
 * @property \App\Model\Table\BoldNoInventoryTranTable $BoldNoInventoryTran
 *
 * @method \App\Model\Entity\BoldNoInventoryTran[] paginate($object = null, array $settings = [])
 */
class BoldNoInventoryTranController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
    	$ownercomp= $this->request->session()->read('OwnerCompany.id');
    	$condn= array(['AND' => [
    			'BoldNumberInventory.owner_company_id' => $ownercomp,
    			'BoldNumberInventory.delete_status' => "0"
    	]]);
        $this->paginate = [
        	'conditions'=>$condn,
            'contain' => ['BoldNumberInventory', 'ProductsMaster', 'Order','OrderAcceptance']
        ];
        $boldNoInventoryTran = $this->paginate($this->BoldNoInventoryTran);
        $this->set(compact('boldNoInventoryTran'));
        $this->set('_serialize', ['boldNoInventoryTran']);
    }

    /**
     * View method
     *
     * @param string|null $id Bold No Inventory Tran id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $boldNoInventoryTran = $this->BoldNoInventoryTran->get($id, [
            'contain' => ['Inventories', 'BoldNumberInventory', 'Products', 'Order']
        ]);

        $this->set('boldNoInventoryTran', $boldNoInventoryTran);
        $this->set('_serialize', ['boldNoInventoryTran']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $boldNoInventoryTran = $this->BoldNoInventoryTran->newEntity();
        if ($this->request->is('post')) {
            $boldNoInventoryTran = $this->BoldNoInventoryTran->patchEntity($boldNoInventoryTran, $this->request->data);
            if ($this->BoldNoInventoryTran->save($boldNoInventoryTran)) {
                $this->Flash->success(__('The {0} has been saved.', 'Bold No Inventory Tran'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bold No Inventory Tran'));
            }
        }
        $inventories = $this->BoldNoInventoryTran->Inventories->find('list', ['limit' => 200]);
        $boldNumberInventory = $this->BoldNoInventoryTran->BoldNumberInventory->find('list', ['limit' => 200]);
        $products = $this->BoldNoInventoryTran->Products->find('list', ['limit' => 200]);
        $order = $this->BoldNoInventoryTran->Order->find('list', ['limit' => 200]);
        $this->set(compact('boldNoInventoryTran', 'inventories', 'boldNumberInventory', 'products', 'order'));
        $this->set('_serialize', ['boldNoInventoryTran']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Bold No Inventory Tran id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $boldNoInventoryTran = $this->BoldNoInventoryTran->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $boldNoInventoryTran = $this->BoldNoInventoryTran->patchEntity($boldNoInventoryTran, $this->request->data);
            if ($this->BoldNoInventoryTran->save($boldNoInventoryTran)) {
                $this->Flash->success(__('The {0} has been saved.', 'Bold No Inventory Tran'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The {0} could not be saved. Please, try again.', 'Bold No Inventory Tran'));
            }
        }
        $inventories = $this->BoldNoInventoryTran->Inventories->find('list', ['limit' => 200]);
        $boldNumberInventory = $this->BoldNoInventoryTran->BoldNumberInventory->find('list', ['limit' => 200]);
        $products = $this->BoldNoInventoryTran->Products->find('list', ['limit' => 200]);
        $order = $this->BoldNoInventoryTran->Order->find('list', ['limit' => 200]);
        $this->set(compact('boldNoInventoryTran', 'inventories', 'boldNumberInventory', 'products', 'order'));
        $this->set('_serialize', ['boldNoInventoryTran']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Bold No Inventory Tran id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $boldNoInventoryTran = $this->BoldNoInventoryTran->get($id);
        if ($this->BoldNoInventoryTran->delete($boldNoInventoryTran)) {
            $this->Flash->success(__('The {0} has been deleted.', 'Bold No Inventory Tran'));
        } else {
            $this->Flash->error(__('The {0} could not be deleted. Please, try again.', 'Bold No Inventory Tran'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
