<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Inquiry Entity
 *
 * @property int $id
 * @property string $reference_number
 * @property int $company_master_id
 * @property int $products_master_id
 * @property float $qty_required
 * @property string $company_contact_persons
 * @property string $cc_email
 * @property \Cake\I18n\FrozenDate $received_on
 * @property string $comments
 * @property int $isoffered
 * @property int $owner_companies_id
 * @property int $uom_id
 * @property float $rate
 * @property int $currency_id
 * @property int $local_offer
 * @property float $total_order_value
 * @property string $inquiry_archive
 * @property int $packing
 * @property \Cake\I18n\FrozenDate $expected_delivery_dt
 * @property int $payment_terms
 * @property \Cake\I18n\FrozenDate $validity_of_inquiry
 * @property int $port_of_discharge
 * @property int $country_of_origin_of_goods
 * @property int $country_final_destination
 * @property string $send_to_offer
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\CompanyMaster $company_master
 * @property \App\Model\Entity\ProductsMaster $products_master
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\Currency $currency
 * @property \App\Model\Entity\FeasibilityMaster[] $feasibility_master
 * @property \App\Model\Entity\Offer[] $offer
 */
class Inquiry extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'reference_number' => true,
        'company_master_id' => true,
        'products_master_id' => true,
        'qty_required' => true,
        'company_contact_persons' => true,
        'cc_email' => true,
        'received_on' => true,
        'comments' => true,
        'isoffered' => true,
        'owner_companies_id' => true,
        'uom_id' => true,
        'rate' => true,
        'currency_id' => true,
        'local_offer' => true,
        'total_order_value' => true,
        'inquiry_archive' => true,
        'packing' => true,
        'expected_delivery_dt' => true,
        'payment_terms' => true,
        'validity_of_inquiry' => true,
    	'countries_id' => true,
        'port_of_discharge_id' => true,
        'country_of_origin_of_goods' => true,
        'country_final_destination' => true,
        'send_to_offer' => true,
    	'product_specifications'=>true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'company_master' => true,
        'products_master' => true,
        'owner_company' => true,
        'uom' => true,
        'currency' => true,
        'feasibility_master' => true,
        'offer' => true,
    		"selected_product_specs"=>true,
    	
    ];
}
