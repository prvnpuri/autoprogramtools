<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * CompanyTaxonomy Entity
 *
 * @property int $id
 * @property int $company_id
 * @property string $website_address
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\Company $company
 * @property \App\Model\Entity\CompanyTaxonomyAssociation[] $company_taxonomy_association
 */
class CompanyTaxonomy extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'company_id' => true,
        'website_address' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'company' => true,
        'company_taxonomy_association' => true
    ];
}
