<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PurchaseRequisition Entity
 *
 * @property int $id
 * @property string $requisition_type
 * @property string $pr_reference_no
 * @property \Cake\I18n\FrozenDate $pr_date
 * @property int $required_by
 * @property string $comment
 * @property int $approved_id
 * @property \Cake\I18n\FrozenDate $date_of_created
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property int $created_by
 */
class PurchaseRequisition extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'requisition_type' => true,
        'pr_reference_no' => true,
        'pr_date' => true,
        'required_by' => true,
        'comment' => true,
        'approved_id' => true,
        'created' => true,
        'modified' => true,
        'created_by' => true,
    	'purchase_requisition_products'=>true,
    	'send_to_approve'=>true,
   		'is_approve'=>true,
    		
    		
    ];
}
