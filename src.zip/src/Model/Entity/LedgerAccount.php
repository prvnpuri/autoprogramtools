<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Cake\Log\Log;

/**
 * LedgerAccount Entity
 *
 * @property int $id
 * @property int $ledger_groups_id
 * @property int $company_id
 * @property string $account_name
 * @property string $notes
 * @property int $parent_id
 * @property float $opening_balance
 * @property string $opening_balance_side
 * @property Cake\I18n\FrozenDate $opening_balance_date
 * 
 * @property \App\Model\Entity\LedgerGroup $ledger_group
 * @property \App\Model\Entity\CompanyMaster $company_master
 * @property \App\Model\Entity\EmployeeDetail $employee_detail
 * @property \App\Model\Entity\BankMaster $bank_master
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\LedgerAccount $parent_ledger_account
 * @property \App\Model\Entity\LedgerAccount[] $child_ledger_accounts
 */
class LedgerAccount extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'ledger_groups_id' => true,
        'model_reference_id' => true,
        'model_reference_name' => true,
        'owner_company_id'=>true,
        'account_name' => true,
        'notes' => true,
        'parent_id' => true,
        'ledger_group' => true,
        'company_master' => true,
        'employee_detail' => true,
        'bank_master' => true,
        'owner_company' => true,
        'parent_ledger_account' => true,
        'child_ledger_accounts' => true,
        'opening_balance'=>true,
        "opening_balance_side"=>true,
        'opening_balance_date'=>true
    ];
    
    
    protected function _getAccountName()
    {
        if($this->has('company_master')){
            return $this->company_master->Company_name . " | ". $this->model_reference_name ;
        }else if($this->has('employee_detail')){
            return $this->employee_detail->first_name . " ". $this->employee_detail->middle_name." ". $this->employee_detail->last_name . " | ". $this->_properties["model_reference_name"];
        }else if($this->has('bank_master')){
            return $this->bank_master->bank_name.", ". $this->bank_master->name.", ".$this->bank_master->account_name . " | ". $this->_properties["model_reference_name"];
        }else {
            return isset($this->_properties["account_name"])?$this->_properties["account_name"]:"";
        }
    }
    
}
