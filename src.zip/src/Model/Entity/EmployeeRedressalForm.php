<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * EmployeeRedressalForm Entity
 *
 * @property int $id
 * @property int $emp_id
 * @property \Cake\I18n\FrozenDate $data_of_submission
 * @property string $describe
 * @property string $status
 * @property string $aboutstatus
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property bool $anonymous
 *
 * @property \App\Model\Entity\Emp $emp
 */
class EmployeeRedressalForm extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'emp_id' => true,
        'data_of_submission' => true,
        'describe' => true,
        'status' => true,
        'aboutstatus' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'anonymous' => true,
        'emp' => true
    ];
}
