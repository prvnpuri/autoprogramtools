<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ControlSampleEntry Entity
 *
 * @property int $id
 * @property string $ref_no
 * @property int $product_id
 * @property string $batch_no
 * @property \Cake\I18n\FrozenDate $production_date
 * @property \Cake\I18n\FrozenDate $expiry_date
 * @property int $supplier_mfg
 * @property int $seller
 * @property int $unique_no_first
 * @property int $unique_no_last
 * @property string $random_bag1
 * @property string $random_bag2
 * @property string $random_bag3
 * @property string $random_bag_photo1
 * @property string $random_bag_photo2
 * @property string $random_bag_photo3
 * @property int $entered_by
 * @property \Cake\I18n\FrozenDate $enter_date
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $modified_date
 * @property string $send_control_sample
 * @property string $note
 * @property string $sent_to_summary
 *
 * @property \App\Model\Entity\Product $product
 */
class ControlSampleEntry extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'ref_no' => true,
        'product_id' => true,
        'batch_no' => true,
        'production_date' => true,
        'expiry_date' => true,
        'supplier_mfg' => true,
        'seller' => true,
        'unique_no_first' => true,
        'unique_no_last' => true,
        'random_bag1' => true,
        'random_bag2' => true,
        'random_bag3' => true,
        'random_bag_photo1' => true,
        'random_bag_photo2' => true,
        'random_bag_photo3' => true,
        'entered_by' => true,
        'enter_date' => true,
        'modified_by' => true,
        'modified_date' => true,
        'send_control_sample' => true,
        'note' => true,
        'sent_to_summary' => true,
        'product' => true
    ];
}
