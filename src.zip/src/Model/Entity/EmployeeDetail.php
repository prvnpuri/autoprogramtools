<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * EmployeeDetail Entity
 *
 * @property int $id
 * @property int $users_id
 * @property int $manager_id
 * @property string $first_name
 * @property string $middle_name
 * @property string $last_name
 * @property bool $gender
 * @property string $address
 * @property string $country
 * @property string $state
 * @property string $city
 * @property string $mob_no
 * @property string $emg_no
 * @property \Cake\I18n\FrozenDate $dob
 * @property string $email
 * @property string $pan_no
 * @property string $aadharcard_no
 * @property string $blood_group
 * @property string $languages
 * @property string $parent_spouse
 * @property string $parentsp_occ
 * @property string $bankacc_no
 * @property string $ifsc_code
 * @property string $ssc_institute
 * @property string $ssc_year
 * @property string $ssc_marks
 * @property string $hsc_institute
 * @property string $hsc_yr
 * @property string $hsc_marks
 * @property string $grad_institute
 * @property string $grad_course
 * @property string $grad_year
 * @property string $grad_marks
 * @property string $postgrad_institute
 * @property string $postgrad_course
 * @property string $postgrad_year
 * @property string $postgrad_marks
 * @property string $prev_company
 * @property string $prev_desgn
 * @property string $prev_kra
 * @property string $prev_ref_empname
 * @property int $cur_comp_name
 * @property int $desi_id
 * @property int $dept_id
 * @property string $curr_kra
 * @property string $curr_empid
 * @property string $curr_join_date
 * @property \Cake\I18n\FrozenTime $probation_end_dt
 * @property string $curr_base_location
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\Manager $manager
 * @property \App\Model\Entity\Desi $desi
 * @property \App\Model\Entity\Dept $dept
 */
class EmployeeDetail extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
        protected $_accessible = [
            'users_id' => true,
            'manager_id' => true,
            'first_name' => true,
            'middle_name' => true,
            'last_name' => true,
            'gender' => true,
            'address' => true,
            'country' => true,
            'state' => true,
            'city' => true,
            'mob_no' => true,
            'emg_no' => true,
            'dob' => true,
            'email' => true,
            'pan_no' => true,
            'aadharcard_no' => true,
            'blood_group' => true,
            'languages' => true,
            'parent_spouse' => true,
            'parentsp_occ' => true,
            'bankacc_no' => true,
            'ifsc_code' => true,
            'ssc_institute' => true,
            'ssc_year' => true,
            'ssc_marks' => true,
            'hsc_institute' => true,
            'hsc_yr' => true,
            'hsc_marks' => true,
            'grad_institute' => true,
            'grad_course' => true,
            'grad_year' => true,
            'grad_marks' => true,
            'postgrad_institute' => true,
            'postgrad_course' => true,
            'postgrad_year' => true,
            'postgrad_marks' => true,
            'prev_company' => true,
            'prev_desgn' => true,
            'prev_kra' => true,
            'prev_ref_empname' => true,
            'cur_comp_name' => true,
            'desi_id' => true,
            'dept_id' => true,
            'curr_kra' => true,
            'curr_empid' => true,
            'curr_join_date' => true,
            'probation_end_dt' => true,
            'curr_base_location' => true,
            'date_of_creation' => true,
            'created_by' => true,
        	'date_of_modification' => true,
            'modified_by' => true,
            'user' => true,
            'manager' => true,
            'designation' => true,
            'deptartment' => true,
            'full_name'=>true,
            'owner_company'=>true
    ];
    
    
    protected  function _getFullName(){
        $first_name=isset($this->_properties['first_name'])?$this->_properties['first_name'].' ':'';
        $middle_name=isset($this->_properties['first_name'])?$this->_properties['middle_name'].' ':'';
        $last_name=isset($this->_properties['first_name'])?$this->_properties['last_name'].' ':'';
        return $first_name.$middle_name.$last_name;
    }
    
}
