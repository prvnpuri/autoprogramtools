<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ReportErpDocument Entity
 *
 * @property int $id
 * @property string $filename
 * @property int $report_erp_issues_id
 * @property int $report_erp_activity_id
 *
 * @property \App\Model\Entity\ReportErpIssue $report_erp_issue
 * @property \App\Model\Entity\ReportErpActivity $report_erp_activity
 */
class ReportErpDocument extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'filename' => true,
        'report_erp_issues_id' => true,
        'report_erp_activity_id' => true,
        'report_erp_issue' => true,
        'report_erp_activity' => true
    ];
}
