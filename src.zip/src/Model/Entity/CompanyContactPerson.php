<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * CompanyContactPerson Entity
 *
 * @property int $id
 * @property int $company_master_id
 * @property string $prefix_name
 * @property string $first_name
 * @property string $middle_name
 * @property string $last_name
 * @property string $department
 * @property string $designation
 * @property string $function
 * @property string $email_id
 * @property string $phone
 * @property string $mobile
 * @property int $for_campaign
 * @property string $visiting_card
 * @property string $sign_file
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\CompanyMaster $company_master
 * @property \App\Model\Entity\Email $email
 */
class CompanyContactPerson extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'company_master_id' => true,
        'prefix_name' => true,
        'first_name' => true,
        'middle_name' => true,
        'last_name' => true,
        'department' => true,
        'designation' => true,
        'function' => true,
        'email_id' => true,
        'phone' => true,
        'mobile' => true,
        'for_campaign' => true,
        'visiting_card' => true,
        'sign_file' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'company_master' => true,
        'email' => true
    ];
}
