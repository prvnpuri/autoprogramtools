<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MarketingCampaign Entity
 *
 * @property int $id
 * @property int $industry_master_id
 * @property int $owner_company_id
 * @property int $campaign_id
 * @property string $campaign_name
 * @property \Cake\I18n\FrozenDate $campaign_date
 * @property string $campaign_purpose
 * @property string $email_status
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property string $country
 *
 * @property \App\Model\Entity\IndustryMaster $industry_master
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\Campaign $campaign
 * @property \App\Model\Entity\MarketingCampaignCompany[] $marketing_campaign_company
 * @property \App\Model\Entity\MarketingCampaignProduct[] $marketing_campaign_products
 */
class MarketingCampaign extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'industry_master_id' => true,
        'owner_company_id' => true,
        'campaign_id' => true,
        'campaign_name' => true,
        'campaign_date' => true,
        'campaign_purpose' => true,
        'email_status' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'country' => true,
        'industry_master' => true,
        'owner_company' => true,
        'campaign' => true,
        'marketing_campaign_company' => true,
        'marketing_campaign_products' => true
    ];
}
