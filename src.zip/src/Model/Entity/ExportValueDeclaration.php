<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ExportValueDeclaration Entity
 *
 * @property int $id
 * @property int $invoice_id
 * @property int $oa_id
 * @property string $shipping_bill_no
 * @property \Cake\I18n\FrozenDate $shipping_bill_date
 * @property string $sale
 * @property string $sample
 * @property string $sale_on_consignment
 * @property string $gift
 * @property string $other
 * @property string $rule_3
 * @property string $rule_4
 * @property string $rule_5
 * @property string $rule_6
 * @property string $wether_yes
 * @property string $wether_no
 * @property string $price_yes
 * @property string $price_no
 * @property string $previous_export_bill_no
 * @property \Cake\I18n\FrozenDate $previous_export_bill_date
 * @property string $place
 * @property \Cake\I18n\FrozenDate $date
 * @property string $other_reivent_info
 * @property string $ready_to_print
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\Oa $oa
 */
class ExportValueDeclaration extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_id' => true,
        'oa_id' => true,
        'shipping_bill_no' => true,
        'shipping_bill_date' => true,
        'sale' => true,
        'sample' => true,
        'sale_on_consignment' => true,
        'gift' => true,
        'other' => true,
        'rule_3' => true,
        'rule_4' => true,
        'rule_5' => true,
        'rule_6' => true,
        'wether_yes' => true,
        'wether_no' => true,
        'price_yes' => true,
        'price_no' => true,
        'previous_export_bill_no' => true,
        'previous_export_bill_date' => true,
        'place' => true,
        'date' => true,
        'other_reivent_info' => true,
        'ready_to_print' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'invoice' => true,
        'oa' => true
    ];
}
