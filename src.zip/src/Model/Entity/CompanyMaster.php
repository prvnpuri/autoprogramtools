<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * CompanyMaster Entity
 *
 * @property int $id
 * @property string $Company_name
 * @property int $company_types_master_id
 * @property string $company_information
 * @property string $website_address
 * @property string $Address
 * @property string $pin_code
 * @property int $city
 * @property int $state
 * @property int $country
 * @property string $port_of_discharge_air
 * @property string $port_of_discharge_sea
 * @property string $gstin
 * @property string $pan_number
 * @property string $vat
 * @property string $cst
 * @property string $duns
 * @property int $iso
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\CompanyTypesMaster $company_types_master
 * @property \App\Model\Entity\CompanyBankMaster[] $company_bank_master
 * @property \App\Model\Entity\CompanyContactPerson[] $company_contact_persons
 * @property \App\Model\Entity\CompanyIndustryType[] $company_industry_types
 * @property \App\Model\Entity\CompanySublocation[] $company_sublocation
 * @property \App\Model\Entity\Inquiry[] $inquiry
 * @property \App\Model\Entity\MarketingCampaignCompany[] $marketing_campaign_company
 * @property \App\Model\Entity\SupplierEvaluationRegistrationTable[] $supplier_evaluation_registration_table
 */
class CompanyMaster extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'Company_name' => true,
        'company_types_master_id' => true,
        'company_information' => true,
        'website_address' => true,
        'Address' => true,
        'pin_code' => true,
        'city' => true,
        'state' => true,
        'country' => true,
        'port_of_discharge_air' => true,
        'port_of_discharge_sea' => true,
        'gstin' => true,
        'pan_number' => true,
        'vat' => true,
        'cst' => true,
        'duns' => true,
        'iso' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'company_types_master' => true,
        'company_bank_master' => true,
        'company_contact_persons' => true,
        'company_industry_types' => true,
    	'industry_type_master_id'=>true,
        'company_sublocation' => true,
        'inquiry' => true,
        'marketing_campaign_company' => true,
        'supplier_evaluation_registration_table' => true
    ];
}
