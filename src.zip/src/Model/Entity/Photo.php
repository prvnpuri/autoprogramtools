<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Photo Entity
 *
 * @property int $id
 * @property string $image
 * @property int $uploaded_by
 * @property \Cake\I18n\FrozenTime $uploaded_date
 * @property string $edited_by
 * @property \Cake\I18n\FrozenTime $edited_date
 * @property int $owner_company_id
 * @property string $image_title
 * @property string $description
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\Lrcopy[] $lrcopy
 */
class Photo extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'image' => true,
        'uploaded_by' => true,
        'uploaded_date' => true,
        'edited_by' => true,
        'edited_date' => true,
        'owner_company_id' => true,
        'image_title' => true,
        'description' => true,
        'owner_company' => true,
        'lrcopy' => true
    ];
}
