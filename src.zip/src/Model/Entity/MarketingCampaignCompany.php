<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MarketingCampaignCompany Entity
 *
 * @property int $id
 * @property string $company_master_id
 * @property bool $email_status
 * @property int $marketing_campaign_id
 * @property bool $existing_customer
 * @property \Cake\I18n\FrozenTime $email_date
 * @property string $contact_person_ids
 *
 * @property \App\Model\Entity\CompanyMaster $company_master
 * @property \App\Model\Entity\MarketingCampaign $marketing_campaign
 */
class MarketingCampaignCompany extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'company_master_id' => true,
        'email_status' => true,
        'marketing_campaign_id' => true,
        'existing_customer' => true,
        'email_date' => true,
        'contact_person_ids' => true,
        'company_master' => true,
        'marketing_campaign' => true
    ];
}
