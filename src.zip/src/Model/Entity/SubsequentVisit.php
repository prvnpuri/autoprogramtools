<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * SubsequentVisit Entity
 *
 * @property int $id
 * @property int $attendee_id
 * @property string $our_attendee
 * @property \Cake\I18n\FrozenDate $meeting_date
 * @property int $owner_company_id
 * @property string $product_discussion
 * @property string $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modified
 * @property string $reference_number
 *
 * @property \App\Model\Entity\Attendee $attendee
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\ProductInterested[] $product_interested
 * @property \App\Model\Entity\VisitCustomerRepresentative[] $visit_customer_representatives
 * @property \App\Model\Entity\VisitStatusUpdate[] $visit_status_updates
 */
class SubsequentVisit extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'attendee_id' => true,
        'our_attendee' => true,
        'meeting_date' => true,
        'owner_company_id' => true,
        'product_discussion' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modified' => true,
        'reference_number' => true,
        'attendee' => true,
        'owner_company' => true,
        'product_interested' => true,
        'visit_customer_representatives' => true,
        'visit_status_updates' => true
    ];
}
