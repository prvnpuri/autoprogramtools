<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * CommercialStateInfo Entity
 *
 * @property int $id
 * @property int $state_id
 * @property string $state_initials
 * @property string $state_code
 * @property string $state_type
 *
 * @property \App\Model\Entity\State $state
 */
class CommercialStateInfo extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'state_id' => true,
        'state_initials' => true,
        'state_code' => true,
        'state_type' => true,
        'state' => true
    ];
}
