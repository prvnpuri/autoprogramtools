<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * AssetMaintenanceSchedule Entity
 *
 * @property int $id
 * @property int $owner_company_assets_id
 * @property int $maintenance_agency
 * @property string $maintenance_schedule_frequency
 * @property \Cake\I18n\FrozenDate $maintenance_start_date
 * @property int $calibration_agency
 * @property string $calibration_schedule_frequency
 * @property \Cake\I18n\FrozenDate $calibration_start_date
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\OwnerCompanyAsset $owner_company_asset
 * @property \App\Model\Entity\AssetMaintenanceRecord[] $asset_maintenance_records
 */
class AssetMaintenanceSchedule extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'owner_company_assets_id' => true,
        'maintenance_agency' => true,
        'maintenance_schedule_frequency' => true,
        'maintenance_start_date' => true,
        'calibration_agency' => true,
        'calibration_schedule_frequency' => true,
        'calibration_start_date' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'owner_company_asset' => true,
        'asset_maintenance_records' => true
    ];
}
