<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PostsipmentDocument Entity
 *
 * @property int $id
 * @property int $invoice_id
 * @property int $owner_company_id
 * @property string $bill_of_landing_no
 * @property \Cake\I18n\FrozenDate $bill_of_lading_date
 * @property string $bill_of_lading_ocean_vessel
 * @property string $bill_of_lading_voyage_number
 * @property int $bill_of_lading_port_of_loading
 * @property int $bill_of_lading_port_of_discharge
 * @property string $bill_of_lading_container_no
 * @property string $bill_of_lading_seal_no
 * @property int $bill_of_lading_quantity
 * @property int $lr_no
 * @property string $lr_vehicle_number
 * @property int $lr_transporter_id
 * @property int $international_transporter_company_id
 * @property string $international_transporter_from_locaton
 * @property string $international_transporter_to_location
 * @property string $international_transporter_bill_no
 * @property \Cake\I18n\FrozenDate $international_transporter_bill_date
 * @property float $international_transporter_frieght_amt
 * @property float $international_transporter_thc_amt
 * @property float $international_transporter_total_amt
 * @property \Cake\I18n\FrozenDate $shipment_advice_date_port_of_loading
 * @property \Cake\I18n\FrozenDate $shipment_advice_date_port_of_discharge
 * @property int $insurance_policy_policy_no
 * @property string $insurance_policy_code
 * @property int $insurance_policy_collection_no
 * @property \Cake\I18n\FrozenDate $insurance_policy_collection_date
 * @property string $insurance_policy_voyage
 * @property string $insurance_policy_mode_of_transport
 * @property \Cake\I18n\FrozenDate $insurance_policy_date
 * @property string $insurance_policy_commodity
 * @property string $insurance_policy_sum_insured
 * @property float $insurance_policy_rate
 * @property float $insurance_policy_marine_premium
 * @property string $insurance_policy_place
 * @property float $insurance_policy_total_amount
 * @property string $shipping_bill_leo_no
 * @property string $shipping_bill_sb_no
 * @property \Cake\I18n\FrozenDate $shipping_bill_brc_realisation_date
 * @property string $shipping_bill_cha
 * @property string $shipping_bill_port_of_ldg_code
 * @property float $shipping_bill_amount_qty
 * @property float $shipping_bill_duty_drawback_amount
 * @property float $shipping_bill_total
 * @property int $bank_realisation_firm_id
 * @property string $bank_realisation_iec
 * @property string $bank_realisation_shipping_bill_no
 * @property \Cake\I18n\FrozenDate $bank_realisation_shipping_bill_date
 * @property int $bank_realisation_bank_id
 * @property string $bank_realisation_bank_file_no
 * @property string $bank_realisation_bill_id_no
 * @property string $bank_realisation_certificate_no
 * @property \Cake\I18n\FrozenDate $date_of_realisation_of_money_by_bank
 * @property int $realised_value_in_foreign_currency
 * @property int $currency_of_realisation
 * @property \Cake\I18n\FrozenDate $bank_realisation_printing_date
 * @property string $bank_realisation_printing_time
 * @property string $remitance_sr_no
 * @property \Cake\I18n\FrozenDate $remitance_date
 * @property string $remitance_inward_ref_no
 * @property string $remitance_credit_to_account_no
 * @property string $remitance_branch
 * @property string $remitance_remark
 * @property string $remitance_remitter
 * @property int $remitance_bank_id
 * @property string $remitance_ref_no
 * @property int $remitance_currency_id
 * @property float $remitance_amount
 * @property string $remitance_favouring_company
 * @property float $remitance_exchange_rate
 * @property bool $is_local
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\LrTransporter $lr_transporter
 * @property \App\Model\Entity\InternationalTransporterCompany $international_transporter_company
 */
class PostsipmentDocument extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_id' => true,
        'owner_company_id' => true,
        'bill_of_landing_no' => true,
        'bill_of_lading_date' => true,
        'bill_of_lading_ocean_vessel' => true,
        'bill_of_lading_voyage_number' => true,
        'bill_of_lading_port_of_loading' => true,
        'bill_of_lading_port_of_discharge' => true,
        'bill_of_lading_container_no' => true,
        'bill_of_lading_seal_no' => true,
        'bill_of_lading_quantity' => true,
        'lr_no' => true,
        'lr_vehicle_number' => true,
        'lr_transporter_id' => true,
        'international_transporter_company_id' => true,
        'international_transporter_from_locaton' => true,
    	'international_transporter_to_location'=>true,	
    	'international_transporter_quantity'=> true,
    	'international_transporter_product_id' =>true,	
        'international_transporter_to_location' => true,
        'international_transporter_bill_no' => true,
        'international_transporter_bill_date' => true,
        'international_transporter_frieght_amt' => true,
        'international_transporter_thc_amt' => true,
        'international_transporter_total_amt' => true,
        'shipment_advice_date_port_of_loading' => true,
        'shipment_advice_date_port_of_discharge' => true,
        'insurance_policy_policy_no' => true,
        'insurance_policy_code' => true,
        'insurance_policy_collection_no' => true,
        'insurance_policy_collection_date' => true,
        'insurance_policy_voyage' => true,
        'insurance_policy_mode_of_transport' => true,
        'insurance_policy_date' => true,
        'insurance_policy_commodity' => true,
        'insurance_policy_sum_insured' => true,
        'insurance_policy_rate' => true,
        'insurance_policy_marine_premium' => true,
        'insurance_policy_place' => true,
        'insurance_policy_total_amount' => true,
        'shipping_bill_leo_no' => true,
        'shipping_bill_sb_no' => true,
        'shipping_bill_brc_realisation_date' => true,
        'shipping_bill_cha' => true,
        'shipping_bill_port_of_ldg_code' => true,
        'shipping_bill_amount_qty' => true,
        'shipping_bill_duty_drawback_amount' => true,
        'shipping_bill_total' => true,
        'bank_realisation_firm_id' => true,
        'bank_realisation_iec' => true,
        'bank_realisation_shipping_bill_no' => true,
        'bank_realisation_shipping_bill_date' => true,
        'bank_realisation_bank_id' => true,
        'bank_realisation_bank_file_no' => true,
        'bank_realisation_bill_id_no' => true,
        'bank_realisation_certificate_no' => true,
        'date_of_realisation_of_money_by_bank' => true,
        'realised_value_in_foreign_currency' => true,
        'currency_of_realisation' => true,
        'bank_realisation_printing_date' => true,
        'bank_realisation_printing_time' => true,
        'remitance_sr_no' => true,
        'remitance_date' => true,
        'remitance_inward_ref_no' => true,
        'remitance_credit_to_account_no' => true,
        'remitance_branch' => true,
        'remitance_remark' => true,
        'remitance_remitter' => true,
        'remitance_bank_id' => true,
        'remitance_ref_no' => true,
        'remitance_currency_id' => true,
        'remitance_amount' => true,
        'remitance_favouring_company' => true,
        'remitance_exchange_rate' => true,
        'is_local' => true,
        'created_by' => true,
        'created' => true,
        'modified_by' => true,
        'modified' => true,
        'invoice' => true,
        'owner_company' => true,
        'international_transporter_company' => true
    ];
}
