<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PreShipmentBase Entity
 *
 * @property int $id
 * @property int $invoice_id
 * @property int $owner_company_id
 * @property int $owner_company_office_id
 * @property int $consignee_id
 * @property int $notify_id
 * @property int $buyer_id
 * @property int $product_id
 * @property int $uom_id
 * @property int $currency_id
 * @property int $inco_term
 * @property int $oa_id
 * @property int $order_id
 * @property bool $preshipment_type
 * @property string $preshipment_done
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\OwnerCompanyOffice $owner_company_office
 * @property \App\Model\Entity\Consignee $consignee
 * @property \App\Model\Entity\Notify $notify
 * @property \App\Model\Entity\Buyer $buyer
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\Currency $currency
 * @property \App\Model\Entity\Oa $oa
 * @property \App\Model\Entity\Order $order
 */
class PreShipmentBase extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_id' => true,
        'owner_company_id' => true,
        'owner_company_office_id' => true,
        'consignee_id' => true,
        'notify_id' => true,
        'buyer_id' => true,
        'product_id' => true,
        'uom_id' => true,
        'currency_id' => true,
        'inco_term' => true,
        'oa_id' => true,
        'order_id' => true,
        'preshipment_type' => true,
        'preshipment_done' => true,
        'invoice' => true,
        'owner_company' => true,
        'owner_company_office' => true,
        'consignee' => true,
        'notify' => true,
        'buyer' => true,
        'product' => true,
        'uom' => true,
        'currency' => true,
        'oa' => true,
        'order' => true
    ];
}
