<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ProformaInvoice Entity
 *
 * @property int $id
 * @property int $order_id
 * @property int $oa_id
 * @property int $invoice_no
 * @property \Cake\I18n\FrozenDate $invoice_date
 * @property string $transport_mode
 * @property string $vehicle_no
 * @property bool $is_reverse_charge
 * @property \Cake\I18n\FrozenDate $date_of_supply
 * @property int $state_id
 * @property string $place_of_supply
 * @property float $discount
 * @property int $taxable_value
 * @property float $cgst_rate
 * @property float $cgst_amount
 * @property float $sgst_rate
 * @property float $sgst_amount
 * @property float $total_amount
 * @property float $gst_on_reverse
 * @property int $bank_id
 * @property float $igst_rate
 * @property float $igst_amount
 * @property bool $is_local
 * @property bool $mail_sent
 * @property bool $is_localstate
 * @property int $date_of_creation
 * @property int $date_of_modification
 * @property int $created_by
 * @property int $modified_by
 *
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Oa $oa
 * @property \App\Model\Entity\State $state
 * @property \App\Model\Entity\Bank $bank
 */
class ProformaInvoice extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'order_id' => true,
        'oa_id' => true,
        'invoice_no' => true,
        'invoice_date' => true,
        'transport_mode' => true,
        'vehicle_no' => true,
        'is_reverse_charge' => true,
        'date_of_supply' => true,
        'state_id' => true,
        'place_of_supply' => true,
        'discount' => true,
        'taxable_value' => true,
        'cgst_rate' => true,
        'cgst_amount' => true,
        'sgst_rate' => true,
        'sgst_amount' => true,
        'total_amount' => true,
        'gst_on_reverse' => true,
        'bank_id' => true,
        'igst_rate' => true,
        'igst_amount' => true,
        'is_local' => true,
        'mail_sent' => true,
        'is_localstate' => true,
        'date_of_creation' => true,
        'date_of_modification' => true,
        'created_by' => true,
        'modified_by' => true,
        'order' => true,
        'oa' => true,
        'state' => true,
        'bank' => true
    ];
}
