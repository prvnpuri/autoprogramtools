<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * BoldNumber Entity
 *
 * @property int $id
 * @property int $supplier
 * @property string $po_number
 * @property int $cust_name
 * @property string $invoice_no
 * @property \Cake\I18n\FrozenDate $dispatch_date
 * @property string $product
 * @property int $quantity
 * @property string $uom
 * @property string $packing
 * @property string $batch
 * @property string $bold_number
 * @property string $unique_sr
 */
class BoldNumber extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'supplier' => true,
        'po_number' => true,
        'cust_name' => true,
        'invoice_no' => true,
        'dispatch_date' => true,
        'product' => true,
        'quantity' => true,
        'uom' => true,
        'packing' => true,
        'batch' => true,
        'bold_number' => true,
        'unique_sr' => true
    ];
}
