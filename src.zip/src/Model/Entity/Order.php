<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Order Entity
 *
 * @property int $id
 * @property int $offer_id
 * @property string $ref_number
 * @property \Cake\I18n\FrozenDate $order_date
 * @property int $buyer_company
 * @property int $supplier_company
 * @property string $buyer_address
 * @property string $supplier_vendor_code
 * @property int $owner_companies_id
 * @property int $products_master_id
 * @property string $product_specifications
 * @property string $buyer_item_number
 * @property string $buyer_specification_code
 * @property string $product_code
 * @property float $quantity_ordered
 * @property float $rate
 * @property float $total_order_price
 * @property int $uom_id
 * @property int $currency_id
 * @property int $packing_required
 * @property \Cake\I18n\FrozenDate $offer_validity
 * @property int $port_of_discharge_id
 * @property int $country_of_origin_of_goods
 * @property int $country_final_destination
 * @property int $inco_terms_id
 * @property int $status
 * @property int $payment_status
 * @property int $buyerpo_status
 * @property int $so_status
 * @property int $outward_status
 * @property string $review_status
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property int $modified_by
 * @property string $reference_number
 * @property string $order_file
 * @property string $order_no
 * @property string $purchase_group
 * @property string $packing_charges
 * @property string $excise_duty
 * @property string $sales_tax
 * @property bool $batch_sample_required
 * @property string $shipping_terms
 * @property string $shipping_conditions
 * @property \Cake\I18n\FrozenDate $shipping_document_date
 * @property string $final_destination
 * @property int $consignee
 * @property string $consignee_address
 * @property string $notify_party_address
 * @property int $is_local
 * @property \Cake\I18n\FrozenDate $expected_delivery_dt
 * @property string $delivery_conditions
 * @property int $packing_terms
 * @property \Cake\I18n\FrozenDate $validity_of_order
 * @property string $company_contact_persons
 * @property string $supplier_contact_persons
 * @property string $cc_email
 * @property string $comments
 * @property string $notify_contact_persons
 * @property string $ship_contact_persons
 * @property int $buyer_office
 * @property int $supplier_office
 * @property int $notify_office
 * @property int $ship_office
 * @property string $supplier_address
 * @property int $order_type
 * @property string $consignee_point_delivery
 *
 * @property \App\Model\Entity\NotifyTo[] $notify_to
 * @property \App\Model\Entity\Offer $offer
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\ProductsMaster $products_master
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\Currency $currency
 * @property \App\Model\Entity\PortOfDischarge $port_of_discharge
 * @property \App\Model\Entity\IncoTerm $inco_term
 * @property \App\Model\Entity\AdditionalBuyerSpecification[] $additional_buyer_specification
 * @property \App\Model\Entity\BuyerPurchaseOrder[] $buyer_purchase_order
 * @property \App\Model\Entity\CertificateOfAnalysis[] $certificate_of_analyses
 * @property \App\Model\Entity\DemandQueue[] $demand_queue
 * @property \App\Model\Entity\ExciseTaxInvoice[] $excise_tax_invoice
 * @property \App\Model\Entity\InvoiceProduct[] $invoice_products
 * @property \App\Model\Entity\InvoiceTo[] $invoice_to
 * @property \App\Model\Entity\LrcopyPhoto[] $lrcopy_photo
 * @property \App\Model\Entity\OrderAcceptance[] $order_acceptance
 * @property \App\Model\Entity\OrderReview[] $order_reviews
 * @property \App\Model\Entity\Outward[] $outward
 * @property \App\Model\Entity\PaymentsReceived[] $payments_received
 * @property \App\Model\Entity\PreShipmentBase[] $pre_shipment_base
 * @property \App\Model\Entity\PreShipmentPacking[] $pre_shipment_packing
 * @property \App\Model\Entity\PreshipmentTsca[] $preshipment_tsca
 * @property \App\Model\Entity\ProformaInvoice[] $proforma_invoice
 * @property \App\Model\Entity\ShipTo[] $ship_to
 * @property \App\Model\Entity\ShippingDocumentsPhysical[] $shipping_documents_physical
 */
class Order extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'offer_id' => true,
        'ref_number' => true,
        'order_date' => true,
        'buyer_company' => true,
        'supplier_company' => true,
        'buyer_address' => true,
        'supplier_vendor_code' => true,
        'owner_companies_id' => true,
        'products_master_id' => true,
        'product_specifications' => true,
        'buyer_item_number' => true,
        'buyer_specification_code' => true,
        'product_code' => true,
        'quantity_ordered' => true,
        'rate' => true,
        'total_order_price' => true,
        'uom_id' => true,
        'currency_id' => true,
        'packing_required' => true,
        'offer_validity' => true,
        'port_of_discharge_id' => true,
        'country_of_origin_of_goods' => true,
        'country_final_destination' => true,
        'inco_terms_id' => true,
        'status' => true,
        'payment_status' => true,
        'buyerpo_status' => true,
        'so_status' => true,
        'outward_status' => true,
        'review_status' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'reference_number' => true,
        'order_file' => true,
        'order_no' => true,
        'purchase_group' => true,
        'packing_charges' => true,
        'excise_duty' => true,
        'sales_tax' => true,
        'batch_sample_required' => true,
        'shipping_terms' => true,
        'shipping_conditions' => true,
        'shipping_document_date' => true,
        'final_destination' => true,
        'consignee' => true,
        'consignee_address' => true,
        'notify_to' => true,
        'notify_party_address' => true,
        'is_local' => true,
        'expected_delivery_dt' => true,
        'delivery_conditions' => true,
        'packing_terms' => true,
        'validity_of_order' => true,
        'company_contact_persons' => true,
        'supplier_contact_persons' => true,
        'cc_email' => true,
        'comments' => true,
        'notify_contact_persons' => true,
        'ship_contact_persons' => true,
        'buyer_office' => true,
        'supplier_office' => true,
        'notify_office' => true,
        'ship_office' => true,
        'supplier_address' => true,
        'order_type' => true,
        'consignee_point_delivery' => true,
        'offer' => true,
        'owner_company' => true,
        'products_master' => true,
        'uom' => true,
        'currency' => true,
        'port_of_discharge' => true,
        'inco_term' => true,
        'additional_buyer_specification' => true,
        'buyer_purchase_order' => true,
        'certificate_of_analyses' => true,
        'demand_queue' => true,
        'excise_tax_invoice' => true,
        'invoice_products' => true,
        'invoice_to' => true,
        'lrcopy_photo' => true,
        'order_acceptance' => true,
        'order_reviews' => true,
        'outward' => true,
        'payments_received' => true,
        'pre_shipment_base' => true,
        'pre_shipment_packing' => true,
        'preshipment_tsca' => true,
        'proforma_invoice' => true,
    	'ship_to' => true,
        'shipping_documents_physical' => true,
    	'countries_id' => true,
    	'payment_terms'=>true,
    	'send_to_oa'=>true,
    	'mother_order_id'=>true,
    	'balance_qty'=>true,
    	'is_multiorder'=>true,
    	'quantity_despatch'=>true,
    	'mother_order_callof_order'=>true,
    	'delivery_terms' => true,
    ];
}
