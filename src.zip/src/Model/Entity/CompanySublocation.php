<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * CompanySublocation Entity
 *
 * @property int $id
 * @property int $company_master_id
 * @property string $sublocation_name
 * @property int $location_type
 * @property string $office_address_name
 * @property string $Address
 * @property string $postal_code
 * @property int $city
 * @property int $state
 * @property int $country
 * @property string $port_of_discharge_air
 * @property string $port_of_discharge_sea
 * @property string $gstin
 * @property string $vat
 * @property string $cst
 * @property string $duns
 * @property int $iso
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 * @property string $range_address
 * @property string $division_address
 *
 * @property \App\Model\Entity\CompanyMaster $company_master
 */
class CompanySublocation extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'company_master_id' => true,
        'sublocation_name' => true,
        'location_type' => true,
    	'office_address_name' => true,
        'Address' => true,
        'postal_code' => true,
        'city' => true,
        'state' => true,
        'country' => true,
        'port_of_discharge_air' => true,
        'port_of_discharge_sea' => true,
        'gstin' => true,
        'vat' => true,
        'cst' => true,
        'duns' => true,
        'iso' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'range_address' => true,
        'division_address' => true,
        'company_master' => true
    ];
}
