<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * BatchsheetBom Entity
 *
 * @property int $id
 * @property int $batchsheet_tran_id
 * @property int $reference_bom_id
 * @property string $actual_purity
 * @property float $total_actual_weight
 * @property int $uom_id
 *
 * @property \App\Model\Entity\BatchsheetTran $batchsheet_tran
 * @property \App\Model\Entity\ReferenceBom $reference_bom
 * @property \App\Model\Entity\Uom $uom
 */
class BatchsheetBom extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'batchsheet_tran_id' => true,
        'reference_bom_id' => true,
        'actual_purity' => true,
        'total_actual_weight' => true,
        'uom_id' => true,
        'batchsheet_tran' => true,
        'reference_bom' => true,
        'uom' => true
    ];
}
