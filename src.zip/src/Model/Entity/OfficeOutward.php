<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OfficeOutward Entity
 *
 * @property int $id
 * @property \Cake\I18n\FrozenDate $outward_date
 * @property int $sender
 * @property string $through
 * @property string $docket_no
 * @property string $sent_for
 * @property int $sent_to_company
 * @property string $contact_name
 * @property string $country
 * @property string $state
 * @property string $city
 * @property string $description
 * @property int $owner_company_id
 * @property int $s_no
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property string $reference_number
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 */
class OfficeOutward extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'outward_date' => true,
        'sender' => true,
        'through' => true,
        'docket_no' => true,
        'sent_for' => true,
        'sent_to_company' => true,
        'contact_name' => true,
        'country' => true,
        'state' => true,
        'city' => true,
        'description' => true,
        'owner_company_id' => true,
        's_no' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'reference_number' => true,
        'owner_company' => true
    ];
}
