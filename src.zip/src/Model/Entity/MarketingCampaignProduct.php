<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MarketingCampaignProduct Entity
 *
 * @property int $id
 * @property int $product_id
 * @property string $uom
 * @property string $moq
 * @property int $marketing_campaign_id
 * @property int $is_msds
 * @property int $is_tech_ds
 *
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\MarketingCampaign $marketing_campaign
 */
class MarketingCampaignProduct extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'product_id' => true,
        'uom' => true,
        'moq' => true,
        'marketing_campaign_id' => true,
        'is_msds' => true,
        'is_tech_ds' => true,
        'product' => true,
        'marketing_campaign' => true
    ];
}
