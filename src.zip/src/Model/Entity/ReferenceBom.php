<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ReferenceBom Entity
 *
 * @property int $id
 * @property int $products_master_id
 * @property int $material_id
 * @property string $purity
 * @property float $weight
 * @property int $uom
 *
 * @property \App\Model\Entity\ProductsMaster $products_master
 * @property \App\Model\Entity\Material $material
 * @property \App\Model\Entity\BatchsheetBom[] $batchsheet_bom
 */
class ReferenceBom extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'sr_no' => true,
    	'batchsheet_master_id' => true,
        'material_id' => true,
    	'material_type' => true,
        'purity' => true,
        'weight' => true,
        'uom' => true,
        'products_master' => true,
        'batchsheet_bom' => true
    ];
}
