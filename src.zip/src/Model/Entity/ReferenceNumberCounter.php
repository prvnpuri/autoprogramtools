<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ReferenceNumberCounters Entity
 *
 * @property int $id
 * @property int $owner_companies_id
 * @property string $activity_name
 * @property string $year
 * @property int $reference_counter
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property \Cake\I18n\FrozenTime $date_of_modification
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 */
class ReferenceNumberCounter extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'owner_companies_id' => true,
        'activity_name' => true,
        'year' => true,
        'reference_counter' => true,
        'date_of_creation' => true,
        'date_of_modification' => true,
        'owner_company' => true
    ];
}
