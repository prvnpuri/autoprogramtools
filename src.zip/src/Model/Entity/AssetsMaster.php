<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * AssetsMaster Entity
 *
 * @property int $id
 * @property string $asset_type
 * @property string $asset_name
 * @property string $asset_purpose
 * @property string $capacity
 * @property int $uom
 * @property string $specification
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 *
 * @property \App\Model\Entity\OwnerCompanyAsset[] $owner_company_assets
 */
class AssetsMaster extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'asset_name' => true,
        'asset_type' => true,
        'asset_purpose' => true,
        'capacity' => true,
        'uom_id' => true,
        'specification' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'owner_company_assets' => true
    ];
}
