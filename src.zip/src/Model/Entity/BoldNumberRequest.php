<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * BoldNumberRequest Entity
 *
 * @property int $id
 * @property string $unique_series
 * @property string $batch_number
 * @property int $bold_number_from
 * @property int $bold_number_to
 * @property int $is_approved
 * @property int $vendor_id
 * @property string $grn_file_path
 * @property int $del_status
 * @property int $is_delivered
 * @property int $vendor_accepted
 * @property \Cake\I18n\FrozenDate $vendor_accepted_date
 * @property int $quality_accepted
 * @property \Cake\I18n\FrozenDate $quality_accepted_date
 * @property int $quality_accepted_by
 * @property int $quantity_reject
 * @property int $owner_company_id
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 * @property int $created_by
 * @property int $modified_by
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\BoldNumberInventory $bold_number_inventory
 */
class BoldNumberRequest extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'unique_series' => true,
        'batch_number' => true,
        'bold_number_from' => true,
        'bold_number_to' => true,
        'is_approved' => true,
        'vendor_id' => true,
        'grn_file_path' => true,
        'del_status' => true,
        'is_delivered' => true,
        'vendor_accepted' => true,
        'vendor_accepted_date' => true,
        'quality_accepted' => true,
        'quality_accepted_date' => true,
        'quality_accepted_by' => true,
        'quantity_reject' => true,
        'owner_company_id' => true,
        'created' => true,
        'modified' => true,
        'created_by' => true,
        'modified_by' => true,
        'owner_company' => true,
        'bold_number_inventory' => true
    ];
}
