<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * EmployeeAdvancePayment Entity
 *
 * @property int $id
 * @property int $employee_details_id
 * @property float $advance_amount
 * @property string $description
 * @property \Cake\I18n\FrozenDate $payment_date
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $created_by
 *
 * @property \App\Model\Entity\EmployeeDetail $employee_detail
 * @property \App\Model\Entity\EmployeeMonthlySalary[] $employee_monthly_salaries
 */
class EmployeeAdvancePayment extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'employee_details_id' => true,
        'advance_amount' => true,
        'description' => true,
        'payment_date' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'employee_detail' => true,
        'employee_monthly_salaries' => true
    ];
}
