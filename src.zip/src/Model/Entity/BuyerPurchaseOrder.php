<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * BuyerPurchaseOrder Entity
 *
 * @property int $id
 * @property int $order_id
 * @property string $buyer_po_number
 * @property string $reference_no
 * @property \Cake\I18n\FrozenDate $buyer_po_date
 * @property float $quantity_ordered
 * @property float $rate
 * @property string $packing_details
 * @property string $payment_terms
 * @property string $delivery_terms
 * @property string $lead_time
 * @property string $labelling_details
 * @property string $taxes_mentioned
 * @property string $penalty_clause
 * @property string $other_details
 * @property int $uom_id
 * @property int $currency_id
 * @property int $inco_terms_id
 * @property string $po_file
 * @property string $po_query
 * @property string $status
 * @property string $description_of_goods
 * @property float $total_order_price
 * @property float $cash_discount
 * @property float $excise_tax
 * @property float $sales_cst_tax
 * @property float $transporting_tax
 * @property float $insurance_tax
 * @property float $packing_forwarding_charge
 * @property float $other_charge
 * @property float $octroi_charge
 * @property float $vat_charge
 * @property float $service_tax
 * @property float $total_price
 * @property string $special_instruction
 * @property string $range
 * @property string $division
 * @property string $commissionerate
 * @property \Cake\I18n\FrozenDate $delivery_date
 * @property string $delivery_schcedule
 * @property string $deliver_address
 * @property string $buyer_transport
 * @property string $vat_tin_no
 * @property string $cst_tin_no
 * @property string $pan_no
 * @property string $ecc_no
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\Currency $currency
 * @property \App\Model\Entity\IncoTerm $inco_term
 * @property \App\Model\Entity\ExciseTaxInvoice[] $excise_tax_invoice
 * @property \App\Model\Entity\TaxInvoice[] $tax_invoice
 */
class BuyerPurchaseOrder extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'order_id' => true,
        'buyer_po_number' => true,
        'reference_no' => true,
        'buyer_po_date' => true,
        'quantity_ordered' => true,
        'rate' => true,
        'packing_details' => true,
        'payment_terms' => true,
        'delivery_terms' => true,
        'lead_time' => true,
        'labelling_details' => true,
        'taxes_mentioned' => true,
        'penalty_clause' => true,
        'other_details' => true,
        'uom_id' => true,
        'currency_id' => true,
        'inco_terms_id' => true,
        'po_file' => true,
        'po_query' => true,
        'status' => true,
        'description_of_goods' => true,
        'total_order_price' => true,
        'cash_discount' => true,
        'excise_tax' => true,
        'sales_cst_tax' => true,
        'transporting_tax' => true,
        'insurance_tax' => true,
        'packing_forwarding_charge' => true,
        'other_charge' => true,
        'octroi_charge' => true,
        'vat_charge' => true,
        'service_tax' => true,
        'total_price' => true,
        'special_instruction' => true,
        'range' => true,
        'division' => true,
        'commissionerate' => true,
        'delivery_date' => true,
        'delivery_schcedule' => true,
        'deliver_address' => true,
        'buyer_transport' => true,
        'vat_tin_no' => true,
        'cst_tin_no' => true,
        'pan_no' => true,
        'ecc_no' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'order' => true,
        'uom' => true,
        'currency' => true,
        'inco_term' => true,
        'excise_tax_invoice' => true,
        'tax_invoice' => true
    ];
}
