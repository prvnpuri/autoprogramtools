<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Brochure Entity
 *
 * @property int $id
 * @property int $brochure_type
 * @property int $brochure_reference
 * @property string $description
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 * @property string $filename
 *
 * @property \App\Model\Entity\BrochureFile[] $brochure_file
 */
class Brochure extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'brochure_type' => true,
        'brochure_reference' => true,
        'description' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'filename' => true,
        'brochure_file' => true
    ];
}
