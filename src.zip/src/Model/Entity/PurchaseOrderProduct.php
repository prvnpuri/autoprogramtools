<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PurchaseOrderProduct Entity
 *
 * @property int $id
 * @property int $purchase_order_id
 * @property int $product_id
 * @property float $qty
 * @property int $uom_id
 * @property int $packingMaster_id
 * @property float $price
 * @property int $currency_id
 * @property float $total_order_value
 *
 * @property \App\Model\Entity\PurchaseOrder $purchase_order
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\PackingMaster $packing_master
 * @property \App\Model\Entity\Currency $currency
 */
class PurchaseOrderProduct extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'purchase_order_id' => true,
        'product_id' => true,
        'qty' => true,
        'uom_id' => true,
        'packingMaster_id' => true,
        'price' => true,
        'currency_id' => true,
        'total_order_value' => true,
        'purchase_order' => true,
        'product' => true,
        'uom' => true,
        'packing_master' => true,
        'currency' => true
    ];
}
