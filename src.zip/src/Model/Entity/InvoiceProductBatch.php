<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * InvoiceProductBatch Entity
 *
 * @property int $id
 * @property int $invoice_products_id
 * @property string $batch_number
 * @property float $batch_size
 * @property int $batch_size_uom
 * @property string $no_of_bags
 * @property string $sample_bag_nos
 * @property \Cake\I18n\FrozenDate $expiry_date
 * @property \Cake\I18n\FrozenDate $manufacturing_date
 *
 * @property \App\Model\Entity\InvoiceProduct $invoice_product
 */
class InvoiceProductBatch extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
    	'invoice_id'=>true,	
        'invoice_products_id' => true,
        'batch_number' => true,
        'batch_size' => true,
        'batch_size_uom' => true,
        'no_of_bags' => true,
        'sample_bag_nos' => true,
        'expiry_date' => true,
        'manufacturing_date' => true,
        'invoice_products' => true
    ];
}
