<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * EmployeeLeave Entity
 *
 * @property int $id
 * @property int $emp_id
 * @property int $leave_type_id
 * @property int $total_eligibility
 * @property int $till_date_eligibility
 * @property int $leave_taken
 *
 * @property \App\Model\Entity\Emp $emp
 * @property \App\Model\Entity\LeaveType $leave_type
 */
class EmployeeLeave extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'emp_id' => true,
        'leave_type_id' => true,
        'total_eligibility' => true,
        'till_date_eligibility' => true,
        'leave_taken' => true,
        'emp' => true,
        'leave_type' => true
    ];
}
