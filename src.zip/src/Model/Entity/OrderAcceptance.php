<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OrderAcceptance Entity
 *
 * @property int $id
 * @property int $order_id
 * @property string $oa_reference_number
 * @property \Cake\I18n\FrozenDate $oa_date
 * @property string $remarks
 *
 * @property \App\Model\Entity\Order $order
 */
class OrderAcceptance extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'order_id' => true,
        'reference_number' => true,
        'oa_date' => true,
    	'eta_date' => true,
    	'marks_and_numbers' => true,
    	'number_and_kind_of_packages' => true,
    	'send_to_doc' => true,
        'remarks' => true,
        'order' => true,
    	'supplier_contact_persons' => true,
    	'consignee_contact_persons' => true,
    	'total_value' => true,
    	'end_use' => true,
    	'status' => true,
    	'order_acceptance_no' => true,
    	'date' => true,
    	'date_of_creation' => true,
    	'created_by' => true,
    	'date_of_modification' => true,
    	'modified_by' => true,
    	'send_to_demandqueue'=>true
    ];
}
