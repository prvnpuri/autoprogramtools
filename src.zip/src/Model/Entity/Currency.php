<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Currency Entity
 *
 * @property int $id
 * @property string $name
 * @property string $mini_currency
 * @property string $iso_code
 * @property string $iso_code_num
 * @property string $sign
 * @property bool $blank
 * @property bool $format
 * @property bool $decimals
 * @property float $conversion_rate
 * @property bool $deleted
 * @property bool $active
 *
 * @property \App\Model\Entity\BuyerPurchaseOrder[] $buyer_purchase_order
 * @property \App\Model\Entity\CompanyBankMaster[] $company_bank_master
 * @property \App\Model\Entity\Inquiry[] $inquiry
 * @property \App\Model\Entity\Invoice[] $invoice
 * @property \App\Model\Entity\Lrcopy[] $lrcopy
 * @property \App\Model\Entity\Offer[] $offer
 * @property \App\Model\Entity\Order[] $order
 * @property \App\Model\Entity\OwnerBankMaster[] $owner_bank_master
 * @property \App\Model\Entity\PaymentDeposit[] $payment_deposits
 * @property \App\Model\Entity\PaymentsReceived[] $payments_received
 * @property \App\Model\Entity\PostshipmentRemittance[] $postshipment_remittance
 * @property \App\Model\Entity\PostshipmentTransporter[] $postshipment_transporter
 * @property \App\Model\Entity\PreShipmentBase[] $pre_shipment_base
 * @property \App\Model\Entity\PreShipmentInsurance[] $pre_shipment_insurance
 * @property \App\Model\Entity\PurchaseOrder[] $purchase_order
 * @property \App\Model\Entity\SupplierInquiry[] $supplier_inquiry
 * @property \App\Model\Entity\SupplierOffer[] $supplier_offer
 * @property \App\Model\Entity\Transporter[] $transporters
 */
class Currency extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'name' => true,
        'mini_currency' => true,
        'iso_code' => true,
        'iso_code_num' => true,
        'sign' => true,
        'blank' => true,
        'format' => true,
        'decimals' => true,
        'conversion_rate' => true,
        'deleted' => true,
        'active' => true,
        'buyer_purchase_order' => true,
        'company_bank_master' => true,
        'inquiry' => true,
        'invoices' => true,
        'lrcopy' => true,
        'offer' => true,
        'order' => true,
        'owner_bank_master' => true,
        'payment_deposits' => true,
        'payments_received' => true,
        'postshipment_remittance' => true,
        'postshipment_transporter' => true,
        'pre_shipment_base' => true,
        'pre_shipment_insurance' => true,
        'purchase_order' => true,
        'supplier_inquiry' => true,
        'supplier_offer' => true,
        'transporters' => true
    ];
}
