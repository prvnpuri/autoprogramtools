<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ShipTo Entity
 *
 * @property int $id
 * @property string $consignee_point_delivery
 * @property string $phone
 * @property string $address
 * @property string $email
 * @property int $order_id
 * @property int $company_id
 * @property string $company_contact_persons
 *
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Company $company
 */
class ShipTo extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'consignee_point_delivery' => true,
        'phone' => true,
        'address' => true,
        'email' => true,
        'order_id' => true,
        'company_id' => true,
        'company_contact_persons' => true,
        'order' => true,
        'company' => true
    ];
}
