<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OrderReview Entity
 *
 * @property int $id
 * @property int $offer_id
 * @property int $order_id
 * @property int $updated_payment_terms
 * @property string $payment_terms_remark
 * @property float $updated_rate
 * @property string $rate_remark
 * @property string $delivery_terms_remark
 * @property string $updated_lead_time
 * @property string $lead_time_remark
 * @property float $updated_qty
 * @property string $quantity_remark
 * @property string $update_packing_terms
 * @property string $packing_remark
 * @property string $updated_labelling
 * @property string $labelling_remark
 * @property string $taxes_mentioned_remark
 * @property string $updated_penalty_clause
 * @property string $penalty_clause_remark
 * @property string $remarks_for_client
 * @property string $other_details_remark
 * @property string $review_status
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\Offer $offer
 * @property \App\Model\Entity\Order $order
 */
class OrderReview extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'offer_id' => true,
        'order_id' => true,
        'updated_payment_terms' => true,
        'payment_terms_remark' => true,
        'updated_rate' => true,
        'rate_remark' => true,
        'delivery_terms_remark' => true,
        'updated_lead_time' => true,
        'lead_time_remark' => true,
        'updated_qty' => true,
        'quantity_remark' => true,
        'update_packing_terms' => true,
        'packing_remark' => true,
        'updated_labelling' => true,
        'labelling_remark' => true,
        'taxes_mentioned_remark' => true,
        'updated_penalty_clause' => true,
        'penalty_clause_remark' => true,
        'remarks_for_client' => true,
        'other_details_remark' => true,
        'review_status' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'offer' => true,
        'order' => true,
    	'date' => true,
    	'prepared_by' => true,
    	'reviewed_by' => true,
    	'iso_ref_no' => true,
    	'inquiry_no' => true,
    	'offer_no' => true,
    	'port_of_discharge_id' => true,
    	'batch_no' => true,
    	'transport_charges' => true,
    	'charges_label' => true,
    	'charges_value' => true,
    	'order_review_particular_master' => true,
    	'send_to_oa'=>true
    ];
}
