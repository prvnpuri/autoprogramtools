<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PostshipmentShippingBill Entity
 *
 * @property int $id
 * @property int $oa_id
 * @property string $leo_no
 * @property string $sb_no
 * @property \Cake\I18n\FrozenDate $brc_realisation_date
 * @property string $cha
 * @property string $port_of_ldg_code
 * @property string $state_of_origin
 * @property float $amount_qty
 * @property float $amount_rate
 * @property float $total
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property \Cake\I18n\FrozenDate $sb_date
 *
 * @property \App\Model\Entity\Oa $oa
 */
class PostshipmentShippingBill extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'oa_id' => true,
        'leo_no' => true,
        'sb_no' => true,
        'brc_realisation_date' => true,
        'cha' => true,
        'port_of_ldg_code' => true,
        'state_of_origin' => true,
        'amount_qty' => true,
        'amount_rate' => true,
        'total' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'sb_date' => true,
        'oa' => true
    ];
}
