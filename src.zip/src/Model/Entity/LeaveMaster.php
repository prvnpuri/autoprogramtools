<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * LeaveMaster Entity
 *
 * @property int $id
 * @property string $leave_type
 * @property int $default_eligibility
 * @property string $default_add
 * @property \Cake\I18n\FrozenDate $year_start
 * @property \Cake\I18n\FrozenDate $year_end
 * @property string $allowed_in_probation
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 */
class LeaveMaster extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'leave_type' => true,
        'default_eligibility' => true,
        'default_add' => true,
        'year_start' => true,
        'year_end' => true,
        'allowed_in_probation' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true
    ];
}
