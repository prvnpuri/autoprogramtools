<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * LedgerAccountDailyClBalance Entity
 *
 * @property int $id
 * @property int $ledger_accounts_id
 * @property \Cake\I18n\FrozenTime $date
 * @property string $side
 * @property float $amount
 * @property int $owner_companies_id
 * @property \App\Model\Entity\LedgerAccount $ledger_account
 * @property \App\Model\Entity\OwnerCompany $owner_company
 */
class LedgerAccountDailyClBalance extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'ledger_accounts_id' => true,
        'date' => true,
        'side' => true,
        'amount' => true,
        'ledger_account' => true,
        'owner_companies_id'=>true,
        'owner_company'=>true,
    ];
}
