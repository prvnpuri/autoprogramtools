<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * InvoiceShippingDocument Entity
 *
 * @property int $id
 * @property int $invoice_id
 * @property int $packing_list_gross_weight
 * @property string $non_haz_awb_no
 * @property \Cake\I18n\FrozenDate $non_haz_date
 * @property \Cake\I18n\FrozenDate $tsca_date
 * @property string $tsca_auth_sign
 * @property string $tsca_airway_bill
 * @property string $sdf_shipping_bill_no
 * @property string $val_decl_shipping_bill_no
 * @property string $val_decl_nature_of_transaction
 * @property string $val_decl_method_of_valuation
 * @property string $val_decl_wheater_related
 * @property string $val_decl_wheater_related_influence
 * @property string $val_decl_information
 * @property string $val_decl_place
 * @property \Cake\I18n\FrozenDate $val_decl_date
 * @property string $bill_of_landing_no
 * @property \Cake\I18n\FrozenDate $bill_of_lading_date
 * @property string $bill_of_lading_ocean_vessel
 * @property string $bill_of_lading_voyage_number
 * @property int $bill_of_lading_port_of_loading
 * @property int $bill_of_lading_port_of_discharge
 * @property string $bill_of_lading_container_no
 * @property string $bill_of_lading_seal_no
 * @property int $bill_of_lading_quantity
 * @property string $insurance_policy_no
 * @property string $insurance_name
 * @property string $insurance_code
 * @property int $lr_no
 * @property int $lr_vehicle_number
 * @property int $lr_transporter_id
 * @property int $international_transporter_company_id
 * @property string $international_transporter_from_locaton
 * @property string $international_transporter_to_location
 * @property string $international_transporter_bill_no
 * @property \Cake\I18n\FrozenDate $international_transporter_bill_date
 * @property float $international_transporter_frieght_amt
 * @property float $international_transporter_thc_amt
 * @property float $international_transporter_total_amt
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\LrTransporter $lr_transporter
 * @property \App\Model\Entity\InternationalTransporterCompany $international_transporter_company
 */
class InvoiceShippingDocument extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_id' => true,
        'packing_list_gross_weight' => true,
        'non_haz_awb_no' => true,
        'non_haz_date' => true,
    	'tsca_title'=>true,	
        'tsca_date' => true,
        'tsca_auth_sign' => true,
        'tsca_airway_bill' => true,
        'sdf_shipping_bill_no' => true,
        'val_decl_shipping_bill_no' => true,
        'val_decl_nature_of_transaction' => true,
    	'val_decl_previous_export_bill_date'=>true,
    	'val_decl_sale'=>true,
    	'val_decl_sample'=>true,
    	'val_decl_sale_on_consignment'=>true,
    	'val_decl_gift'=>true,
    	'val_decl_other'=>true,
    	'val_decl_rule_3'=>true,
    	'val_decl_rule_4'=>true,
    	'val_decl_rule_5'=>true,
    	'val_decl_rule_6'=>true,
    	'val_decl_wether_yes_no'=>true,
    	'val_decl_price_yes_no'=>true,
    	'val_decl_previous_export_bill_no'=>true,
    	'val_decl_other_reivent_info'=>true,    		
        'val_decl_method_of_valuation' => true,
        'val_decl_wheater_related' => true,
        'val_decl_wheater_related_influence' => true,
        'val_decl_information' => true,
        'val_decl_place' => true,
        'val_decl_date' => true,
        'bill_of_landing_no' => true,
        'bill_of_lading_date' => true,
        'bill_of_lading_ocean_vessel' => true,
        'bill_of_lading_voyage_number' => true,
        'bill_of_lading_port_of_loading' => true,
        'bill_of_lading_port_of_discharge' => true,
        'bill_of_lading_container_no' => true,
        'bill_of_lading_seal_no' => true,
        'bill_of_lading_quantity' => true,
        'insurance_policy_no' => true,
        'insurance_company_id' => true,
        'insurance_code' => true,
    		'insurance_current_date'=>true,
    	'insurance_date'=>true,
    	'insurance_time'=>true,
    	'insurance_pro_desc'=>true,
    	'insurance_transpoter_address'=>true,
    	'insurance_sum_of_insured'=>true,
    	'insurance_total_sum_insured'=>true,
    	'insurance_exchange_amount'=>true,
    	'insurance_total_amount'=>true,
    	'insurance_business_period'=>true,
    	'insurance_currency_id'=>true,
    	'insurance_decision'=>true,
    	'insurance_dept'=>true,
    	'certificateoforigin_transport_route'=>true,
    	'certificateoforigin_place'=>true,
    	'certificateoforigin_origin_criteria'=>true,
    	'certificateoforigin_date'=>true,    
		'certificateoforigin_yes_no'=>true,    		
        'lr_no' => true,
        'lr_vehicle_number' => true,
        'lr_transporter_id' => true,
        'international_transporter_company_id' => true,
        'international_transporter_from_locaton' => true,
        'international_transporter_to_location' => true,
        'international_transporter_bill_no' => true,
        'international_transporter_bill_date' => true,
        'international_transporter_frieght_amt' => true,
        'international_transporter_thc_amt' => true,
        'international_transporter_total_amt' => true,
        'created_by' => true,
        'created' => true,
        'modified_by' => true,
        'modified' => true,
        'invoice' => true,
        'lr_transporter' => true,
        'international_transporter_company' => true,
    	'packing_list_gross_weight_uom_id'=>true,
    	"is_local"=>true,
    	'owner_company_id'=>true	
    ];
}
