<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PurchaseOrder Entity
 *
 * @property int $id
 * @property int $owner_companies_id
 * @property string $po_number
 * @property string $po_number_skynet
 * @property string $po_file
 * @property \Cake\I18n\FrozenDate $po_date
 * @property int $status
 * @property int $product_id
 * @property float $quantity_ordered
 * @property float $rate
 * @property float $total_order_price
 * @property int $supplier_id
 * @property int $supplier_offer_id
 * @property int $uom_id
 * @property int $currency_id
 * @property int $inco_terms_id
 * @property int $port_of_discharge
 * @property int $country_of_origin_of_goods
 * @property int $country_final_destination
 * @property int $payment_depostited_status
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 * @property int $inward_status
 * @property string $dispatch_through
 * @property string $destination
 * @property string $delivery_to
 * @property string $required_by_us
 * @property int $packingMaster_id
 * @property string $delivery
 * @property string $your_ref_no
 * @property string $packing_terms
 * @property string $payment_terms
 * @property int $asset
 * @property int $transport_status
 * @property int $inward_id
 *
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\Supplier $supplier
 * @property \App\Model\Entity\SupplierOffer $supplier_offer
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\Currency $currency
 * @property \App\Model\Entity\IncoTerm $inco_term
 * @property \App\Model\Entity\PackingMaster $packing_master
 * @property \App\Model\Entity\Inward $inward
 * @property \App\Model\Entity\PaymentDeposit[] $payment_deposits
 */
class PurchaseOrder extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'owner_companies_id' => true,
        'po_number' => true,       
        'po_file' => true,
        'po_date' => true,
        'status' => true,
        'product_id' => true,
        'quantity_ordered' => true,
        'rate' => true,
        'total_order_price' => true,
        'supplier_id' => true,
        'supplier_offer_id' => true,
        'uom_id' => true,
        'currency_id' => true,
        'inco_terms_id' => true,
        'port_of_discharge' => true,
        'country_of_origin_of_goods' => true,
        'country_final_destination' => true,
        'payment_depostited_status' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'inward_status' => true,
        'dispatch_through' => true,
        'destination' => true,
        'delivery_to' => true,
        'required_by_us' => true,
        'packingMaster_id' => true,
        'delivery' => true,
        'your_ref_no' => true,
        'packing_terms' => true,
        'payment_terms' => true,
        'product' => true,
        'asset' => true,
        'transport_status' => true,       
        'owner_company' => true,
        'supplier' => true,
        'supplier_offer' => true,
        'uom' => true,
        'currency' => true,
        'inco_term' => true,
        'packing_master' => true,       
        'payment_deposits' => true,
    	'send_to_doc'=> true,
    	'consignee_id'=>true,
        'shipping_conditions'=> true,
    	'send_to_invoice'=>true,
    	'quantity_despatch'=>true,
    	'balance_qty'=>true	,
    	'send_to_inward'=>true,
    	"purchase_order_products"=>true,
    	"purchase_type"=>true,
    	'qc_status'=>true
    ];
}
