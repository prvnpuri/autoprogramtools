<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PostshipmentRemittance Entity
 *
 * @property int $id
 * @property int $oa_id
 * @property string $sr_no
 * @property \Cake\I18n\FrozenDate $date
 * @property string $inward_ref_no
 * @property string $credit_to_account_no
 * @property string $branch
 * @property string $remark
 * @property string $remitter
 * @property string $remitting_bank
 * @property string $ref_no
 * @property int $currency_id
 * @property float $amount
 * @property string $favouring
 * @property float $exchange_rate
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 *
 * @property \App\Model\Entity\Oa $oa
 * @property \App\Model\Entity\Currency $currency
 */
class PostshipmentRemittance extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'oa_id' => true,
        'sr_no' => true,
        'date' => true,
        'inward_ref_no' => true,
        'credit_to_account_no' => true,
        'branch' => true,
        'remark' => true,
        'remitter' => true,
        'remitting_bank' => true,
        'ref_no' => true,
        'currency_id' => true,
        'amount' => true,
        'favouring' => true,
        'exchange_rate' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'oa' => true,
        'currency' => true
    ];
}
