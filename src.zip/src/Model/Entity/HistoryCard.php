<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * HistoryCard Entity
 *
 * @property int $id
 * @property string $make
 * @property string $range
 * @property string $acceptance_criteria
 * @property string $l_c
 * @property \Cake\I18n\FrozenDate $date_of_calibration
 * @property string $certificate_no
 * @property \Cake\I18n\FrozenDate $certificate_date
 * @property string $traceability
 * @property string $remarks
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 * @property int $equipment_calibration_master_id
 *
 * @property \App\Model\Entity\EquipmentCalibrationMaster $equipment_calibration_master
 */
class HistoryCard extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'make' => true,
        'range' => true,
        'acceptance_criteria' => true,
        'l_c' => true,
        'date_of_calibration' => true,
        'certificate_no' => true,
        'certificate_date' => true,
        'traceability' => true,
        'remarks' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'equipment_calibration_master_id' => true,
        'equipment_calibration_master' => true
    ];
}
