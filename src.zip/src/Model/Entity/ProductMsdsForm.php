<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ProductMsdsForm Entity
 *
 * @property int $id
 * @property int $display_order
 * @property string $sr_no
 * @property string $title
 * @property string $title_type
 * @property string $divclass
 * @property string $divclass_input
 * @property string $data_type
 * @property int $data_length
 * @property string $data_type_col2
 * @property int $data_length_col2
 * @property string $data_type_col3
 * @property int $data_length_col3
 * @property string $radiocheck
 * @property string $auto_value
 *
 * @property \App\Model\Entity\ProductMsd[] $product_msds
 */
class ProductMsdsForm extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'display_order' => true,
        'sr_no' => true,
        'title' => true,
        'title_type' => true,
        'divclass' => true,
        'divclass_input' => true,
        'data_type' => true,
        'data_length' => true,
        'data_type_col2' => true,
        'data_length_col2' => true,
        'data_type_col3' => true,
        'data_length_col3' => true,
        'radiocheck' => true,
        'auto_value' => true,
        'product_msds' => true
    ];
}
