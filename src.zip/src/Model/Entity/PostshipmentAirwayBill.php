<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PostshipmentAirwayBill Entity
 *
 * @property int $id
 * @property int $oa_id
 * @property string $carrier_agent_name
 * @property string $airport_of_departure
 * @property string $mawb_no
 * @property string $awb_no
 * @property string $first_carrier
 * @property string $airport_of_destination
 * @property string $req_flight
 * @property \Cake\I18n\FrozenDate $date
 * @property float $gross_wt
 * @property float $chargable_wt
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property string $airway_bill
 *
 * @property \App\Model\Entity\Oa $oa
 */
class PostshipmentAirwayBill extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'oa_id' => true,
        'carrier_agent_name' => true,
        'airport_of_departure' => true,
        'mawb_no' => true,
        'awb_no' => true,
        'first_carrier' => true,
        'airport_of_destination' => true,
        'req_flight' => true,
        'date' => true,
        'gross_wt' => true,
        'chargable_wt' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'airway_bill' => true,
        'oa' => true
    ];
}
