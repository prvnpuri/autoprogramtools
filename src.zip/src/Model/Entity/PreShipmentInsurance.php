<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PreShipmentInsurance Entity
 *
 * @property int $id
 * @property int $invoice_id
 * @property \Cake\I18n\FrozenDate $date
 * @property int $islocal
 * @property \Cake\I18n\FrozenDate $insurance_date
 * @property string $insurance_time
 * @property string $till_delivery
 * @property string $nature_of_packing
 * @property string $conditions
 * @property string $details_of_transit
 * @property string $details_of_transit_address
 * @property float $sum_of_insured
 * @property float $total_sum_insured
 * @property string $decision
 * @property string $ready_to_print
 * @property int $to_company
 * @property string $dept
 * @property string $office_name
 * @property string $office_address
 * @property string $business_period
 * @property string $pro_desc
 * @property string $exchange_amount
 * @property int $currency_id
 * @property string $total_amount
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\Currency $currency
 */
class PreShipmentInsurance extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_id' => true,
        'date' => true,
        'islocal' => true,
        'insurance_date' => true,
        'insurance_time' => true,
        'till_delivery' => true,
        'nature_of_packing' => true,
        'conditions' => true,
        'details_of_transit' => true,
        'details_of_transit_address' => true,
        'sum_of_insured' => true,
        'total_sum_insured' => true,
        'decision' => true,
        'ready_to_print' => true,
        'to_company' => true,
        'dept' => true,
        'office_name' => true,
        'office_address' => true,
        'business_period' => true,
        'pro_desc' => true,
        'exchange_amount' => true,
        'currency_id' => true,
        'total_amount' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'invoice' => true,
        'currency' => true
    ];
}
