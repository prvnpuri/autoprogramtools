<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * LrcopyPhoto Entity
 *
 * @property int $id
 * @property int $order_id
 * @property int $lr_id
 * @property int $oa_id
 * @property string $photo
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Lr $lr
 * @property \App\Model\Entity\Oa $oa
 */
class LrcopyPhoto extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'order_id' => true,
        'lr_id' => true,
        'oa_id' => true,
        'photo' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'order' => true,
        'lr' => true,
        'oa' => true
    ];
}
