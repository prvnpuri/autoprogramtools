<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Lrcopy Entity
 *
 * @property int $id
 * @property int $company_name
 * @property int $oa_id
 * @property string $lr_no
 * @property \Cake\I18n\FrozenDate $date
 * @property int $consignor
 * @property int $consignee
 * @property string $from
 * @property string $to
 * @property string $no_of_packages
 * @property string $description
 * @property string $weight
 * @property string $statistical_charges
 * @property string $handling
 * @property string $bilty
 * @property string $others / misc_charge
 * @property string $freight / FOV
 * @property string $door_delivery
 * @property string $ODA/ out_of_delivery
 * @property string $hamali
 * @property string $collection
 * @property string $form charges/ N-FORM_charges
 * @property string $service_tax
 * @property string $octrai
 * @property string $oct_service
 * @property string $oct_form
 * @property string $R/C
 * @property string $demurrage
 * @property string $fuel_surcharge
 * @property string $door_pickup
 * @property string $COD/DOD_charge
 * @property string $pick_up_crane_charge
 * @property string $delivery_crane_charge
 * @property string $toll_charge
 * @property string $E_B/ Discount/ SPL_Discount
 * @property string $total
 * @property string $vehicle_no
 * @property string $challan_no
 * @property string $time
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property string $bill_number
 * @property string $currency_id
 * @property \Cake\I18n\FrozenDate $bill_date
 * @property float $bill_amount
 * @property string $inward_outward
 * @property string $status
 * @property int $product_id
 * @property float $quantity
 * @property int $uom_id
 * @property string $type
 * @property string $grn
 * @property \Cake\I18n\FrozenDate $date1
 *
 * @property \App\Model\Entity\Oa $oa
 * @property \App\Model\Entity\Currency $currency
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\Transporter[] $transporters
 * @property \App\Model\Entity\Photo[] $photo
 */
class Lrcopy extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'company_name' => true,
        'oa_id' => true,
        'lr_no' => true,
        'date' => true,
        'consignor' => true,
        'consignee' => true,
        'from' => true,
        'to' => true,
        'no_of_packages' => true,
        'description' => true,
        'weight' => true,
        'statistical_charges' => true,
        'handling' => true,
        'bilty' => true,
        'others / misc_charge' => true,
        'freight / FOV' => true,
        'door_delivery' => true,
        'ODA/ out_of_delivery' => true,
        'hamali' => true,
        'collection' => true,
        'form charges/ N-FORM_charges' => true,
        'service_tax' => true,
        'octrai' => true,
        'oct_service' => true,
        'oct_form' => true,
        'R/C' => true,
        'demurrage' => true,
        'fuel_surcharge' => true,
        'door_pickup' => true,
        'COD/DOD_charge' => true,
        'pick_up_crane_charge' => true,
        'delivery_crane_charge' => true,
        'toll_charge' => true,
        'E_B/ Discount/ SPL_Discount' => true,
        'total' => true,
        'vehicle_no' => true,
        'challan_no' => true,
        'time' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'bill_number' => true,
        'currency_id' => true,
        'bill_date' => true,
        'bill_amount' => true,
        'inward_outward' => true,
        'status' => true,
        'product_id' => true,
        'quantity' => true,
        'uom_id' => true,
        'type' => true,
        'grn' => true,
        'date1' => true,
        'oa' => true,
        'currency' => true,
        'product' => true,
        'uom' => true,
        'transporters' => true,
        'photo' => true
    ];
}
