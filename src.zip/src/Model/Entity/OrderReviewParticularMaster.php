<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OrderReviewParticularMaster Entity
 *
 * @property int $id
 * @property int $particular_id
 * @property int $order_review_id
 * @property string $offer_term
 * @property string $order_term
 * @property string $remark
 *
 * @property \App\Model\Entity\Particular $particular
 * @property \App\Model\Entity\OrderReview $order_review
 */
class OrderReviewParticularMaster extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'particular_id' => true,
        'order_review_id' => true,
        'offer_term' => true,
        'order_term' => true,
        'remark' => true,
        'particular' => true,
        'order_review' => true
    ];
}
