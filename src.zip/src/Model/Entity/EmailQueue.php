<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * EmailQueue Entity
 *
 * @property int $id
 * @property string $model_name
 * @property int $model_id
 * @property int $contact_person_id
 * @property string $to
 * @property string $from_name
 * @property string $from_email
 * @property string $subject
 * @property string $config
 * @property string $template
 * @property string $layout
 * @property string $format
 * @property string $template_vars
 * @property string $attachment
 * @property bool $sent
 * @property bool $locked
 * @property int $send_tries
 * @property \Cake\I18n\FrozenTime $send_at
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\Model $model
 * @property \App\Model\Entity\ContactPerson $contact_person
 */
class EmailQueue extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'model_name' => true,
        'model_id' => true,
        'contact_person_id' => true,
        'to' => true,
        'from_name' => true,
        'from_email' => true,
        'subject' => true,
        'config' => true,
        'template' => true,
        'layout' => true,
        'format' => true,
        'template_vars' => true,
        'attachment' => true,
        'sent' => true,
        'locked' => true,
        'send_tries' => true,
        'send_at' => true,
        'created' => true,
        'modified' => true,
        'model' => true,
        'contact_person' => true
    ];
}
