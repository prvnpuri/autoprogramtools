<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * EmailStatus Entity
 *
 * @property int $id
 * @property string $status
 * @property \Cake\I18n\FrozenTime $email_sent
 * @property string $metadata
 * @property int $send_by
 * @property string $to
 * @property string $cc
 * @property string $bcc
 * @property string $send_from
 */
class EmailStatus extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'status' => true,
        'email_sent' => true,
        'metadata' => true,
        'send_by' => true,
        'to' => true,
        'cc' => true,
        'bcc' => true,
        'send_from' => true
    ];
}
