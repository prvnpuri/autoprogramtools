<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * BoldNumberInventory Entity
 *
 * @property int $id
 * @property string $unique_series
 * @property int $from
 * @property int $to
 * @property int $remain_quantity
 * @property int $delete_status
 * @property int $bold_number_request_id
 * @property int $owner_company_id
 *
 * @property \App\Model\Entity\BoldNumberRequest $bold_number_request
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\BoldNoInventoryTran[] $bold_no_inventory_tran
 */
class BoldNumberInventory extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'unique_series' => true,
        'from' => true,
        'to' => true,
        'remain_quantity' => true,
        'delete_status' => true,
        'bold_number_request_id' => true,
        'owner_company_id' => true,
        'bold_number_request' => true,
        'owner_company' => true,
        'bold_no_inventory_tran' => true
    ];
}
