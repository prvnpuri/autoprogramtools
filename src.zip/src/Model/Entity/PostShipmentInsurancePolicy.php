<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PostShipmentInsurancePolicy Entity
 *
 * @property int $id
 * @property string $invoice_no
 * @property string $policy_no
 * @property string $insured_name
 * @property string $code
 * @property string $collection_no
 * @property \Cake\I18n\FrozenDate $collection_date
 * @property string $voyage
 * @property string $mode_of_transport
 * @property \Cake\I18n\FrozenDate $date
 * @property string $commodity
 * @property string $sum_insured
 * @property string $rate
 * @property string $marine_premium
 * @property string $place
 * @property \Cake\I18n\FrozenDate $date1
 * @property string $total_amount
 * @property string $created_by
 * @property string $modified_by
 * @property \Cake\I18n\FrozenDate $creation_date
 * @property \Cake\I18n\FrozenDate $modification_date
 * @property int $oa_id
 *
 * @property \App\Model\Entity\Oa $oa
 */
class PostShipmentInsurancePolicy extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_no' => true,
        'policy_no' => true,
        'insured_name' => true,
        'code' => true,
        'collection_no' => true,
        'collection_date' => true,
        'voyage' => true,
        'mode_of_transport' => true,
        'date' => true,
        'commodity' => true,
        'sum_insured' => true,
        'rate' => true,
        'marine_premium' => true,
        'place' => true,
        'date1' => true,
        'total_amount' => true,
        'created_by' => true,
        'modified_by' => true,
        'creation_date' => true,
        'modification_date' => true,
        'oa_id' => true,
        'oa' => true
    ];
}
