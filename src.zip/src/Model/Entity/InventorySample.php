<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * InventorySample Entity
 *
 * @property int $id
 * @property int $product_id
 * @property int $owner_company_id
 * @property int $warehouse_master_id
 * @property float $balance_qty
 * @property float $in_processing
 * @property float $qty_in_warehouse
 * @property int $uom
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 *
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\WarehouseMaster $warehouse_master
 */
class InventorySample extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'product_id' => true,
        'owner_company_id' => true,
        'warehouse_master_id' => true,
        'balance_qty' => true,
        'in_processing' => true,
        'qty_in_warehouse' => true,
        'uom' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'product' => true,
        'owner_company' => true,
        'warehouse_master' => true
    ];
}
