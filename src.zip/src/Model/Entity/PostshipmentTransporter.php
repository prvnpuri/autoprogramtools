<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PostshipmentTransporter Entity
 *
 * @property int $id
 * @property int $oa_id
 * @property int $company_id
 * @property string $lr_number
 * @property \Cake\I18n\FrozenDate $lr_date
 * @property string $from_location
 * @property string $to_location
 * @property string $bill_number
 * @property \Cake\I18n\FrozenDate $bill_date
 * @property float $bill_amount
 * @property string $currency_id
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 * @property string $inward_outward
 * @property int $in_out_ward_id
 * @property string $status
 * @property int $purchase_id
 * @property int $inward_id
 * @property int $warehouse_id_from
 * @property int $warehouse_id_to
 * @property int $product_id
 * @property float $quantity
 * @property int $uom_id
 * @property string $type
 * @property string $grn
 * @property string $dc
 * @property \Cake\I18n\FrozenDate $date
 *
 * @property \App\Model\Entity\Oa $oa
 * @property \App\Model\Entity\Company $company
 * @property \App\Model\Entity\Currency $currency
 * @property \App\Model\Entity\InOutWard $in_out_ward
 * @property \App\Model\Entity\Purchase $purchase
 * @property \App\Model\Entity\Inward $inward
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\Uom $uom
 */
class PostshipmentTransporter extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'oa_id' => true,
        'company_id' => true,
        'lr_number' => true,
        'lr_date' => true,
        'from_location' => true,
        'to_location' => true,
        'bill_number' => true,
        'bill_date' => true,
        'bill_amount' => true,
        'currency_id' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'inward_outward' => true,
        'in_out_ward_id' => true,
        'status' => true,
        'purchase_id' => true,
        'inward_id' => true,
        'warehouse_id_from' => true,
        'warehouse_id_to' => true,
        'product_id' => true,
        'quantity' => true,
        'uom_id' => true,
        'type' => true,
        'grn' => true,
        'dc' => true,
        'date' => true,
        'oa' => true,
        'company' => true,
        'currency' => true,
        'in_out_ward' => true,
        'purchase' => true,
        'inward' => true,
        'product' => true,
        'uom' => true
    ];
}
