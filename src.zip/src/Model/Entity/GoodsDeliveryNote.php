<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * GoodsDeliveryNote Entity
 *
 * @property int $id
 * @property int $po_id
 * @property float $quantity
 * @property int $uom_id
 * @property int $company_master_id
 * @property string $lr_number
 * @property \Cake\I18n\FrozenDate $lr_date
 * @property int $products_master_id
 * @property string $from_location
 * @property string $to_location
 * @property string $reference_number
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 *
 * @property \App\Model\Entity\Po $po
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\CompanyMaster $company_master
 * @property \App\Model\Entity\ProductsMaster $products_master
 */
class GoodsDeliveryNote extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'po_id' => true,
       
        'company_master_id' => true,
        'lr_number' => true,
        'lr_date' => true,
       
        'from_location_id' => true,
        'to_location_id' => true,
        'reference_number' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'po' => true,
        'uom' => true,
        'company_master' => true,
        'products_master' => true,
    	'consumables_master' => true,
    	'gdn_products' => true,
    	'gdn_status'=>true,
    		'qc_status'=>true,
    		'parent_id'=>true
    ];
}
