<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ProductStandard Entity
 *
 * @property int $id
 * @property int $products_master_id
 * @property int $standard_packing_type
 * @property int $standard_packing_subtype
 * @property float $standard_packing_qty
 * @property int $standard_packing_qty_uom_id
 * @property float $standard_unit_price
 * @property int $currency_id
 *
 * @property \App\Model\Entity\ProductsMaster $products_master
 * @property \App\Model\Entity\StandardPackingQtyUom $standard_packing_qty_uom
 * @property \App\Model\Entity\Currency $currency
 */
class ProductStandardMarketing extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'products_master_id' => true,
        'standard_packing_type' => true,
        'standard_packing_subtype' => true,
        'standard_packing_min_qty' => true,
    	'standard_packing_max_qty' => true,
        'standard_packing_qty_uom_id' => true,
        'standard_unit_price' => true,
        'currency_id' => true,
        'products_master_marketing' => true,
    	'packing_type'=>true,
    	'packing_subtype'=>true,
        'uom' => true,
        'currency' => true,
    		
    ];
}
