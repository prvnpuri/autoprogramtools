<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ImportExportData Entity
 *
 * @property int $id
 * @property string $imp_exp
 * @property string $sb_be_no
 * @property \Cake\I18n\FrozenDate $sb_be_date
 * @property string $cas
 * @property int $item_id
 * @property float $qty
 * @property int $uom
 * @property float $rate_fc
 * @property int $curr
 * @property string $net_val_fc
 * @property int $port_of_loading
 * @property int $country_of_loading
 * @property int $shipper_id
 * @property int $consignee_id
 * @property int $destination_port
 * @property int $destination_country
 *
 * @property \App\Model\Entity\Item $item
 * @property \App\Model\Entity\Shipper $shipper
 * @property \App\Model\Entity\Consignee $consignee
 */
class ImportExportData extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'imp_exp' => true,
        'sb_be_no' => true,
        'sb_be_date' => true,
        'item' => true,
        'cas' => true,
        'item_id' => true,
        'qty' => true,
        'uom' => true,
        'rate_fc' => true,
        'curr' => true,
        'net_val_fc' => true,
        'port_of_loading' => true,
        'country_of_loading' => true,
        'shipper_id' => true,
        'consignee_id' => true,
        'destination_port' => true,
        'destination_country' => true,
        'shipper' => true,
        'consignee' => true
    ];
}
