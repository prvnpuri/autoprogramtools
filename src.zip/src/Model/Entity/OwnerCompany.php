<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OwnerCompany Entity
 *
 * @property int $id
 * @property string $Company_name
 * @property string $logo_image
 * @property string $acronym
 * @property string $header_image
 * @property string $footer_image
 * @property string $stamp_image
 * @property string $website_address
 * @property string $Address
 * @property string $pin_code
 * @property int $city
 * @property int $state
 * @property int $country
 * @property string $company_email
 * @property string $company_phone1
 * @property string $company_phone2
 * @property string $fax1
 * @property string $fax2
 * @property string $var
 * @property string $cst
 * @property string $gstin
 * @property string $pan
 * @property string $iec_no
 * @property int $port_of_discharge_air
 * @property int $port_of_discharge_sea
 * @property bool $iso
 * @property string $duns
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\OwnerCompanyOffice[] $owner_company_offices
 */
class OwnerCompany extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'Company_name' => true,
        'logo_image' => true,
        'acronym' => true,
        'header_image' => true,
        'footer_image' => true,
        'stamp_image' => true,
        'website_address' => true,
        'Address' => true,
        'pin_code' => true,
        'city' => true,
        'state' => true,
        'country' => true,
        'company_email' => true,
        'company_phone1' => true,
        'company_phone2' => true,
        'fax1' => true,
        'fax2' => true,
        'var' => true,
        'cst' => true,
        'gstin' => true,
        'pan' => true,
        'iec_no' => true,
        'port_of_discharge_air' => true,
        'port_of_discharge_sea' => true,
        'iso' => true,
        'duns' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
    	'fedex_acc_no' => true,
        'owner_company_offices' => true,
    	'owner_contact_persons' => true,
    	'cd_acc_no' => true,
    	'lut_detail' => true
    ];
}
