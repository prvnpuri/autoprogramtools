<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * InvoiceTax Entity
 *
 * @property int $id
 * @property int $taxes_master_id
 * @property int $invoice_products_id
 * @property float $amount
 *
 * @property \App\Model\Entity\TaxMaster $tax_master
 * @property \App\Model\Entity\InvoiceProduct $invoice_product
 */
class InvoiceTax extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'taxes_master_id' => true,
        'invoice_products_id' => true,
        'amount' => true,
        'rate'=>true,
        'tax_master' => true,
        'invoice_product' => true
    ];
}
