<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * LeaveApplication Entity
 *
 * @property int $id
 * @property int $employee_id
 * @property int $leave_type_id
 * @property \Cake\I18n\FrozenDate $start_date
 * @property string $leave_for_start
 * @property \Cake\I18n\FrozenDate $end_date
 * @property string $leave_for_end
 * @property float $total_days
 * @property string $reason
 * @property string $leave_status
 * @property int $approved_by
 * @property int $notification_mark
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\Employee $employee
 * @property \App\Model\Entity\LeaveType $leave_type
 */
class LeaveApplication extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'employee_id' => true,
        'leave_type_id' => true,
        'start_date' => true,
        'leave_for_start' => true,
        'end_date' => true,
        'leave_for_end' => true,
        'total_days' => true,
        'reason' => true,
        'leave_status' => true,
        'approved_by' => true,
        'notification_mark' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'employee' => true,
        'leave_type' => true
    ];
}
