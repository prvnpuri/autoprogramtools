<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Invoice Entity
 *
 * @property int $id
 * @property int $invoice_types_id
 * @property int $owner_company_id
 * @property int $owner_company_office
 * @property string $invoice_no
 * @property \Cake\I18n\FrozenDate $invoice_date
 * @property string $item_no
 * @property string $other_ref
 * @property string $exporter_ref
 * @property string $transport_mode
 * @property string $vessel_no
 * @property string $port_load
 * @property string $place_of_receipt
 * @property string $pre_carriage
 * @property int $consignee_id
 * @property int $notify_id
 * @property string $kind_of_pkg
 * @property string $end_use
 * @property string $marks_nos
 * @property string $instruction
 * @property string $ready_to_print
 * @property string $preshipment_done
 * @property string $buyer_order_no
 * @property \Cake\I18n\FrozenDate $buyer_order_date
 * @property int $port_of_discharge
 * @property int $final_destination
 * @property int $country_final_destination
 * @property int $country_origin_goods
 * @property int $delivery_term
 * @property int $payment_term
 * @property float $amount_wo_tax
 * @property float $amount_wi_tax
 * @property int $currency_id
 * @property string $total_in_words
 * @property int $buyer_id
 * @property bool $is_reverse_charge
 * @property float $reverse_charge_amount
 * @property string $additional_info
 * @property bool $mail_sent
 * @property int $company_bank_master_id
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $created
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $modified
 * @property float $grand_total_amount
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\CompanyMaster $company_master
 * @property \App\Model\Entity\Currency $currency
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\InvoiceType $invoice_type
 * @property \App\Model\Entity\CertificateOfAnalysis[] $certificate_of_analyses
 * @property \App\Model\Entity\ExciseTaxInvoice[] $excise_tax_invoice
 * @property \App\Model\Entity\ExportValueDeclaration[] $export_value_declaration
 * @property \App\Model\Entity\InvoiceOrder[] $invoice_orders
 * @property \App\Model\Entity\InvoiceProduct[] $invoice_products
 * @property \App\Model\Entity\LocalPreShipmentAttachment[] $local_pre_shipment_attachment
 * @property \App\Model\Entity\LocalPreShipmentTransporter[] $local_pre_shipment_transporter
 * @property \App\Model\Entity\MultiorderExportProformaInvoiceDetail[] $multiorder_export_proforma_invoice_detail
 * @property \App\Model\Entity\MultiorderInvoiceBase[] $multiorder_invoice_base
 * @property \App\Model\Entity\MultiorderLocalInvoiceDetail[] $multiorder_local_invoice_details
 * @property \App\Model\Entity\MultiorderLocalProformaInvoiceDetail[] $multiorder_local_proforma_invoice_details
 * @property \App\Model\Entity\MultiorderPreShipmentInvoiceDetail[] $multiorder_pre_shipment_invoice_detail
 * @property \App\Model\Entity\MultiorderProformaInvoiceBase[] $multiorder_proforma_invoice_base
 * @property \App\Model\Entity\PreShipmentAttachment[] $pre_shipment_attachment
 * @property \App\Model\Entity\PreShipmentBase[] $pre_shipment_base
 * @property \App\Model\Entity\PreShipmentInsurance[] $pre_shipment_insurance
 * @property \App\Model\Entity\PreShipmentPacking[] $pre_shipment_packing
 * @property \App\Model\Entity\PreShipmentSdf[] $pre_shipment_sdf
 * @property \App\Model\Entity\PreShipmentShipperDeclaration[] $pre_shipment_shipper_declaration
 * @property \App\Model\Entity\PreShipmentShipperInstruction[] $pre_shipment_shipper_instruction
 * @property \App\Model\Entity\PreShipmentTransporter[] $pre_shipment_transporter
 * @property \App\Model\Entity\PreshipmentTsca[] $preshipment_tsca
 * @property \App\Model\Entity\ShippingDocumentsPhysical[] $shipping_documents_physical
 * @property \App\Model\Entity\TaxInvoice[] $tax_invoice
 * @property \App\Model\Entity\LedgerTransaction[] $ledger_transactions
 */
class Invoice extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_types_id' => true,
        'owner_company_id' => true,
        'owner_company_office_id' => true,
        'owner_company_office' => true,
        'invoice_no' => true,
        'invoice_date' => true,
        'item_no' => true,
        'other_ref' => true,
        'exporter_ref' => true,
        'transport_mode' => true,
        'vessel_no' => true,
        'port_load' => true,
        'place_of_receipt' => true,
        'pre_carriage' => true,
        'consignee_id' => true,
        'notify_id' => true,
        'end_use' => true,
        'instruction' => true,
        'ready_to_print' => true,
        'preshipment_done' => true,
        'buyer_order_no' => true,
        'buyer_order_date' => true,
        'port_of_discharge' => true,
        'final_destination' => true,
        'country_final_destination' => true,
        'country_origin_goods' => true,
        'delivery_term' => true,
        'payment_term_id' => true,
        'payment_term' => true,
        'amount_wo_tax' => true,
        'amount_wi_tax' => true,
        'currency_id' => true,
        'total_in_words' => true,
        'buyer_id' => true,
        'is_reverse_charge' => true,
        'reverse_charge_amount' => true,
        'additional_info' => true,
        'mail_sent' => true,
        'company_bank_master_id' => true,
        'created_by' => true,
        'created' => true,
        'modified_by' => true,
        'modified' => true,
        'owner_company' => true,
        'order' => true,
        'company_master' => true,
        'currency' => true,
        'uom' => true,
        'invoice_type' => true,
		'supplier_id'=>true,
        'invoice_orders' => true,
        'invoice_products' => true,
        'is_local'=>true,
        'tax_invoice' => true,
        'ledger_transactions' => true,
        'grand_total_amount'=>true,
    	'challan_no'=>true,
    	'challan_date'=>true,
    	'is_proforma'	=>true,
    	'send_to_payment'=>true,
        'supplier'=>true,
    	'order_buyer_id'=>true,
    	'send_to_inward' => true,    
    	'send_to_postshipment'=>true,
    	'delivery_term_id'=>true	
    ];
}
