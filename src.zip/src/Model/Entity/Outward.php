<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Outward Entity
 *
 * @property int $id
 * @property int $warehouse_master_id
 * @property int $material_request_id
 * @property int $oa_id
 * @property int $order_id
 * @property string $invoice_no
 * @property \Cake\I18n\FrozenDate $invoice_date
 * @property int $product_id
 * @property float $quantity_supplied
 * @property int $uom_id
 * @property int $inco_terms_id
 * @property int $transporter_id
 * @property string $batch_no
 * @property string $lr_number
 * @property string $address
 * @property string $reference_number
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\WarehouseMaster $warehouse_master
 * @property \App\Model\Entity\MaterialRequest $material_request
 * @property \App\Model\Entity\Oa $oa
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\IncoTerm $inco_term
 * @property \App\Model\Entity\Transporter $transporter
 * @property \App\Model\Entity\SampleProduct[] $sample_product
 * @property \App\Model\Entity\TransactionProduct[] $transaction_product
 */
class Outward extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'warehouse_master_id' => true,
        'material_request_id' => true,
        'oa_id' => true,
        'order_id' => true,
        'invoice_no' => true,
        'invoice_date' => true,
        'product_id' => true,
        'quantity_supplied' => true,
        'uom_id' => true,
        'inco_terms_id' => true,
        'transporter_id' => true,
        'batch_no' => true,
        'lr_number' => true,
        'address' => true,
        'reference_number' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'warehouse_master' => true,
        'material_request' => true,
        'oa' => true,
        'order' => true,
        'product' => true,
        'uom' => true,
        'inco_term' => true,
        'transporter' => true,
        'sample_product' => true,
        'transaction_product' => true
    ];
}
