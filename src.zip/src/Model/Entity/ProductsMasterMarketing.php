<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ProductsMaster Entity
 *
 * @property int $id
 * @property string $product_name
 * @property string $product_information
 * @property string $grade_name
 * @property string $well_known_grade_name
 * @property string $acronym
 * @property string $cas_no
 * @property string $einecs_no
 * @property string $hs_code
 * @property string $molecular_formula
 * @property string $molecular_weight
 * @property string $td_status
 * @property string $td_created_by
 * @property string $td_modified_by
 * @property string $msds_status
 * @property string $msds_created_by
 * @property string $msds_modified_by
 * @property string $coa_status
 * @property string $coa_created_by
 * @property string $coa_modified_by
 * @property \Cake\I18n\FrozenTime $modified_timestamp
 * @property string $solubility_at
 * @property string $dosage
 * @property string $is_compound
 * @property int $has_techds_pdf
 * @property int $has_msds_pdf
 * @property int $status
 * @property string $msds_attachment
 * @property string $product_details
 * @property float $reorder_level
 * @property float $reorder_qty
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\BatchsheetMaster[] $batchsheet_master
 * @property \App\Model\Entity\Inquiry[] $inquiry
 * @property \App\Model\Entity\Order[] $order
 * @property \App\Model\Entity\ProductDataTest[] $product_data_tests
 * @property \App\Model\Entity\ProductIndustryApplication[] $product_industry_applications
 * @property \App\Model\Entity\ProductMsd[] $product_msds
 * @property \App\Model\Entity\ProductSolubilityTest[] $product_solubility_tests
 * @property \App\Model\Entity\ReferenceBom[] $reference_bom
 * @property \App\Model\Entity\SupplierInquiry[] $supplier_inquiry
 * @property \App\Model\Entity\ProductTax[] $product_taxes
 * 
 */
class ProductsMasterMarketing extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'product_name' => true,
        'product_information' => true,
        'grade_name' => true,
        'well_known_grade_name' => true,
        'acronym' => true,
        'cas_no' => true,
        'einecs_no' => true,
    	'hs_code' => true,
    	'ritc_code' => true,
        'molecular_formula' => true,
        'molecular_weight' => true,
        'td_status' => true,
        'td_created_by' => true,
        'td_modified_by' => true,
        'msds_status' => true,
        'msds_created_by' => true,
        'msds_modified_by' => true,
        'coa_status' => true,
        'coa_created_by' => true,
        'coa_modified_by' => true,
        'modified_timestamp' => true,
        'solubility_at' => true,
        'dosage' => true,
        'is_compound' => true,
        'has_techds_pdf' => true,
        'has_msds_pdf' => true,
        'status' => true,
        'msds_attachment' => true,
        'product_details' => true,
        'reorder_level' => true,
        'reorder_qty' => true,
        'created' => true,
        'modified' => true,
        'batchsheet_master' => true,
        'inquiry' => true,
        'order' => true,
        'product_data_tests_marketing' => true,
        'product_industry_applications_marketing' => true,
        'product_msds_marketing' => true,
        'product_solubility_tests_marketing' => true,
        'reference_bom' => true,
        'supplier_inquiry' => true,
        'product_taxes_marketing'=>true,
    	'product_standards_marketing'=>true	
    ];
}
