<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * SupplierInquiry Entity
 *
 * @property int $id
 * @property string $company_ids
 * @property int $product_id
 * @property string $product_specifications
 * @property float $qty_required
 * @property string $contact_person
 * @property string $company_contact_persons
 * @property string $contact_person_email
 * @property string $cc_email
 * @property \Cake\I18n\FrozenDate $raised_on
 * @property string $comments
 * @property int $status
 * @property int $is_local
 * @property int $owner_companies_id
 * @property int $uom_id
 * @property float $rate
 * @property int $currency_id
 * @property float $total_order_value
 * @property string $packing
 * @property \Cake\I18n\FrozenDate $expected_delivery_dt
 * @property string $payment_terms
 * @property int $port_of_discharge
 * @property int $country_of_origin_of_goods
 * @property int $country_final_destination
 * @property \Cake\I18n\FrozenDate $validity_of_inquiry
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 * @property string $reference_number
 * @property int $packingMaster_id
 * @property int $packing_qty
 * @property string $inquiry_type
 * @property int $product
 * @property int $asset
 *
 * @property \App\Model\Entity\ProductsMaster $products_master
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\Currency $currency
 * @property \App\Model\Entity\PackingMaster $packing_master
 * @property \App\Model\Entity\SupplierOffer[] $supplier_offer
 */
class SupplierInquiry extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
    	'id' => true,
    	'demand_queue_id' => true,
    	'company_ids' => true,
        'products_master_id' => true,
        'product_specifications' => true,
        'qty_required' => true,
        'contact_person' => true,
        'company_contact_persons' => true,
        'contact_person_email' => true,
        'cc_email' => true,
        'raised_on' => true,
    	'expected_delivery_date' => true,
        'comments' => true,
        'status' => true,
        'is_local' => true,
        'owner_companies_id' => true,
        'uom_id' => true,
        'rate' => true,
        'currency_id' => true,
        'total_order_value' => true,
        'packing_id' => true,
        'expected_delivery_dt' => true,
        'payment_terms' => true,
       // 'port_of_discharge' => true,
       // 'country_of_origin_of_goods' => true,
       // 'country_final_destination' => true,
        'validity_of_inquiry' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'reference_number' => true,
        'packingMaster_id' => true,
        'packing_qty' => true,
        'inquiry_type' => true,
        'product' => true,
        'asset' => true,
        'products_master' => true,
        'owner_company' => true,
        'uom' => true,
        'currency' => true,
        'packing_master' => true,
        'supplier_offer' => true,
    	'assets_master'=>true,
    	'send_to_offer'=>true,
    	'demand_queue' => true,
    	"selected_product_specs"=>true,
    	"supplier_inquiry_products"=>true
    ];
}
