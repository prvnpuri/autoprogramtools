<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ProductHistory Entity
 *
 * @property int $id
 * @property int $product_id
 * @property string $buy_or_sell
 * @property float $qty
 * @property float $rate
 * @property int $currency
 * @property \Cake\I18n\FrozenDate $transaction_date
 *
 * @property \App\Model\Entity\Product $product
 */
class ProductHistory extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'product_id' => true,
        'buy_or_sell' => true,
        'qty' => true,
        'rate' => true,
        'currency' => true,
        'transaction_date' => true,
        'product' => true
    ];
}
