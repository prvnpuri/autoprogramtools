<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * QualityDelPerformanceOfSupplier Entity
 *
 * @property int $id
 * @property string $reference_number
 * @property string $supplier_name
 * @property string $item_description
 * @property int $qty_received
 * @property int $qty_accepted
 * @property int $qty_rejected
 * @property int $marks
 * @property string $remark
 * @property int $owner_company_id
 * @property int $supplier_id
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\Supplier $supplier
 */
class QualityDelPerformanceOfSupplier extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'reference_number' => true,
        'supplier_name' => true,
        'item_description' => true,
        'qty_received' => true,
        'qty_accepted' => true,
        'qty_rejected' => true,
        'marks' => true,
        'remark' => true,
        'owner_company_id' => true,
        'supplier_id' => true,
        'owner_company' => true,
        'supplier' => true
    ];
}
