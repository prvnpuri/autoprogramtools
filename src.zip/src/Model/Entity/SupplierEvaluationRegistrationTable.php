<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * SupplierEvaluationRegistrationTable Entity
 *
 * @property int $id
 * @property int $company_master_id
 * @property string $vat_tin_reg_no
 * @property string $cst_tin_reg_no
 * @property string $iso_certification
 * @property string $product_ids
 * @property string $packing_master_ids
 * @property string $list_of_existing_client
 * @property string $manufacturing_facility
 * @property string $inspection_equipment_fasility
 * @property string $method_of_approval
 * @property string $payment_terms_conditions
 * @property int $approved_status
 * @property string $reason_for_status
 * @property string $trail_po_details
 * @property string $evaluation_remark
 * @property \Cake\I18n\FrozenDate $date_of_assessment
 * @property string $assessed_by
 * @property string $approved_by
 * @property int $owner_company_id
 * @property string $reference_number
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $created_by
 * @property int $modified_by
 *
 * @property \App\Model\Entity\CompanyMaster $company_master
 * @property \App\Model\Entity\OwnerCompany $owner_company
 */
class SupplierEvaluationRegistrationTable extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'company_master_id' => true,
        'vat_tin_reg_no' => true,
        'cst_tin_reg_no' => true,
        'iso_certification' => true,
        'product_ids' => true,
        'packing_master_ids' => true,
        'list_of_existing_client' => true,
        'manufacturing_facility' => true,
        'inspection_equipment_fasility' => true,
        'method_of_approval' => true,
        'payment_terms_conditions' => true,
        'approved_status' => true,
        'reason_for_status' => true,
        'trail_po_details' => true,
        'evaluation_remark' => true,
        'date_of_assessment' => true,
        'assessed_by' => true,
        'approved_by' => true,
        'owner_company_id' => true,
        'reference_number' => true,
        'date_of_creation' => true,
        'date_of_modification' => true,
        'created_by' => true,
        'modified_by' => true,
        'company_master' => true,
        'owner_company' => true
    ];
}
