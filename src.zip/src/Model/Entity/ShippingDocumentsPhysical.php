<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ShippingDocumentsPhysical Entity
 *
 * @property int $id
 * @property int $order_id
 * @property int $invoice_id
 * @property int $shipping_docs_master_id
 * @property string $file_name_with_path
 * @property string $ready_to_print
 *
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\ShippingDocsMaster $shipping_docs_master
 */
class ShippingDocumentsPhysical extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'order_id' => true,
        'invoice_id' => true,
        'shipping_docs_master_id' => true,
        'file_name_with_path' => true,
        'ready_to_print' => true,
        'order' => true,
        'invoice' => true,
        'shipping_docs_master' => true
    ];
}
