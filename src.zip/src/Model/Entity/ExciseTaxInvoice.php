<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ExciseTaxInvoice Entity
 *
 * @property int $id
 * @property int $order_id
 * @property int $invoice_id
 * @property int $buyer_purchase_order_id
 * @property int $order_acc_id
 * @property int $owner_company_id
 * @property string $tariff_no
 * @property string $location_code
 * @property string $rate_of_duty
 * @property string $transporter
 * @property string $vehicle_no
 * @property string $buyervat_no
 * @property string $buyercst_no
 * @property string $buyerecc_no
 * @property \Cake\I18n\FrozenDate $date_of_prepration_of_invoice
 * @property \Cake\I18n\FrozenDate $date_of_removal_of_goods
 * @property string $no_of_pkgs
 * @property float $assessable_value
 * @property string $excise_duty
 * @property float $grand_total
 * @property string $pla_entry_no
 * @property \Cake\I18n\FrozenDate $dated_pla
 * @property string $amount_pla
 * @property string $cenvat_entry_no
 * @property \Cake\I18n\FrozenDate $dated_cenvat
 * @property string $amount_cenvat
 * @property string $invoice_time
 * @property string $goods_time
 * @property string $excise_rs
 * @property string $print_status
 * @property string $invoice_no
 * @property \Cake\I18n\FrozenDate $invoice_date
 * @property int $consignee_id
 * @property \Cake\I18n\FrozenDate $buyer_wefv
 * @property \Cake\I18n\FrozenDate $buyer_wefc
 * @property string $consigneevat_no
 * @property \Cake\I18n\FrozenDate $consignee_wefv
 * @property string $consigneecst_no
 * @property \Cake\I18n\FrozenDate $consignee_wefc
 * @property string $consigneeecc_no
 * @property string $h_form
 * @property string $duty
 * @property string $duty_excise
 * @property string $duty_excise_rs
 * @property string $transport_duty
 * @property string $transport_excise_rs
 * @property string $others_duty
 * @property string $others_excise_rs
 * @property string $product_description
 * @property string $order_no
 * @property \Cake\I18n\FrozenDate $order_date
 * @property string $payment_term
 * @property float $qty
 * @property string $rate
 * @property int $created_by
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property int $uom_id
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\BuyerPurchaseOrder $buyer_purchase_order
 * @property \App\Model\Entity\OrderAcc $order_acc
 * @property \App\Model\Entity\Consignee $consignee
 * @property \App\Model\Entity\Uom $uom
 */
class ExciseTaxInvoice extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'order_id' => true,
        'invoice_id' => true,
        'buyer_purchase_order_id' => true,
        'order_acc_id' => true,
        'owner_company_id' => true,
        'tariff_no' => true,
        'location_code' => true,
        'rate_of_duty' => true,
        'transporter' => true,
        'vehicle_no' => true,
        'buyervat_no' => true,
        'buyercst_no' => true,
        'buyerecc_no' => true,
        'date_of_prepration_of_invoice' => true,
        'date_of_removal_of_goods' => true,
        'no_of_pkgs' => true,
        'assessable_value' => true,
        'excise_duty' => true,
        'grand_total' => true,
        'pla_entry_no' => true,
        'dated_pla' => true,
        'amount_pla' => true,
        'cenvat_entry_no' => true,
        'dated_cenvat' => true,
        'amount_cenvat' => true,
        'invoice_time' => true,
        'goods_time' => true,
        'excise_rs' => true,
        'print_status' => true,
        'invoice_no' => true,
        'invoice_date' => true,
        'consignee_id' => true,
        'buyer_wefv' => true,
        'buyer_wefc' => true,
        'consigneevat_no' => true,
        'consignee_wefv' => true,
        'consigneecst_no' => true,
        'consignee_wefc' => true,
        'consigneeecc_no' => true,
        'h_form' => true,
        'duty' => true,
        'duty_excise' => true,
        'duty_excise_rs' => true,
        'transport_duty' => true,
        'transport_excise_rs' => true,
        'others_duty' => true,
        'others_excise_rs' => true,
        'product_description' => true,
        'order_no' => true,
        'order_date' => true,
        'payment_term' => true,
        'qty' => true,
        'rate' => true,
        'owner_company' => true,
        'created_by' => true,
        'modified_by' => true,
        'date_of_creation' => true,
        'date_of_modification' => true,
        'uom_id' => true,
        'order' => true,
        'invoice' => true,
        'buyer_purchase_order' => true,
        'order_acc' => true,
        'consignee' => true,
        'uom' => true
    ];
}
