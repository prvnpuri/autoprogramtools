<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Product Entity
 *
 * @property int $id
 * @property int $group
 * @property int $subgroup
 * @property string $product_name
 * @property string $product_information
 * @property string $grade_name
 * @property string $well_known_grade_name
 * @property string $cas_no
 * @property string $einecs_no
 * @property string $hs_code
 * @property string $molecular_formula
 * @property string $molecular_weight
 * @property string $synonym1
 * @property string $synonym2
 * @property string $synonym3
 * @property string $td_status
 * @property string $td_created_by
 * @property string $td_modified_by
 * @property string $msds_status
 * @property string $msds_created_by
 * @property string $msds_modified_by
 * @property string $coa_status
 * @property string $coa_created_by
 * @property string $coa_modified_by
 * @property \Cake\I18n\FrozenTime $modified_timestamp
 * @property string $application1
 * @property string $application2
 * @property string $application3
 * @property string $benefit1
 * @property string $benefit2
 * @property string $benefit3
 * @property string $solubility_at
 * @property string $dosage
 * @property string $is_compound
 * @property int $has_techds_pdf
 * @property int $has_msds_pdf
 */
class Product extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'group' => true,
        'subgroup' => true,
        'product_name' => true,
        'product_information' => true,
        'grade_name' => true,
        'well_known_grade_name' => true,
        'cas_no' => true,
        'einecs_no' => true,
        'hs_code' => true,
        'molecular_formula' => true,
        'molecular_weight' => true,
        'synonym1' => true,
        'synonym2' => true,
        'synonym3' => true,
        'td_status' => true,
        'td_created_by' => true,
        'td_modified_by' => true,
        'msds_status' => true,
        'msds_created_by' => true,
        'msds_modified_by' => true,
        'coa_status' => true,
        'coa_created_by' => true,
        'coa_modified_by' => true,
        'modified_timestamp' => true,
        'application1' => true,
        'application2' => true,
        'application3' => true,
        'benefit1' => true,
        'benefit2' => true,
        'benefit3' => true,
        'solubility_at' => true,
        'dosage' => true,
        'is_compound' => true,
        'has_techds_pdf' => true,
        'has_msds_pdf' => true
    ];
}
