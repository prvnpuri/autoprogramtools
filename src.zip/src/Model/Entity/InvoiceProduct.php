<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * InvoiceProduct Entity
 *
 * @property int $id
 * @property string $tax_amount_data
 * @property int $invoice_id
 * @property int $order_id
 * @property int $product_id
 * @property string $batch_no
 * @property string $bold_no
 * @property string $unique_series_no
 * @property string $bold_no2
 * @property string $unique_series_no2
 * @property float $rate
 * @property float $qty
 * @property int $uom_id
 * @property float $amount_wo_tax
 * @property float $discount
 * @property float $total_amount_wi_discount
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\Uom $uom
 */
class InvoiceProduct extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'tax_amount_data' => true,
        'invoice_id' => true,
        'order_id' => true,
        'product_id' => true,
        'rate' => true,
        'qty' => true,
        'uom_id' => true,
    	'kind_of_pkg' => true,
    	'marks_nos' => true,
    	'amount_wo_tax' => true,
        'discount' => true,
    	'discount_amount'=>true,	
        'total_amount_wi_discount' => true,
        'invoice' => true,
        'order' => true,
        'products_master' => true,
        'uom' => true,
        'net_amount'=>true,
        'invoice_taxes'=>true,
    	'currency_id'=>true	,
    	'invoice_product_batches'=>true,
    	'invoice_product_boldno'=>true	
    ];
}
