<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ProductSolubilityTest Entity
 *
 * @property int $id
 * @property int $products_master_id
 * @property string $solvent
 * @property string $solubility
 * @property string $unit
 *
 * @property \App\Model\Entity\ProductsMaster $products_master
 */
class ProductSolubilityTest extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'products_master_id' => true,
        'solvent' => true,
        'solubility' => true,
        'unit' => true,
        'products_master' => true
    ];
}
