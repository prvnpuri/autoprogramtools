<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * BoldNoInventoryTran Entity
 *
 * @property int $id
 * @property string $transaction_type
 * @property int $inventory_id
 * @property int $from
 * @property int $to
 * @property int $del_status
 * @property int $bold_number_inventory_id
 * @property string $invoice_number
 * @property int $product_id
 * @property int $total
 * @property \Cake\I18n\FrozenDate $added_date
 * @property int $order_id
 * @property int $oa_id
 * @property int $invoice_done
 *
 * @property \App\Model\Entity\Inventory $inventory
 * @property \App\Model\Entity\BoldNumberInventory $bold_number_inventory
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Oa $oa
 */
class BoldNoInventoryTran extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'transaction_type' => true,
        'inventory_id' => true,
        'from' => true,
        'to' => true,
        'del_status' => true,
        'bold_number_inventory_id' => true,
        'invoice_number' => true,
        'product_id' => true,
        'total' => true,
        'added_date' => true,
        'order_id' => true,
        'oa_id' => true,
        'invoice_done' => true,
        'inventory' => true,
        'bold_number_inventory' => true,
        'product' => true,
        'order' => true,
        'oa' => true
    ];
}
