<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Offer Entity
 *
 * @property int $id
 * @property int $inquiry_id
 * @property string $reference_number
 * @property \Cake\I18n\FrozenDate $offer_date
 * @property int $packing_required
 * @property int $delivery_terms
 * @property int $payment_terms
 * @property int $local_offer
 * @property float $offer_price
 * @property \Cake\I18n\FrozenDate $offer_validity
 * @property string $opening_comments
 * @property string $closing_comments
 * @property int $status
 * @property \Cake\I18n\FrozenDate $offer_submitted_date
 * @property int $port_of_discharge
 * @property int $country_of_final_destination
 * @property int $offering_company
 * @property int $owner_companies_id
 * @property float $qty_offered
 * @property int $uom_id
 * @property int $currency_id
 * @property int $inco_terms
 * @property float $total_order_value
 * @property string $offer_archive
 * @property int $validity_reminder_sent_flag
 * @property \Cake\I18n\FrozenDate $validity_reminder_sent_date
 * @property int $date_age_reminder_sent_flag
 * @property \Cake\I18n\FrozenDate $date_age_reminder_sent_date
 * @property string $labeling_details
 * @property string $penalty_clause
 * @property string $other_details
 * @property string $lead_time
 * @property string $send_to_submit
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\Inquiry $inquiry
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\Currency $currency
 * @property \App\Model\Entity\Order[] $order
 * @property \App\Model\Entity\OrderReview[] $order_reviews
 */
class Offer extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'inquiry_id' => true,
        'reference_number' => true,
        'offer_date' => true,
        'packing_required' => true,
        'delivery_terms' => true,
        'payment_terms' => true,
        'local_offer' => true,
        'offer_price' => true,
        'offer_validity' => true,
        'opening_comments' => true,
        'closing_comments' => true,
    	'status' => true,
    	'countries_id' => true,
        'offer_submitted_date' => true,
        'port_of_discharge_id' => true,
        'country_final_destination' => true,
        'offering_company' => true,
        'owner_companies_id' => true,
        'qty_offered' => true,
        'uom_id' => true,
        'currency_id' => true,
        'inco_terms' => true,
        'total_order_value' => true,
        'offer_archive' => true,
        'validity_reminder_sent_flag' => true,
        'validity_reminder_sent_date' => true,
        'date_age_reminder_sent_flag' => true,
        'date_age_reminder_sent_date' => true,
        'labeling_details' => true,
        'penalty_clause' => true,
        'other_details' => true,
        'lead_time' => true,
        'send_to_submit' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'inquiry' => true,
        'owner_company' => true,
        'uom' => true,
        'currency' => true,
        'order' => true,
        'order_reviews' => true,
    	'country_of_origin_of_goods'=>true,
    	'company_master_id' => true,
    	'products_master_id' => true
    ];
}
