<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PreShipmentSdf Entity
 *
 * @property int $id
 * @property int $invoice_id
 * @property int $oa_id
 * @property string $shipping_bill_no
 * @property \Cake\I18n\FrozenDate $shipping_bill_date
 * @property string $ready_to_print
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\Oa $oa
 */
class PreShipmentSdf extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_id' => true,
        'oa_id' => true,
        'shipping_bill_no' => true,
        'shipping_bill_date' => true,
        'ready_to_print' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'invoice' => true,
        'oa' => true
    ];
}
