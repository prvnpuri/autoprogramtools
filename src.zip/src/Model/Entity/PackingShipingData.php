<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PackingShipingData Entity
 *
 * @property int $id
 * @property int $invoice_id
 * @property int $invoice_product_id
 * @property int $product_id
 * @property int $gross_weight
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\InvoiceProduct $invoice_product
 * @property \App\Model\Entity\ProductsMaster $product_id
 */
class PackingShipingData extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_id' => true,
        'invoice_product_id' => true,
        'product_id' => true,
        'gross_weight' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'invoice' => true,
        'invoice_product' => true,
        'products_master' => true,
    	'uom_id'=>true	
    ];
}
