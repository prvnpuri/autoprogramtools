<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * BatchsheetTran Entity
 *
 * @property int $id
 * @property int $batchsheet_master_id
 * @property string $name
 * @property string $description
 * @property string $batch_no
 * @property \Cake\I18n\FrozenDate $batchsheet_date
 * @property float $room_temp
 * @property int $room_temp_uom_id
 * @property float $total_yeild
 * @property int $total_yeild_uom_id
 * @property float $weight_crud_product
 * @property int $weight_crud_uom_id
 * @property string $batch_file
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\BatchsheetMaster $batchsheet_master
 * @property \App\Model\Entity\RoomTempUom $room_temp_uom
 * @property \App\Model\Entity\TotalYeildUom $total_yeild_uom
 * @property \App\Model\Entity\WeightCrudUom $weight_crud_uom
 * @property \App\Model\Entity\BatchsheetBom[] $batchsheet_bom
 * @property \App\Model\Entity\BatchsheetStepsTran[] $batchsheet_steps_tran
 * @property \App\Model\Entity\MaterialRequest[] $material_request
 * @property \App\Model\Entity\ProductionBatch[] $production_batches
 */
class BatchsheetTran extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'batchsheet_master_id' => true,
        'name' => true,
        'description' => true,
        'batch_no' => true,
        'batchsheet_date' => true,
        'room_temp' => true,
        'room_temp_uom_id' => true,
        'total_yeild' => true,
        'total_yeild_uom_id' => true,
        'weight_crud_product' => true,
        'weight_crud_uom_id' => true,
        'batch_file' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'batchsheet_master' => true,
        'room_temp_uom' => true,
        'total_yeild_uom' => true,
        'weight_crud_uom' => true,
        'batchsheet_bom' => true,
        'batchsheet_steps_tran' => true,
        'material_request' => true,
        'production_batches' => true
    ];
}
