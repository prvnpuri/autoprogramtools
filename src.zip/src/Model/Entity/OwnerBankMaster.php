<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OwnerBankMaster Entity
 *
 * @property int $id
 * @property int $owner_companies_id
 * @property string $name
 * @property string $bank_name
 * @property string $account_no
 * @property string $ifsc
 * @property string $account_name
 * @property string $address
 * @property string $status
 * @property string $swift_code
 * @property int $currency_id
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\Currency $currency
 */
class OwnerBankMaster extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'owner_companies_id' => true,
        'name' => true,
        'bank_name' => true,
        'account_no' => true,
        'ifsc' => true,
        'account_name' => true,
        'address' => true,
        'status' => true,
        'swift_code' => true,
        'currency_id' => true,
        'owner_company' => true,
        'currency' => true
    ];
}
