<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * FeasibilityParticular Entity
 *
 * @property int $id
 * @property int $particular_master_id
 * @property int $feasibility_master_id
 * @property string $comments
 * @property bool $feasibility
 *
 * @property \App\Model\Entity\ParticularMaster $particular_master
 * @property \App\Model\Entity\FeasibilityMaster $feasibility_master
 */
class FeasibilityParticular extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'particular_master_id' => true,
        'feasibility_master_id' => true,
        'comments' => true,
        'feasibility' => true,
        'particular_master' => true,
        'feasibility_master' => true
    ];
}
