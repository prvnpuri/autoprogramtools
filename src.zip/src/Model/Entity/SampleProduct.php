<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * SampleProduct Entity
 *
 * @property int $id
 * @property int $from_to_id
 * @property int $inward_id
 * @property int $outward_id
 * @property string $in_out_type
 * @property string $process_type
 * @property string $document_no
 * @property int $product_id
 * @property float $qty
 * @property int $uom_id
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property string $warehouse_master
 * @property int $owner_companies_id
 * @property \Cake\I18n\FrozenDate $date
 *
 * @property \App\Model\Entity\FromTo $from_to
 * @property \App\Model\Entity\Inward $inward
 * @property \App\Model\Entity\Outward $outward
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\Uom $uom
 * @property \App\Model\Entity\OwnerCompany $owner_company
 */
class SampleProduct extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'from_to_id' => true,
        'inward_id' => true,
        'outward_id' => true,
        'in_out_type' => true,
        'process_type' => true,
        'document_no' => true,
        'product_id' => true,
        'qty' => true,
        'uom_id' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'warehouse_master' => true,
        'owner_companies_id' => true,
        'date' => true,
        'from_to' => true,
        'inward' => true,
        'outward' => true,
        'product' => true,
        'uom' => true,
        'owner_company' => true
    ];
}
