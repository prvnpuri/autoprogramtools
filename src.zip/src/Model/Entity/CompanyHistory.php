<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * CompanyHistory Entity
 *
 * @property int $id
 * @property string $buy_or_sell
 * @property int $company_id
 * @property int $product_id
 * @property float $inquiry_qty
 * @property float $offer_qty
 * @property float $offer_rate
 * @property float $order_qty
 * @property float $order_rate
 * @property int $currency
 * @property int $rating
 * @property \Cake\I18n\FrozenDate $last_transaction_date
 *
 * @property \App\Model\Entity\Company $company
 * @property \App\Model\Entity\Product $product
 */
class CompanyHistory extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'buy_or_sell' => true,
        'company_id' => true,
        'product_id' => true,
    	'inquiry_id' => true,
        'inquiry_qty' => true,
    	'inquiry_rate'=>true,
        'offer_qty' => true,
        'offer_rate' => true,
        'order_qty' => true,
        'order_rate' => true,
        'currency' => true,
        'rating' => true,
        'last_transaction_date' => true,
    	'rate' => true,
    	'uom_id' => true,
    	'owner_company_id' => true,
    	'inquiry_date' => true,
    	'offer_date' => true,
    	'order_date' => true,
    	'financial_year' => true,
    	'is_local' => true,
    		
     
    ];
}
