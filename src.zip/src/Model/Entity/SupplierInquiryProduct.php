<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * SupplierInquiryProduct Entity
 *
 * @property int $id
 * @property int $supplier_inquiry_id
 * @property int $product_id
 * @property float $qty_required
 * @property int $uom_id
 *
 * @property \App\Model\Entity\SupplierInquiry $supplier_inquiry
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\Uom $uom
 */
class SupplierInquiryProduct extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'supplier_inquiry_id' => true,
        'product_id' => true,
        'qty_required' => true,
        'uom_id' => true,
        'supplier_inquiry' => true,
        'product' => true,
        'uom' => true,
        'packingMaster_id' => true
    ];
}
