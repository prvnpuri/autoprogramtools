<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PreshipmentTsca Entity
 *
 * @property int $id
 * @property int $order_id
 * @property int $invoice_id
 * @property int $order_acc_id
 * @property int $owner_company_id
 * @property string $print_status
 * @property \Cake\I18n\FrozenDate $date
 * @property string $signatory_name
 * @property string $title
 * @property string $airway_bill_no
 * @property int $created_by
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property \Cake\I18n\FrozenDate $date_of_modification
 *
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\OrderAcc $order_acc
 * @property \App\Model\Entity\OwnerCompany $owner_company
 */
class PreshipmentTsca extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'order_id' => true,
        'invoice_id' => true,
        'order_acc_id' => true,
        'owner_company_id' => true,
        'print_status' => true,
        'date' => true,
        'signatory_name' => true,
        'title' => true,
        'airway_bill_no' => true,
        'created_by' => true,
        'modified_by' => true,
        'date_of_creation' => true,
        'date_of_modification' => true,
        'order' => true,
        'invoice' => true,
        'order_acc' => true,
        'owner_company' => true
    ];
}
