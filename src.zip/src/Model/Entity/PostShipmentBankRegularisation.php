<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PostShipmentBankRegularisation Entity
 *
 * @property int $id
 * @property int $oa_id
 * @property string $invoice_number
 * @property string $firm_name
 * @property string $address
 * @property string $iec
 * @property string $shipping_bill_no
 * @property \Cake\I18n\FrozenDate $shipping_bill_date
 * @property string $bank_name
 * @property string $bank_file_no
 * @property string $bill_id_no
 * @property string $bank_realisation_certificate_no
 * @property \Cake\I18n\FrozenDate $date_of_realisation_of_money_by_bank
 * @property string $realised_value_in_foreign_currency
 * @property string $currency_of_realisation
 * @property \Cake\I18n\FrozenDate $date_and_time_of_printing
 * @property string $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property string $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property string $time
 *
 * @property \App\Model\Entity\Oa $oa
 */
class PostShipmentBankRegularisation extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'oa_id' => true,
        'invoice_number' => true,
        'firm_name' => true,
        'address' => true,
        'iec' => true,
        'shipping_bill_no' => true,
        'shipping_bill_date' => true,
        'bank_name' => true,
        'bank_file_no' => true,
        'bill_id_no' => true,
        'bank_realisation_certificate_no' => true,
        'date_of_realisation_of_money_by_bank' => true,
        'realised_value_in_foreign_currency' => true,
        'currency_of_realisation' => true,
        'date_and_time_of_printing' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'time' => true,
        'oa' => true
    ];
}
