<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * CustomerSatisfactionSurvey Entity
 *
 * @property int $id
 * @property int $company_id
 * @property int $owner_company_id
 * @property string $contact_persons
 * @property string $add_emails
 * @property string $cc
 * @property string $message
 * @property string $adverse_feedback
 * @property \Cake\I18n\FrozenTime $sent_mail_date
 * @property string $reference_no
 * @property string $customer_suggestion
 * @property string $action_taken
 * @property string $remarks
 * @property string $received_file
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property \Cake\I18n\FrozenDate $survey_period_from_date
 * @property \Cake\I18n\FrozenDate $survey_period_to_date
 *
 * @property \App\Model\Entity\Company $company
 * @property \App\Model\Entity\OwnerCompany $owner_company
 */
class CustomerSatisfactionSurvey extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'company_id' => true,
        'owner_company_id' => true,
        'contact_persons' => true,
        'add_emails' => true,
        'cc' => true,
        'message' => true,
        'adverse_feedback' => true,
        'sent_mail_date' => true,
        'reference_no' => true,
        'customer_suggestion' => true,
        'action_taken' => true,
        'remarks' => true,
        'received_file' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'survey_period_from_date' => true,
        'survey_period_to_date' => true,
        'company' => true,
        'owner_company' => true
    ];
}
