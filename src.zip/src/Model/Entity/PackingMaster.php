<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PackingMaster Entity
 *
 * @property int $id
 * @property int $paking_type
 * @property int $packing_subtype
 * @property string $specification
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property string $color
 * @property string $description
 * @property int $uom
 * @property string $length
 * @property string $breadth
 * @property string $height
 * @property string $diameter
 * @property string $volume
 * @property string $thikness
 * @property int $printed_plain
 * @property int $inner_bag
 */
class PackingMaster extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
    	'paking_type' => true,
    	'packing_subtype' => true,
        'paking_type_id' => true,
        'packing_subtype_id' => true,
        'specification' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'color' => true,
        'description' => true,
        'uom_id' => true,
        'length' => true,
        'breadth' => true,
        'height' => true,
        'diameter' => true,
        'volume' => true,
        'thikness' => true,
        'printed_plain' => true,
        'inner_bag' => true,
    	'supplier_inquiry'=>true,	
    ];
}
