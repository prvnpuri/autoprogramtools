<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ConsumableInventoryDetail Entity
 *
 * @property int $id
 * @property int $consumable_inventory_id
 * @property int $inward_id
 * @property int $consumable_store_id
 * @property string $batch_number
 * @property string $lot_number
 * @property \Cake\I18n\FrozenDate $in_date
 * @property \Cake\I18n\FrozenDate $expiry_date
 * @property float $balance_qty
 * @property int $uom
 * @property float $total_qty
 * @property int $total_uom
 * @property float $blocked_qty
 * @property int $blocked_uom
 *
 * @property \App\Model\Entity\ConsumableInventory $consumable_inventory
 * @property \App\Model\Entity\Inward $inward
 * @property \App\Model\Entity\WarehouseUnit $warehouse_unit
 * @property \App\Model\Entity\WarehouseSubunit $warehouse_subunit
 */
class ConsumableInventoryDetail extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'consumable_inventory_id' => true,
        'inward_id' => true,
        'consumable_store_id' => true,
        'batch_number' => true,
        'lot_number' => true,
        'in_date' => true,
        'expiry_date' => true,
        'balance_qty' => true,
        'uom' => true,
        'total_qty' => true,
        'total_uom' => true,
        'blocked_qty' => true,
        'blocked_uom' => true,
        'consumable_inventory' => true,
        'inward' => true,
        
    ];
}
