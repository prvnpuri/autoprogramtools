<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OwnerCompanyAsset Entity
 *
 * @property int $id
 * @property int $owner_companies_id
 * @property int $asset_location
 * @property int $assets_master_id
 * @property string $asset_tag
 * @property int $po_reference
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\AssetsMaster $assets_master
 */
class OwnerCompanyAsset extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'owner_companies_id' => true,
        'asset_location' => true,
        'assets_master_id' => true,
        'asset_tag' => true,
        'po_reference' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'owner_company' => true,
        'assets_master' => true
    ];
}
