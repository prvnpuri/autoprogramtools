<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PostShipmentBillOfLading Entity
 *
 * @property int $id
 * @property int $shipper_exporter
 * @property int $consignee
 * @property string $notify
 * @property string $bill_of_landing_no
 * @property \Cake\I18n\FrozenDate $bill_of_lading_date
 * @property string $invoice_no
 * @property string $ocean_vessel
 * @property string $voyage_number
 * @property int $port_of_loading
 * @property int $port_of_discharge
 * @property string $container_no
 * @property string $seal_no
 * @property string $quantity
 * @property string $created_by
 * @property string $modified_by
 * @property \Cake\I18n\FrozenDate $created_date
 * @property \Cake\I18n\FrozenDate $modified_date
 * @property int $oa_id
 * @property string $bill_of_lading
 *
 * @property \App\Model\Entity\Oa $oa
 */
class PostShipmentBillOfLading extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'shipper_exporter' => true,
        'consignee' => true,
        'notify' => true,
        'bill_of_landing_no' => true,
        'bill_of_lading_date' => true,
        'invoice_no' => true,
        'ocean_vessel' => true,
        'voyage_number' => true,
        'port_of_loading' => true,
        'port_of_discharge' => true,
        'container_no' => true,
        'seal_no' => true,
        'quantity' => true,
        'created_by' => true,
        'modified_by' => true,
        'created_date' => true,
        'modified_date' => true,
        'oa_id' => true,
        'bill_of_lading' => true,
        'oa' => true
    ];
}
