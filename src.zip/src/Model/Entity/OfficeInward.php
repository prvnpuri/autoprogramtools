<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OfficeInward Entity
 *
 * @property int $id
 * @property int $owner_company_id
 * @property int $s_no
 * @property string $received_from
 * @property string $document_details
 * @property int $document_for
 * @property \Cake\I18n\FrozenDate $inward_date
 * @property \Cake\I18n\FrozenDate $delivered_date
 * @property int $is_delivered
 * @property bool $status
 * @property int $currently_with
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property string $reference_number
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\OfficeInwardActivity[] $office_inward_activity
 */
class OfficeInward extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'owner_company_id' => true,
        's_no' => true,
        'received_from' => true,
        'document_details' => true,
        'document_for' => true,
        'inward_date' => true,
        'delivered_date' => true,
        'is_delivered' => true,
		'forward_to'=>true,
        'status' => true,
        'currently_with' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'reference_number' => true,
        'owner_company' => true,
        'office_inward_activity' => true
    ];
}
