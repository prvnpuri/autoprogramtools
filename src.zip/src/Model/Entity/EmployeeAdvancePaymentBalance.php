<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * EmployeeAdvancePaymentBalance Entity
 *
 * @property int $id
 * @property int $employee_details_id
 * @property float $total_amount_balance
 *
 * @property \App\Model\Entity\EmployeeDetail $employee_detail
 */
class EmployeeAdvancePaymentBalance extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'employee_details_id' => true,
        'total_amount_balance' => true,
        'employee_detail' => true
    ];
}
