<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * AssetMaintenanceRecord Entity
 *
 * @property int $id
 * @property int $assets_master_id
 * @property int $asset_maintenance_schedule_id
 * @property \Cake\I18n\FrozenDate $maintenance_date
 * @property string $maintenance_report
 *
 * @property \App\Model\Entity\AssetsMaster $assets_master
 * @property \App\Model\Entity\AssetMaintenanceSchedule $asset_maintenance_schedule
 */
class AssetMaintenanceRecord extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'assets_master_id' => true,
        'asset_maintenance_schedule_id' => true,
        'maintenance_date' => true,
        'maintenance_report' => true,
        'assets_master' => true,
        'asset_maintenance_schedule' => true
    ];
}
