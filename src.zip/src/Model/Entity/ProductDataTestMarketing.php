<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ProductDataTest Entity
 *
 * @property int $id
 * @property int $products_master_id
 * @property string $test
 * @property string $specification
 * @property string $methods
 * @property string $purpose
 *
 * @property \App\Model\Entity\ProductsMaster $products_master
 */
class ProductDataTestMarketing extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'products_master_id' => true,
        'test' => true,
        'specification' => true,
        'methods' => true,
        'purpose' => true,
        'products_master_marketing' => true
    ];
}
