<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MaterialRequest Entity
 *
 * @property int $id
 * @property int $batchsheet_tran_id
 * @property string $reference_number
 * @property \Cake\I18n\FrozenDate $request_date
 * @property string $product_type
 * @property string $status
 *
 * @property \App\Model\Entity\MaterialRequestDetail[] $material_request_details
 */
class MaterialRequest extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'batchsheet_tran_id' => true,
        'reference_number' => true,
        'request_date' => true,
        'product_type' => true,
        'status' => true,
        'material_request_details' => true,
    	'send_to_approve'=>true	,
    	'send_to_pr'=>true,
    	'is_materialrequest'=>true,
    	'is_approve'=>true,
    	'ready_to_pr'=>true	,
    	'created'=>true,
    	'created_by'=>true,
    	'modified'=>true,
    	'modified_by'=>true	
    	
    ];
}
