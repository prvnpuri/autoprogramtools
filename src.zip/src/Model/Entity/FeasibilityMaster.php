<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * FeasibilityMaster Entity
 *
 * @property int $id
 * @property int $inquiry_id
 * @property string $reason_for_regret
 * @property bool $offer_feasible
 * @property \Cake\I18n\FrozenDate $feasibility_date
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 * @property string $reference_number
 * @property int $supplier_id
 *
 * @property \App\Model\Entity\Inquiry $inquiry
 * @property \App\Model\Entity\Supplier $supplier
 * @property \App\Model\Entity\FeasibilityParticular[] $feasibility_particular
 */
class FeasibilityMaster extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'inquiry_id' => true,
        'reason_for_regret' => true,
        'offer_feasible' => true,
        'feasibility_date' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'reference_number' => true,
        'supplier_id' => true,
        'inquiry' => true,
        'supplier' => true,
        'feasibility_particular' => true,
    	'company_master' => true,
    ];
}
