<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PettyCashMonthlyBalance Entity
 *
 * @property int $id
 * @property string $month
 * @property float $total_amount
 * @property float $net_balance_amount
 * @property int $sublocation
 * @property int $owner_company_id
 * @property bool $entry_status
 * @property int $created_by
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 */
class PettyCashMonthlyBalance extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'month' => true,
        'total_amount' => true,
        'net_balance_amount' => true,
        'sublocation' => true,
        'owner_company_id' => true,
        'entry_status' => true,
        'created_by' => true,
        'owner_company' => true
    ];
}
