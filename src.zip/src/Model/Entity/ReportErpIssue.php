<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ReportErpIssue Entity
 *
 * @property int $id
 * @property int $assign_to
 * @property string $issue_url
 * @property string $program_error_data
 * @property string $issue_description
 * @property string $issue_status
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $issue_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 * @property string $status
 */
class ReportErpIssue extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'assign_to' => true,
        'issue_url' => true,
        'program_error_data' => true,
        'issue_description' => true,
        'issue_status' => true,
        'date_of_creation' => true,
        'issue_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'status' => true
    ];
}
