<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * IndustryTypeMaster Entity
 *
 * @property int $id
 * @property string $acronym
 * @property string $industry_type
 * @property string $industry_description
 *
 * @property \App\Model\Entity\CompanyIndustryType[] $company_industry_types
 * @property \App\Model\Entity\ProductIndustryApplication[] $product_industry_applications
 */
class IndustryTypeMaster extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'acronym' => true,
        'industry_type' => true,
        'industry_description' => true,
        'company_industry_types' => true,
        'product_industry_applications' => true
    ];
}
