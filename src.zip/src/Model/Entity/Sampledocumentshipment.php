<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Sampledocumentshipment Entity
 *
 * @property int $id
 * @property int $shipper_id
 * @property int $consignee_id
 * @property string $description
 * @property string $declared_value
 * @property int $shipped_by
 * @property string $airway_bill_no
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property int $shipment_type
 *
 * @property \App\Model\Entity\Shipper $shipper
 * @property \App\Model\Entity\Consignee $consignee
 */
class Sampledocumentshipment extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'shipper_id' => true,
        'consignee_id' => true,
        'description' => true,
        'declared_value' => true,
        'shipped_by' => true,
        'airway_bill_no' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'shipment_type' => true,
        'shipper' => true,
        'consignee' => true
    ];
}
