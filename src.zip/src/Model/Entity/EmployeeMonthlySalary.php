<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * EmployeeMonthlySalary Entity
 *
 * @property int $id
 * @property int $employee_salary_master_id
 * @property string $month
 * @property float $basic_sal
 * @property float $hra
 * @property float $conveyance_allowance
 * @property float $medical_allowance
 * @property float $professional_tax
 * @property float $leave_travel_allowance
 * @property float $special_allowance
 * @property float $telephone_reimbursement
 * @property float $chidlren_education_allowance
 * @property float $city_compensation_allowance
 * @property float $total_ctc
 * @property int $employee_details_id
 * @property float $advanced_payment
 * @property int $leave_taken
 * @property float $paid_leave_deduction
 * @property float $net_amount
 * @property float $total_deduction
 * @property int $present_day
 * @property float $total_payment
 * @property int $employee_advance_payment_id
 * @property string $employee_monthly_salariescol
 * @property float $incentive_amount
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $created_by
 * @property float $income_tax
 *
 * @property \App\Model\Entity\EmployeeSalaryMaster $employee_salary_master
 * @property \App\Model\Entity\EmployeeDetail $employee_detail
 * @property \App\Model\Entity\EmployeeAdvancePayment $employee_advance_payment
 */
class EmployeeMonthlySalary extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'employee_salary_master_id' => true,
        'month' => true,
        'basic_sal' => true,
        'hra' => true,
        'conveyance_allowance' => true,
        'medical_allowance' => true,
        'professional_tax' => true,
        'leave_travel_allowance' => true,
        'special_allowance' => true,
        'telephone_reimbursement' => true,
        'chidlren_education_allowance' => true,
        'city_compensation_allowance' => true,
        'total_ctc' => true,
        'employee_details_id' => true,
        'advanced_payment' => true,
        'leave_taken' => true,
        'paid_leave_deduction' => true,
        'net_amount' => true,
        'total_deduction' => true,
        'present_day' => true,
        'total_payment' => true,
        'employee_advance_payment_id' => true,
        'employee_monthly_salariescol' => true,
        'incentive_amount' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'income_tax' => true,
        'employee_salary_master' => true,
        'employee_detail' => true,
        'employee_advance_payment' => true
    ];
}
