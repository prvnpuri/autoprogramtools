<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * BatchsheetStepsTran Entity
 *
 * @property int $id
 * @property int $batchsheet_steps_id
 * @property int $batchsheet_tran_id
 * @property \Cake\I18n\FrozenDate $step_date
 * @property int $step_no
 * @property float $weight
 * @property int $weight_uom_id
 * @property float $distillation
 * @property int $distillation_uom_id
 * @property float $product_weight
 * @property int $product_weight_uom_id
 * @property float $start_time
 * @property int $start_time_uom_id
 * @property float $finish_time
 * @property int $finish_time_uom_id
 * @property float $total_time
 * @property int $total_time_uom_id
 * @property float $start_temp
 * @property int $start_temp_uom_id
 * @property float $end_temp
 * @property int $end_temp_uom_id
 * @property string $ph
 * @property string $LOD
 *
 * @property \App\Model\Entity\BatchsheetStepsMaster $batchsheet_steps_master
 * @property \App\Model\Entity\BatchsheetTran $batchsheet_tran
 * @property \App\Model\Entity\WeightUom $weight_uom
 * @property \App\Model\Entity\DistillationUom $distillation_uom
 * @property \App\Model\Entity\ProductWeightUom $product_weight_uom
 * @property \App\Model\Entity\StartTimeUom $start_time_uom
 * @property \App\Model\Entity\FinishTimeUom $finish_time_uom
 * @property \App\Model\Entity\TotalTimeUom $total_time_uom
 * @property \App\Model\Entity\StartTempUom $start_temp_uom
 * @property \App\Model\Entity\EndTempUom $end_temp_uom
 */
class BatchsheetStepsTran extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'batchsheet_steps_id' => true,
        'batchsheet_tran_id' => true,
        'step_date' => true,
        'step_no' => true,
        'weight' => true,
        'weight_uom_id' => true,
        'distillation' => true,
        'distillation_uom_id' => true,
        'product_weight' => true,
        'product_weight_uom_id' => true,
        'start_time' => true,
        'start_time_uom_id' => true,
        'finish_time' => true,
        'finish_time_uom_id' => true,
        'total_time' => true,
        'total_time_uom_id' => true,
        'start_temp' => true,
        'start_temp_uom_id' => true,
        'end_temp' => true,
        'end_temp_uom_id' => true,
        'ph' => true,
        'LOD' => true,
        'batchsheet_steps_master' => true,
        'batchsheet_tran' => true,
        'weight_uom' => true,
        'distillation_uom' => true,
        'product_weight_uom' => true,
        'start_time_uom' => true,
        'finish_time_uom' => true,
        'total_time_uom' => true,
        'start_temp_uom' => true,
        'end_temp_uom' => true
    ];
}
