<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OwnerCompanyOffice Entity
 *
 * @property int $id
 * @property int $owner_companies_id
 * @property string $name
 * @property string $type
 * @property string $address
 * @property int $city
 * @property int $state
 * @property int $country
 * @property string $postal_code
 * @property string $phone_no
 * @property int $fax_no
 * @property string $ecc_no
 * @property string $_range
 * @property string $division
 * @property string $commissionerate
 * @property string $pan_no
 * @property string $vat_no
 * @property \Cake\I18n\FrozenDate $vat_no_wef
 * @property string $cst_no
 * @property \Cake\I18n\FrozenDate $cst_no_wef
 * @property string $adress_of_range
 * @property string $lbt_no
 * @property string $bin_number
 * @property string $name_of_bank
 * @property string $ac_number
 * @property string $ad_code
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\OwnerCompany $owner_companies
 * @property \App\Model\Entity\PreShipmentBase[] $pre_shipment_base
 */
class OwnerCompanyOffice extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'owner_companies_id' => true,
        'name' => true,
        'type' => true,
        'address' => true,
        'city' => true,
        'state' => true,
        'country' => true,
        'postal_code' => true,
        'phone_no' => true,
        'fax_no' => true,
        'ecc_no' => true,
        '_range' => true,
        'division' => true,
        'commissionerate' => true,
        'pan_no' => true,
        'vat_no' => true,
        'vat_no_wef' => true,
        'cst_no' => true,
        'cst_no_wef' => true,
        'adress_of_range' => true,
        'lbt_no' => true,
        'bin_number' => true,
        'name_of_bank' => true,
        'ac_number' => true,
        'ad_code' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'owner_company' => true,
        'pre_shipment_base' => true
    ];
}
