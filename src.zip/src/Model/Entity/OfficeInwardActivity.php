<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OfficeInwardActivity Entity
 *
 * @property int $id
 * @property int $office_inward_id
 * @property int $forward_to
 * @property int $forward_by
 * @property bool $status
 * @property string $comment
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 *
 * @property \App\Model\Entity\OfficeInward $office_inward
 */
class OfficeInwardActivity extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'office_inward_id' => true,
        'forward_to' => true,
        'forward_by' => true,
        'status' => true,
        'comment' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'office_inward' => true
    ];
}
