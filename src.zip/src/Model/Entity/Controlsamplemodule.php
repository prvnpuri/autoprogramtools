<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Controlsamplemodule Entity
 *
 * @property int $id
 * @property int $control_sample_id
 * @property \Cake\I18n\FrozenDate $sample_dispatched_date
 * @property int $dispatched_by
 * @property string $control_sample_sent_from_bag_no
 * @property string $control_sample_bottle_no
 * @property string $control_sample_bottle_photo
 * @property string $control_sample_bag_photo
 * @property string $comments_from_qc
 * @property int $courier_company
 * @property string $courier_airway_bill_no
 * @property string $courier_arranged_by
 * @property string $courier_sample_handed_over_by
 * @property \Cake\I18n\FrozenDate $sample_sending_date
 * @property \Cake\I18n\FrozenDate $sample_delivered_on
 * @property string $sample_recieved_by
 * @property string $sample_sent
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property string $sample_delivered
 * @property string $move_to_delivered
 *
 * @property \App\Model\Entity\ControlSample $control_sample
 */
class Controlsamplemodule extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'control_sample_id' => true,
        'sample_dispatched_date' => true,
        'dispatched_by' => true,
        'control_sample_sent_from_bag_no' => true,
        'control_sample_bottle_no' => true,
        'control_sample_bottle_photo' => true,
        'control_sample_bag_photo' => true,
        'comments_from_qc' => true,
        'courier_company' => true,
        'courier_airway_bill_no' => true,
        'courier_arranged_by' => true,
        'courier_sample_handed_over_by' => true,
        'sample_sending_date' => true,
        'sample_delivered_on' => true,
        'sample_recieved_by' => true,
        'sample_sent' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'sample_delivered' => true,
        'move_to_delivered' => true,
        'control_sample' => true
    ];
}
