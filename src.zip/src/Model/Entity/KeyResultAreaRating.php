<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * KeyResultAreaRating Entity
 *
 * @property int $id
 * @property int $key_result_area_id
 * @property string $month_name
 * @property int $rating
 * @property int $created_by
 * @property int $modifed_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property \Cake\I18n\FrozenDate $date_of_modification
 *
 * @property \App\Model\Entity\KeyResultArea $key_result_area
 */
class KeyResultAreaRating extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'key_result_area_id' => true,
        'month_name' => true,
        'rating' => true,
        'created_by' => true,
        'modifed_by' => true,
        'date_of_creation' => true,
        'date_of_modification' => true,
        'key_result_area' => true
    ];
}
