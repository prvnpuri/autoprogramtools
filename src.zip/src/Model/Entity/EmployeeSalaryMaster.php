<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * EmployeeSalaryMaster Entity
 *
 * @property int $id
 * @property int $employee_details_id
 * @property float $basic_sal
 * @property float $hra
 * @property float $conveyance_allowance
 * @property float $medical_allowance
 * @property float $professional_tax
 * @property float $leave_travel_allowance
 * @property float $special_allowance
 * @property float $telephone_reimbursement
 * @property float $chidlren_education_allowance
 * @property float $city_compensation_allowance
 * @property float $total_ctc
 * @property string $employee_salarycol
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $created_by
 *
 * @property \App\Model\Entity\EmployeeDetail $employee_detail
 * @property \App\Model\Entity\EmployeeMonthlySalary[] $employee_monthly_salaries
 */
class EmployeeSalaryMaster extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'employee_details_id' => true,
        'basic_sal' => true,
        'hra' => true,
        'conveyance_allowance' => true,
        'medical_allowance' => true,
        'professional_tax' => true,
        'leave_travel_allowance' => true,
        'special_allowance' => true,
        'telephone_reimbursement' => true,
        'chidlren_education_allowance' => true,
        'city_compensation_allowance' => true,
        'total_ctc' => true,
        'employee_salarycol' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'employee_detail' => true,
        'employee_monthly_salaries' => true
    ];
}
