<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * CompanySetting Entity
 *
 * @property int $id
 * @property int $owner_companies_id
 * @property string $category
 * @property string $key
 * @property string $value
 * @property int $active
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 */
class CompanySetting extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'owner_companies_id' => true,
        'category' => true,
        'key' => true,
        'value' => true,
        'active' => true,
        'owner_company' => true
    ];
}
