<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PreShipmentShipperInstruction Entity
 *
 * @property int $id
 * @property int $invoice_id
 * @property int $oa_id
 * @property string $bl_or_airway_bill
 * @property int $federal_express_airway_bill
 * @property int $customs_invoice
 * @property int $packing_list
 * @property int $certificate_of_analysis
 * @property int $sdf_gr_form
 * @property int $non_hazardous_declaration
 * @property int $tsca
 * @property int $material_safety_data_sheet
 * @property int $export_value_declaration
 * @property int $excise_invoice
 * @property int $are_1
 * @property int $form_n
 * @property int $mumbai_noc
 * @property int $iec_code_copy
 * @property int $undertaking
 * @property int $adc_noc
 * @property int $gsp_form_a
 * @property int $octroi_permission_latter
 * @property int $nfei
 * @property int $defc
 * @property int $free
 * @property int $dfrc
 * @property int $euo
 * @property int $dept
 * @property int $re_export
 * @property int $drawback
 * @property string $inv_item_no
 * @property string $inv_item_no1
 * @property string $inv_item_no2
 * @property string $sbi_apt_acc_no
 * @property string $sbi_apt_acc_no1
 * @property string $dbk_rate
 * @property string $dbk_rate1
 * @property string $dbk_rate2
 * @property string $dbk_rate3
 * @property string $grp_code1
 * @property string $grp_code2
 * @property string $sr_no1
 * @property string $sr_no2
 * @property string $rate1
 * @property string $rate2
 * @property string $sion1
 * @property string $sion2
 * @property string $sion3
 * @property string $sion4
 * @property string $reg_no
 * @property \Cake\I18n\FrozenDate $date
 * @property string $federal_express_airway_bill_list
 * @property string $customs_invoice_list
 * @property string $packing_list_list
 * @property string $certificate_of_analysis_list
 * @property string $sdf_gr_form_list
 * @property string $non_hazardous_declaration_list
 * @property string $tsca_list
 * @property string $material_safety_data_sheet_list
 * @property string $export_value_declaration_list
 * @property string $excise_invoice_list
 * @property string $are_1_list
 * @property string $form_n_list
 * @property string $mumbai_noc_list
 * @property string $iec_code_copy_list
 * @property string $undertaking_list
 * @property string $adc_noc_list
 * @property string $gsp_form_a_list
 * @property string $octroi_permission_latter_list
 * @property string $special_instruction
 * @property string $ready_to_print
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date1
 * @property string $iec_code
 * @property string $bin_number
 * @property string $name_of_bank
 * @property string $ac_number
 * @property string $ad_code
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\Oa $oa
 */
class PreShipmentShipperInstruction extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_id' => true,
        'oa_id' => true,
        'bl_or_airway_bill' => true,
        'federal_express_airway_bill' => true,
        'customs_invoice' => true,
        'packing_list' => true,
        'certificate_of_analysis' => true,
        'sdf_gr_form' => true,
        'non_hazardous_declaration' => true,
        'tsca' => true,
        'material_safety_data_sheet' => true,
        'export_value_declaration' => true,
        'excise_invoice' => true,
        'are_1' => true,
        'form_n' => true,
        'mumbai_noc' => true,
        'iec_code_copy' => true,
        'undertaking' => true,
        'adc_noc' => true,
        'gsp_form_a' => true,
        'octroi_permission_latter' => true,
        'nfei' => true,
        'defc' => true,
        'free' => true,
        'dfrc' => true,
        'euo' => true,
        'dept' => true,
        're_export' => true,
        'drawback' => true,
        'inv_item_no' => true,
        'inv_item_no1' => true,
        'inv_item_no2' => true,
        'sbi_apt_acc_no' => true,
        'sbi_apt_acc_no1' => true,
        'dbk_rate' => true,
        'dbk_rate1' => true,
        'dbk_rate2' => true,
        'dbk_rate3' => true,
        'grp_code1' => true,
        'grp_code2' => true,
        'sr_no1' => true,
        'sr_no2' => true,
        'rate1' => true,
        'rate2' => true,
        'sion1' => true,
        'sion2' => true,
        'sion3' => true,
        'sion4' => true,
        'reg_no' => true,
        'date' => true,
        'federal_express_airway_bill_list' => true,
        'customs_invoice_list' => true,
        'packing_list_list' => true,
        'certificate_of_analysis_list' => true,
        'sdf_gr_form_list' => true,
        'non_hazardous_declaration_list' => true,
        'tsca_list' => true,
        'material_safety_data_sheet_list' => true,
        'export_value_declaration_list' => true,
        'excise_invoice_list' => true,
        'are_1_list' => true,
        'form_n_list' => true,
        'mumbai_noc_list' => true,
        'iec_code_copy_list' => true,
        'undertaking_list' => true,
        'adc_noc_list' => true,
        'gsp_form_a_list' => true,
        'octroi_permission_latter_list' => true,
        'special_instruction' => true,
        'ready_to_print' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'date1' => true,
        'iec_code' => true,
        'bin_number' => true,
        'name_of_bank' => true,
        'ac_number' => true,
        'ad_code' => true,
        'invoice' => true,
        'oa' => true
    ];
}
