<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * LedgerTransaction Entity
 *
 * @property int $id
 * @property int $owner_companies_id
 * @property int $transaction_id
 * @property int $transaction_type_id
 * @property \Cake\I18n\FrozenDate $transaction_date
 * @property int $ledger_accounts_id
 * @property string $bank_reference_number
 * @property string $source
 * @property string $narration
 * @property string $entry_side
 * @property float $ledger_amount
 * @property \Cake\I18n\FrozenTime $created
 * @property int $created_by
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\LedgerAccount $ledger_account
 * @property \App\Model\Entity\TransactionType $transaction_type
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\PurchaseOrder $purchase_order
 * @property \App\Model\Entity\InvoiceOrder $invoice_order
 */
class LedgerTransaction extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        "id"=>true,
        'owner_companies_id' => true,
        'transaction_id' => true,
        'transaction_type_id' => true,
        'transaction_date' => true,
        'ledger_accounts_id' => true,
        'bank_reference_number' => true,
        'source' => true,
        'narration' => true,
        'entry_side' => true,
        'ledger_amount' => true,
        'created' => true,
        'created_by' => true,
        'owner_company' => true,
        'ledger_account' => true,
        'transaction_type' => true,
        'order' => true,
        'invoice' => true,
        'purchase_order' => true,
        'invoice_order' => true
    ];
}
