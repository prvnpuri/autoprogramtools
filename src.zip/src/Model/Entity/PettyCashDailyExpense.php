<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * PettyCashDailyExpense Entity
 *
 * @property int $id
 * @property \Cake\I18n\FrozenDate $transaction_date
 * @property int $owner_company_id
 * @property string $description
 * @property string $receipt_no
 * @property float $in_amount
 * @property float $out_amount
 * @property int $sublocation
 * @property float $balance
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 * @property int $modified_by
 *
 * @property \App\Model\Entity\OwnerCompany $owner_company
 */
class PettyCashDailyExpense extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'transaction_date' => true,
        'owner_company_id' => true,
        'description' => true,
        'receipt_no' => true,
        'in_amount' => true,
        'out_amount' => true,
        'sublocation' => true,
        'balance' => true,
        'date_of_creation' => true,
        'created_by' => true,
        'date_of_modification' => true,
        'modified_by' => true,
        'owner_company' => true,
		'Company_name' => true
    ];
}
