<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ProductTaxonomyAssociate Entity
 *
 * @property int $id
 * @property string $dosage
 * @property string $polymer_resin
 * @property string $focus
 * @property string $product_type
 * @property string $product_formulation
 * @property string $industry_type
 * @property int $product_taxonomy_id
 * @property string $additional_information
 *
 * @property \App\Model\Entity\ProductTaxonomy $product_taxonomy
 */
class ProductTaxonomyAssociate extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'dosage' => true,
        'polymer_resin' => true,
        'focus' => true,
        'product_type' => true,
        'product_formulation' => true,
        'industry_type' => true,
        'product_taxonomy_id' => true,
        'additional_information' => true,
        'product_taxonomy' => true
    ];
}
