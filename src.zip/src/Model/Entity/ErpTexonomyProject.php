<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ErpTexonomyProject Entity
 *
 * @property int $id
 * @property int $product_id
 * @property int $prepare_by_id
 * @property string $chemical_name
 * @property string $grade_name
 * @property string $cas_no
 * @property string $product_name
 * @property string $general_use
 * @property string $product_description
 * @property string $menufacturer
 * @property int $company_id
 * @property string $address
 * @property string $prepared_by
 * @property \Cake\I18n\FrozenDate $date
 * @property string $composition
 * @property string $attach_msds_pdf
 * @property string $industry_type
 * @property int $genericenduse
 * @property int $created_by
 * @property \Cake\I18n\FrozenTime $date_of_creation
 * @property int $modified_by
 * @property \Cake\I18n\FrozenTime $date_of_modification
 *
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\PrepareBy $prepare_by
 * @property \App\Model\Entity\Company $company
 */
class ErpTexonomyProject extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'product_id' => true,
        'prepare_by_id' => true,
        'chemical_name' => true,
        'grade_name' => true,
        'cas_no' => true,
        'product_name' => true,
        'general_use' => true,
        'product_description' => true,
        'menufacturer' => true,
        'company_id' => true,
        'address' => true,
        'prepared_by' => true,
        'date' => true,
        'composition' => true,
        'attach_msds_pdf' => true,
        'industry_type' => true,
        'genericenduse' => true,
        'created_by' => true,
        'date_of_creation' => true,
        'modified_by' => true,
        'date_of_modification' => true,
        'product' => true,
        'prepare_by' => true,
        'company' => true
    ];
}
