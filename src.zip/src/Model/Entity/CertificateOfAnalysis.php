<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * CertificateOfAnalysis Entity
 *
 * @property int $id
 * @property int $order_id
 * @property int $invoice_id
 * @property int $test_id
 * @property string $result
 * @property string $print_status
 * @property int $created_by
 * @property int $modified_by
 * @property \Cake\I18n\FrozenDate $date_of_creation
 * @property \Cake\I18n\FrozenDate $date_of_modification
 * @property int $stamp
 * @property string $pre_post_flag
 * @property int $is_local
 *
 * @property \App\Model\Entity\Order $order
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\Test $test
 */
class CertificateOfAnalysis extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'order_id' => true,
        'invoice_id' => true,
        'test_id' => true,
        'result' => true,
        'print_status' => true,
        'created_by' => true,
        'modified_by' => true,
        'date_of_creation' => true,
        'date_of_modification' => true,
        'stamp' => true,
        'pre_post_flag' => true,
        'is_local' => true,
        'order' => true,
        'invoice' => true,
        'test' => true
    ];
}
