<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ConsumableInventory Entity
 *
 * @property int $id
 * @property int $product_id
 * @property string $product_type
 * @property int $owner_company_id
 * @property float $balance_qty
 * @property int $balance_uom
 * @property float $blocked_qty
 * @property int $blocked_uom
 *
 * @property \App\Model\Entity\Product $product
 * @property \App\Model\Entity\OwnerCompany $owner_company
 * @property \App\Model\Entity\ConsumableInventoryDetail[] $consumable_inventory_details
 */
class ConsumableInventory extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'product_id' => true,
        'product_type' => true,
        'owner_company_id' => true,
        'balance_qty' => true,
        'balance_uom' => true,
        'blocked_qty' => true,
        'blocked_uom' => true,
    	'test_request_id'=>true,
        'consumables_master' => true,
        'owner_company' => true,
        'consumable_inventory_details' => true
    ];
}
