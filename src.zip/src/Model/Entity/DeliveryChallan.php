<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * DeliveryChallan Entity
 *
 * @property int $id
 * @property int $invoice_id
 * @property string $challan_no
 * @property \Cake\I18n\FrozenTime $challan_date
 * @property string $lr_no
 * @property \Cake\I18n\FrozenTime $lr_date
 * @property \Cake\I18n\FrozenTime $date_of_supply
 * @property string $vehicle_number
 * @property string $photo
 * @property string $dc_photo
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 * @property int $created_by
 * @property int $modified_by
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\DeliveryChallanEwayBillPhoto[] $delivery_challan_eway_bill_photo
 * @property \App\Model\Entity\DeliveryChallanProduct[] $delivery_challan_product
 */
class DeliveryChallan extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_id' => true,
        'challan_no' => true,
        'challan_date' => true,
        'lr_no' => true,
        'lr_date' => true,
        'date_of_supply' => true,
        'vehicle_number' => true,
        'photo' => true,
        'dc_photo' => true,
        'created' => true,
        'modified' => true,
        'created_by' => true,
        'modified_by' => true,
        'invoice' => true,
        'delivery_challan_eway_bill_photo' => true,
        'delivery_challan_product' => true
    ];
}
