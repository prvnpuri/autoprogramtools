<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * RunningNumber Entity
 *
 * @property int $id
 * @property int $inquiry
 * @property int $offer
 * @property int $order
 * @property int $invoice
 * @property int $supplier_po
 * @property string $financial_year
 */
class RunningNumber extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'inquiry' => true,
        'offer' => true,
        'order' => true,
        'invoice' => true,
        'supplier_po' => true,
        'financial_year' => true
    ];
}
