<?php
namespace App\Event;
use Cake\Controller\ComponentRegistry;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\Event\EventListenerInterface;
use Cake\Network\Exception\NotFoundException;
use App\Model\Table\InvoicesTable;
use App\Model\Entity\Invoice;
/**
 * @author Admin
 *
 */
class InvoiceLedgerTransactionListener implements EventListenerInterface {
    public function implementedEvents()
    {
        return [
            'Model.Inquiry.salesInvoice' => 'updateLedgerForSalesInvoice',
            'Model.Inquiry.purchaseInvoice' => 'updateLedgerForPurchaseInvoice'
        ];
    }
    
    
    /**
     * @param Event $event
     * @param InvoicesTable $invoicesTable
     * @param Invoice $entity
     * @throws NotFoundException
     * @return bool
     */
    public function updateLedgerForPurchaseInvoice(Event $event, $invoicesTable, $entity){
        
        $total_amount=$entity->get("grand_total_amount");
        // Saving Invoice Transactions
        $TransactionComponent= (new ComponentRegistry())->load("Transaction");
        $transaction_no=$TransactionComponent->generate();
        
        // Vendor Company
        $vendorCompany=$invoicesTable->CompanyMaster->find("all")->where(["id"=>$entity->get("supplier_id")])->first();
        $vendorCondition=[
            "model_reference_name"=>"CompanyMaster",
            "model_reference_id"=>$vendorCompany->id
        ];
        
        $vendorAccount=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->LedgerAccounts->find("all")
        ->where($vendorCondition)->first();
        
        if( !isset( $vendorAccount)){
            throw new NotFoundException(__('Vendor Ledger account "{0}"  not found',$vendorCompany->get('Company_name')));
        }
        
        // Assets Account 
        $assetsAccount=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->LedgerAccounts->find("all")
        ->contain(['LedgerGroups']) ->where(["account_name"=>'Material Asset Account',"LedgerGroups.type"=>'Fixed Assets'])->first();
       
        if( !isset( $assetsAccount)){
            throw new NotFoundException(__('Asset account "{0}"  not found','Material Asset Account'));
        }
        
        
        // patching transaction
        $transactionType=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->TransactionType->find('all')
        ->where(["type"=>'Purchases'])->first();
        $InvoiceLedgerTransactions= $invoicesTable->InvoiceLedgerTransactions->find("list",[
            'keyField'=>'id',
            'valueField'=>'ledger_transactions_id'
        ])->select(['InvoiceLedgerTransactions.id','InvoiceLedgerTransactions.ledger_transactions_id'])
        ->contain(['TransactionType'])
        ->where([
            "invoice_id"=>$entity->get("id"),
            "TransactionType.type"=>$transactionType->get("id")
        ])->toArray();
        
        $LedgerTransactionList=[
            // Vendor will always be credited
            [
                "transaction_date"=>$entity->invoice_date,
                "owner_companies_id"=>$entity->owner_company_id,
                "transaction_type_id"=>$transactionType->get("id"),
                "ledger_accounts_id"=>$vendorAccount->get("id"),
                "bank_reference_number"=>"",
                "source"=>__("Invoices"),
                "narration"=>__("Purchase Invoice created and Vendor - {0} credited .",$vendorCompany->get("Company_name")),
                "entry_side"=>Configure::read("transactionEntrySide.CR"),
                "ledger_amount"=>$total_amount
            ],
            // Asset will debited
            [
                "transaction_date"=>$entity->invoice_date,
                "owner_companies_id"=>$entity->owner_company_id,
                "transaction_type_id"=>$transactionType->id,
                "ledger_accounts_id"=>$assetsAccount->id,
                "bank_reference_number"=>"",
                "source"=>__("Invoices"),
                "narration"=>__("Purchase Invoice created and debited from {0}.", $assetsAccount->get("account_name")),
                "entry_side"=>Configure::read("transactionEntrySide.DR"),
                "ledger_amount"=>$total_amount
            ]
        ];
        
        if($InvoiceLedgerTransactions!=null && count($InvoiceLedgerTransactions)>0){
            $LedgerTransactionEntities=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->find("all")
            ->where(["id"=>$InvoiceLedgerTransactions]);
            // need to re-code and re-thinking about
            $LedgerTransactionEntities=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->find("all")->where([
                "id"=>$InvoiceLedgerTransactions
            ]);
            
            $accountListWithLedgerTransactionIdList=[];
            
            foreach ($LedgerTransactionEntities as $LedgerTransaction){
                $accountListWithLedgerTransactionIdList[$LedgerTransaction->ledger_accounts_id]=$LedgerTransaction->id;
            };
            
            foreach ($LedgerTransactionList as &$transaction_data){
                $accountId=$transaction_data["ledger_accounts_id"];
                if(isset($accountListWithLedgerTransactionIdList[$accountId])){
                    $transaction_data["id"]=$accountListWithLedgerTransactionIdList[$accountId];
                }
            }
            
            $LedgerTransactionEntities=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->patchEntities($LedgerTransactionEntities, $LedgerTransactionList);
            
        }else{
            foreach ($LedgerTransactionList as &$transaction_data){
                $transaction_data["transaction_id"]=$transaction_no;
            }
            $LedgerTransactionEntities=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->newEntities($LedgerTransactionList);
        }
        
        
        // Steps 3: Saving invoice_ledger_transaction
        $InvoiceLedgerTransactionsModel=$invoicesTable->InvoiceLedgerTransactions;
        
        return $invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->saveTransactions($LedgerTransactionEntities,function($result) use($InvoiceLedgerTransactionsModel,$InvoiceLedgerTransactions,$entity){
            if($InvoiceLedgerTransactions==null || count($InvoiceLedgerTransactions)==0){
                Log::info($result->get("id"));
                return $InvoiceLedgerTransactionsModel->save($InvoiceLedgerTransactionsModel->newEntity([
                    "invoice_id"=>$entity->get("id"),
                    "ledger_transactions_id"=>$result->get("id")
                ]));
            }else{
                return true;
            }
            throw new  NotFoundException("Unable to save");
        });
        
        
    }
    
    
    
    /**
     * @param Event $event
     * @param InvoicesTable $invoicesTable
     * @param Invoice $entity
     * @throws NotFoundException
     * @return bool
     */
    public function updateLedgerForSalesInvoice(Event $event, $invoicesTable, $entity){
        // Saving Invoice Transactions
        $TransactionComponent= (new ComponentRegistry())->load("Transaction");
        $InvoiceLedgerTransactionEntity=null;
        // Client Details
        $buyer=$invoicesTable->CompanyMaster->find("all")->where(["id"=>$entity->get("order_buyer_id")])->first();
        // Owner details
        $ownerCompany=$invoicesTable->OwnerCompanies->find("all")->where(["id"=>$entity->get("owner_company_id")])->first();
        // grand total amount
        $total_amount=$entity->get("grand_total_amount");
        // Will be -- Pending Currency also taking care
        
        // Steps 1: Takinng Accounts for DR and CR,
        // Steps 1.1: Finding Buyer Account for DR
        $buyerCondition=[
            "model_reference_name"=>"CompanyMaster",
            "model_reference_id"=>$buyer->id
        ];
        $buyerAccount=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->LedgerAccounts->find("all")
        ->where($buyerCondition)->first();
        
        // Steps 1.2: Finding account name for Sales account to CR transaction
        /* Needs to discuss for perfect logic .  */
        /* Logic is finding by account name. */
        $salesAccount=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->LedgerAccounts->find("all")
        ->contain(['LedgerGroups']) ->where(["account_name"=>'Production Sales',"LedgerGroups.type"=>'Sales'])->first();
        $tradeDiscountAccount=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->LedgerAccounts->find("all")
        ->contain(['LedgerGroups']) ->where(["account_name"=>'Trade Discount',"LedgerGroups.type"=>'Sales'])->first();
        
        
        // Steps 2: Saving Ledger Transactions
        $transaction_no=$TransactionComponent->generate();
        //echo $transaction_no; exit();
        $transactionType=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->TransactionType->find('all')
        ->where(["type"=>'Sales'])->first();
        // Steps 2.1 Check transaction Availables if saving and accordingly build ledger transaction entity
        $InvoiceLedgerTransactions= $invoicesTable->InvoiceLedgerTransactions->find("list",[
            'keyField'=>'id',
            'valueField'=>'ledger_transactions_id'
        ])->select(['InvoiceLedgerTransactions.id','InvoiceLedgerTransactions.ledger_transactions_id'])
        ->contain(['TransactionType'])
        ->where([
            "invoice_id"=>$entity->get("id"),
            "TransactionType.type"=>$transactionType->get("id")
        ])->toArray();
        
        $total_qty_amount=0;
        $total_taxes_list=[];
        $total_discount_amount=0;
        $invoice_products=$entity->get('invoice_products');
        foreach ($invoice_products as $invoice_product){
            $total_qty_amount += $invoice_product->get('amount_wo_tax');
            $total_discount_amount +=$invoice_product->get('discount_amount');
            $invoice_product_taxes =$invoice_product->get('invoice_taxes');
            foreach ($invoice_product_taxes as $tax){
                $tax_master_id=$tax->get('taxes_master_id');
                if(!isset($total_taxes_list[$tax_master_id])){
                    $total_taxes_list[$tax_master_id]=0;
                }
                $total_taxes_list[$tax_master_id] +=$tax->get('amount');
            }
            
        }
        
        $InvoiceLedgerTransactionEntities=null;
        $LedgerTransactionEntities=null;
        $LedgerTransactionList=[
            // Customer will always be debited 
            [
                "transaction_date"=>$entity->invoice_date,
                "owner_companies_id"=>$entity->owner_company_id,
                "transaction_type_id"=>$transactionType->get("id"),
                "ledger_accounts_id"=>$buyerAccount->get("id"),
                "bank_reference_number"=>"",
                "source"=>__("Invoices"),
                "narration"=>__("Invoice {1} created and Credited from {0}.",$buyer->get("Company_name"),$entity->get('id')),
                "entry_side"=>Configure::read("transactionEntrySide.DR"),
                "ledger_amount"=>$total_amount
            ],
            // Sales account will always be credited 
            [
                "transaction_date"=>$entity->invoice_date,
                "owner_companies_id"=>$entity->owner_company_id,
                "transaction_type_id"=>$transactionType->id,
                "ledger_accounts_id"=>$salesAccount->id,
                "bank_reference_number"=>"",
                "source"=>__("Invoices"),
                "narration"=>__("Invoice {1} created and debited from {0}.", $salesAccount->get("account_name"),$entity->get('id')),
                "entry_side"=>Configure::read("transactionEntrySide.CR"),
                "ledger_amount"=>$total_qty_amount
            ]
        ];
        
        // discount ledger
        
        if($total_discount_amount>0){
            $LedgerTransactionList[]=[
                "transaction_date"=>$entity->invoice_date,
                "owner_companies_id"=>$entity->owner_company_id,
                "transaction_type_id"=>$transactionType->id,
                "ledger_accounts_id"=>$tradeDiscountAccount->id,
                "bank_reference_number"=>"",
                "source"=>__("Invoices"),
                "narration"=>__("Invoice {1} created and debited to {0}.", $tradeDiscountAccount->get("account_name"),$entity->get('id')),
                "entry_side"=>Configure::read("transactionEntrySide.DR"),
                "ledger_amount"=>$total_discount_amount
            ];
        }
        
       
        
        foreach ($total_taxes_list as $tax_master_id => $total_tax_amount){
            if($total_tax_amount>0){
                $taxAccount=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->LedgerAccounts->find("all")
                ->contain(['LedgerGroups']) ->where(["model_reference_name"=>'TaxMaster',"model_reference_id"=>$tax_master_id])->first();
                
                $LedgerTransactionList[]=[
                    "transaction_date"=>$entity->invoice_date,
                    "owner_companies_id"=>$entity->owner_company_id,
                    "transaction_type_id"=>$transactionType->id,
                    "ledger_accounts_id"=>$taxAccount->id,
                    "bank_reference_number"=>"",
                    "source"=>__("Invoices"),
                    "narration"=>__("Invoice {1} created and debited to {0}.", $taxAccount->get("account_name"),$entity->get('id')),
                    "entry_side"=>Configure::read("transactionEntrySide.CR"),
                    "ledger_amount"=>$total_tax_amount
                ];
            }
            
        }
        
        
        if($InvoiceLedgerTransactions!=null && count($InvoiceLedgerTransactions)>0){
            $LedgerTransactionEntities=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->find("all")
            ->where(["id"=>$InvoiceLedgerTransactions]);
            // need to re-code and re-thinking about
            $LedgerTransactionEntities=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->find("all")->where([
                "id"=>$InvoiceLedgerTransactions
            ]);
            
            $accountListWithLedgerTransactionIdList=[];
            
            foreach ($LedgerTransactionEntities as $LedgerTransaction){
                $accountListWithLedgerTransactionIdList[$LedgerTransaction->ledger_accounts_id]=$LedgerTransaction->id;
            };
            
            foreach ($LedgerTransactionList as &$transaction_data){
                $accountId=$transaction_data["ledger_accounts_id"];
                if(isset($accountListWithLedgerTransactionIdList[$accountId])){
                    $transaction_data["id"]=$accountListWithLedgerTransactionIdList[$accountId];
                }
            }
            
            $LedgerTransactionEntities=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->patchEntities($LedgerTransactionEntities, $LedgerTransactionList);
            
        }else{
            foreach ($LedgerTransactionList as &$transaction_data){
                $transaction_data["transaction_id"]=$transaction_no;
            }
            $LedgerTransactionEntities=$invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->newEntities($LedgerTransactionList);
        }
        
        
        // Steps 3: Saving invoice_ledger_transaction
        $InvoiceLedgerTransactionsModel=$invoicesTable->InvoiceLedgerTransactions;
        
        return $invoicesTable->InvoiceLedgerTransactions->LedgerTransactions->saveTransactions($LedgerTransactionEntities,function($result) use($InvoiceLedgerTransactionsModel,$InvoiceLedgerTransactions,$entity){
            if($InvoiceLedgerTransactions==null || count($InvoiceLedgerTransactions)==0){
                Log::info($result->get("id"));
                return $InvoiceLedgerTransactionsModel->save($InvoiceLedgerTransactionsModel->newEntity([
                    "invoice_id"=>$entity->get("id"),
                    "ledger_transactions_id"=>$result->get("id")
                ]));
            }else{
                return true;
            }
            throw new  NotFoundException("Unable to save");
        });
    }
    
}