<?php
namespace App\Event;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\Event\EventListenerInterface;
use App\Model\Entity\Notifications;
use App\Model\Table\NotificationsTable;
use App\Model\Entity\NotificationMaster;
use App\Model\Table\NotificationMasterTable;
use Cake\ORM\TableRegistry;
use Cake\Event\EventManager;
use Cake\Controller\Component\AuthComponent;
use Cake\Controller\ComponentRegistry;
/**
 * @author Admin
 *
 */
class NotificationListener implements EventListenerInterface {

	public function implementedEvents() {
		return array(
				'Model.Inquiry.saved' => 'NotificationsForInquiry',
		        'Model.OfficeInward.saved' => 'NotificationsForOfficeInward',
				'Model.Order.save' => 'NotificationsForOrder',
				
				'Model.OrderAcceptance.save' => 'NotificationsForOrderAcceptance',
				
		);
	}

	
	/**
	 * @param Cake\Event\Event $event
	 * @param unknown $post
	 */
	public function NotificationsForInquiry(Event $event,  $inqurydata) {
		

 		if(!in_array($inqurydata->send_to_offer, ['FES','YES','DON']) ){
 			$userid=$inqurydata->created_by;
 			$notificationmaster=TableRegistry::get("NotificationMaster");
 			$notifications= $notificationmaster->find()->where(['notification_from' => 'Inquiry','user_id'=>$userid])->first();
 			
 			$notificationdata=array(
 					
 					'notification_master_id' => $notifications->id,
 					'subject' => 'Inquiry Recieved',
 					'message' => 'You have new Inquiries please check out',
 					'msg_date' => date('Y-m-d'),
 					'controller' => 'Inquiry',
 					'action'=>'Index',
 					'status'=>1,
 					'notification_by'=>'Inquiry',
 					'transaction_id'=>$inqurydata->id
 					
 			);
 			
			$notification=TableRegistry::get("Notifications");
			//debug($notification);
			$previous= $notification
			->find()
			->where(['transaction_id' => $inqurydata->id,'notification_by'=>'Inquiry'])
			->first();
			
			
			if(!empty( $previous)){
				
			}
			
			else{
				$note = $notification->newEntity();
				$note= $notification->patchEntity($note, $notificationdata);
				$notification->save($note);
				
			}
		}
	}
	
	
	
	
	public function NotificationsForOrder(Event $event,  $orderdata) {
		
		
		if(!in_array($orderdata->review_status, ['SENT']) ){
			$userid=$orderdata->created_by;
			$notificationmaster=TableRegistry::get("NotificationMaster");
			$notifications= $notificationmaster->find("all")->where(['notification_from' => 'Order','user_id'=>$userid])->first();
			if(!isset($notifications)){
			    $users=TableRegistry::get('Users');
			    $userData=$users->find("all")->where(['id'=>$userid])->first();
			    $data=[
			        'subject'=>'Order Recieved',
			        "notification_from"=>'Order',
			        "message"=>'Testing',
			        'user_id'=>$userid,
			        'group_id'=>$userData->get('group_id')
			    ];
			    $notiEnt=$notificationmaster->newEntity($data);
			    $notificationmaster->save($notiEnt);
			    $notifications=$notiEnt;
			}
			
// 			pr($notifications);exit();
			
			$notificationdata=array(
					
					'notification_master_id' => $notifications->id,
					'subject' => 'Order Recieved',
					'message' => 'You have new Orders please check out',
					'msg_date' => date('Y-m-d'),
					'controller' => 'Order',
					'action'=>'Index',
					'status'=>1,
					'notification_by'=>'Order',
					'transaction_id'=>$orderdata->id
					
			);
			
			$notification=TableRegistry::get("Notifications");
			//debug($notification);
			$previous= $notification
			->find()
			->where(['transaction_id' => $orderdata->id,'notification_by'=>'Order'])
			->first();
			
			
			if(!empty( $previous)){
				
			}
			
			else{
				$note = $notification->newEntity();
				$note= $notification->patchEntity($note, $notificationdata);
				$notification->save($note);
				
			}
		}
	}

	
	public function NotificationsForOrderAcceptance(Event $event,  $orderdata) {
		
		
		if(!in_array($orderdata->send_to_demandqueue, ['Y']) ){
			$userid=$orderdata->created_by;
			$notificationmaster=TableRegistry::get("NotificationMaster");
			$notifications= $notificationmaster->find()->where(['notification_from' => 'OrderAcceptance','user_id'=>$userid])->first();
			if(!isset($notifications)){
			    $users=TableRegistry::get('Users');
			    $userData=$users->find("all")->where(['id'=>$userid])->first();
			    $data=[
			        'subject'=>'Order Acceptance Recieved',
			        "notification_from"=>'OrderAcceptance',
			        "message"=>'Testing',
			        'user_id'=>$userid,
			        'group_id'=>$userData->get('group_id')
			    ];
			    $notiEnt=$notificationmaster->newEntity($data);
			    $notificationmaster->save($notiEnt);
			    $notifications=$notiEnt;
			}
			
			$notificationdata=array(
					
					'notification_master_id' => $notifications->id,
					'subject' => 'Order Acceptance Recieved',
					'message' => 'You have new Orders please check out',
					'msg_date' => date('Y-m-d'),
					'controller' => 'OrderAcceptance',
					'action'=>'Index',
					'status'=>1,
					'notification_by'=>'OrderAcceptance',
					'transaction_id'=>$orderdata->id
					
			);
			
			$notification=TableRegistry::get("Notifications");
			//debug($notification);
			$previous= $notification
			->find()
			->where(['transaction_id' => $orderdata->id,'notification_by'=>'OrderAcceptance'])
			->first();
			
			
			if(!empty( $previous)){
				
			}
			
			else{
				$note = $notification->newEntity();
				$note= $notification->patchEntity($note, $notificationdata);
				$notification->save($note);
				
			}
		}
	}
	
	
	
	public function NotificationsForOfficeInward(Event $event,  $officeinwarddata) {
	    
	        $userid=$officeinwarddata->document_for;
	       
	        $notificationmaster=TableRegistry::get("NotificationMaster");
	        $notifications= $notificationmaster->find()->where(['notification_from' => 'OfficeInward','user_id'=>$userid])->first();
	       
	        $notificationdata=array(
	            
	            'notification_master_id' => $notifications->id,
	            'user_id'=>$userid,
	            'subject' => 'Office Inward Recieved',
	            'message' => 'You have new Office Inward please check out',
	            'msg_date' => date('Y-m-d'),
	            'controller' => 'OfficeInward',
	            'action'=>'Index',
	            'status'=>1,
	            'notification_by'=>'OfficeInward',
	            'transaction_id'=>$officeinwarddata->id
	            
	        );
	        
	        $notification=TableRegistry::get("Notifications");
	       // debug($notificationdata);exit();
	        $previous= $notification
	        ->find()
	        ->where(['transaction_id' => $officeinwarddata->id,'notification_by'=>'MyPage'])
	        ->first();
	        
	        
	        if(!empty( $previous)){
	            
	        }
	        
	        else{
	            $note = $notification->newEntity();
	            $note= $notification->patchEntity($note, $notificationdata);
	            $notification->save($note);
	            
	        }
	    
	}
	
	
}