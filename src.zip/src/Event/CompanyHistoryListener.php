<?php
namespace App\Event;
use Cake\Event\Event;
use Cake\Log\Log;
use Cake\Event\EventListenerInterface;
use App\Model\Entity\CompanyHistory;
use App\Model\Table\CompanyHistoryTable;
use Cake\ORM\TableRegistry;
use Cake\Event\EventManager;
/**
 * @author Admin
 *
 */
class CompanyHistoryListener implements EventListenerInterface {

	public function implementedEvents() {
		return array(
				'Model.Inquiry.saved' => 'updateCompanyHistoryForInquiry',
				'Model.Offer.add' => 'updateCompanyHistoryForOffer',
				'Model.Order.save' => 'updateCompanyHistoryForOrder',
		);
	}

	
	/**
	 * @param Cake\Event\Event $event
	 * @param unknown $post
	 */
	public function updateCompanyHistoryForInquiry(Event $event,  $inqurydata) {
		
		
// 		echo "<pre>";
// 		print_r($inqurydata);exit;
		
 		$currentyear= date("Y"); 
 		if(!in_array($inqurydata->send_to_offer, ['FES','YES','DON']) ){
	 		$avgrate=$inqurydata->qty_required * $inqurydata->rate;
			$companydata=array(
					'owner_company_id'=>$inqurydata->owner_companies_id,
					'company_id' => $inqurydata->company_master_id,
					'product_id' => $inqurydata->products_master_id,
					'inquiry_qty' => $inqurydata->qty_required,
					'currency' => $inqurydata->currency_id,
					'inquiry_rate' => $avgrate,
					'uom_id' => $inqurydata->uom_id,
					'financial_year'=>$currentyear,
					'buy_or_sell'=>'Sale',
					'is_local'=>$inqurydata->local_offer,
					
			);
			
			$companyHistory=TableRegistry::get("CompanyHistory");
			$previous= $companyHistory->find()->where(['owner_company_id' => $inqurydata->owner_companies_id,'company_id'=>$inqurydata->company_master_id,'product_id'=>$inqurydata->products_master_id,'financial_year'=>$currentyear,'is_local'=>$inqurydata->local_offer])->first();
			
			
			if(!empty( $previous ) )
			{
				
				
				$currentyears= date("Y");
				$avgrate=($inqurydata->qty_required * $inqurydata->rate)+ $previous->inquiry_rate;
				
				$totavgrate=$avgrate / ($inqurydata->qty_required + $previous->inquiry_qty);
				$totalqty=$inqurydata->qty_required + $previous->inquiry_qty;
				
				$companydatas=array(
						'owner_company_id'=>$inqurydata->owner_companies_id,
						'company_id' => $inqurydata->company_master_id,
						'product_id' => $inqurydata->products_master_id,
						'inquiry_qty' => $totalqty,
						'currency' => $inqurydata->currency_id,
						'inquiry_rate' => $totavgrate,
						'uom_id' => $inqurydata->uom_id,
						'financial_year'=>$currentyears,
						'buy_or_sell'=>'Sale',
						'is_local'=>$inqurydata->local_offer,
						
				);
				
				
				$company= $companyHistory->patchEntity($previous,$companydatas);
				$companyHistory->save($company);
			}else{
				$company = $companyHistory->newEntity();
				$company= $companyHistory->patchEntity($company, $companydata);
				$companyHistory->save($company);
				
			}
 		}
			
		

	}
	
	public function updateCompanyHistoryForOffer(Event $event,  $offerdata) {
		
// 		echo "<pre>";
// 		print_r($offerdata);exit;
		if(!in_array($offerdata->send_to_submit, ['YES']) ){
		$currentyear= date("Y");
		$avgrate=$offerdata->qty_offered * $offerdata->offer_price;
		$companydata=array(
				'owner_company_id'=>$offerdata->owner_companies_id,
				'company_id' => $offerdata->company_master_id,
				'product_id' => $offerdata->products_master_id,
				'offer_qty' => $offerdata->qty_offered,
				'currency' => $offerdata->currency_id,
				'offer_rate' => $avgrate,
				'uom_id' => $offerdata->uom_id,
				'financial_year'=>$currentyear,
				'buy_or_sell'=>'Sale',
				'is_local'=>$offerdata->local_offer,
				
		);
		
		$companyHistory=TableRegistry::get("CompanyHistory");
		$previous= $companyHistory->find()->where(['owner_company_id' => $offerdata->owner_companies_id,'company_id'=>$offerdata->company_master_id,'product_id'=>$offerdata->products_master_id,'financial_year'=>$currentyear,'is_local'=>$offerdata->local_offer])->first();
		
		
		if(!empty( $previous ) )
		{
			
			
			$currentyears= date("Y");
			$avgrate=($offerdata->qty_offered * $offerdata->offer_price)+ $previous->offer_rate;
			
			$totavgrate=$avgrate / ($offerdata->qty_offered + $previous->offer_qty);
			$totalqty=$offerdata->qty_offered + $previous->offer_qty;
			
			$companydatas=array(
					'owner_company_id'=>$offerdata->owner_companies_id,
					'company_id' => $offerdata->company_master_id,
					'product_id' => $offerdata->products_master_id,
					'offer_qty' => $totalqty,
					'currency' => $offerdata->currency_id,
					'offer_rate' => $totavgrate,
					'uom_id' => $offerdata->uom_id,
					'financial_year'=>$currentyears,
					'buy_or_sell'=>'Sale',
					'is_local'=>$offerdata->local_offer,
					
			);
			
			
			$company= $companyHistory->patchEntity($previous,$companydatas);
			$companyHistory->save($company);
		}else{
			$company = $companyHistory->newEntity();
			$company= $companyHistory->patchEntity($company, $companydata);
			$companyHistory->save($company);
			
		}
		
		
		}
		
	}
	
	
	
	public function updateCompanyHistoryForOrder(Event $event,  $orderdata) {
		
		
// 		echo "<pre>";
// 		print_r($orderdata);exit;
		
		
		
		$currentyear= date("Y");
		$avgrate=$orderdata->quantity_ordered * $orderdata->rate;
		$companydata=array(
				'owner_company_id'=>$orderdata->owner_companies_id,
				'company_id' => $orderdata->buyer_company,
				'product_id' => $orderdata->products_master_id,
				'order_qty' => $orderdata->quantity_ordered,
				'currency' => $orderdata->currency_id,
				'order_rate' => $avgrate,
				'uom_id' => $orderdata->uom_id,
				'financial_year'=>$currentyear,
				'buy_or_sell'=>'Sale',
				'is_local'=>$orderdata->is_local,
				
		);
				
		$companyHistory=TableRegistry::get("CompanyHistory");
		$previous= $companyHistory->find()->where(['owner_company_id' => $orderdata->owner_companies_id,'company_id'=>$orderdata->buyer_company,'product_id'=>$orderdata->products_master_id,'financial_year'=>$currentyear,'is_local'=>$orderdata->is_local])->first();
		
		
		if(!empty( $previous ) )
		{
			
			
			$currentyears= date("Y");
			$avgrate=($orderdata->quantity_ordered* $orderdata->rate)+ $previous->order_rate;
			
			$totavgrate=$avgrate / ($orderdata->quantity_ordered + $previous->order_qty);
			$totalqty=$orderdata->quantity_ordered + $previous->order_qty;
			
			$companydatas=array(
					'owner_company_id'=>$orderdata->owner_companies_id,
					'company_id' => $orderdata->buyer_company,
					'product_id' => $orderdata->products_master_id,
					'order_qty' => $totalqty,
					'currency' => $orderdata->currency_id,
					'order_rate' => $totavgrate,
					'uom_id' => $orderdata->uom_id,
					'financial_year'=>$currentyears,
					'buy_or_sell'=>'Sale',
					'is_local'=>$orderdata->is_local,
					
			);
			
			
			$company= $companyHistory->patchEntity($previous,$companydatas);
			$companyHistory->save($company);
		}else{
			$company = $companyHistory->newEntity();
			$company= $companyHistory->patchEntity($company, $companydata);
			$companyHistory->save($company);
			
		}
		
		
		
		
	}
	
	
	
	
	
	
}